package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import kotlinx.coroutines.delay
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.R
import com.biometric.app.api.MobileApiService
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentMoneyListBinding
import com.biometric.app.sync.SignalRManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class SalaryAdvancesFragment : Fragment() {

    private var _binding: FragmentMoneyListBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore
    @Inject lateinit var signalR: SignalRManager

    private lateinit var adapter: MoneyAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMoneyListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.tvSummaryLabel.text = "TOTAL ADVANCES"
        binding.tvSubLabel.text = "Cumulative advances for current year"
        binding.fabAction.visibility = View.VISIBLE
        binding.fabAction.text = "Request Advance"
        
        setupRecyclerView()
        loadAdvances()
        setupRealTimeSync()
        
        binding.fabAction.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.container, ApplyAdvanceFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun setupRecyclerView() {
        adapter = MoneyAdapter(isBonus = false)
        binding.rvList.layoutManager = LinearLayoutManager(requireContext())
        binding.rvList.adapter = adapter
    }

    private fun loadAdvances() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.advances("Bearer $token")
                if (response.isSuccessful) {
                    val advances = response.body() ?: emptyList()
                    adapter.submitList(advances)
                    
                    val total = advances.sumOf { it.amount }
                    binding.tvTotalAmount.text = String.format(Locale.US, "₹ %,.2f", total)
                    
                    if (advances.isEmpty()) {
                        binding.tvEmpty.visibility = View.VISIBLE
                    } else {
                        binding.tvEmpty.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                // Best User Experience: Silent auto-retry in background
                Log.e("Advances", "Load failed: ${e.message}")
                delay(5000)
                loadAdvances()
            }
        }
    }

    private fun setupRealTimeSync() {
        lifecycleScope.launch {
            signalR.dataChangeEvents.collect { event ->
                Log.d("AdvancesFragment", "Real-time refresh: $event")
                loadAdvances()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
