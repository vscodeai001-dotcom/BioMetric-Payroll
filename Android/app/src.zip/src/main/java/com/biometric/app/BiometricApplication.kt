package com.biometric.app

import android.app.Application
import android.util.Log
import androidx.work.Configuration
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.biometric.app.backup.BackupWorker
import com.google.firebase.database.FirebaseDatabase
import com.biometric.app.domain.location.LocationSyncManager
import com.biometric.app.domain.location.OfflineSyncWorker
import com.biometric.app.domain.location.TrackingRecoveryWorker
import com.biometric.app.sync.DashboardWarmingWorker
import com.biometric.app.sync.NeonSyncWorker
import com.biometric.app.util.ThemeManager
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class BiometricApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var locationSyncManager: LocationSyncManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        super.onCreate()
        
        try {
            FirebaseDatabase.getInstance().setPersistenceEnabled(true)
            FirebaseDatabase.getInstance().setPersistenceCacheSizeBytes(100 * 1024 * 1024)
        } catch (_: Exception) { }

        // OsmDroid Configuration
        org.osmdroid.config.Configuration.getInstance().load(this, getSharedPreferences("osmdroid", MODE_PRIVATE))
        org.osmdroid.config.Configuration.getInstance().userAgentValue = "BioMetricPayroll_Android_" + packageName

        ThemeManager.applyTheme(this)
        
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(2, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "automated_business_backup_periodic",
            ExistingPeriodicWorkPolicy.REPLACE,
            backupRequest
        )

        locationSyncManager.schedulePeriodicSync()

        val neonSyncRequest = PeriodicWorkRequestBuilder<NeonSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "neon_db_sync_periodic",
            ExistingPeriodicWorkPolicy.KEEP,
            neonSyncRequest
        )

        // Aggressive background tracking recovery
        TrackingRecoveryWorker.schedule(this)
        
        // Offline location synchronization
        OfflineSyncWorker.schedule(this)

        // Dashboard data warming (UX: Zero-lag loading)
        DashboardWarmingWorker.schedule(this)
    }
}
