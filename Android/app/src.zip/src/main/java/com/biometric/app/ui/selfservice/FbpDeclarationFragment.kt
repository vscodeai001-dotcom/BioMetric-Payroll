package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import kotlinx.coroutines.delay
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.biometric.app.api.MobileApiService
import com.biometric.app.api.FbpRequest
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentFbpDeclarationBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class FbpDeclarationFragment : Fragment() {

    private var _binding: FragmentFbpDeclarationBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentFbpDeclarationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadFbpData()

        binding.btnSave.setOnClickListener {
            saveFbpData()
        }
    }

    private fun loadFbpData() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.fbp("Bearer $token", 2024)
                if (response.isSuccessful) {
                    val data = response.body() ?: emptyList()
                    // Just show the first one for simplicity in this demo
                    if (data.isNotEmpty()) {
                        binding.etComponent.setText(data[0].componentName)
                        binding.etAmount.setText(data[0].annualAllocatedAmount.toString())
                    }
                }
            } catch (e: Exception) {
                // Best User Experience: Silent auto-retry in background
                Log.e("FBP", "Load failed: ${e.message}")
                delay(5000)
                loadFbpData()
            }
        }
    }

    private fun saveFbpData() {
        val token = sessionStore.token() ?: return
        val request = FbpRequest(
            financialYear = 2024,
            componentName = binding.etComponent.text.toString(),
            annualAllocatedAmount = binding.etAmount.text.toString().toDoubleOrNull() ?: 0.0
        )

        lifecycleScope.launch {
            try {
                val response = mobileApi.saveFbp("Bearer $token", request)
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "FBP declaration saved! ✅", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(requireContext(), "Failed to save FBP", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
