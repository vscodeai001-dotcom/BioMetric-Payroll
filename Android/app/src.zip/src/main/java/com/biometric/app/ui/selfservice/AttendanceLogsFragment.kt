package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.R
import com.biometric.app.api.AttendanceDayDto
import com.biometric.app.api.MobileApiService
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.DialogAttendanceDayDetailsBinding
import com.biometric.app.databinding.FragmentMyAttendanceBinding
import com.biometric.app.sync.SignalRManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class AttendanceLogsFragment : Fragment() {

    private var _binding: FragmentMyAttendanceBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore
    @Inject lateinit var signalR: SignalRManager

    private lateinit var adapter: AttendanceAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMyAttendanceBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        loadAttendance()
        setupRealTimeSync()
    }

    private fun setupRealTimeSync() {
        lifecycleScope.launch {
            signalR.dataChangeEvents.collect { event ->
                Log.d("AttendanceLogs", "Real-time refresh: $event")
                loadAttendance()
            }
        }
    }

    private fun setupRecyclerView() {
        adapter = AttendanceAdapter { day ->
            showDayDetails(day)
        }
        binding.rvAttendance.layoutManager = LinearLayoutManager(requireContext())
        binding.rvAttendance.adapter = adapter
    }

    private fun showDayDetails(day: AttendanceDayDto) {
        val dialogBinding = DialogAttendanceDayDetailsBinding.inflate(layoutInflater)
        
        dialogBinding.tvDialogDate.text = "Punches for ${day.date}"
        
        if (day.punches.isEmpty()) {
            dialogBinding.tvNoPunches.visibility = View.VISIBLE
            dialogBinding.svPunches.visibility = View.GONE
        } else {
            day.punches.forEach { punch ->
                val tv = TextView(requireContext()).apply {
                    text = "${punch.type}: ${punch.time} (${punch.source})"
                    setPadding(16, 16, 16, 16)
                    textSize = 14f
                    setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                }
                dialogBinding.llPunchesContainer.addView(tv)
                
                // Add a divider
                val divider = View(requireContext()).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 1)
                    setBackgroundColor(ContextCompat.getColor(context, R.color.divider))
                }
                dialogBinding.llPunchesContainer.addView(divider)
            }
        }

        MaterialAlertDialogBuilder(requireContext())
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun loadAttendance() {
        val token = sessionStore.token() ?: return
        val sdf = SimpleDateFormat("yyyy-MM-01", Locale.US)
        val fromDate = sdf.format(Date())
        val toDate = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
        
        val monthName = SimpleDateFormat("MMM yyyy", Locale.US).format(Date())
        binding.tvSummaryTitle.text = "Cumulative Summary ($monthName) 📊"

        lifecycleScope.launch {
            try {
                val response = mobileApi.attendance("Bearer $token", fromDate, toDate)
                if (response.isSuccessful) {
                    val logs = response.body() ?: emptyList()
                    adapter.submitList(logs)
                    updateSummary(logs)
                    
                    if (logs.isEmpty()) {
                        // Optional: show a small info text if needed, 
                        // but no Toast as per "Best UX" requirement.
                        Log.i("AttendanceLogs", "No logs found for this period.")
                    }
                } else {
                    Log.e("AttendanceLogs", "Server error: ${response.code()}")
                }
            } catch (e: Exception) {
                // Requirement: Best User Experience, no annoying toasts on background failure
                Log.e("AttendanceLogs", "Load failed: ${e.message}")
            }
        }
    }

    private fun updateSummary(logs: List<AttendanceDayDto>) {
        var totalScheduledSec = 0L
        var totalWorkedSec = 0L
        var totalPenaltySec = 0L
        var totalOtSec = 0L
        
        logs.forEach { 
            totalScheduledSec += (it.scheduledHours * 3600).toLong()
            totalWorkedSec += (it.workedHours * 3600).toLong()
            totalPenaltySec += parseDurationToSeconds(it.penalty)
            totalOtSec += parseDurationToSeconds(it.overtime)
        }
        
        binding.tvTotalScheduled.text = formatDurationFromSeconds(totalScheduledSec)
        binding.tvTotalWorked.text = formatDurationFromSeconds(totalWorkedSec)
        binding.tvTotalPenalty.text = formatDurationFromSeconds(totalPenaltySec)
        binding.tvTotalOt.text = formatDurationFromSeconds(totalOtSec)
    }

    private fun parseDurationToSeconds(duration: String?): Long {
        if (duration.isNullOrBlank()) return 0L
        return try {
            val parts = duration.split(":")
            if (parts.size == 3) {
                parts[0].toLong() * 3600 + parts[1].toLong() * 60 + parts[2].toLong()
            } else if (parts.size == 2) {
                parts[0].toLong() * 60 + parts[1].toLong()
            } else 0L
        } catch (_: Exception) { 0L }
    }

    private fun formatDurationFromSeconds(totalSeconds: Long): String {
        val h = totalSeconds / 3600
        val m = (totalSeconds % 3600) / 60
        return String.format(Locale.US, "%02d:%02d", h, m)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
