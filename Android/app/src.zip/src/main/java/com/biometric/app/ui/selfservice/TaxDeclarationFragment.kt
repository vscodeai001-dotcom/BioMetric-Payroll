package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import kotlinx.coroutines.delay
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.biometric.app.api.MobileApiService
import com.biometric.app.api.TaxDeclarationRequest
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentTaxDeclarationBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class TaxDeclarationFragment : Fragment() {

    private var _binding: FragmentTaxDeclarationBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentTaxDeclarationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadTaxData()

        binding.btnSave.setOnClickListener {
            saveTaxData()
        }
    }

    private fun loadTaxData() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.tax("Bearer $token", 2024)
                if (response.isSuccessful) {
                    response.body()?.let { data ->
                        binding.et80C.setText(data.section80C.toString())
                        binding.et80D.setText(data.section80D.toString())
                        binding.etHra.setText(data.hraRentPaid.toString())
                        binding.etOther.setText(data.otherExemptions.toString())
                    }
                }
            } catch (e: Exception) {
                // Best User Experience: Silent auto-retry in background
                Log.e("Tax", "Load failed: ${e.message}")
                delay(5000)
                loadTaxData()
            }
        }
    }

    private fun saveTaxData() {
        val token = sessionStore.token() ?: return
        val request = TaxDeclarationRequest(
            financialYear = 2024,
            regime = "New",
            section80C = binding.et80C.text.toString().toDoubleOrNull() ?: 0.0,
            section80D = binding.et80D.text.toString().toDoubleOrNull() ?: 0.0,
            hraRentPaid = binding.etHra.text.toString().toDoubleOrNull() ?: 0.0,
            otherExemptions = binding.etOther.text.toString().toDoubleOrNull() ?: 0.0
        )

        lifecycleScope.launch {
            try {
                val response = mobileApi.saveTax("Bearer $token", request)
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "Tax declaration saved! ✅", Toast.LENGTH_SHORT).show()
                }
            } catch (_: Exception) {
                Toast.makeText(requireContext(), "Failed to save declaration", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
