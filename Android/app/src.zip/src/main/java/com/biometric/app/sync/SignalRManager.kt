package com.biometric.app.sync

import android.util.Log
import com.biometric.app.data.MobileSessionStore
import com.google.gson.Gson
import com.google.gson.annotations.SerializedName
import com.microsoft.signalr.HubConnection
import com.microsoft.signalr.HubConnectionBuilder
import com.microsoft.signalr.HubConnectionState
import io.reactivex.rxjava3.core.Single
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class SignalRManager @Inject constructor(
    private val sessionStore: MobileSessionStore
) {
    private var hubConnection: HubConnection? = null
    private val managerScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    
    private val _dataChangeEvents = MutableSharedFlow<SyncEvent>(extraBufferCapacity = 10)
    val dataChangeEvents = _dataChangeEvents.asSharedFlow()

    private val _liveLocations = MutableStateFlow<Map<Int, LiveLocation>>(emptyMap())
    val liveLocations = _liveLocations.asStateFlow()

    private val hubUrl = "https://biometric-payroll.onrender.com/hubs/attendance-refresh"

    @Synchronized
    fun start() {
        if (!sessionStore.isLoggedIn()) return
        
        if (hubConnection != null) {
             if (hubConnection?.connectionState == HubConnectionState.DISCONNECTED) {
                 connect()
             }
             return
        }

        managerScope.launch {
            try {
                hubConnection = HubConnectionBuilder.create(hubUrl)
                    .withAccessTokenProvider(Single.fromCallable { sessionStore.token() ?: "" })
                    .build()

                setupListeners()
                connect()
            } catch (e: Exception) {
                Log.e("SignalR", "Failed to build HubConnection", e)
            }
        }
    }

    private fun setupListeners() {
        val hub = hubConnection ?: return

        hub.on("LocationChanged", { data ->
            managerScope.launch {
                Log.d("SignalR", "LocationChanged received: $data")
                try {
                    val json = Gson().toJson(data)
                    val update = Gson().fromJson(json, LiveLocation::class.java)
                    if (update != null && update.employeeId > 0) {
                        val current = _liveLocations.value.toMutableMap()
                        current[update.employeeId] = update
                        _liveLocations.value = current
                        _dataChangeEvents.emit(SyncEvent.LocationChanged)
                    }
                } catch (e: Exception) {
                    Log.e("SignalR", "Failed to parse LocationChanged", e)
                }
            }
        }, Any::class.java)

        hub.on("DataChanged", { _ ->
            Log.d("SignalR", "DataChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.DataChanged) }
        }, Any::class.java)

        hub.on("AttendanceChanged", { _ ->
            Log.d("SignalR", "AttendanceChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.AttendanceChanged) }
        }, Any::class.java)

        hub.on("PunchChanged", { _ ->
            Log.d("SignalR", "PunchChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.PunchChanged) }
        }, Any::class.java)

        hub.on("LeaveChanged", { _ ->
            Log.d("SignalR", "LeaveChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.LeaveChanged) }
        }, Any::class.java)

        hub.on("AdvanceChanged", { _ ->
            Log.d("SignalR", "AdvanceChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.AdvanceChanged) }
        }, Any::class.java)

        hub.on("EmployeeChanged", { _ ->
            Log.d("SignalR", "EmployeeChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.EmployeeChanged) }
        }, Any::class.java)

        hub.on("SessionEnded", { data ->
            Log.d("SignalR", "SessionEnded received: $data")
            try {
                val json = Gson().toJson(data)
                val event = Gson().fromJson(json, SessionEndedEvent::class.java)
                
                managerScope.launch { 
                    _dataChangeEvents.emit(SyncEvent.SessionEnded(event?.employeeId ?: 0, event?.sessionId ?: "")) 
                }
            } catch (e: Exception) {
                Log.e("SignalR", "Failed to parse SessionEnded", e)
                managerScope.launch { _dataChangeEvents.emit(SyncEvent.SessionEnded(0, "")) }
            }
        }, Any::class.java)

        hub.on("GlobalRefresh", { _ ->
            Log.d("SignalR", "GlobalRefresh received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.GlobalRefresh) }
        }, Any::class.java)

        hub.on("ApplicationDataChanged", { _ ->
            Log.d("SignalR", "ApplicationDataChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.ApplicationDataChanged) }
        }, Any::class.java)

        hub.on("RegularizationChanged", { _ ->
            Log.d("SignalR", "RegularizationChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.RegularizationChanged) }
        }, Any::class.java)

        hub.on("ExitChanged", { _ ->
            Log.d("SignalR", "ExitChanged received")
            managerScope.launch { _dataChangeEvents.emit(SyncEvent.ExitChanged) }
        }, Any::class.java)

        hub.on("SessionStarted", { data ->
            Log.d("SignalR", "SessionStarted received: $data")
            managerScope.launch { 
                try {
                    val json = Gson().toJson(data)
                    val event = Gson().fromJson(json, SessionStartedEvent::class.java)
                    if (event != null) {
                        _dataChangeEvents.emit(SyncEvent.SessionStarted(event.employeeId, event.sessionId))
                    }
                } catch (e: Exception) {
                    Log.e("SignalR", "Failed to parse SessionStarted", e)
                }
            }
        }, Any::class.java)

        hub.onClosed { exception ->
            Log.w("SignalR", "Connection closed. Retrying in 5s...", exception)
            managerScope.launch {
                delay(5000)
                connect()
            }
        }
    }

    private fun connect() {
        managerScope.launch {
            try {
                hubConnection?.start()?.blockingAwait()
                Log.i("SignalR", "Successfully connected to Real-Time Hub ✅")
            } catch (e: Exception) {
                Log.e("SignalR", "Failed to connect to Hub: ${e.message}")
                delay(10000)
                connect()
            }
        }
    }

    fun stop() {
        hubConnection?.stop()
        hubConnection = null
    }

    data class SessionEndedEvent(
        @SerializedName("EmployeeId") val employeeId: Int,
        @SerializedName("SessionId") val sessionId: String?
    )

    sealed class SyncEvent {
        object DataChanged : SyncEvent()
        object AttendanceChanged : SyncEvent()
        object PunchChanged : SyncEvent()
        object LocationChanged : SyncEvent()
        object LeaveChanged : SyncEvent()
        object AdvanceChanged : SyncEvent()
        object EmployeeChanged : SyncEvent()
        object GlobalRefresh : SyncEvent()
        object ApplicationDataChanged : SyncEvent()
        object RegularizationChanged : SyncEvent()
        object ExitChanged : SyncEvent()
        data class SessionStarted(val employeeId: Int, val sessionId: String) : SyncEvent()
        data class SessionEnded(val employeeId: Int, val sessionId: String?) : SyncEvent()
    }

    data class SessionStartedEvent(
        @SerializedName("EmployeeId") val employeeId: Int,
        @SerializedName("SessionId") val sessionId: String
    )

    data class LiveLocation(
        @SerializedName("EmployeeId") val employeeId: Int,
        @SerializedName("Latitude") val latitude: Double,
        @SerializedName("Longitude") val longitude: Double,
        @SerializedName("AccuracyMeters") val accuracyMeters: Double,
        @SerializedName("DistanceMeters") val distanceMeters: Double,
        @SerializedName("AllowedRadiusMeters") val allowedRadiusMeters: Int = 100,
        @SerializedName("IsWithinAllowedRadius") val isWithinAllowedRadius: Boolean,
        @SerializedName("Timestamp") val timestamp: String? = null,
        @SerializedName("SpeedMps") val speedMps: Double = 0.0
    )
}
