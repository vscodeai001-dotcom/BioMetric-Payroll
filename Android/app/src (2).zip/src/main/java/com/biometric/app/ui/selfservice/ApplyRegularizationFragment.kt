package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.biometric.app.api.MobileApiService
import com.biometric.app.api.RegularizationCreateRequest
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentApplyRegularizationBinding
import com.google.android.material.datepicker.MaterialDatePicker
import com.google.android.material.timepicker.MaterialTimePicker
import com.google.android.material.timepicker.TimeFormat
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class ApplyRegularizationFragment : Fragment() {

    private var _binding: FragmentApplyRegularizationBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore

    private var selectedDate: Long = System.currentTimeMillis()
    private val dateSdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
    private var selectedTime = "09:00"

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentApplyRegularizationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupForm()
    }

    private fun setupForm() {
        binding.etDate.setText(dateSdf.format(Date(selectedDate)))
        binding.etDate.setOnClickListener {
            val picker = MaterialDatePicker.Builder.datePicker()
                .setTitleText("Date of Punch")
                .setSelection(selectedDate)
                .build()
            picker.addOnPositiveButtonClickListener { selection ->
                selectedDate = selection ?: selectedDate
                binding.etDate.setText(dateSdf.format(Date(selectedDate)))
            }
            picker.show(parentFragmentManager, "punch_date")
        }

        binding.etTime.setText(selectedTime)
        binding.etTime.setOnClickListener {
            val picker = MaterialTimePicker.Builder()
                .setTimeFormat(TimeFormat.CLOCK_24H)
                .setHour(9)
                .setMinute(0)
                .setTitleText("Select Punch Time")
                .build()
            picker.addOnPositiveButtonClickListener {
                selectedTime = String.format(Locale.US, "%02d:%02d", picker.hour, picker.minute)
                binding.etTime.setText(selectedTime)
            }
            picker.show(parentFragmentManager, "punch_time")
        }

        binding.btnSubmit.setOnClickListener {
            submitCorrection()
        }
    }

    private fun submitCorrection() {
        val date = binding.etDate.text.toString()
        val time = binding.etTime.text.toString()
        val isInPunch = binding.btnIn.isChecked
        val reason = binding.etReason.text.toString()

        if (reason.isBlank()) {
            Toast.makeText(requireContext(), "Please provide a reason", Toast.LENGTH_SHORT).show()
            return
        }

        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val request = RegularizationCreateRequest(date, isInPunch, time, reason)
                val response = mobileApi.createRegularization("Bearer $token", request)
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "Correction request submitted! 🛠️", Toast.LENGTH_SHORT).show()
                    parentFragmentManager.popBackStack()
                } else {
                    Toast.makeText(requireContext(), "Submission failed ❌", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Submission error ⚠️", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
