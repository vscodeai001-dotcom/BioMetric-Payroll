package com.biometric.app.ui

import android.content.Intent
import android.os.Bundle
import android.graphics.Typeface
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.card.MaterialCardView
import com.google.android.material.button.MaterialButton
import com.biometric.app.R
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class EmployeeToolsActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_employee_tools)
        findViewById<com.google.android.material.appbar.MaterialToolbar>(R.id.toolbar)
            .setNavigationOnClickListener { finish() }
        val container = findViewById<LinearLayout>(R.id.toolsContainer)
        val items = listOf(
            Triple("📊 My Attendance", "Daily punches, worked hours, OT and penalties", "attendance"),
            Triple("💳 My Payslips", "Monthly salary, deductions and net pay", "payslips"),
            Triple("🌴 Leave", "Request leave and view leave history", "leaves"),
            Triple("💰 Salary Advances", "View advance payments and deductions", "advances"),
            Triple("🎁 My Bonuses", "View bonuses and payment status", "bonuses"),
            Triple("📝 Regularization", "Submit and track punch corrections", "regularizations"),
            Triple("🚪 My Resignation", "Submit or view resignation status", "resignation"),
            Triple("🧾 Tax Declaration", "View or submit annual tax declaration", "tax"),
            Triple("✨ FBP Declaration", "View or allocate flexible benefits", "fbp"),
            Triple("🗓 Shift Schedule", "View assigned shifts by month", "shifts")
        )
        items.forEach { (title, subtitle, key) ->
            val card = MaterialCardView(this).apply {
                radius = 22f
                cardElevation = 4f
                useCompatPadding = true
                setOnClickListener { startActivity(Intent(this@EmployeeToolsActivity, EmployeeDataActivity::class.java).putExtra(EmployeeDataActivity.EXTRA_SCREEN, key)) }
            }
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(20, 18, 20, 18)
            }
            val t = TextView(this).apply { text = title; textSize = 17f; setTypeface(typeface, Typeface.BOLD) }
            val s = TextView(this).apply { text = subtitle; textSize = 13f; setTextColor(android.graphics.Color.GRAY); setPadding(0, 6, 0, 0) }
            box.addView(t); box.addView(s); card.addView(box)
            container.addView(card, LinearLayout.LayoutParams(-1, LinearLayout.LayoutParams.WRAP_CONTENT).apply { bottomMargin = 8 })
        }
    }
}
