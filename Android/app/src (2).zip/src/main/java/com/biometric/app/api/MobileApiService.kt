package com.biometric.app.api

import com.google.gson.annotations.SerializedName
import okhttp3.ResponseBody
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Header
import retrofit2.http.POST
import retrofit2.http.Path
import retrofit2.http.Query

interface MobileApiService {
    @POST("api/mobile/employee/login")
    suspend fun login(@Body request: MobileLoginRequest): Response<MobileLoginResponse>

    @GET("api/mobile/employee/me")
    suspend fun me(@Header("Authorization") authorization: String): Response<MobileLoginResponse>

    @POST("api/mobile/employee/logout")
    suspend fun logout(@Header("Authorization") authorization: String): Response<Unit>

    @POST("api/mobile/employee/gps/start")
    suspend fun startGps(
        @Header("Authorization") authorization: String,
        @Body request: GpsSessionRequest
    ): Response<GpsSessionResponse>

    @POST("api/mobile/employee/gps/update")
    suspend fun updateGps(
        @Header("Authorization") authorization: String,
        @Body request: GpsUpdateRequest
    ): Response<GpsUpdateResponse>


    @GET("api/mobile/employee/punch-status")
    suspend fun punchStatus(@Header("Authorization") authorization: String): Response<PunchStatusDto>

    @POST("api/mobile/employee/punch")
    suspend fun punch(@Header("Authorization") authorization: String, @Body request: EmployeePunchRequest): Response<PunchStatusDto>

    @GET("api/mobile/employee/dashboard")
    suspend fun dashboard(@Header("Authorization") authorization: String): Response<EmployeeDashboardResponse>

    @GET("api/mobile/employee/company-settings")
    suspend fun getCompanySettings(@Header("Authorization") authorization: String): Response<CompanySettingsResponse>

    @GET("api/mobile/employee/attendance")
    suspend fun attendance(
        @Header("Authorization") authorization: String,
        @Query("from") from: String,
        @Query("to") to: String
    ): Response<List<AttendanceDayDto>>

    @GET("api/mobile/employee/payslips")
    suspend fun payslips(@Header("Authorization") authorization: String): Response<List<PayslipDto>>

    @GET("api/mobile/employee/payslips/{id}/pdf")
    suspend fun downloadPayslipPdf(@Header("Authorization") authorization: String, @Path("id") id: Int): Response<ResponseBody>

    @GET("api/mobile/employee/leaves")
    suspend fun leaves(@Header("Authorization") authorization: String): Response<List<LeaveDto>>

    @POST("api/mobile/employee/leaves")
    suspend fun createLeave(@Header("Authorization") authorization: String, @Body request: LeaveCreateRequest): Response<LeaveDto>

    @GET("api/mobile/employee/advances")
    suspend fun advances(@Header("Authorization") authorization: String): Response<List<MoneyEntryDto>>

    @POST("api/mobile/employee/advances")
    suspend fun createAdvance(@Header("Authorization") authorization: String, @Body request: AdvanceCreateRequest): Response<MoneyEntryDto>

    @GET("api/mobile/employee/bonuses")
    suspend fun bonuses(@Header("Authorization") authorization: String): Response<List<MoneyEntryDto>>

    @GET("api/mobile/employee/regularizations")
    suspend fun regularizations(@Header("Authorization") authorization: String): Response<List<RegularizationDto>>

    @POST("api/mobile/employee/regularizations")
    suspend fun createRegularization(@Header("Authorization") authorization: String, @Body request: RegularizationCreateRequest): Response<RegularizationDto>

    @GET("api/mobile/employee/resignation")
    suspend fun resignation(@Header("Authorization") authorization: String): Response<ResignationDto?>

    @POST("api/mobile/employee/resignation")
    suspend fun createResignation(@Header("Authorization") authorization: String, @Body request: ResignationCreateRequest): Response<ResignationDto>

    @GET("api/mobile/employee/tax")
    suspend fun tax(@Header("Authorization") authorization: String, @Query("financialYear") financialYear: Int): Response<TaxDeclarationDto?>

    @POST("api/mobile/employee/tax")
    suspend fun saveTax(@Header("Authorization") authorization: String, @Body request: TaxDeclarationRequest): Response<TaxDeclarationDto>

    @GET("api/mobile/employee/fbp")
    suspend fun fbp(@Header("Authorization") authorization: String, @Query("financialYear") financialYear: Int): Response<List<FbpDto>>

    @POST("api/mobile/employee/fbp")
    suspend fun saveFbp(@Header("Authorization") authorization: String, @Body request: FbpRequest): Response<FbpDto>

    @GET("api/mobile/employee/shifts")
    suspend fun shifts(@Header("Authorization") authorization: String, @Query("month") month: String): Response<List<ShiftDto>>

    @POST("api/mobile/employee/gps/end")
    suspend fun endGps(
        @Header("Authorization") authorization: String,
        @Body request: GpsSessionRequest
    ): Response<Unit>
}

data class MobileLoginRequest(
    @SerializedName("Email") val email: String,
    @SerializedName("Password") val password: String,
    @SerializedName("DeviceId") val deviceId: String,
    @SerializedName("EmployeeId") val employeeId: String = "",
    @SerializedName("ForceReplace") val forceReplace: Boolean = false
)

data class MobileLoginResponse(
    @SerializedName("success") val success: Boolean = false,
    @SerializedName("token") val token: String? = null,
    @SerializedName("message") val message: String? = null,
    @SerializedName("employeeId") val employeeId: Int = 0,
    @SerializedName("name") val name: String = "",
    @SerializedName("email") val email: String = "",
    @SerializedName("role") val role: String? = null,
    @SerializedName("monthlySalary") val monthlySalary: Double = 0.0,
    @SerializedName("paidLeaveBalance") val paidLeaveBalance: Double = 0.0,
    @SerializedName("sickLeaveBalance") val sickLeaveBalance: Double = 0.0
)

data class GpsSessionRequest(val sessionId: String)

data class GpsSessionResponse(
    val success: Boolean = false,
    val sessionId: String? = null
)

data class GpsUpdateRequest(
    val sessionId: String,
    val latitude: Double,
    val longitude: Double,
    val accuracy: Double,
    val speed: Double,
    val timestamp: Long,
    val batteryLevel: Int
)

data class GpsUpdateResponse(
    val success: Boolean = false,
    val employeeId: Int = 0,
    val distanceMeters: Double = 0.0,
    val allowedRadiusMeters: Int = 0,
    val isWithinAllowedRadius: Boolean = false,
    val timestamp: String? = null
)
