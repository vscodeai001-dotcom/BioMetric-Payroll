package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.R
import com.biometric.app.api.MobileApiService
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentMyRegularizationBinding
import com.biometric.app.sync.SignalRManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class RegularizationFragment : Fragment() {

    private var _binding: FragmentMyRegularizationBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore
    @Inject lateinit var signalR: SignalRManager

    private lateinit var adapter: RegularizationAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMyRegularizationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        loadRegularizations()
        setupRealTimeSync()

        binding.fabNewRequest.setOnClickListener {
            parentFragmentManager.beginTransaction()
                .replace(R.id.container, ApplyRegularizationFragment())
                .addToBackStack(null)
                .commit()
        }
    }

    private fun setupRecyclerView() {
        adapter = RegularizationAdapter()
        binding.rvRequests.layoutManager = LinearLayoutManager(requireContext())
        binding.rvRequests.adapter = adapter
    }

    private fun loadRegularizations() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.regularizations("Bearer $token")
                if (response.isSuccessful) {
                    adapter.submitList(response.body() ?: emptyList())
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Failed to load corrections", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupRealTimeSync() {
        lifecycleScope.launch {
            signalR.dataChangeEvents.collect { event ->
                Log.d("RegularizationFragment", "Real-time refresh: $event")
                loadRegularizations()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
