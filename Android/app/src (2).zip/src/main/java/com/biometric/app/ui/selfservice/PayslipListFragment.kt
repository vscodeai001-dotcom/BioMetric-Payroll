package com.biometric.app.ui.selfservice

import android.content.Intent
import android.os.Bundle
import android.os.Environment
import android.util.Log
import android.view.LayoutInflater
import kotlinx.coroutines.delay
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.api.MobileApiService
import com.biometric.app.api.PayslipDto
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentPayslipListBinding
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import java.io.File
import java.io.FileOutputStream
import javax.inject.Inject

@AndroidEntryPoint
class PayslipListFragment : Fragment() {

    private var _binding: FragmentPayslipListBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore

    private lateinit var adapter: PayslipAdapter

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentPayslipListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        setupRecyclerView()
        loadPayslips()
    }

    private fun setupRecyclerView() {
        adapter = PayslipAdapter { payslip ->
            downloadPayslip(payslip)
        }
        binding.rvPayslips.layoutManager = LinearLayoutManager(requireContext())
        binding.rvPayslips.adapter = adapter
    }

    private fun downloadPayslip(payslip: PayslipDto) {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.downloadPayslipPdf("Bearer $token", payslip.payrollId)
                if (response.isSuccessful) {
                    val body = response.body()
                    if (body != null) {
                        saveAndOpenPdf(body, "Payslip_${payslip.month}_${payslip.year}.pdf")
                    }
                } else {
                    Toast.makeText(requireContext(), "Download failed", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                Toast.makeText(requireContext(), "Error downloading PDF", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun saveAndOpenPdf(body: ResponseBody, fileName: String) {
        try {
            val file =
                File(requireContext().getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS), fileName)
            val inputStream = body.byteStream()
            val outputStream = FileOutputStream(file)
            inputStream.use { input ->
                outputStream.use { output ->
                    input.copyTo(output)
                }
            }
            
            val uri = FileProvider.getUriForFile(requireContext(), "${requireContext().packageName}.fileprovider", file)
            val intent = Intent(Intent.ACTION_VIEW).apply {
                setDataAndType(uri, "application/pdf")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            startActivity(Intent.createChooser(intent, "Open Payslip"))
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Failed to save or open PDF", Toast.LENGTH_SHORT).show()
        }
    }

    private fun loadPayslips() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.payslips("Bearer $token")
                if (response.isSuccessful) {
                    val payslips = response.body() ?: emptyList()
                    adapter.submitList(payslips)
                    if (payslips.isEmpty()) {
                        binding.tvEmpty.visibility = View.VISIBLE
                    } else {
                        binding.tvEmpty.visibility = View.GONE
                    }
                }
            } catch (e: Exception) {
                // Best User Experience: Silent auto-retry in background
                Log.e("Payslips", "Load failed: ${e.message}")
                delay(5000)
                loadPayslips()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
