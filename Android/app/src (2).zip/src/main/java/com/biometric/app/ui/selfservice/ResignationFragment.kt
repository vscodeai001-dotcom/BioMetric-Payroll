package com.biometric.app.ui.selfservice

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.content.ContextCompat
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.biometric.app.R
import com.biometric.app.api.MobileApiService
import com.biometric.app.api.ResignationCreateRequest
import com.biometric.app.data.MobileSessionStore
import com.biometric.app.databinding.FragmentResignationBinding
import com.biometric.app.sync.SignalRManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class ResignationFragment : Fragment() {

    private var _binding: FragmentResignationBinding? = null
    private val binding get() = _binding!!

    @Inject lateinit var mobileApi: MobileApiService
    @Inject lateinit var sessionStore: MobileSessionStore
    @Inject lateinit var signalR: SignalRManager

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentResignationBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        loadResignationStatus()
        setupRealTimeSync()

        binding.btnSubmit.setOnClickListener {
            submitResignation()
        }
    }

    private fun loadResignationStatus() {
        val token = sessionStore.token() ?: return
        lifecycleScope.launch {
            try {
                val response = mobileApi.resignation("Bearer $token")
                if (response.isSuccessful && response.body() != null) {
                    val data = response.body()!!
                    
                    binding.cvStatus.visibility = View.VISIBLE
                    binding.tvStatusText.text = data.status
                    binding.tvAdminRemarks.text = data.adminRemarks ?: "No remarks from admin yet."
                    
                    // Style based on status
                    val context = requireContext()
                    when (data.status.lowercase()) {
                        "approved" -> binding.tvStatusText.setTextColor(ContextCompat.getColor(context, R.color.green_700))
                        "pending" -> binding.tvStatusText.setTextColor(ContextCompat.getColor(context, R.color.amber_900))
                        else -> binding.tvStatusText.setTextColor(ContextCompat.getColor(context, R.color.red_700))
                    }

                    binding.etLastDay.setText(data.desiredLastWorkingDay)
                    binding.etReason.setText(data.reason)
                    
                    // Disable form if already submitted
                    binding.btnSubmit.isEnabled = false
                    binding.etLastDay.isEnabled = false
                    binding.etReason.isEnabled = false
                }
            } catch (_: Exception) { }
        }
    }

    private fun submitResignation() {
        val token = sessionStore.token() ?: return
        val lastDay = binding.etLastDay.text.toString()
        val reason = binding.etReason.text.toString()

        if (lastDay.isBlank() || reason.isBlank()) {
            Toast.makeText(requireContext(), "Please fill all fields", Toast.LENGTH_SHORT).show()
            return
        }

        val request = ResignationCreateRequest(lastDay, reason)

        lifecycleScope.launch {
            try {
                val response = mobileApi.createResignation("Bearer $token", request)
                if (response.isSuccessful) {
                    Toast.makeText(requireContext(), "Resignation submitted successfully 🚪", Toast.LENGTH_SHORT).show()
                    loadResignationStatus()
                }
            } catch (_: Exception) {
                Toast.makeText(requireContext(), "Failed to submit resignation ❌", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupRealTimeSync() {
        lifecycleScope.launch {
            signalR.dataChangeEvents.collect { event ->
                if (event is SignalRManager.SyncEvent.GlobalRefresh) {
                    loadResignationStatus()
                }
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
