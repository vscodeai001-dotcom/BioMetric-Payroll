package com.biometric.app.util

import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.bluetooth.BluetoothSocket
import android.content.Context
import android.util.Log
import com.biometric.app.data.OrderWithItems
import com.biometric.app.data.entity.Shop
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.OutputStream
import java.net.InetSocketAddress
import java.net.Socket
import java.text.SimpleDateFormat
import java.util.*

class BillPrintManager(private val context: Context) {

    private val bluetoothAdapter: BluetoothAdapter? by lazy {
        val bluetoothManager = context.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        bluetoothManager.adapter
    }

    @SuppressLint("MissingPermission")
    suspend fun printBluetooth(deviceAddress: String, shop: Shop, orderWithItems: OrderWithItems): Boolean = withContext(Dispatchers.IO) {
        var socket: BluetoothSocket? = null
        try {
            val device: BluetoothDevice = bluetoothAdapter?.getRemoteDevice(deviceAddress) ?: return@withContext false
            val uuid = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")
            socket = device.createRfcommSocketToServiceRecord(uuid)
            socket.connect()
            
            val outputStream = socket.outputStream
            val printerData = generateEscPosData(shop, orderWithItems)
            outputStream.write(printerData)
            outputStream.flush()
            
            // Wait for print to complete before closing
            Thread.sleep(1000)
            true
        } catch (e: Exception) {
            Log.e("BillPrintManager", "BT Print Error", e)
            false
        } finally {
            try { socket?.close() } catch (e: Exception) {}
        }
    }

    suspend fun printWiFi(ip: String, port: Int, shop: Shop, orderWithItems: OrderWithItems): Boolean = withContext(Dispatchers.IO) {
        var socket: Socket? = null
        try {
            socket = Socket()
            socket.connect(InetSocketAddress(ip, port), 5000)
            
            val outputStream = socket.getOutputStream()
            val printerData = generateEscPosData(shop, orderWithItems)
            outputStream.write(printerData)
            outputStream.flush()
            
            Thread.sleep(1000)
            true
        } catch (e: Exception) {
            Log.e("BillPrintManager", "WiFi Print Error", e)
            false
        } finally {
            try { socket?.close() } catch (e: Exception) {}
        }
    }

    private fun generateEscPosData(shop: Shop, orderWithItems: OrderWithItems): ByteArray {
        val bytes = mutableListOf<Byte>()
        
        // ESC/POS Commands
        val ESC = 0x1B.toByte()
        val GS = 0x1D.toByte()
        val ALIGN_CENTER = byteArrayOf(ESC, 0x61, 1)
        val ALIGN_LEFT = byteArrayOf(ESC, 0x61, 0)
        val ALIGN_RIGHT = byteArrayOf(ESC, 0x61, 2)
        val BOLD_ON = byteArrayOf(ESC, 0x45, 1)
        val BOLD_OFF = byteArrayOf(ESC, 0x45, 0)
        val FEED_PAPER = byteArrayOf(ESC, 0x64, 3) // Feed 3 lines
        val CUT_PAPER = byteArrayOf(GS, 0x56, 66, 0)

        fun addString(text: String) {
            bytes.addAll(text.toByteArray(Charsets.US_ASCII).toList())
        }

        // Header
        bytes.addAll(ALIGN_CENTER.toList())
        bytes.addAll(BOLD_ON.toList())
        addString("${shop.name}\n")
        bytes.addAll(BOLD_OFF.toList())
        if (shop.location.isNotEmpty()) addString("${shop.location}\n")
        addString("--------------------------------\n")
        
        // Order Info
        bytes.addAll(ALIGN_LEFT.toList())
        val sdf = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault())
        addString("Bill: ${orderWithItems.order.orderId.takeLast(6)}\n")
        addString("Date: ${sdf.format(Date(orderWithItems.order.closedAt ?: System.currentTimeMillis()))}\n")
        addString("Type: ${orderWithItems.order.serviceType}\n")
        if (orderWithItems.order.tableId != null) addString("Table: ${orderWithItems.order.tableId}\n")
        addString("--------------------------------\n")

        // Items
        addString("Item            Qty    Price\n")
        addString("--------------------------------\n")
        orderWithItems.items.forEach { item ->
            val name = if (item.itemName.length > 15) item.itemName.take(12) + ".." else item.itemName.padEnd(15)
            val qty = item.quantity.toInt().toString().padStart(4)
            val price = String.format(Locale.getDefault(), "%.2f", item.subTotal).padStart(10)
            addString("$name $qty $price\n")
        }
        addString("--------------------------------\n")

        // Total
        bytes.addAll(ALIGN_RIGHT.toList())
        bytes.addAll(BOLD_ON.toList())
        addString("TOTAL: RS. ${String.format(Locale.getDefault(), "%.2f", orderWithItems.order.totalAmount)}\n")
        bytes.addAll(BOLD_OFF.toList())
        
        addString("\nThank you! Visit again.\n")
        
        bytes.addAll(FEED_PAPER.toList())
        bytes.addAll(CUT_PAPER.toList())

        return bytes.toByteArray()
    }
}
