package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.data.SmartStockReminder
import com.biometric.app.databinding.ItemSmartStockBinding
import java.util.*

class SmartStockAdapter : ListAdapter<SmartStockReminder, SmartStockAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemSmartStockBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ViewHolder(private val binding: ItemSmartStockBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: SmartStockReminder) {
            val context = binding.root.context
            binding.apply {
                tvItemName.text = item.itemName
                tvCurrentStock.text = String.format(Locale.getDefault(), "%.1f %s", item.currentStock, item.unit)
                tvSuggestedTomorrow.text = String.format(Locale.getDefault(), "%.1f %s", item.suggestedDaily, item.unit)
                tvSuggestedWeekly.text = String.format(Locale.getDefault(), "%.1f %s", item.suggestedWeekly, item.unit)
                tvConfidenceScore.text = "${item.confidence}%"
                tvPatternInsight.text = "💡 ${item.patternInsight}"

                tvUrgencyTag.text = item.urgency
                val bgRes = when(item.urgency) {
                    "URGENT" -> R.drawable.tag_bg_red
                    "MEDIUM" -> R.drawable.tag_bg_amber
                    else -> R.drawable.tag_bg_green
                }
                tvUrgencyTag.setBackgroundResource(bgRes)
                
                tvConfidenceScore.setTextColor(
                    if (item.confidence >= 80) ContextCompat.getColor(context, R.color.green)
                    else ContextCompat.getColor(context, R.color.amber)
                )
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<SmartStockReminder>() {
        override fun areItemsTheSame(oldItem: SmartStockReminder, newItem: SmartStockReminder) = oldItem.itemName == newItem.itemName
        override fun areContentsTheSame(oldItem: SmartStockReminder, newItem: SmartStockReminder) = oldItem == newItem
    }
}
