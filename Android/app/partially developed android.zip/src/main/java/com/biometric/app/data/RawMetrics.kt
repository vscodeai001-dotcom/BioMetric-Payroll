package com.biometric.app.data

data class RawMetrics(
    val sales: Double = 0.0,
    val salary: Double = 0.0,
    val expense: Double = 0.0,
    val fixed: Double = 0.0,
    val profit: Double = 0.0
)
