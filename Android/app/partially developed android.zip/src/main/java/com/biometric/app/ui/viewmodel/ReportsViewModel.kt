package com.biometric.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.paging.Pager
import androidx.paging.PagingConfig
import androidx.paging.PagingData
import androidx.paging.cachedIn
import com.biometric.app.data.MainRepository
import com.biometric.app.data.DayData
import com.biometric.app.data.CashFlowSummary
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.FinancialCategorySummary
import com.biometric.app.data.OrderWithItems
import com.biometric.app.data.entity.*
import com.biometric.app.sync.FirebaseSyncManager
import com.biometric.app.ui.reports.CashbookPagingSource
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class ReportsViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel,
    private val firebaseSync: FirebaseSyncManager,
) : AndroidViewModel(application) {

    private val _employees = MutableStateFlow<List<Employee>>(emptyList())
    val employees: StateFlow<List<Employee>> = _employees.asStateFlow()

    private val _smartStock = MutableStateFlow<List<SmartStockReminder>>(emptyList())
    val smartStock: StateFlow<List<SmartStockReminder>> = _smartStock.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _isComputing = MutableStateFlow(false)
    val isComputing: StateFlow<Boolean> = _isComputing.asStateFlow()

    private val _reportParams = MutableStateFlow<ReportParams?>(null)
    
    val reportData: StateFlow<DetailedReportState> = _reportParams.filterNotNull().flatMapLatest { params ->
        val cacheKey = "report_${params.shopId}_${params.startTime}_${params.endTime}"

        // OPTIMISTIC UI: Try to emit cached data immediately
        val cached = repository.getListCache<DetailedReportState>(cacheKey).firstOrNull()

        flow {
            if (cached != null) {
                emit(cached)
                _isLoading.value = false
            }

            emitAll(combine(
                repository.getFullDayWiseDataFlow(params.shopId, params.startTime, params.endTime, params.includeBonus),
                repository.getCashbookEntriesForPeriod(params.shopId, params.startTime, params.endTime),
                repository.getFixedExpensesForShop(params.shopId),
                repository.getAllShops()
            ) { dayWise, entries, fixedList, shops ->
                val totalIn = dayWise.sumOf { it.totalIn }
                val totalOutOther = dayWise.sumOf { it.totalOut }
                val salary = dayWise.sumOf { it.salaryEarned }
                val fixed = dayWise.sumOf { it.fixedExpense }
                
                val cashFlow = CashFlowSummary(totalIn, totalOutOther, salary, fixed)
                
                val openingDates = shops.associateBy({ it.shopId }) { it.openingDate }
                val analysis = calculateExpenseAnalysis(entries, fixedList, salary, params.startTime, params.endTime, openingDates)
                
                val state = DetailedReportState(
                    dayWiseReport = dayWise,
                    totalSalary = salary,
                    cashFlow = cashFlow,
                    cashbookEntries = entries,
                    expenseAnalysis = analysis,
                    financeBreakdown = entries.groupBy { Triple(it.category, it.description ?: "", it.transactionType) }
                        .map { (key, list) -> FinancialCategorySummary(key.first, key.second, list.sumOf { it.amount }, key.third) },
                )

                // Save to cache for next rocket open
                repository.saveListCache(cacheKey, listOf(state))

                _isComputing.value = false
                _isLoading.value = false
                state
            }.onStart {
                // UNIFORM LOADING: Only set loading true if no cache available
                if (cached == null) {
                    _isLoading.value = true
                }
                _isComputing.value = true
            })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(30000), DetailedReportState())

    private val _state = MutableStateFlow(DetailedReportState())
    // Note: I'll use reportData directly as it's a StateFlow now.

    // COMPATIBILITY FLOWS (Mapped from unified reportData to avoid double calculation)
    val dayWiseReport: Flow<List<DayData>> = reportData.map { it.dayWiseReport }.distinctUntilChanged()
    val cashFlow: Flow<CashFlowSummary?> = reportData.map { it.cashFlow }.distinctUntilChanged()
    val totalSalary: Flow<Double> = reportData.map { it.totalSalary }.distinctUntilChanged()
    val totalFixedExpenses: Flow<Double> = reportData.map { it.cashFlow?.fixedExpenses ?: 0.0 }.distinctUntilChanged()
    val cashbookEntries: Flow<List<Cashbook>> = reportData.map { it.cashbookEntries }.distinctUntilChanged()
    val expenseAnalysis: Flow<ExpenseAnalysis?> = reportData.map { it.expenseAnalysis }.distinctUntilChanged()
    val financeBreakdown: Flow<List<FinancialCategorySummary>> = reportData.map { it.financeBreakdown }.distinctUntilChanged()

    private suspend fun calculateExpenseAnalysis(
        entries: List<Cashbook>, 
        fixedList: List<FixedExpense>, 
        salary: Double, 
        startTime: Long, 
        endTime: Long,
        shopOpeningDates: Map<String, Long> = emptyMap()
    ): ExpenseAnalysis {
        // ONE SOURCE OF TRUTH: Same logic as Dashboard and Day Wise Report
        val variable = entries.asSequence().filter {
            it.transactionType == "OUT" && (!FinancialCategory.isSalary(it.category, it.description) && 
            !FinancialCategory.isAdvance(it.category) && !FinancialCategory.isFixed(it.category))
        }.sumOf { it.amount }
        
        val proratedFixed = repository.calculateProratedExpenses(fixedList, startTime, endTime, shopOpeningDates)
        return ExpenseAnalysis(
            fixedExpenses = proratedFixed,
            variableExpenses = variable,
            salaryExpenses = salary,
            categoryBreakdown = entries.filter { it.transactionType == "OUT" && !FinancialCategory.isAdvance(it.category) }
                .groupBy { it.category }
                .mapValues { it.value.sumOf { entry -> entry.amount } }
        )
    }

    private val _posBillReports = MutableStateFlow<List<OrderWithItems>>(emptyList())
    val posBillReports: StateFlow<List<OrderWithItems>> = _posBillReports.asStateFlow()

    private val _posReportSummary = MutableStateFlow<PosReportSummary?>(null)
    val posReportSummary: StateFlow<PosReportSummary?> = _posReportSummary.asStateFlow()

    private val _topSellingItems = MutableStateFlow<List<Pair<String, Int>>>(emptyList())
    val topSellingItems: StateFlow<List<Pair<String, Int>>> = _topSellingItems.asStateFlow()

    private val _lowSellingItems = MutableStateFlow<List<Pair<String, Int>>>(emptyList())
    val lowSellingItems: StateFlow<List<Pair<String, Int>>> = _lowSellingItems.asStateFlow()

    private var posReportJob: Job? = null

    private var lastShopId: String? = null
    private var lastStartTime: Long = 0
    private var lastEndTime: Long = 0
    private var lastIncludeBonus: Boolean = true

    // Paging Data Flow
    private val _pagingParams = MutableStateFlow<Triple<String?, Long, Long>?>(null)
    val pagedCashbookEntries: Flow<PagingData<Cashbook>> = _pagingParams.flatMapLatest { params ->
        if (params == null) flowOf(PagingData.empty())
        else {
            Pager(PagingConfig(pageSize = 50, prefetchDistance = 10)) {
                CashbookPagingSource(firebaseSync, params.first, params.second, params.third)
            }.flow.cachedIn(viewModelScope)
        }
    }

    init {
        viewModelScope.launch {
            sharedViewModel.selectedShop.collect { shop ->
                shop?.let {
                    // Only auto-reload if we are currently in "Specific Shop" mode.
                    // If lastShopId is null or empty, we are in Global mode and should stay there.
                    if ((lastStartTime != 0L) && (lastEndTime != 0L) && !lastShopId.isNullOrEmpty()) {
                        loadReportsForPeriod(it.shopId, lastStartTime, lastEndTime, lastIncludeBonus)
                    }
                }
            }
        }
    }

    fun loadEmployees(shopId: String) {
        viewModelScope.launch {
            repository.getShopEmployees(shopId)
                .catch { e -> Log.e("ReportsViewModel", "Error loading employees", e); emit(emptyList()) }
                .collect { _employees.value = it }
        }
    }

    fun loadReportsForPeriod(
        shopId: String?,
        startTime: Long,
        endTime: Long,
        includeBonus: Boolean = true,
    ) {
        lastShopId = shopId
        lastStartTime = startTime
        lastEndTime = endTime
        lastIncludeBonus = includeBonus
        _pagingParams.value = Triple(shopId, startTime, endTime)
        _reportParams.value = ReportParams(shopId, startTime, endTime, includeBonus)
        
        viewModelScope.launch {
            repository.logAction(shopId, "VIEW", "Reports", "Detailed Report", "${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(startTime))} - ${SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date(endTime))}")
        }
    }

    fun loadDayWiseReport(shopId: String, monthCal: Calendar) {
        val cal = (monthCal.clone() as Calendar).apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        val start = cal.timeInMillis

        cal.apply {
            set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
            set(Calendar.HOUR_OF_DAY, 23)
            set(Calendar.MINUTE, 59)
            set(Calendar.SECOND, 59)
            set(Calendar.MILLISECOND, 999)
        }
        val end = cal.timeInMillis

        loadReportsForPeriod(shopId, start, end, includeBonus = true)

        viewModelScope.launch {
            try {
                repository.logAction(shopId, "VIEW", "Reports", "Day Wise Report", SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(monthCal.time))
            } catch (e: Exception) {
                Log.e("ReportsViewModel", "Error logging report view", e)
            }
        }
    }

    fun loadPosReports(shopId: String, startTime: Long, endTime: Long) {
        posReportJob?.cancel()
        posReportJob = viewModelScope.launch {
            val cacheKey = "pos_report_${shopId}_${startTime}_${endTime}"
            
            // OPTIMISTIC UI: Load from cache
            val cached = repository.getListCache<PosReportState>(cacheKey).firstOrNull()
            if (cached != null) {
                _posBillReports.value = cached.bills
                _posReportSummary.value = cached.summary
                _topSellingItems.value = cached.topSelling
                _lowSellingItems.value = cached.lowSelling
                _isLoading.value = false
            }

            try {
                repository.getOrdersWithItemsForPeriod(shopId, startTime, endTime)
                    .catch { e -> Log.e("ReportsViewModel", "Error loading POS reports", e) }
                    .collect { orders ->
                        _posBillReports.value = orders
                        val total = orders.sumOf { it.order.totalAmount }
                        val cash = orders.filter { it.order.paymentMethod == "CASH" }.sumOf { it.order.totalAmount }
                        val qr = orders.filter { it.order.paymentMethod == "QR" }.sumOf { it.order.totalAmount }
                        val summary = PosReportSummary(total, cash, qr)
                        _posReportSummary.value = summary

                        val itemMap = mutableMapOf<String, Double>()
                        orders.flatMap { it.items }.forEach {
                            itemMap[it.itemName] = (itemMap[it.itemName] ?: 0.0) + it.quantity
                        }
                        val sortedItems = itemMap.toList().sortedByDescending { it.second }
                        val topSelling = sortedItems.take(5).map { it.first to it.second.toInt() }
                        val lowSelling = sortedItems.takeLast(5).reversed().map { it.first to it.second.toInt() }
                        
                        _topSellingItems.value = topSelling
                        _lowSellingItems.value = lowSelling
                        _isLoading.value = false

                        repository.saveListCache(cacheKey, listOf(PosReportState(orders, summary, topSelling, lowSelling)))
                    }
            } catch (e: Exception) {
                Log.e("ReportsViewModel", "Error in loadPosReports", e)
            }
        }
    }

    fun deleteCashbookEntry(entry: Cashbook) {
        viewModelScope.launch {
            repository.deleteCashbookEntry(entry)
            reSyncSnapshots(entry.shopId, entry.transactionDate)
        }
    }

    fun deleteOrder(order: Order) {
        viewModelScope.launch {
            repository.deleteOrder(order)
            reSyncSnapshots(order.shopId, order.createdAt)
        }
    }

    fun updateOrderAndItems(order: Order, items: List<OrderItem>) {
        viewModelScope.launch {
            repository.updateOrder(order)
            reSyncSnapshots(order.shopId, order.createdAt)
        }
    }

    fun reSyncSnapshots(shopId: String?, date: Long) {
        if (shopId.isNullOrEmpty()) return
        viewModelScope.launch {
            val cal = Calendar.getInstance().apply { timeInMillis = date }
            val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(cal.time)
            repository.clearMonthlySnapshot(shopId, monthKey)
            sharedViewModel.triggerDashboardRefresh()
        }
    }

    data class ReportParams(val shopId: String?, val startTime: Long, val endTime: Long, val includeBonus: Boolean)
    
    data class DetailedReportState(
        val dayWiseReport: List<DayData> = emptyList(),
        val totalSalary: Double = 0.0,
        val cashFlow: CashFlowSummary? = null,
        val cashbookEntries: List<Cashbook> = emptyList(),
        val expenseAnalysis: ExpenseAnalysis? = null,
        val financeBreakdown: List<FinancialCategorySummary> = emptyList()
    )
}

data class PosReportSummary(val totalSales: Double, val cashSales: Double, val qrSales: Double)

data class PosReportState(
    val bills: List<OrderWithItems>,
    val summary: PosReportSummary,
    val topSelling: List<Pair<String, Int>>,
    val lowSelling: List<Pair<String, Int>>
)

data class ExpenseAnalysis(
    val fixedExpenses: Double,
    val variableExpenses: Double,
    val salaryExpenses: Double,
    val categoryBreakdown: Map<String, Double>
)

data class SmartStockReminder(
    val itemName: String,
    val currentStock: Double,
    val weekdayStandard: Double,
    val weekendStandard: Double,
    val supplierName: String?,
    val supplierContact: String?
)
