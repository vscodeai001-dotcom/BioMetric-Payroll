package com.biometric.app.ui.adapter

import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import androidx.core.content.ContextCompat
import com.google.android.material.button.MaterialButton
import com.biometric.app.R

class TableButtonAdapter(
    private val onTableClick: (String?) -> Unit,
) : ListAdapter<TableButtonAdapter.TableItem, TableButtonAdapter.TableButtonViewHolder>(TableDiffCallback()) {

    data class TableItem(
        val number: String,
        val isSelected: Boolean
    )

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): TableButtonViewHolder {
        val button = LayoutInflater.from(parent.context).inflate(R.layout.item_table_button, parent, false) as MaterialButton
        return TableButtonViewHolder(button)
    }

    override fun onBindViewHolder(holder: TableButtonViewHolder, position: Int) {
        val item = getItem(position)
        holder.bind(item) {
            onTableClick(item.number)
        }
    }

    class TableButtonViewHolder(private val button: MaterialButton) :
        RecyclerView.ViewHolder(button) {

        fun bind(item: TableItem, onClick: () -> Unit) {
            button.text = item.number
            button.setOnClickListener { onClick() }

            val context = button.context

            if (item.isSelected) {
                button.setBackgroundColor(ContextCompat.getColor(context, R.color.colorPrimary))
                button.setTextColor(Color.WHITE)
                button.strokeWidth = 0
            } else {
                button.setBackgroundColor(Color.TRANSPARENT)
                button.setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                button.strokeWidth = (1 * context.resources.displayMetrics.density).toInt()
            }
        }
    }

    class TableDiffCallback : DiffUtil.ItemCallback<TableItem>() {
        override fun areItemsTheSame(oldItem: TableItem, newItem: TableItem): Boolean {
            return oldItem.number == newItem.number
        }

        override fun areContentsTheSame(oldItem: TableItem, newItem: TableItem): Boolean {
            return oldItem == newItem
        }
    }
}
