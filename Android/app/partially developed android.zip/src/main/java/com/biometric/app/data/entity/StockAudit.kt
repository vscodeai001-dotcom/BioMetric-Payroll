package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class StockAudit(
    @get:PropertyName("auditId") @set:PropertyName("auditId")
    var auditId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("timestamp") @set:PropertyName("timestamp")
    var timestamp: Long = System.currentTimeMillis(),
    
    @get:PropertyName("items") @set:PropertyName("items")
    var items: List<StockAuditItem> = emptyList(),
    
    @get:PropertyName("totalVariance") @set:PropertyName("totalVariance")
    var totalVariance: Double = 0.0,
    
    @get:PropertyName("userId") @set:PropertyName("userId")
    var userId: String = "",
    
    @get:PropertyName("userName") @set:PropertyName("userName")
    var userName: String = ""
)

@Keep
data class StockAuditItem(
    @get:PropertyName("itemName") @set:PropertyName("itemName")
    var itemName: String = "",
    
    @get:PropertyName("systemQty") @set:PropertyName("systemQty")
    var systemQty: Double = 0.0,
    
    @get:PropertyName("physicalQty") @set:PropertyName("physicalQty")
    var physicalQty: Double = 0.0,
    
    @get:PropertyName("variance") @set:PropertyName("variance")
    var variance: Double = 0.0,
    
    @get:PropertyName("unitType") @set:PropertyName("unitType")
    var unitType: String = ""
)
