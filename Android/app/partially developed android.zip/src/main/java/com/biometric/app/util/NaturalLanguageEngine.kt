package com.biometric.app.util

import com.biometric.app.data.entity.Cashbook
import java.util.*

object NaturalLanguageEngine {

    private val STOP_WORDS = setOf(
        "how", "much", "did", "i", "on", "for", "the", "of", "a", "an", "is", "was", "show", "me", "find", "get", "what", "total", "any", "at", "were", "my", "list", "all", "about", "your", "can", "tell", "please", "thanks", "thank", "you", "give", "display", "amt", "amount", "record", "records",
    )

    private val TIME_KEYWORDS = setOf(
        "today", "yesterday", "week", "month", "last", "this", "days", "day", "ago", "period", "range", "from", "to", "between",
        "january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december",
        "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "oct", "nov", "dec",
        "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday",
        "mondays", "tuesdays", "wednesdays", "thursdays", "fridays", "saturdays", "sundays", "1st", "first", "last",
    )

    private val INTENT_KEYWORDS = setOf(
        "profit", "loss", "net", "margin", "result", "performance", "earn", "earned", "earning", "make", "made",
        "sales", "sale", "income", "revenue", "received", "collection", "cash", "qr", "inflow", "inward", "incoming",
        "purchase", "spent", "spend", "expense", "spending", "bought", "buy", "order", "ordered", "grocery", "bill", "outflow", "outward", "outgoing", "cost", "costing",
        "salary", "advance", "payment", "staff", "worker", "employee", "absent", "present", "attendance", "leave", "absentees", "workers", "employees", "stock", "inventory", "investment", "health", "goal", "target",
    )

    private val SORT_KEYWORDS = setOf(
        "highest", "top", "largest", "most", "max", "maximum", "best", "greatest",
        "lowest", "bottom", "smallest", "least", "min", "minimum", "worst",
        "latest", "recent", "newest", "fresh",
        "oldest", "earliest", "first",
    )

    /**
     * Advanced Search Engine: Parses questions and returns a filtered, sorted list.
     */
    fun filterLedger(items: List<Cashbook>, query: String): List<Cashbook> {
        if (query.isBlank()) return items
        
        val q = query.lowercase().trim()
        var filteredList = items.toList()

        // 1. Specific Day Name Filtering (e.g. "sundays")
        val days = listOf("sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday")
        days.forEach { name ->
            if (q.contains(name) || q.contains("${name}s")) {
                filteredList = filteredList.filter { 
                    val cal = Calendar.getInstance().apply { timeInMillis = it.transactionDate }
                    val dayName = cal.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault())?.lowercase()
                    dayName == name
                }
            }
        }

        // 2. "1st day" or "first day" logic
        if (q.contains("1st day") || q.contains("first day")) {
            val minDate = filteredList.minOfOrNull { it.transactionDate } ?: 0L
            if (minDate > 0) {
                val cal = Calendar.getInstance().apply { timeInMillis = minDate }
                val targetDay = cal[Calendar.DAY_OF_MONTH]
                filteredList = filteredList.filter {
                    val itemCal = Calendar.getInstance().apply { timeInMillis = it.transactionDate }
                    itemCal[Calendar.DAY_OF_MONTH] == targetDay
                }
            }
        }

        // 3. Intent Identification (Credit vs Debit)
        val inflowKeywords = listOf("cash in", "inflow", "credit", "received", "income", "sales", "sale", "revenue", "collection", "earn")
        val outflowKeywords = listOf("cash out", "outflow", "debit", "expense", "purchase", "paid", "spent", "spending", "bought", "buy", "order", "ordered", "salary", "advance", "payment", "grocery", "cost")
        
        val hasInflowIntent = inflowKeywords.any { q.contains(it) }
        val hasOutflowIntent = outflowKeywords.any { q.contains(it) }

        if (hasInflowIntent && !hasOutflowIntent) {
            filteredList = filteredList.filter { it.transactionType == "IN" }
        } else if (hasOutflowIntent && !hasInflowIntent) {
            filteredList = filteredList.filter { it.transactionType == "OUT" }
        }

        // 4. Numeric Operator Logic (e.g. "> 500")
        val overRegex = Regex("(over|more than|greater than|>)\\s*(\\d+)")
        val underRegex = Regex("(under|less than|smaller than|<)\\s*(\\d+)")
        
        overRegex.find(q)?.let { match ->
            val amount = match.groupValues[2].toDoubleOrNull() ?: 0.0
            filteredList = filteredList.filter { it.amount > amount }
        }
        underRegex.find(q)?.let { match ->
            val amount = match.groupValues[2].toDoubleOrNull() ?: 0.0
            filteredList = filteredList.filter { it.amount < amount }
        }

        // 5. Pure Subject Extraction
        val cleanTokens = q.split(" ", ">", "<", ",", "-", ":")
            .asSequence()
            .map { it.trim().removeSuffix("s") }
            .filter { token ->
                token.isNotEmpty() && 
                token !in STOP_WORDS && 
                !TIME_KEYWORDS.any { (it == token) || it.contains(token) } && 
                !INTENT_KEYWORDS.any { (it == token) || it.contains(token) } && 
                !SORT_KEYWORDS.any { (it == token) || it.contains(token) } && 
                token.toDoubleOrNull() == null
            }
            .toList()

        if (cleanTokens.isNotEmpty()) {
            filteredList = filteredList.filter { item ->
                cleanTokens.all { token ->
                    (item.category.contains(token, ignoreCase = true)) || 
                    (item.description?.contains(token, ignoreCase = true) == true)
                }
            }
        }

        // 6. Sorting
        filteredList = when {
            containsAny(q, "highest", "top", "largest", "most", "max", "best", "greatest") -> filteredList.sortedByDescending { it.amount }
            containsAny(q, "lowest", "bottom", "smallest", "least", "min", "worst") -> filteredList.sortedBy { it.amount }
            containsAny(q, "latest", "recent", "newest", "fresh") -> filteredList.sortedByDescending { it.transactionDate }
            containsAny(q, "oldest", "earliest", "first") -> filteredList.sortedBy { it.transactionDate }
            else -> filteredList 
        }

        return filteredList
    }

    fun parseGlobalTimeCommand(query: String): Triple<String, Long, Long>? {
        val q = query.lowercase().trim()
        val cal = Calendar.getInstance()
        val now = cal.timeInMillis
        
        // Match "last X days" or "last X days"
        Regex("last\\s*(\\d+)\\s*days?").find(q)?.let { match ->
            val count = match.groupValues[1].toIntOrNull() ?: 1
            val start = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -(count - 1)); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            return Triple("Last $count Days", start.timeInMillis, now)
        }

        // Match "X days ago"
        Regex("(\\d+)\\s*days?\\s*ago").find(q)?.let { match ->
            val count = match.groupValues[1].toIntOrNull() ?: 1
            val start = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -count); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val end = (start.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
            return Triple("$count Days Ago", start.timeInMillis, end.timeInMillis)
        }

        // Match Specific Month and Year
        Regex("(january|february|march|april|may|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|oct|nov|dec)\\s*(\\d{4})").find(q)?.let { match ->
            val monthName = match.groupValues[1]
            val year = match.groupValues[2].toIntOrNull() ?: cal[Calendar.YEAR]
            val monthIndex = getMonthIndex(monthName)
            val start = Calendar.getInstance().apply { set(Calendar.YEAR, year); set(Calendar.MONTH, monthIndex); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val end = (start.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
            return Triple("${monthName.uppercase(Locale.getDefault())} $year", start.timeInMillis, end.timeInMillis)
        }

        if (q.contains("last month") || q.contains("previous month")) {
            cal.add(Calendar.MONTH, -1)
            val start = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val end = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
            return Triple("Last Month", start.timeInMillis, end.timeInMillis)
        }
        
        if (q.contains("last week")) {
            cal.add(Calendar.WEEK_OF_YEAR, -1)
            val start = (cal.clone() as Calendar).apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val end = (start.clone() as Calendar).apply { add(Calendar.DAY_OF_WEEK, 6); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
            return Triple("Last Week", start.timeInMillis, end.timeInMillis)
        }

        if (q.contains("this week")) {
            val start = Calendar.getInstance().apply { set(Calendar.DAY_OF_WEEK, firstDayOfWeek); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            return Triple("This Week", start.timeInMillis, now)
        }

        if (q.contains("yesterday")) {
            val start = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, -1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            val end = (start.clone() as Calendar).apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
            return Triple("Yesterday", start.timeInMillis, end.timeInMillis)
        }

        if (q.contains("today")) {
            val start = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
            return Triple("Today", start.timeInMillis, now)
        }

        val months = listOf("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december")
        months.forEachIndexed { index, name ->
            if (q.contains(name) || q.contains(name.take(3))) {
                val start = Calendar.getInstance().apply { set(Calendar.MONTH, index); set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
                val end = (start.clone() as Calendar).apply { set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH)); set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }
                return Triple(name.uppercase(Locale.getDefault()), start.timeInMillis, end.timeInMillis)
            }
        }
        
        return null
    }

    private fun getMonthIndex(name: String): Int {
        val months = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
        return months.indexOfFirst { name.startsWith(it) }.coerceAtLeast(0)
    }

    private fun containsAny(query: String, vararg keywords: String): Boolean {
        return keywords.any { query.contains(it, ignoreCase = true) }
    }
}
