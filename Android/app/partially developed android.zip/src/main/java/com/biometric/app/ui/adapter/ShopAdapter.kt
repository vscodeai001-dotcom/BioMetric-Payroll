package com.biometric.app.ui.adapter

import android.os.Handler
import android.os.Looper
import android.text.SpannableStringBuilder
import android.text.Spanned
import android.text.style.ForegroundColorSpan
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.AnimationUtils
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import java.util.Locale
import com.biometric.app.R
import com.biometric.app.data.entity.Shop
import com.biometric.app.databinding.ItemShopCardBinding
import com.biometric.app.ui.viewmodel.MetricData
import com.biometric.app.ui.viewmodel.ShopWithProfit
import com.biometric.app.util.HapticUtil

import com.biometric.app.domain.FeatureManager
import com.biometric.app.util.MotionManager

class ShopAdapter(
    private val featureManager: FeatureManager,
    private val onShopClick: (Shop) -> Unit,
    private val onEditClick: (Shop) -> Unit,
    private val onDeleteClick: (Shop) -> Unit,
    private val onSalesClick: (Shop) -> Unit,
    private val onSalaryClick: (Shop) -> Unit,
    private val onPurchasesClick: (Shop) -> Unit,
    private val onFixedExpClick: (Shop) -> Unit
) : ListAdapter<ShopWithProfit, ShopAdapter.ShopViewHolder>(ShopDiffCallback()) {

    private val visibilityStates = mutableMapOf<String, Boolean>()
    private val handler = Handler(Looper.getMainLooper())
    private val hideRunnables = mutableMapOf<String, Runnable>()
    private var isPrivacyModeEnabled = true

    fun setPrivacyMode(enabled: Boolean) {
        if (isPrivacyModeEnabled != enabled) {
            isPrivacyModeEnabled = enabled
            notifyDataSetChanged()
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ShopViewHolder {
        val binding = ItemShopCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ShopViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ShopViewHolder, position: Int) {
        holder.bind(getItem(position))
        
        // Professional Entrance Animation
        val animation = AnimationUtils.loadAnimation(holder.itemView.context, R.anim.slide_up_premium)
        animation.startOffset = (position * 50).toLong()
        holder.itemView.startAnimation(animation)
    }

            inner class ShopViewHolder(private val binding: ItemShopCardBinding) :
        RecyclerView.ViewHolder(binding.root) {

        private var clickCount = 0

        fun bind(shopWithProfit: ShopWithProfit) {
            val shop = shopWithProfit.shop
            binding.tvShopName.text = shop.name
            binding.tvLocation.text = shop.location
            
            val currentProfit = shopWithProfit.profit.current
            
            // Privacy Masking Logic
            val shopId = shop.shopId
            val isVisible = !isPrivacyModeEnabled || (visibilityStates[shopId] ?: false)
            
            if (isVisible) {
                binding.tvShopNetProfit.text = String.format(Locale.getDefault(), "₹ %.2f", currentProfit)
                binding.btnShopProfitPrivacy.alpha = 1.0f
                if (!isPrivacyModeEnabled) {
                    binding.btnShopProfitPrivacy.visibility = android.view.View.GONE
                } else {
                    binding.btnShopProfitPrivacy.visibility = android.view.View.VISIBLE
                }
            } else {
                binding.tvShopNetProfit.text = itemView.context.getString(R.string.privacy_mask)
                binding.btnShopProfitPrivacy.alpha = 0.5f
                binding.btnShopProfitPrivacy.visibility = android.view.View.VISIBLE
            }

            binding.btnShopProfitPrivacy.setOnClickListener {
                if (!isPrivacyModeEnabled) return@setOnClickListener
                visibilityStates[shopId] = true
                val currentPos = bindingAdapterPosition
                if (currentPos != RecyclerView.NO_POSITION) {
                    notifyItemChanged(currentPos)
                }
                
                // Use central handler to ensure timer works even if view is recycled
                hideRunnables[shopId]?.let { handler.removeCallbacks(it) }
                val runnable = Runnable {
                    visibilityStates[shopId] = false
                    val latestPos = currentList.indexOfFirst { it.shop.shopId == shopId }
                    if (latestPos != -1) {
                        notifyItemChanged(latestPos)
                    }
                }
                hideRunnables[shopId] = runnable
                handler.postDelayed(runnable, 5000)
            }
            
            binding.tvNetProfitComp.text = formatComp(shopWithProfit.profit)
            
            // Professional coloring and Trend icons
            if (currentProfit >= 0) {
                binding.tvShopNetProfit.setTextColor(ContextCompat.getColor(itemView.context, R.color.green))
                binding.ivProfitTrend.setImageResource(R.drawable.ic_arrow_forward)
                binding.ivProfitTrend.rotation = -45f // Up
                binding.ivProfitTrend.setColorFilter(ContextCompat.getColor(itemView.context, R.color.green))
            } else {
                binding.tvShopNetProfit.setTextColor(ContextCompat.getColor(itemView.context, R.color.red))
                binding.ivProfitTrend.setImageResource(R.drawable.ic_arrow_forward)
                binding.ivProfitTrend.rotation = 45f // Down
                binding.ivProfitTrend.setColorFilter(ContextCompat.getColor(itemView.context, R.color.red))
            }

            // Rich Metrics Tiles (Formatted for professionalism)
            binding.tvTotalSales.text = formatCurrency(shopWithProfit.sales.current)
            binding.tvTotalSalary.text = formatCurrency(shopWithProfit.salary.current)
            binding.tvTotalExpense.text = formatCurrency(shopWithProfit.expense.current)
            binding.tvFixedExpense.text = formatCurrency(shopWithProfit.fixed.current)

            binding.tvTotalSalesComp.text = formatCompShort(shopWithProfit.sales)
            binding.tvTotalSalaryComp.text = formatCompShort(shopWithProfit.salary)
            binding.tvTotalExpenseComp.text = formatCompShort(shopWithProfit.expense)
            binding.tvFixedExpenseComp.text = formatCompShort(shopWithProfit.fixed)

            // GESTURE CONTROL: Use standard listeners for card actions
            binding.root.setOnClickListener { 
                clickCount++
                if (clickCount == 1) {
                    handler.postDelayed({
                        if (clickCount == 1) {
                            onShopClick(shop)
                        } else if (clickCount >= 2) {
                            onEditClick(shop)
                        }
                        clickCount = 0
                    }, 300) // Double-tap window
                }
            }
            
            binding.root.setOnLongClickListener {
                onDeleteClick(shop)
                true
            }

            // Apply Scale Animation manually but DON'T consume the event
            binding.root.setOnTouchListener { v, event ->
                when (event.action) {
                    android.view.MotionEvent.ACTION_DOWN -> v.animate().scaleX(0.98f).scaleY(0.98f).setDuration(80).start()
                    android.view.MotionEvent.ACTION_UP, android.view.MotionEvent.ACTION_CANCEL -> v.animate().scaleX(1.0f).scaleY(1.0f).setDuration(150).start()
                }
                false // Allow standard listeners to work
            }

            // Tile Drill-down listeners (Keep these as they are specific areas)
            binding.llSalesTile.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.FINANCE)) android.view.View.VISIBLE else android.view.View.GONE
            binding.llSalaryTile.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.STAFF)) android.view.View.VISIBLE else android.view.View.GONE
            binding.llPurchasesTile.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.INVENTORY)) android.view.View.VISIBLE else android.view.View.GONE
            binding.llFixedExpTile.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.FIXED_EXPENSES)) android.view.View.VISIBLE else android.view.View.GONE

            MotionManager.applyTouchScale(binding.llSalesTile)
            binding.llSalesTile.setOnClickListener {
                onSalesClick(shop)
            }
            MotionManager.applyTouchScale(binding.llSalaryTile)
            binding.llSalaryTile.setOnClickListener {
                onSalaryClick(shop)
            }
            MotionManager.applyTouchScale(binding.llPurchasesTile)
            binding.llPurchasesTile.setOnClickListener {
                onPurchasesClick(shop)
            }
            MotionManager.applyTouchScale(binding.llFixedExpTile)
            binding.llFixedExpTile.setOnClickListener {
                onFixedExpClick(shop)
            }
        }

        private fun formatCurrency(v: Double): String {
            return String.format("₹ %.0f", v)
        }

        private fun formatComp(data: MetricData): CharSequence {
            val context = itemView.context
            val builder = SpannableStringBuilder()

            // P: Accurate Past (P1)
            builder.append("P:₹${formatVal(data.past)}")
            builder.setSpan(ForegroundColorSpan(ContextCompat.getColor(context, R.color.text_secondary)), 0, builder.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            
            builder.append(" | ")
            
            // E: Prediction (Rolling + Seasonal)
            val startExp = builder.length
            builder.append("E:₹${formatVal(data.expected)}")
            builder.setSpan(ForegroundColorSpan(ContextCompat.getColor(context, R.color.colorPrimary)), startExp, builder.length, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            
            return builder
        }

        private fun formatCompShort(data: MetricData): String {
            return "P:${formatVal(data.past)}|E:${formatVal(data.expected)}"
        }

        private fun formatVal(v: Double): String {
            val absV = kotlin.math.abs(v)
            val sign = if (v < 0) "-" else ""
            return when {
                absV >= 100000 -> String.format("%s%.1fL", sign, absV / 100000)
                absV >= 1000 -> String.format("%s%.1fK", sign, absV / 1000)
                else -> String.format("%s%.0f", sign, absV)
            }
        }
    }

    class ShopDiffCallback : DiffUtil.ItemCallback<ShopWithProfit>() {
        override fun areItemsTheSame(oldItem: ShopWithProfit, newItem: ShopWithProfit) = oldItem.shop.shopId == newItem.shop.shopId
        override fun areContentsTheSame(oldItem: ShopWithProfit, newItem: ShopWithProfit) = oldItem == newItem
    }
}
