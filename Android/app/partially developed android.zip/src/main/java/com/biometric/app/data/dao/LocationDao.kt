package com.biometric.app.data.dao

import androidx.room.*
import com.biometric.app.data.entity.LocationTrack
import kotlinx.coroutines.flow.Flow

@Dao
interface LocationDao {
    @Insert
    fun insert(track: LocationTrack): Long

    @Query("SELECT * FROM location_tracks WHERE isSynced = 0 ORDER BY timestamp ASC")
    fun getUnsyncedTracks(): Flow<List<LocationTrack>>

    @Query("SELECT * FROM location_tracks WHERE isSynced = 0 ORDER BY timestamp ASC LIMIT :limit")
    fun getUnsyncedTracksSync(limit: Int): List<LocationTrack>

    @Update
    fun update(track: LocationTrack): Int

    @Query("UPDATE location_tracks SET isSynced = 1 WHERE locationId IN (:ids)")
    fun markAsSynced(ids: Array<Long>): Int

    @Query("DELETE FROM location_tracks WHERE isSynced = 1 AND timestamp < :beforeTimestamp")
    fun deleteOldSyncedTracks(beforeTimestamp: Long): Int
}
