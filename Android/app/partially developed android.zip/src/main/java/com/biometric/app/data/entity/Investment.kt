package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class Investment(
    @get:PropertyName("investmentId") @set:PropertyName("investmentId")
    var investmentId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("itemName") @set:PropertyName("itemName")
    var itemName: String = "",
    
    @get:PropertyName("amount") @set:PropertyName("amount")
    var amount: Double = 0.0,
    
    @get:PropertyName("date") @set:PropertyName("date")
    var date: Long = System.currentTimeMillis(),
    
    @get:PropertyName("category") @set:PropertyName("category")
    var category: String = "Miscellaneous", // Capital, Deposit, Equipment, Furniture, Renovation, Interior, Machinery, Miscellaneous
    
    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis()
)
