package com.biometric.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ActivityStockAuditBinding
import com.biometric.app.databinding.ItemStockAuditRowBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.viewmodel.StockAuditItemUI
import com.biometric.app.ui.viewmodel.StockAuditViewModel
import com.biometric.app.util.HapticUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class StockAuditActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityStockAuditBinding
    private val viewModel: StockAuditViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    
    private lateinit var auditAdapter: StockAuditAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStockAuditBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: "Shop"
        
        setupToolbar(shopName)
        setupRecyclerView()
        observeViewModel()
        
        viewModel.setShopId(shopId)

        binding.btnSubmitAudit.setOnClickListener {
            val user = sharedViewModel.userProfile.value
            viewModel.submitAudit(user?.name ?: "Admin", user?.uid ?: "unknown")
        }
        
        setupMotionFeedback(binding.btnSubmitAudit)
    }

    private fun setupToolbar(shopName: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        setupDualHeader(binding.toolbar, shopName, "Stock Audit")
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupRecyclerView() {
        auditAdapter = StockAuditAdapter { itemName, qty ->
            viewModel.updatePhysicalQty(itemName, qty)
        }
        binding.rvStockAudit.layoutManager = LinearLayoutManager(this)
        binding.rvStockAudit.adapter = auditAdapter
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.state.collectLatest { state ->
                        if (state.isLoading) {
                            binding.brewingLoader.root.visibility = View.VISIBLE
                        } else {
                            binding.brewingLoader.root.visibility = View.GONE
                        }

                        if (state.isSubmitted) {
                            HapticUtil.vibrateSuccess(binding.root)
                            Toast.makeText(this@StockAuditActivity, "Audit Submitted Successfully", Toast.LENGTH_SHORT).show()
                            finish()
                        }

                        auditAdapter.submitList(state.items)
                        binding.tvTotalVariance.text = String.format(Locale.getDefault(), "₹ %.2f", state.totalVarianceValue)
                        
                        val varianceColor = if (state.totalVarianceValue >= 0) R.color.green else R.color.red
                        binding.tvTotalVariance.setTextColor(ContextCompat.getColor(this@StockAuditActivity, varianceColor))
                    }
                }
            }
        }
    }

    class StockAuditAdapter(private val onQtyChanged: (String, Double) -> Unit) :
        androidx.recyclerview.widget.ListAdapter<StockAuditItemUI, StockAuditAdapter.ViewHolder>(DiffCallback()) {

        class ViewHolder(val binding: ItemStockAuditRowBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            return ViewHolder(ItemStockAuditRowBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val ui = getItem(position)
            holder.binding.tvItemName.text = ui.item.name
            holder.binding.tvSystemQty.text = String.format(Locale.getDefault(), "%.1f", ui.item.totalQuantity)
            holder.binding.tvUnitType.text = ui.item.unitType
            
            // Remove text watcher before setting text to avoid infinite loop
            holder.binding.etPhysicalQty.tag = null 
            holder.binding.etPhysicalQty.setText(String.format(Locale.getDefault(), "%.1f", ui.physicalQty))
            
            holder.binding.tvVariance.text = String.format(Locale.getDefault(), "%.1f", ui.variance)
            val color = if (ui.variance == 0.0) R.color.text_secondary else if (ui.variance > 0) R.color.green else R.color.red
            holder.binding.tvVariance.setTextColor(ContextCompat.getColor(holder.itemView.context, color))

            val watcher = object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    val newVal = s.toString().toDoubleOrNull() ?: 0.0
                    if (newVal != ui.physicalQty) {
                        onQtyChanged(ui.item.name, newVal)
                    }
                }
            }
            holder.binding.etPhysicalQty.addTextChangedListener(watcher)
            holder.binding.etPhysicalQty.tag = watcher
        }

        class DiffCallback : androidx.recyclerview.widget.DiffUtil.ItemCallback<StockAuditItemUI>() {
            override fun areItemsTheSame(oldItem: StockAuditItemUI, newItem: StockAuditItemUI) = oldItem.item.name == newItem.item.name
            override fun areContentsTheSame(oldItem: StockAuditItemUI, newItem: StockAuditItemUI) = oldItem == newItem
        }
    }
}
