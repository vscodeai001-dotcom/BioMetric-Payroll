package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName

@Keep
data class GeofenceLocation(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = "",
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("latitude") @set:PropertyName("latitude")
    var latitude: Double = 0.0,
    
    @get:PropertyName("longitude") @set:PropertyName("longitude")
    var longitude: Double = 0.0,
    
    @get:PropertyName("radius") @set:PropertyName("radius")
    var radius: Float = 100f, // Default 100 meters
    
    @get:PropertyName("type") @set:PropertyName("type")
    var type: String = "SHOP", // SHOP, CUSTOMER, etc.
    
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true,
    
    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis()
)
