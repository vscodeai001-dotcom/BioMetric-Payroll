package com.biometric.app.ai

/**
 * Legacy AI Engine.
 * Logic has been migrated to specialized engines:
 * - [AIIntentEngine] for intent detection
 * - [BusinessInsightEngine] for data analysis
 * - [GeminiService] for natural language generation
 */
object AiEngine
