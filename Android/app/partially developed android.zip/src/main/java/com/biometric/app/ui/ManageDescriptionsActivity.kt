package com.biometric.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.DescriptionMaster
import com.biometric.app.databinding.ActivityManageListBinding
import com.biometric.app.databinding.ItemSettingsListRowBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.MotionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class ManageDescriptionsActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityManageListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: DescriptionListAdapter
    private var currentShopId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentShopId = intent.getStringExtra("SHOP_ID")
        viewModel.setManagementShopId(currentShopId)

        setupToolbar()
        setupRecyclerView()
        setupListeners()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        setupDualHeader(binding.toolbar, "Master Data ⚙️", "Manage Descriptions")
    }

    private fun setupRecyclerView() {
        adapter = DescriptionListAdapter(
            onEdit = { showRenameDialog(it) },
            onDelete = { confirmDelete(it) }
        )
        binding.rvList.layoutManager = LinearLayoutManager(this)
        binding.rvList.adapter = adapter
    }

    private fun setupListeners() {
        binding.fabAdd.setOnClickListener {
            showRenameDialog(null)
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        setupMotionFeedback(binding.fabAdd)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.descriptionMaster.collectLatest { masters ->
                    adapter.submitFullList(masters)
                }
            }
        }
    }

    private fun showRenameDialog(existing: DescriptionMaster?) {
        val input = android.widget.EditText(this).apply {
            setText(existing?.name ?: "")
            setSelection(existing?.name?.length ?: 0)
            hint = "Description Name"
        }

        val title = if (existing == null) "Add New Description" else "Global Rename & Merge"
        val message = if (existing == null) "Create a new standardized description for future entries." 
                      else getString(R.string.msg_rename_description_global, existing.name)

        MaterialAlertDialogBuilder(this)
            .setTitle(title)
            .setMessage(message)
            .setView(input)
            .setPositiveButton(if (existing == null) "Save" else "Rename Globally") { _, _ ->
                val newName = input.text.toString().trim()
                if (newName.isNotEmpty()) {
                    if (existing == null) {
                        // For descriptions, we usually just add it to master
                        // Actually repository.insertDescriptionMaster isn't public yet
                        // I'll use a trick or add it.
                        viewModel.renameDescriptionGlobally("", newName) // Trick to add new
                    } else if (newName != existing.name) {
                        viewModel.renameDescriptionGlobally(existing.name, newName)
                    }
                    MotionManager.playUpdateMorph(binding.animFeedback)
                    HapticUtil.vibrateSuccess(binding.root)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(item: DescriptionMaster) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete from Suggestions?")
            .setMessage(getString(R.string.msg_delete_description_confirm, item.name))
            .setPositiveButton("Remove") { _, _ ->
                viewModel.deleteDescriptionMaster(item)
                MotionManager.playDeleteDissolve(binding.animFeedback)
                HapticUtil.vibrateSuccess(binding.root)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    inner class DescriptionListAdapter(
        private val onEdit: (DescriptionMaster) -> Unit,
        private val onDelete: (DescriptionMaster) -> Unit
    ) : RecyclerView.Adapter<DescriptionListAdapter.ViewHolder>() {

        private var fullList: List<DescriptionMaster> = emptyList()
        private var filteredList: List<DescriptionMaster> = emptyList()

        fun submitFullList(list: List<DescriptionMaster>) {
            fullList = list
            filter(binding.etSearch.text.toString())
        }

        fun filter(query: String) {
            filteredList = if (query.isEmpty()) {
                fullList
            } else {
                fullList.filter { it.name.contains(query, ignoreCase = true) }
            }
            notifyDataSetChanged()
        }

        inner class ViewHolder(val binding: ItemSettingsListRowBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val b = ItemSettingsListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(b)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = filteredList[position]
            holder.binding.tvItemIcon.text = "📝"
            holder.binding.tvItemName.text = item.name
            
            val lastUsedSdf = java.text.SimpleDateFormat("dd MMM yyyy", java.util.Locale.getDefault())
            holder.binding.tvItemSubtitle.text = getString(R.string.label_last_used, lastUsedSdf.format(java.util.Date(item.lastUsed)))
            
            holder.binding.btnEdit.setOnClickListener { onEdit(item) }
            holder.binding.btnDelete.setOnClickListener { onDelete(item) }
            
            MotionManager.applyTouchScale(holder.binding.root)
        }

        override fun getItemCount() = filteredList.size
    }
}
