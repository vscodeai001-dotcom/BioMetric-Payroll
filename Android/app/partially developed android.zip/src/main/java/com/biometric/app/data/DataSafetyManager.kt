package com.biometric.app.data

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.gson.Gson
import com.biometric.app.data.entity.*
import com.biometric.app.sync.FirebaseSyncManager
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class DataSafetyManager @Inject constructor(
    private val firebaseSync: FirebaseSyncManager
) {
    private val gson = Gson()
    private val auth = FirebaseAuth.getInstance()

    suspend fun recordDeletion(module: String, recordId: String, item: Any, itemName: String) {
        val snapshotJson = gson.toJson(item)
        val user = auth.currentUser
        
        // Extract shopId if available
        val shopId = when (item) {
            is Cashbook -> item.shopId
            is Employee -> item.shopId
            is Attendance -> item.shopId
            is Shop -> item.shopId
            is Investment -> item.shopId
            is FixedExpense -> item.shopId
            is Order -> item.shopId
            is ShopClosedDay -> item.shopId
            is AdvancePayment -> item.shopId
            is EmployeeHistory -> {
                // We might need to look up the employee to get shopId, 
                // but for now let's try to see if it's in the snapshot
                null
            }
            else -> null
        }

        val binItem = RecycleBinItem(
            recordId = recordId,
            shopId = shopId,
            module = module,
            actionType = "DELETED",
            snapshotJson = snapshotJson,
            userId = user?.uid ?: "unknown",
            userName = user?.displayName ?: "Unknown User",
            itemName = itemName,
            timestamp = System.currentTimeMillis()
        )
        
        firebaseSync.pushRecycleBin(binItem)
        
        // Also log to Audit
        recordAudit(module, "DELETE", itemName, null, snapshotJson, shopId)
    }

    suspend fun recordUpdate(module: String, recordId: String, oldItem: Any, newItem: Any, itemName: String) {
        val oldJson = gson.toJson(oldItem)
        val newJson = gson.toJson(newItem)
        val user = auth.currentUser

        // Extract shopId from new item
        val shopId = when (newItem) {
            is Cashbook -> newItem.shopId
            is Employee -> newItem.shopId
            is Attendance -> newItem.shopId
            is Shop -> newItem.shopId
            is Investment -> newItem.shopId
            is FixedExpense -> newItem.shopId
            is Order -> newItem.shopId
            is ShopClosedDay -> newItem.shopId
            is AdvancePayment -> newItem.shopId
            else -> null
        }
        
        val binItem = RecycleBinItem(
            recordId = recordId,
            shopId = shopId,
            module = module,
            actionType = "UPDATED",
            snapshotJson = newJson,
            previousValueJson = oldJson,
            userId = user?.uid ?: "unknown",
            userName = user?.displayName ?: "Unknown User",
            itemName = itemName,
            timestamp = System.currentTimeMillis()
        )
        
        firebaseSync.pushRecycleBin(binItem)
        
        // Also log to Audit
        recordAudit(module, "UPDATE", itemName, oldJson, newJson, shopId)
    }

    private suspend fun recordAudit(module: String, action: String, itemName: String, oldVal: String?, newVal: String?, shopId: String? = null) {
        val user = auth.currentUser
        val log = AuditLog(
            shopId = shopId ?: "Global",
            action = action,
            module = "$module: $itemName",
            oldValue = oldVal?.take(500), // Avoid giant logs
            newValue = newVal?.take(500),
            userDisplayName = user?.displayName ?: "Unknown",
            userId = user?.uid ?: "unknown",
            timestamp = System.currentTimeMillis()
        )
        firebaseSync.pushAuditLog(log)
    }

    suspend fun restoreItem(binItem: RecycleBinItem): Boolean {
        return try {
            val json = binItem.snapshotJson
            when (binItem.module) {
                "CASHBOOK" -> firebaseSync.pushCashbookEntry(gson.fromJson(json, Cashbook::class.java))
                "STAFF" -> {
                    val employee = gson.fromJson(json, Employee::class.java)
                    employee.isActive = true
                    employee.terminateDate = null
                    firebaseSync.pushEmployee(employee)
                }
                "ATTENDANCE" -> firebaseSync.pushAttendance(gson.fromJson(json, Attendance::class.java))
                "SHOP" -> {
                    val shop = gson.fromJson(json, Shop::class.java)
                    shop.isActive = true // Ensure restored shop is active
                    firebaseSync.pushShop(shop)
                }
                "INVESTMENT" -> firebaseSync.pushInvestment(gson.fromJson(json, Investment::class.java))
                "EXPENSE" -> firebaseSync.pushFixedExpense(gson.fromJson(json, FixedExpense::class.java))
                "ORDER" -> firebaseSync.pushOrder(gson.fromJson(json, Order::class.java))
                "ITEM" -> {
                    val item = gson.fromJson(json, Item::class.java)
                    item.isActive = true
                    firebaseSync.pushItem(item)
                }
                "SUPPLIER" -> firebaseSync.pushSupplier(gson.fromJson(json, Supplier::class.java))
                "PURCHASE" -> firebaseSync.pushPurchase(gson.fromJson(json, Purchase::class.java))
                "REMINDER" -> firebaseSync.pushReminder(gson.fromJson(json, Reminder::class.java))
                "CLOSED_DAY" -> firebaseSync.pushClosedDay(gson.fromJson(json, ShopClosedDay::class.java))
                "ADVANCE" -> firebaseSync.pushAdvance(gson.fromJson(json, AdvancePayment::class.java))
                "STAFF_HISTORY" -> firebaseSync.pushHistory(gson.fromJson(json, EmployeeHistory::class.java))
                else -> return false
            }
            
            // Log restore action
            recordAudit(binItem.module, "RESTORE", binItem.itemName, null, binItem.snapshotJson, binItem.shopId)
            
            // Remove from bin after successful restore
            firebaseSync.deleteRecycleBinItem(binItem.id)
            true
        } catch (e: Exception) {
            Log.e("DataSafetyManager", "Restore failed", e)
            false
        }
    }
}
