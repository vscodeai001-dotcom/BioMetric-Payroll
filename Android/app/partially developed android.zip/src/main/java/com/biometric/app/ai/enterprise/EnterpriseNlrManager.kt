package com.biometric.app.ai.enterprise

import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.*
import kotlinx.coroutines.flow.first
import java.util.*

class EnterpriseNlrManager(
    private val repository: MainRepository,
    private val sqlGenerator: SqlGenerator,
    private val sqlExecutor: SqlExecutor,
    private val nativeEngine: NativeIntelligenceEngine
) {

    private val conversationHistory = mutableListOf<String>()

    suspend fun processQuery(query: String, shopId: String?): EnterpriseResponse {
        // 1. NATIVE INTELLIGENCE FIRST (Instant, Offline, Never Fails)
        val nativeResult = nativeEngine.analyze(query, shopId)
        if (nativeResult != null) {
            updateHistory(query, nativeResult)
            return EnterpriseResponse(nativeResult, "NATIVE_LOGIC")
        }

        val historyStr = conversationHistory.joinToString("\n")
        val sql = sqlGenerator.generateSql(query, historyStr, shopId)

        // SILENT FALLBACK: If SQL fails, don't show error. Show heuristic analysis.
        if (sql.startsWith("ERROR") || sql.contains("OUT_OF_SCOPE")) {
            return performHeuristicFallback(query, shopId, sql)
        }

        // Security Validation
        if (!isSqlSafe(sql)) {
            return performHeuristicFallback(query, shopId, "SQL_SECURITY_BLOCK")
        }

        try {
            val neededTables = detectNeededTables(sql)
            val data = fetchCollections(neededTables, shopId)
            val rawResults = sqlExecutor.populateAndExecute(sql, data)
            
            if (rawResults.isNotEmpty() && rawResults[0].containsKey("ERROR")) {
                return performHeuristicFallback(query, shopId, sql)
            }

            val formattedAnswer = formatResults(query, sql, rawResults)
            updateHistory(query, formattedAnswer)
            return EnterpriseResponse(formattedAnswer, sql, rawResults)

        } catch (e: Exception) {
            return performHeuristicFallback(query, shopId, sql)
        }
    }

    private suspend fun performHeuristicFallback(query: String, shopId: String?, originalSql: String): EnterpriseResponse {
        android.util.Log.d("EnterpriseNLR", "Heuristic fallback triggered for: $query. Error SQL: $originalSql")
        
        // Use Native Engine directly as a fallback for specific business entities
        val nativeResult = nativeEngine.analyze(query, shopId)
        if (nativeResult != null) return EnterpriseResponse(nativeResult, "FALLBACK_NATIVE")

        val q = query.lowercase()
        val range = com.biometric.app.util.DateRangeUtil.getRangeForPeriod("Monthly", System.currentTimeMillis(), true)
        val metrics = repository.getShopMetricsFlow(shopId ?: "", range.first, range.second).first()
        
        val message = when {
            q.contains("sale") -> "I couldn't find specific sales breakdown for that request, but your **Total Sales** for this month is **₹%,.2f**.".format(metrics.sales)
            q.contains("profit") -> "I couldn't calculate the specific profit trend, but your **Net Profit** for this month is **₹%,.2f**.".format(metrics.profit)
            q.contains("expense") || q.contains("spend") -> "I analyzed your expenses: Total outflows for this month are **₹%,.2f**.".format(metrics.expense + metrics.fixed)
            else -> "I couldn't find the exact details for \"$query\". \n\nHowever, looking at your overall business this month: \n• Sales: ₹%,.2f\n• Profit: ₹%,.2f\n• Expenses: ₹%,.2f".format(metrics.sales, metrics.profit, metrics.expense + metrics.fixed)
        }
        
        return EnterpriseResponse(message, originalSql)
    }

    private fun updateHistory(query: String, answer: String) {
        conversationHistory.add("User: $query")
        conversationHistory.add("AI: $answer")
        if (conversationHistory.size > 10) {
            conversationHistory.removeAt(0)
            conversationHistory.removeAt(0)
        }
    }

    private fun isSqlSafe(sql: String): Boolean {
        val upperSql = sql.trim().uppercase()
        val dangerousKeywords = listOf("DELETE", "DROP", "TRUNCATE", "UPDATE", "ALTER", "CREATE", "INSERT", "MERGE", "EXEC", "REPLACE")
        return dangerousKeywords.none { upperSql.contains(it) } && upperSql.startsWith("SELECT")
    }

    private fun detectNeededTables(sql: String): Set<String> {
        val tables = listOf("shops", "items", "orders", "order_items", "cashbook", "employees", "attendance", "fixed_expenses", "investments", "inventory")
        return tables.filter { sql.contains(it, ignoreCase = true) }.toSet()
    }

    private suspend fun fetchCollections(tables: Set<String>, shopId: String?): Map<String, List<Any>> {
        val data = mutableMapOf<String, List<Any>>()
        
        if (tables.contains("shops")) data["shops"] = repository.getAllShops().first()
        if (tables.contains("items")) data["items"] = repository.getActiveItems().first()
        if (tables.contains("orders")) data["orders"] = repository.allOrdersFlow.first().filter { shopId == null || it.shopId == shopId }
        if (tables.contains("order_items")) data["order_items"] = repository.firebaseSync.getDataFlow<OrderItem>("order_items").first()
        if (tables.contains("cashbook")) data["cashbook"] = repository.allCashbookFlow.first().filter { shopId == null || it.shopId == shopId }
        if (tables.contains("employees")) data["employees"] = repository.getAllEmployees().first().filter { shopId == null || it.shopId == shopId }
        if (tables.contains("attendance")) data["attendance"] = repository.allAttendanceFlow.first().filter { shopId == null || it.shopId == shopId }
        if (tables.contains("fixed_expenses")) data["fixed_expenses"] = repository.getAllFixedExpenses().first().filter { shopId == null || it.shopId == shopId }
        if (tables.contains("investments")) data["investments"] = if (shopId != null) repository.getInvestments(shopId).first() else emptyList()
        if (tables.contains("inventory")) data["inventory"] = if (shopId != null) repository.getInventoryItems(shopId).first() else emptyList()

        return data
    }

    private fun formatResults(query: String, sql: String, results: List<Map<String, Any?>>): String {
        if (results.isEmpty()) return "I couldn't find any records matching that specific request in your business data."
        
        // CASE 1: Single Numeric Result (Total, Max, Min)
        if (results.size == 1 && results[0].size == 1) {
            val key = results[0].keys.first()
            val value = results[0].values.first()
            
            if (value == null || (value is Number && value.toDouble() == 0.0)) {
                return "I found no data for **${key.replace("_", " ")}** in that period."
            }
            
            return when (value) {
                is Double, is Float -> String.format(Locale.getDefault(), "The calculated **%s** is **₹%,.2f** ✨", key.replace("_", " "), value)
                is Long, is Int -> "The total **${key.replace("_", " ")}** is **$value**."
                else -> "The result for **${key.replace("_", " ")}** is **$value**."
            }
        }

        // CASE 2: List-based Result (Breakdown, Ranking, List)
        val sb = StringBuilder()
        
        // Detect if we have currency/amount columns and date columns
        val amountKeys = results[0].keys.filter { it.contains("amount", true) || it.contains("total", true) || it.contains("profit", true) || it.contains("sales", true) || it.contains("price", true) }
        val dateKeys = results[0].keys.filter { it.contains("date", true) || it.contains("time", true) || it.contains("at", true) || it.contains("day", true) }
        val labelKeys = results[0].keys.filter { !amountKeys.contains(it) && !dateKeys.contains(it) }

        if (amountKeys.isNotEmpty() && (dateKeys.isNotEmpty() || labelKeys.isNotEmpty())) {
            sb.append("📊 **Analysis Results**\n\n")
            var grandTotal = 0.0
            
            results.take(31).forEach { row ->
                val label = row[labelKeys.firstOrNull() ?: ""]?.toString() ?: ""
                val dateVal = row[dateKeys.firstOrNull() ?: ""]
                val amtVal = row[amountKeys.firstOrNull() ?: ""] as? Number
                
                val dateStr = try {
                    if (dateVal is Number && dateVal.toLong() > 1000000000000L) {
                        java.text.SimpleDateFormat("dd MMM (EEE)", Locale.getDefault()).format(java.util.Date(dateVal.toLong()))
                    } else dateVal?.toString() ?: ""
                } catch (_: Exception) { dateVal?.toString() ?: "" }

                val rowLabel = if (dateStr.isNotEmpty() && label.isNotEmpty()) "$dateStr ($label)"
                              else if (dateStr.isNotEmpty()) dateStr
                              else label

                if (amtVal != null) {
                    sb.append("• $rowLabel → **₹%,.2f**\n".format(amtVal.toDouble()))
                    grandTotal += amtVal.toDouble()
                } else {
                    sb.append("• $rowLabel → **${row[amountKeys.first()]}**\n")
                }
            }
            
            if (results.size > 1 && grandTotal != 0.0) {
                sb.append("\n💰 **Total: ₹%,.2f**".format(grandTotal))
            }
            
            if (results.size > 31) {
                sb.append("\n\n*...and ${results.size - 31} more records.*")
            }
        } else {
            // Generic Table Format
            sb.append("📋 **Details Found**\n\n")
            results.take(10).forEach { row ->
                sb.append("• ")
                row.forEach { (k, v) ->
                    val displayVal = if (v is Number && (k.contains("amount") || k.contains("total") || k.contains("price"))) "₹%,.2f".format(v.toDouble()) else v.toString()
                    sb.append("**${k.replace("_", " ")}**: $displayVal | ")
                }
                sb.append("\n")
            }
        }
        
        return sb.toString()
    }
}

data class EnterpriseResponse(
    val text: String,
    val generatedSql: String,
    val rawData: List<Map<String, Any?>> = emptyList()
)
