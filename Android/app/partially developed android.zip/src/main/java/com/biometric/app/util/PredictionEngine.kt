package com.biometric.app.util

import com.biometric.app.data.RawMetrics
import com.biometric.app.data.entity.PriceHistory
import java.util.Calendar
import kotlin.math.max
import kotlin.math.pow
import kotlin.math.sqrt

object PredictionEngine {

    data class FinancialForecast(
        val pastValue: RawMetrics,
        val rollingAverage: RawMetrics,
        val aiExpected: RawMetrics,
        val seasonalityImpact: Double,
        val growthTrend: Double, // Percentage
    )

    /**
     * Centralized Financial Prediction Logic
     * Uses Weighted Rolling Average (50/30/20) + Seasonality + Trend analysis
     */
    fun calculateForecast(
        current: RawMetrics,
        p1: RawMetrics, // Same duration past
        p2: RawMetrics,
        p3: RawMetrics
    ): FinancialForecast {
        val result = FinanceEngine.getFullForecast(current, p1, p2, p3)

        return FinancialForecast(
            pastValue = result.past,
            rollingAverage = result.rolling,
            aiExpected = result.expected,
            seasonalityImpact = 0.0,
            growthTrend = result.growthTrend
        )
    }

    data class StockPrediction(
        val suggestedDaily: Double,
        val suggestedWeekly: Double,
        val insight: String,
        val confidence: Int,
        val avgGapDays: Int,
        val daysUntilEmpty: Int? = null,
        val outOfStockDate: Long? = null
    )

    fun predictStockNeed(history: List<PriceHistory>, currentStock: Double = 0.0): StockPrediction {
        if (history.size < 2) {
            val lastQty = history.firstOrNull()?.quantity ?: 0.0
            return StockPrediction(lastQty / 7.0, lastQty, "Need more purchase history for better prediction.", 30, 7)
        }

        val sorted = history.sortedBy { it.date }
        val gaps = mutableListOf<Long>()
        for (i in 1 until sorted.size) {
            val gap = sorted[i].date - sorted[i-1].date
            if (gap > (3600000 * 12)) gaps.add(gap)
        }
        val avgGapMillis = if (gaps.isNotEmpty()) gaps.average() else 7.0 * 86400000L
        val avgGapDays = (avgGapMillis / 86400000.0).toInt().coerceAtLeast(1)
        
        val firstDate = sorted.first().date
        val xValues = sorted.map { ((it.date - firstDate) / 86400000.0) }
        val yValues = sorted.map { it.quantity }
        val regression = calculateLinearRegression(xValues, yValues)
        
        val historyDays = ((sorted.last().date - sorted.first().date) / 86400000.0).coerceAtLeast(1.0)
        val totalPurchased = sorted.sumOf { it.quantity }
        val dailyConsumptionRate = totalPurchased / historyDays

        var daysUntilEmpty: Int? = null
        var outOfStockDate: Long? = null
        if (currentStock > 0 && dailyConsumptionRate > 0) {
            daysUntilEmpty = (currentStock / dailyConsumptionRate).toInt()
            outOfStockDate = System.currentTimeMillis() + (daysUntilEmpty * 86400000L)
        }

        val confidence = (history.size * 8).coerceAtMost(98)
        val trend = when {
            regression.slope > 0.05 -> "Increasing 📈"
            regression.slope < -0.05 -> "Decreasing 📉"
            else -> "Stable ↔️"
        }
        
        val stockStatus = when {
            daysUntilEmpty == null -> ""
            daysUntilEmpty <= 1 -> " | ⚠ DEPLETION IMMINENT"
            daysUntilEmpty <= 3 -> " | ⏳ ~$daysUntilEmpty days left"
            else -> " | ✅ Sufficient"
        }

        return StockPrediction(
            suggestedDaily = max(dailyConsumptionRate, regression.predict(xValues.last() + 1)),
            suggestedWeekly = dailyConsumptionRate * 7,
            insight = "Consumption is $trend. Typically refilled every $avgGapDays days$stockStatus.",
            confidence = confidence,
            avgGapDays = avgGapDays,
            daysUntilEmpty = daysUntilEmpty,
            outOfStockDate = outOfStockDate
        )
    }

    fun detectAnomaly(newItem: PriceHistory, history: List<PriceHistory>): String? {
        if (history.size < 3) return null
        val prices = history.map { it.price }
        val avgPrice = prices.average()
        val stdDev = sqrt(prices.asSequence().map { (it - avgPrice).pow(2.0) }.average())
        if (newItem.price > avgPrice + (2 * stdDev) || newItem.price > avgPrice * 1.3) {
            val percent = ((newItem.price - avgPrice) / avgPrice * 100).toInt()
            return "Price Spike: ${newItem.itemName} is $percent% more expensive than your typical average."
        }
        return null
    }

    private fun calculateLinearRegression(x: List<Double>, y: List<Double>): RegressionResult {
        val n = x.size
        val sumX = x.sum()
        val sumY = y.sum()
        val sumXY = x.zip(y).sumOf { it.first * it.second }
        val sumX2 = x.sumOf { it * it }
        val denominator = (n * sumX2) - (sumX * sumX)
        if (denominator == 0.0) return RegressionResult(0.0, y.average())
        val slope = ((n * sumXY) - (sumX * sumY)) / denominator
        val intercept = (sumY - (slope * sumX)) / n
        return RegressionResult(slope, intercept)
    }

    data class RegressionResult(val slope: Double, val intercept: Double) {
        fun predict(x: Double) = max(0.0, (slope * x) + intercept)
    }
}
