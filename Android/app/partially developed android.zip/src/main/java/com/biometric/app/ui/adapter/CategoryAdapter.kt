package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ItemCategoryGridBinding

class CategoryAdapter(private val onCategoryClick: (String?) -> Unit) :
    ListAdapter<CategoryAdapter.CategoryDisplayItem, CategoryAdapter.CategoryViewHolder>(CategoryDiffCallback()) {

    data class CategoryDisplayItem(
        val name: String?,
        val isSelected: Boolean
    )

    fun submitList(newCategories: List<String?>, selected: Set<String>) {
        val displayItems = newCategories.map { category ->
            val isSelected = if (category == null) {
                selected.isEmpty()
            } else {
                selected.contains(category)
            }
            CategoryDisplayItem(category, isSelected)
        }
        super.submitList(displayItems)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CategoryViewHolder {
        val binding = ItemCategoryGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CategoryViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CategoryViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CategoryViewHolder(private val binding: ItemCategoryGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        
        fun bind(item: CategoryDisplayItem) {
            val category = item.name
            binding.tvCategoryName.text = category ?: "All"
            
            if (item.isSelected) {
                binding.root.setCardBackgroundColor(ContextCompat.getColor(binding.root.context, R.color.colorPrimary))
                binding.tvCategoryName.setTextColor(ContextCompat.getColor(binding.root.context, R.color.white))
                binding.root.strokeWidth = 0
                binding.tvCategoryName.typeface = android.graphics.Typeface.DEFAULT_BOLD
            } else {
                binding.root.setCardBackgroundColor(ContextCompat.getColor(binding.root.context, R.color.card_bg))
                binding.tvCategoryName.setTextColor(ContextCompat.getColor(binding.root.context, R.color.colorPrimary))
                binding.root.strokeWidth = 1
                binding.tvCategoryName.typeface = android.graphics.Typeface.DEFAULT
            }

            binding.root.setOnClickListener { onCategoryClick(category) }
        }
    }

    class CategoryDiffCallback : DiffUtil.ItemCallback<CategoryDisplayItem>() {
        override fun areItemsTheSame(oldItem: CategoryDisplayItem, newItem: CategoryDisplayItem): Boolean {
            return oldItem.name == newItem.name
        }

        override fun areContentsTheSame(oldItem: CategoryDisplayItem, newItem: CategoryDisplayItem): Boolean {
            return oldItem == newItem
        }
    }
}
