package com.biometric.app.util

import android.view.View
import android.widget.TextView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.LifecycleOwner
import com.biometric.app.R
import com.biometric.app.databinding.LayoutBrewingLoaderBinding
import kotlinx.coroutines.*
import java.util.Locale

object PremiumLoader {

    enum class ScreenType {
        GENERIC, ATTENDANCE, STOCK, CASHBOOK, POS, REPORTS, INVESTMENT, 
        COMPARISON, FORECAST, STAFF, SALARY, HEALTH, AUDIT, RECYCLE_BIN, 
        RISK, SALES_PATTERN, SPEND_ANALYSIS, SMART_STOCK
    }

    private val activeJobs = mutableMapOf<Int, Job>()

    /**
     * Shows a premium screen-specific loader with a "Smart Delay".
     */
    fun show(
        binding: LayoutBrewingLoaderBinding, 
        type: ScreenType = ScreenType.GENERIC,
        scope: CoroutineScope? = null,
        immediate: Boolean = false,
        lifecycleOwner: LifecycleOwner? = null
    ) {
        showInternal(binding.root, type, scope, immediate, binding.hashCode(), lifecycleOwner)
    }

    fun show(
        binding: com.biometric.app.databinding.LayoutTeaLoadingBinding,
        type: ScreenType = ScreenType.GENERIC,
        scope: CoroutineScope? = null,
        immediate: Boolean = false,
        lifecycleOwner: LifecycleOwner? = null
    ) {
        showInternal(binding.root, type, scope, immediate, binding.hashCode(), lifecycleOwner)
    }

    private fun showInternal(
        root: View, 
        type: ScreenType, 
        scope: CoroutineScope?, 
        immediate: Boolean,
        bindingId: Int,
        lifecycleOwner: LifecycleOwner?
    ) {
        if (activeJobs.containsKey(bindingId) && root.visibility == View.VISIBLE) {
            return // Already showing and loop is running
        }
        activeJobs[bindingId]?.cancel()
        
        // Preparation
        if (!immediate) {
            root.alpha = 0f
        } else {
            root.alpha = 1f
            root.visibility = View.VISIBLE
        }
        
        // Auto-cleanup on lifecycle destroy
        lifecycleOwner?.lifecycle?.addObserver(LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_DESTROY) {
                activeJobs[bindingId]?.cancel()
                activeJobs.remove(bindingId)
            }
        })
        
        scope?.let { s ->
            val job = s.launch {
                if (!immediate) {
                    delay(150)
                    withContext(Dispatchers.Main) {
                        setupUI(root, type)
                        root.visibility = View.VISIBLE
                        root.animate().alpha(1f).setDuration(400).start()
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        setupUI(root, type)
                        root.visibility = View.VISIBLE
                        root.alpha = 1f
                    }
                }

                runProgressLoop(root, bindingId)
            }
            activeJobs[bindingId] = job
        }
    }

    private fun setupUI(root: View, type: ScreenType) {
        val lottieAnim = root.findViewById<com.airbnb.lottie.LottieAnimationView>(R.id.lottieLoadingAnim)
        val tvBrewingLabel = root.findViewById<TextView>(R.id.tvBrewingLabel)
        val tvLoaderIcon = root.findViewById<TextView>(R.id.tvLoaderIcon)
        val ivNeonRing = root.findViewById<android.widget.ImageView>(R.id.ivNeonRing)
        val cardLoader = root.findViewById<View>(R.id.cardLoader)
        val progressIndicator = root.findViewById<com.google.android.material.progressindicator.CircularProgressIndicator>(R.id.progressIndicator)
        val tvProgressPercent = root.findViewById<TextView>(R.id.tvProgressPercent)

        progressIndicator?.progress = 0
        tvProgressPercent?.text = "0%"

        val (animRes, emoji) = when(type) {
            ScreenType.REPORTS -> R.raw.anim_detailed_reports to "📊"
            ScreenType.HEALTH -> R.raw.anim_business_health to "💪"
            ScreenType.FORECAST -> R.raw.anim_ai_forecast to "🔮"
            ScreenType.CASHBOOK -> R.raw.anim_cashbook to "📖"
            ScreenType.STOCK -> R.raw.anim_stock to "📦"
            ScreenType.POS -> R.raw.anim_pos_sales to "🛒"
            ScreenType.ATTENDANCE -> R.raw.anim_attendance to "👥"
            ScreenType.RISK -> R.raw.anim_risk_alerts to "🚨"
            ScreenType.INVESTMENT -> R.raw.anim_investment_recovery to "🔄"
            ScreenType.AUDIT -> R.raw.anim_audit_trail to "🛡️"
            ScreenType.SPEND_ANALYSIS -> R.raw.anim_spend_analysis to "📉"
            ScreenType.SALES_PATTERN -> R.raw.anim_sales_patterns to "📈"
            ScreenType.SMART_STOCK -> R.raw.anim_stock to "🧠"
            ScreenType.RECYCLE_BIN -> R.raw.anim_empty_trash to "🗑️"
            else -> R.raw.anim_tea_cup_hero to "🍵"
        }
        lottieAnim?.setAnimation(animRes)
        lottieAnim?.playAnimation()
        tvLoaderIcon?.text = emoji

        val label = when(type) {
            ScreenType.POS -> "🛒 Preparing POS..."
            ScreenType.REPORTS -> "📊 Analyzing Reports..."
            ScreenType.STOCK -> "📦 Loading Inventory..."
            ScreenType.CASHBOOK -> "📖 Opening Ledger..."
            ScreenType.ATTENDANCE -> "👥 Staff Records..."
            ScreenType.HEALTH -> "💪 Vitality Check..."
            ScreenType.FORECAST -> "🔮 Consulting AI..."
            ScreenType.AUDIT -> "🛡️ Security Audit..."
            ScreenType.INVESTMENT -> "🔄 Recovery Tracking..."
            ScreenType.RISK -> "🚨 Risk Assessment..."
            ScreenType.SPEND_ANALYSIS -> "🧾 Spend Analysis..."
            ScreenType.SALES_PATTERN -> "📈 Patterns..."
            ScreenType.SMART_STOCK -> "🧠 Smart Stock..."
            else -> "🍵 Brewing..."
        }
        tvBrewingLabel?.text = label

        ivNeonRing?.let {
            val rotate = android.view.animation.RotateAnimation(0f, 360f, 1, 0.5f, 1, 0.5f).apply {
                duration = 1500; repeatCount = -1; interpolator = android.view.animation.LinearInterpolator()
            }
            it.startAnimation(rotate)
        }

        cardLoader?.let {
            it.scaleX = 0.5f; it.scaleY = 0.5f
            it.animate().scaleX(1f).scaleY(1f).setDuration(700).setInterpolator(android.view.animation.OvershootInterpolator(1.3f)).start()
        }
    }

    private suspend fun runProgressLoop(root: View, bindingId: Int) {
        val tvSubLabel = root.findViewById<TextView>(R.id.tvSubLabel)
        val tvProgressPercent = root.findViewById<TextView>(R.id.tvProgressPercent)
        val progressIndicator = root.findViewById<com.google.android.material.progressindicator.CircularProgressIndicator>(R.id.progressIndicator)
        
        val tips = listOf(
            "Tip: Long-press a shop to edit its details.",
            "Tip: You can use Voice Chat for quick insights.",
            "Tip: Set monthly targets to track growth.",
            "Tip: Cloud backup is automated every 24 hours.",
            "Tip: Check 'Risk Alerts' for financial leakages."
        )
        var tipIndex = 0
        var progress = 0
        
        coroutineScope {
            while (isActive && root.visibility == View.VISIBLE) {
                if (progress % 20 == 0) {
                    withContext(Dispatchers.Main) {
                        tvSubLabel?.animate()?.alpha(0f)?.setDuration(400)?.withEndAction {
                            tvSubLabel.text = tips[tipIndex % tips.size]
                            tipIndex++
                            tvSubLabel.animate().alpha(0.85f).setDuration(500).start()
                        }?.start()
                    }
                }
                if (progress < 100) {
                    progress += if (progress < 60) (2..4).random() else 1
                    if (progress > 100) progress = 100
                    withContext(Dispatchers.Main) {
                        progressIndicator?.setProgress(progress, true)
                        tvProgressPercent?.text = String.format(Locale.getDefault(), "%d%%", progress)
                    }
                }
                delay(if (progress < 40) 80 else if (progress < 80) 150 else 400)
            }
        }
        activeJobs.remove(bindingId)
    }

    fun hide(binding: LayoutBrewingLoaderBinding) {
        val id = binding.hashCode()
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        binding.root.visibility = View.GONE
    }

    fun hide(binding: com.biometric.app.databinding.LayoutTeaLoadingBinding) {
        val id = binding.hashCode()
        activeJobs[id]?.cancel()
        activeJobs.remove(id)
        binding.root.visibility = View.GONE
    }
}
