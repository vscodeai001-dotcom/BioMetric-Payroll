package com.biometric.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.*
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.data.entity.Supplier
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class SpendAnalysisViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    val state: StateFlow<SpendAnalysisState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        val normalizedPeriod = period.lowercase().replace("-", " ").trim()
        val isUptoDate = normalizedPeriod == "up to date"

        val currentRange = DateRangeUtil.getRangeForPeriod(period, date, isMatchingDays = isUptoDate)
        val start = currentRange.first
        val end = currentRange.second
        
        val p1Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; if (isUptoDate) c.add(Calendar.MONTH, -1) else DateRangeUtil.shiftPeriod(period, c, -1); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = isUptoDate) }
        val p2Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; if (isUptoDate) c.add(Calendar.MONTH, -2) else DateRangeUtil.shiftPeriod(period, c, -2); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = isUptoDate) }
        val p3Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; if (isUptoDate) c.add(Calendar.MONTH, -2) else DateRangeUtil.shiftPeriod(period, c, -2); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = isUptoDate) }

        val cacheKey = "spend_analysis_${shopId}_${period}_${start}_${end}"
        val cached = repository.getListCache<SpendAnalysisState>(cacheKey).firstOrNull()

        flow {
            // UNIFORM LOADING: Only set loading true if no cache available
            emit((cached ?: SpendAnalysisState()).copy(isLoading = cached == null))

            emitAll(combine(
                repository.getCashbookEntriesForPeriod(shopId, start, end).onStart { emit(emptyList()) },
                repository.getProjectedSalaryFlow(shopId, start, end, true).onStart { emit(0.0) },
                repository.getShopMetricsFlow(shopId, p1Range.first, p1Range.second).onStart { emit(RawMetrics()) },
                repository.getShopMetricsFlow(shopId, p2Range.first, p2Range.second).onStart { emit(RawMetrics()) },
                repository.getShopMetricsFlow(shopId, p3Range.first, p3Range.second).onStart { emit(RawMetrics()) },
                repository.getShopSuppliers(shopId).onStart { emit(emptyList()) },
                repository.getFullDayWiseDataFlow(shopId, start, end).onStart { emit(emptyList()) },
                repository.getCashFlowSummary(shopId, start, end, 0.0).onStart { emit(null) }
            ) { args: Array<Any?> ->
                // Use withContext to ensure heavy mapping doesn't block the combine collector
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                    @Suppress("UNCHECKED_CAST") val periodCashbookAll = args[0] as List<Cashbook>
                    val totalSalary = args[1] as Double
                    val p1 = args[2] as RawMetrics
                    val p2 = args[3] as RawMetrics
                    val p4 = args[4] as RawMetrics // renamed to p4 to avoid shadowing p3 if needed
                    @Suppress("UNCHECKED_CAST") val suppliers = args[5] as List<Supplier>
                    @Suppress("UNCHECKED_CAST") val currentDays = args[6] as List<DayData>
                    val summary = (args[7] as CashFlowSummary?)?.copy(salary = totalSalary)

                    val baselinePurchase = (p1.expense + p2.expense + (args[4] as RawMetrics).expense) / 3.0

                    val periodCashbook = periodCashbookAll.filter { it.transactionType == "OUT" }
                    val totalPurchase = summary?.totalOut ?: 0.0
                    val totalFixed = summary?.fixedExpenses ?: 0.0
                    val totalIn = summary?.totalIn ?: 0.0
                    val totalBusinessSpending = totalPurchase + totalSalary + totalFixed
                    val activeDays = currentDays.count { it.totalIn > 0 || it.totalOut > 0 || it.salaryEarned > 0 }.coerceAtLeast(1)

                    val allCategories = mutableListOf<SpendCategory>()
                    val purchaseOnlyEntries = periodCashbook.filter { !FinancialCategory.isSalary(it.category, it.description) && !FinancialCategory.isAdvance(it.category) }

                    purchaseOnlyEntries.groupBy { it.category }.forEach { (cat, list) ->
                        val amt = list.sumOf { it.amount }
                        allCategories.add(SpendCategory(cat, amt, if (totalBusinessSpending > 0) (amt / totalBusinessSpending) * 100 else 0.0, getIconForCategory(cat)))
                    }
                    if (totalSalary > 0) allCategories.add(SpendCategory("Staff Salary", totalSalary, if (totalBusinessSpending > 0) (totalSalary / totalBusinessSpending) * 100 else 0.0, "👨‍💼", false))
                    if (totalFixed > 0) allCategories.add(SpendCategory("Fixed Expenses", totalFixed, if (totalBusinessSpending > 0) (totalFixed / totalBusinessSpending) * 100 else 0.0, "🏠", false))

                    val itemSpends = purchaseOnlyEntries.filter { !it.description.isNullOrBlank() }.groupBy { it.description!!.uppercase().trim() }
                        .map { (name, entries) ->
                            val qty = entries.sumOf { it.quantity?.coerceAtLeast(1.0) ?: 1.0 }
                            val spend = entries.sumOf { it.amount }
                            SpendItem(name, qty, spend, if (qty > 0) spend / qty else 0.0)
                        }.sortedByDescending { it.totalSpend }

                    val supplierSpends = purchaseOnlyEntries.groupBy { entry -> suppliers.find { s -> entry.description?.contains(s.name, true) == true }?.name ?: "Market/Others" }
                        .map { (name, list) -> val amt = list.sumOf { it.amount }; SupplierSpend(name, amt, if (totalPurchase > 0) (amt / totalPurchase) * 100 else 0.0) }.sortedByDescending { it.amount }

                    val result = SpendAnalysisState(
                        totalBusinessSpending = totalBusinessSpending, totalPurchase = totalPurchase, totalSalary = totalSalary, totalFixed = totalFixed,
                        avgDailyPurchase = totalPurchase / activeDays, purchaseToSalesRatio = if (totalIn > 0) (totalPurchase / totalIn) * 100 else 0.0,
                        trendPercentage = if (baselinePurchase > 0) ((totalPurchase - baselinePurchase) / baselinePurchase) * 100 else 0.0,
                        allExpenseCategories = allCategories.sortedByDescending { it.amount }, items = itemSpends, suppliers = supplierSpends,
                        trendData = currentDays.map { SpendTrendPoint(it.displayDate.split(",")[0], it.totalOut, it.calendar.timeInMillis) }.reversed(),
                        isLoading = false
                    )

                    val stateWithInsights = result.copy(insights = generateInsights(result))

                    repository.saveListCache(cacheKey, listOf(stateWithInsights))
                    stateWithInsights
                }
            }.onStart { if (cached == null) emit(SpendAnalysisState(isLoading = true)) })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SpendAnalysisState())

    fun loadAnalysis(shopId: String, period: String, date: Long) { _params.value = Triple(shopId, period, date) }

    private fun generateInsights(state: SpendAnalysisState): List<String> {
        val insights = mutableListOf<String>()
        
        // 1. Purchase to Sales Ratio
        if (state.purchaseToSalesRatio > 40.0) {
            insights.add("⚠️ High Purchase Ratio: Your purchases are ${String.format(Locale.getDefault(), "%.1f%%", state.purchaseToSalesRatio)} of sales. Consider optimizing inventory.")
        } else if (state.purchaseToSalesRatio > 0) {
            insights.add("✅ Healthy Purchase Ratio: ${String.format(Locale.getDefault(), "%.1f%%", state.purchaseToSalesRatio)} of sales is within safe limits.")
        }

        // 2. Trend Analysis
        if (state.trendPercentage > 10.0) {
            insights.add("📉 Spending Hike: Purchases are up ${String.format(Locale.getDefault(), "%.1f%%", state.trendPercentage)} compared to the 3-month baseline.")
        } else if (state.trendPercentage < -10.0) {
            insights.add("🚀 Cost Efficiency: Spending has decreased by ${String.format(Locale.getDefault(), "%.1f%%", kotlin.math.abs(state.trendPercentage))} - Great job!")
        }

        // 3. Top Category
        state.allExpenseCategories.firstOrNull()?.let {
            insights.add("📊 Top Expense: ${it.icon} ${it.category} accounts for ${String.format(Locale.getDefault(), "%.1f%%", it.percentage)} of total business spending.")
        }

        // 4. Supplier Concentration
        state.suppliers.firstOrNull()?.let {
            if (it.share > 60.0 && it.name != "Market/Others") {
                insights.add("🤝 Supplier Dependency: ${it.name} controls ${String.format(Locale.getDefault(), "%.1f%%", it.share)} of your procurement.")
            }
        }

        // 5. Daily Average Suggestion
        if (state.avgDailyPurchase > 0) {
            insights.add("🛒 Spending Pattern: Your daily procurement average is ₹${String.format(Locale.getDefault(), "%,.0f", state.avgDailyPurchase)}.")
        }

        if (insights.isEmpty()) insights.add("🔍 No significant spending anomalies detected for this period.")
        return insights
    }

    private fun getIconForCategory(cat: String): String = when { cat.contains("MILK", true) -> "🥛"; cat.contains("GAS", true) -> "🔥"; cat.contains("RENT", true) -> "🏠"; else -> "📦" }
}

data class SpendCategory(val category: String, val amount: Double, val percentage: Double, val icon: String, val isPurchase: Boolean = true)
data class SpendItem(val name: String, val qty: Double, val totalSpend: Double, val avgPrice: Double, val trend: Double = 0.0, val trendIcon: String = "➖")
data class SupplierSpend(val name: String, val amount: Double, val share: Double)
data class SpendTrendPoint(val label: String, val amount: Double, val date: Long)
data class SpendAnalysisState(
    val totalBusinessSpending: Double = 0.0, val totalPurchase: Double = 0.0, val totalSalary: Double = 0.0, val totalFixed: Double = 0.0,
    val avgDailyPurchase: Double = 0.0, val purchaseToSalesRatio: Double = 0.0, val trendPercentage: Double = 0.0,
    val allExpenseCategories: List<SpendCategory> = emptyList(), val items: List<SpendItem> = emptyList(), val suppliers: List<SupplierSpend> = emptyList(),
    val insights: List<String> = emptyList(), val trendData: List<SpendTrendPoint> = emptyList(), val isLoading: Boolean = false
)
