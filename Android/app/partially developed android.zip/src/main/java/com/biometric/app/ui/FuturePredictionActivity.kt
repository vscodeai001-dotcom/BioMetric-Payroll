package com.biometric.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.core.content.edit
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityFuturePredictionBinding
import com.biometric.app.databinding.ItemFuturePredictionBinding
import com.biometric.app.sync.FirebaseSyncManager
import com.biometric.app.ui.viewmodel.FuturePredictionState
import com.biometric.app.ui.viewmodel.FuturePredictionViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.PeriodPrediction
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class FuturePredictionActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityFuturePredictionBinding
    private val viewModel: FuturePredictionViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var firebaseSyncManager: FirebaseSyncManager
    
    private val statePrefs by lazy { getSharedPreferences("prediction_state_prefs", MODE_PRIVATE) }
    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var isGlobal: Boolean = false
    private lateinit var adapter: PredictionAdapter
    private lateinit var filterAdapter: HorizontalFilterAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityFuturePredictionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentFilter = statePrefs.getString("last_filter", "Up To Date") ?: "Up To Date"
        val lastDate = statePrefs.getLong("last_date", System.currentTimeMillis())
        selectedDate.timeInMillis = lastDate

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Shop")
        
        if (isGlobal) shopId = ""

        setupToolbar(shopName)
        setupUI()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        supportActionBar?.title = null // Explicitly clear action bar title
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    private var tvLastSynced: TextView? = null
    private var ivSyncStatus: android.widget.ImageView? = null

    private fun updateToolbarTitle(shopName: String) {
        val line1 = if (shopName.contains("Global", ignoreCase = true)) "Global Network 🏰" else shopName
        val headers = setupDualHeader(binding.toolbar, line1, "Future Prediction")
        tvLastSynced = headers.status
        tvLastSynced?.visibility = View.GONE // Hide sync text status
        
        ivSyncStatus = binding.toolbar.findViewById(R.id.ivSyncStatus)
        ivSyncStatus?.visibility = View.GONE // Hide sync icon in this screen
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        adapter = PredictionAdapter()
        binding.rvPredictions.layoutManager = LinearLayoutManager(this)
        binding.rvPredictions.adapter = adapter

        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
        
        statePrefs.edit {
            putString("last_filter", currentFilter)
            putLong("last_date", selectedDate.timeInMillis)
        }
        
        viewModel.load(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // Strict Anti-Flicker Logic: Wait for future simulations
                        val isDataZero = (state.predictions.isEmpty()) || (state.totalEstimatedProfit == 0.0)
                        if (state.isLoading && isDataZero) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.FORECAST, lifecycleScope)
                            binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                        
                        binding.tvSummaryTitle.text = state.title.uppercase(Locale.getDefault())
                        binding.tvTotalEstimatedProfit.text = formatCurrency(state.totalEstimatedProfit)
                        adapter.submitList(state.predictions)
                    }
                }
                launch {
                    firebaseSyncManager.syncStatus.collectLatest { connected ->
                        ivSyncStatus?.setColorFilter(
                            ContextCompat.getColor(this@FuturePredictionActivity, if (connected) R.color.green_700 else R.color.red_700)
                        )
                        tvLastSynced?.setTextColor(
                            ContextCompat.getColor(this@FuturePredictionActivity, if (connected) R.color.green else R.color.red)
                        )
                    }
                }
                launch {
                    firebaseSyncManager.lastSyncTime.collectLatest { timestamp ->
                        val now = System.currentTimeMillis()
                        val diff = now - timestamp
                        val text = when {
                            diff < 10000 -> "Syncing..."
                            diff < 60000 -> "Synced just now"
                            diff < 3600000 -> "Synced ${diff / 60000}m ago"
                            else -> {
                                val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
                                "Last synced: ${sdf.format(Date(timestamp))}"
                            }
                        }
                        tvLastSynced?.text = "• $text"
                    }
                }
            }
        }
    }

    private fun formatCurrency(value: Double): String {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        currencyFormat.maximumFractionDigits = 0
        return currencyFormat.format(value)
    }

    inner class PredictionAdapter : RecyclerView.Adapter<PredictionAdapter.ViewHolder>() {
        private var items = listOf<PeriodPrediction>()

        fun submitList(newList: List<PeriodPrediction>) {
            val oldSize = items.size
            items = newList
            if (oldSize != items.size) {
                notifyDataSetChanged()
            } else {
                notifyItemRangeChanged(0, items.size)
            }
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemFuturePredictionBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(items[position])
        }

        override fun getItemCount() = items.size

        inner class ViewHolder(private val binding: ItemFuturePredictionBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(data: PeriodPrediction) {
                binding.tvPeriodLabel.text = data.label
                binding.tvDateRange.text = data.dateRange
                
                if (data.isLive) {
                    if (data.isPartial) {
                        binding.tvStatusBadge.text = "PARTIAL LIVE"
                        binding.tvStatusBadge.backgroundTintList = ContextCompat.getColorStateList(itemView.context, R.color.amber)
                        binding.tvStatusBadge.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                    } else {
                        binding.tvStatusBadge.text = "LIVE DATA"
                        binding.tvStatusBadge.backgroundTintList = ContextCompat.getColorStateList(itemView.context, R.color.green)
                        binding.tvStatusBadge.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                    }
                } else {
                    binding.tvStatusBadge.text = "PREDICTED"
                    binding.tvStatusBadge.backgroundTintList = ContextCompat.getColorStateList(itemView.context, R.color.colorPrimary)
                    binding.tvStatusBadge.setTextColor(ContextCompat.getColor(itemView.context, R.color.white))
                }

                binding.tvSales.text = formatCurrency(data.sales)
                binding.tvSalary.text = formatCurrency(data.salary)
                binding.tvFixed.text = formatCurrency(data.fixed)
                binding.tvExpense.text = formatCurrency(data.expense)
                binding.tvProfit.text = formatCurrency(data.profit)
                
                binding.tvProfit.setTextColor(ContextCompat.getColor(itemView.context, if (data.profit >= 0) R.color.green else R.color.red))
            }
        }
    }
}
