package com.biometric.app.ui.viewmodel

import android.app.Application
import android.content.Context
import androidx.core.content.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.github.mikephil.charting.data.Entry
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.biometric.app.ai.*
import com.biometric.app.ai.enterprise.EnterpriseNlrManager
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.NaturalLanguageEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

data class ChatMessage(
    val text: String,
    val isUser: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val chartData: List<Entry>? = null,
    val chartLabel: String? = null,
    val actionText: String? = null,
    val actionType: String? = null,
    val tableData: List<Cashbook>? = null,
)

@HiltViewModel
class AiChatViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository,
    private val geminiService: GeminiService,
    private val enterpriseNlrManager: EnterpriseNlrManager,
) : AndroidViewModel(application) {

    private val gson = Gson()
    private val prefs = application.getSharedPreferences("ai_chat_prefs", Context.MODE_PRIVATE)
    private val memoryManager = ConversationMemoryManager(application)

    private val _messages = MutableStateFlow(loadHistory())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _isLoading = MutableStateFlow(value = false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _suggestions = MutableStateFlow<List<String>>(emptyList())
    val suggestions: StateFlow<List<String>> = _suggestions.asStateFlow()

    private var currentShopId: String? = null

    fun setShopId(shopId: String?) {
        currentShopId = if (shopId.isNullOrEmpty()) null else shopId
        memoryManager.update(shopId = currentShopId)
        generateInitialSuggestions()
    }

    private fun loadHistory(): List<ChatMessage> {
        val json = prefs.getString("history", null)
        return if (json != null) {
            try {
                gson.fromJson(json, object : TypeToken<List<ChatMessage>>() {}.type)
            } catch (_: Exception) {
                listOf(getDefaultWelcome())
            }
        } else {
            listOf(getDefaultWelcome())
        }
    }

    private fun getDefaultWelcome() = ChatMessage("Hello! I'm **Beast AI** 🦁, your personal business advisor. I can analyze your sales, profit, staff, and even predict stock needs! Ask me anything about your business.", false)

    private fun saveHistory(messages: List<ChatMessage>) {
        viewModelScope.launch(Dispatchers.IO) {
            val lastFifty = if (messages.size > 50) messages.takeLast(50) else messages
            prefs.edit {
                putString("history", gson.toJson(lastFifty))
            }
        }
    }

    fun clearHistory() {
        _messages.value = listOf(getDefaultWelcome())
        memoryManager.clear()
        prefs.edit {
            remove("history")
        }
    }

    private fun generateInitialSuggestions() {
        val base = mutableListOf("Why profit dropped this week? 📉", "Last 5 days milk amount 🥛", "Top selling items May 🏆")
        if (currentShopId == null) base.add(0, "Shop performance ranking 🥇")
        else base.add("Stock I should buy tomorrow 🛒")
        _suggestions.value = base
    }

    fun sendMessage(query: String) {
        if (query.isBlank()) return
        val userMsg = ChatMessage(query, true)
        _messages.update { (it + userMsg).takeLast(60) }

        viewModelScope.launch {
            _isLoading.value = true
            processEnterpriseQuery(query)
            _isLoading.value = false
            saveHistory(_messages.value)
        }
    }

    private suspend fun processEnterpriseQuery(query: String) {
        val q = query.lowercase().trim()
        
        // Use the Enterprise-grade NLR Engine
        val enterpriseResponse = enterpriseNlrManager.processQuery(q, currentShopId)
        
        var responseText = enterpriseResponse.text
        
        // SELF-IMPROVEMENT: If SQL returns nothing, try heuristic summary
        if (responseText.contains("couldn't find any records") && currentShopId != null) {
            val range = DateRangeUtil.getRangeForPeriod("Monthly", System.currentTimeMillis(), true)
            val bundle = BusinessContextBuilder(repository).build(currentShopId, range.first, range.second, "This Month")
            val insights = BusinessInsightEngine.analyze(AiIntent.GENERAL, bundle)
            val fallback = geminiService.generateResponse(q, AiIntent.GENERAL, bundle, insights)
            if (!fallback.contains("look into your records")) {
                responseText = "I couldn't find specific data for that query in your ledger, but looking at your overall business this month:\n\n$fallback"
            }
        }

        // Handle specialized UI logic if raw data is available
        val chartData = detectChartData(enterpriseResponse.rawData)
        
        val message = ChatMessage(
            text = responseText,
            isUser = false,
            chartData = chartData,
            chartLabel = if (chartData != null) "Business Trend" else null
        )

        _messages.update { (it + message).takeLast(60) }
        
        // Extract intent from query for suggestions (simplified for now)
        val intent = AIIntentEngine.detectIntent(q)
        updateSuggestionsAfterResponse(intent)
    }

    private fun detectChartData(data: List<Map<String, Any?>>): List<Entry>? {
        if (data.size < 2) return null
        
        // Attempt to find a numeric column and a time/sequence column
        val numericKey = data[0].entries.find { it.value is Double || it.value is Long || it.value is Float }?.key ?: return null
        
        return try {
            data.mapIndexed { index, map ->
                val value = (map[numericKey] as? Number)?.toFloat() ?: 0f
                Entry(index.toFloat(), value)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun updateSuggestionsAfterResponse(intent: AiIntent) {
        val next = mutableListOf<String>()
        when (intent) {
            AiIntent.PROFIT_SUMMARY, AiIntent.PROFIT_ANALYSIS -> next.addAll(listOf("Show sales trend 📈", "Why is it low? 📉", "Compare vs last month 🔄"))
            AiIntent.SALES_SUMMARY -> next.addAll(listOf("Top selling items? 🏆", "Check profit? 💹", "Expense breakdown 💸"))
            AiIntent.ATTENDANCE_QUERY -> next.addAll(listOf("Who is most absent? 🚶", "Staff salary total 💰"))
            AiIntent.STOCK_QUERY -> next.addAll(listOf("What stock should I buy next week? 🛒", "Inventory health 📦"))
            else -> next.addAll(listOf("Business health? 💪", "Goal status 🎯", "Recovery projection 🔄", "Forecast next month 🔮"))
        }
        _suggestions.value = next
    }
}
