package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ItemCartRowBinding
import com.biometric.app.ui.viewmodel.CartItem
import com.biometric.app.util.HapticUtil
import java.util.Locale

class CartAdapter(
    private val onIncrease: (CartItem) -> Unit,
    private val onDecrease: (CartItem) -> Unit,
    private val onParcelClick: (CartItem) -> Unit
) : ListAdapter<CartItem, CartAdapter.CartViewHolder>(CartItemDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = ItemCartRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class CartViewHolder(private val binding: ItemCartRowBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(cartItem: CartItem) {
            val context = binding.root.context
            val itemName = cartItem.item.name.ifBlank { "Item" }

            binding.tvCartItemName.text = itemName
            binding.tvCartQty.text = String.format(Locale.getDefault(), "%d", cartItem.quantity.toInt())
            binding.tvCartSubtotal.text = context.getString(R.string.currency_format, (cartItem.price * cartItem.quantity) + cartItem.parcelCharge)

            if (cartItem.parcelCharge > 0) {
                binding.tvParcelLink.text = context.getString(R.string.parcel_format, cartItem.parcelCharge, context.getString(R.string.item_parcel))
            } else {
                binding.tvParcelLink.setText(R.string.add_parcel)
            }

            binding.btnPlus.setOnClickListener { 
                HapticUtil.vibrateIncrement(it)
                onIncrease(cartItem) 
            }
            binding.btnMinus.setOnClickListener { 
                HapticUtil.vibrateDecrement(it)
                onDecrease(cartItem) 
            }
            binding.tvParcelLink.setOnClickListener { onParcelClick(cartItem) }
        }
    }
}

class CartItemDiffCallback : DiffUtil.ItemCallback<CartItem>() {
    override fun areItemsTheSame(oldItem: CartItem, newItem: CartItem):
            Boolean = oldItem.item.itemId == newItem.item.itemId

    override fun areContentsTheSame(oldItem: CartItem, newItem: CartItem):
            Boolean = oldItem == newItem
}
