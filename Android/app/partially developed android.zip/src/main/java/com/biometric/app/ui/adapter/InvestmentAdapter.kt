package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.graphics.toColorInt
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.data.entity.Investment
import com.biometric.app.databinding.ItemInvestmentBinding
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class InvestmentAdapter(
    private val onDeleteClick: (Investment) -> Unit,
    private val onEditClick: (Investment) -> Unit
) : ListAdapter<Investment, InvestmentAdapter.ViewHolder>(DiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemInvestmentBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    inner class ViewHolder(private val binding: ItemInvestmentBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(investment: Investment) {
            val locale = Locale.forLanguageTag("en-IN")
            val currencyFormat = NumberFormat.getCurrencyInstance(locale)
            val dateFormat = SimpleDateFormat("dd MMM yyyy", locale)

            binding.tvItemName.text = investment.itemName
            binding.tvCategory.text = String.format(locale, "%s • %s", investment.category, dateFormat.format(Date(investment.date)))
            binding.tvAmount.text = currencyFormat.format(investment.amount)

            val indicatorColor = when (investment.category) {
                "Capital" -> "#4CAF50"
                "Deposit" -> "#2196F3"
                "Equipment" -> "#FF9800"
                "Furniture" -> "#9C27B0"
                "Renovation" -> "#795548"
                "Interior" -> "#00BCD4"
                "Machinery" -> "#607D8B"
                else -> "#9E9E9E"
            }
            binding.categoryIndicator.setBackgroundColor(indicatorColor.toColorInt())

            binding.btnDelete.setOnClickListener {
                onDeleteClick(investment)
            }
            
            binding.root.setOnClickListener {
                onEditClick(investment)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<Investment>() {
        override fun areItemsTheSame(oldItem: Investment, newItem: Investment) = oldItem.investmentId == newItem.investmentId
        override fun areContentsTheSame(oldItem: Investment, newItem: Investment) = oldItem == newItem
    }
}
