package com.biometric.app.ui

import android.Manifest
import android.annotation.SuppressLint
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothManager
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.Menu
import android.view.MenuItem
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.core.content.edit
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.ShopMenuItem
import com.biometric.app.databinding.ActivityPosBinding
import com.biometric.app.ui.adapter.CartAdapter
import com.biometric.app.ui.adapter.CategoryAdapter
import com.biometric.app.ui.adapter.MenuAdapter
import com.biometric.app.ui.adapter.TableButtonAdapter
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.POSViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.utils.PremiumUI
import com.biometric.app.util.PremiumLoader
import com.biometric.app.util.BillExportManager
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.BillPrintManager
import com.biometric.app.util.MotionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class POSActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityPosBinding
    private val mainViewModel: MainViewModel by viewModels()
    private val viewModel: POSViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel

    private lateinit var menuAdapter: MenuAdapter
    private lateinit var favoriteAdapter: MenuAdapter
    private lateinit var categoryAdapter: CategoryAdapter
    private lateinit var cartAdapter: CartAdapter
    private lateinit var tableButtonAdapter: TableButtonAdapter

    private lateinit var printManager: BillPrintManager
    private lateinit var exportManager: BillExportManager

    private var shopId: String = ""
    private var shopName: String = ""
    private var tableCount: Int = 0

    private var allMenuItems = emptyList<ShopMenuItem>()
    private val selectedCategories = mutableSetOf<String>()

    private var lastClickTime: Long = 0

    private val layoutPrefs by lazy { getSharedPreferences("pos_layout_prefs", MODE_PRIVATE) }

    private val requestPermissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions(),
    ) { permissions ->
        val granted = permissions.entries.all { it.value }
        if (!granted) {
            Toast.makeText(this, R.string.permissions_required_printing, Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityPosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fix Task bar overlap
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        printManager = BillPrintManager(this)
        exportManager = BillExportManager(this)

        shopId = intent.getStringExtra(EXTRA_SHOP_ID).orEmpty()
        shopName = intent.getStringExtra(EXTRA_SHOP_NAME).orEmpty()
        tableCount = intent.getIntExtra(EXTRA_TABLE_COUNT, 0)

        setupToolbar()
        binding.contentLayout.visibility = View.VISIBLE
        setupUI()
        loadLayoutSettings()
        setupTableSelection()
        observeViewModel()
        checkPermissions()

        setupMotionFeedback(
            binding.btnCheckout, binding.btnHold, binding.btnViewHeld, binding.btnClearCart
        )
    }

    private fun loadLayoutSettings() {
        val savedCols = layoutPrefs.getInt("cols", 4)
        val savedSplit = layoutPrefs.getFloat("split", 0.8f)

        binding.sliderColumns.value = savedCols.toFloat()
        binding.sliderWidth.value = savedSplit

        applyLayout(savedCols, savedSplit)
    }

    private fun applyLayout(cols: Int, split: Float) {
        (binding.rvCategories.layoutManager as? GridLayoutManager)?.spanCount = cols
        (binding.rvMenu.layoutManager as? GridLayoutManager)?.spanCount = cols

        val params = binding.guidelineVertical.layoutParams as androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
        params.guidePercent = split
        binding.guidelineVertical.layoutParams = params
    }

    private fun saveLayoutSettings(cols: Int, split: Float) {
        layoutPrefs.edit { 
            putInt("cols", cols)
            putFloat("split", split)
        }
    }

    private fun checkPermissions() {
        val permissions = mutableListOf<String>()
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            permissions.add(Manifest.permission.BLUETOOTH_SCAN)
            permissions.add(Manifest.permission.BLUETOOTH_CONNECT)
        } else {
            permissions.add(Manifest.permission.BLUETOOTH)
            permissions.add(Manifest.permission.BLUETOOTH_ADMIN)
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }

        val missing = permissions.filter {
            ContextCompat.checkSelfPermission(this, it) != PackageManager.PERMISSION_GRANTED
        }

        if (missing.isNotEmpty()) {
            requestPermissionLauncher.launch(missing.toTypedArray())
        }
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(shopName)
    }

    private var tvTableStatus: android.widget.TextView? = null

    private fun updateToolbarTitle(name: String) {
        val headers = setupDualHeader(binding.toolbar, name, "Sales Entry")
        tvTableStatus = headers.line3
        tvTableStatus?.visibility = View.VISIBLE
    }

    private fun setupUI() {
        categoryAdapter = CategoryAdapter { category ->
            binding.rvCategories.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            if (category == null) {
                selectedCategories.clear()
            } else {
                if (selectedCategories.contains(category)) {
                    selectedCategories.remove(category)
                } else {
                    selectedCategories.add(category)
                }
            }
            updateCategoryList()
            filterMenu()
        }
        binding.rvCategories.layoutManager = GridLayoutManager(this, 4)
        binding.rvCategories.adapter = categoryAdapter

        favoriteAdapter = MenuAdapter { menuItem ->
            binding.rvFavorites.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.addToCart(menuItem)
        }
        binding.rvFavorites.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        binding.rvFavorites.adapter = favoriteAdapter

        menuAdapter = MenuAdapter { menuItem ->
            binding.rvMenu.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.addToCart(menuItem)
        }
        binding.rvMenu.layoutManager = GridLayoutManager(this, 4)
        binding.rvMenu.adapter = menuAdapter

        binding.sliderColumns.addOnChangeListener { _, value, _ ->
            val spanCount = value.toInt()
            (binding.rvCategories.layoutManager as? GridLayoutManager)?.spanCount = spanCount
            (binding.rvMenu.layoutManager as? GridLayoutManager)?.spanCount = spanCount
            saveLayoutSettings(spanCount, binding.sliderWidth.value)
        }

        binding.sliderWidth.addOnChangeListener { _, value, _ ->
            val params = binding.guidelineVertical.layoutParams as androidx.constraintlayout.widget.ConstraintLayout.LayoutParams
            params.guidePercent = value
            binding.guidelineVertical.layoutParams = params
            // Force re-layout of the constraint container
            binding.rvMenu.parent?.requestLayout()
            saveLayoutSettings(binding.sliderColumns.value.toInt(), value)
        }

        cartAdapter = CartAdapter(
            onIncrease = { cartItem ->
                viewModel.addToCart(ShopMenuItem(cartItem.item, cartItem.price))
            },
            onDecrease = { viewModel.removeFromCart(it) },
        ) { cartItem ->
            ManualParcelDialogFragment.newInstance(cartItem)
                .show(supportFragmentManager, ManualParcelDialogFragment.TAG)
        }
        binding.rvCart.layoutManager = LinearLayoutManager(this)
        binding.rvCart.adapter = cartAdapter

        binding.btnCheckout.setOnClickListener {
            if (isDebounced() && viewModel.cart.value.isNotEmpty()) {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                SplitPaymentDialogFragment.newInstance(viewModel.serviceType.value, viewModel.tableId.value)
                    .show(supportFragmentManager, SplitPaymentDialogFragment.TAG)
            }
        }

        binding.btnHold.setOnClickListener {
            if (isDebounced() && viewModel.cart.value.isNotEmpty()) {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                viewModel.holdOrder()
            }
        }

        binding.btnClearCart.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            viewModel.clearCart()
        }

        binding.btnViewHeld.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            HeldOrdersDialogFragment.newInstance().show(supportFragmentManager, HeldOrdersDialogFragment.TAG)
        }
    }

    private fun isDebounced(): Boolean {
        val currentTime = System.currentTimeMillis()
        if ((currentTime - lastClickTime) < 500) return false
        lastClickTime = currentTime
        return true
    }

    private fun setupTableSelection() {
        val spanCount = if (tableCount > 7) (tableCount + 1) / 2 else tableCount + 1
        binding.rvTables.layoutManager = GridLayoutManager(this, spanCount)

        tableButtonAdapter = TableButtonAdapter { table ->
            binding.rvTables.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            val serviceType = if (table == "S") SERVICE_TYPE_STANDING else SERVICE_TYPE_TABLE
            val tableId = if (table == "S") null else table
            viewModel.setServiceType(serviceType, tableId)
        }
        binding.rvTables.adapter = tableButtonAdapter
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            shopName = it.name
                            tableCount = it.tableCount
                            updateToolbarTitle(it.name)
                            viewModel.setShop(it.shopId)
                            setupTableSelection()
                        }
                    }
                }

                launch {
                    viewModel.isLoading.collect { isLoading ->
                        // Strict Anti-Flicker Logic
                        val isDataZero = allMenuItems.isEmpty()
                        if (isLoading && isDataZero) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.POS, lifecycleScope)
                            binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                    }
                }

                launch {
                    viewModel.menuItems.collect { menu ->
                        allMenuItems = menu
                        updateCategoryList()
                        filterMenu()
                        
                        // Automatic Favorites (Top 6 most sold)
                        val favorites = menu.asSequence().sortedByDescending { it.salesCount }.take(6).toList()
                        favoriteAdapter.submitList(favorites)
                        binding.rvFavorites.isVisible = favorites.isNotEmpty()
                    }
                }
                launch {
                    viewModel.cart.collect {
                        cartAdapter.submitList(it)
                        val total = it.sumOf { item -> (item.price * item.quantity) + item.parcelCharge }
                        binding.tvTotalAmount.text = String.format(Locale.getDefault(), "₹%.2f", total)

                        val hasItems = it.isNotEmpty()
                        binding.btnCheckout.isEnabled = hasItems
                        binding.btnHold.isEnabled = hasItems
                        binding.btnClearCart.isEnabled = hasItems
                    }
                }

                launch {
                    combine(viewModel.serviceType, viewModel.tableId) { type, table ->
                        updateTableSelectionUI(type, table)
                        if (type == SERVICE_TYPE_TABLE) {
                            getString(R.string.label_table_subtitle, table ?: "...")
                        } else {
                            getString(R.string.service_standing)
                        }
                    }.collect { subtitle ->
                        tvTableStatus?.text = subtitle
                    }
                }

                launch {
                    viewModel.transactionComplete.collect { orderId ->
                        if (orderId != null) {
                            HapticUtil.vibrateSuccess(binding.root)
                            MotionManager.playCreateBlast(binding.animFeedback)
                            PremiumUI.showSuccess(this@POSActivity, getString(R.string.order_placed), getString(R.string.order_success_msg))
                            
                            val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
                            val autoShare = prefs.getBoolean("auto_share_bill", false)
                            
                            if (autoShare) {
                                handlePdfGeneration(orderId)
                                handleWhatsAppShare(orderId)
                            } else {
                                showPostTransactionOptions(orderId)
                            }
                            viewModel.onTransactionComplete()
                        }
                    }
                }
            }
        }

        viewModel.heldOrders.observe(this) { orders ->
            binding.btnViewHeld.text = String.format(Locale.getDefault(), "H (%d)", orders.size)
        }
    }

    private fun showPostTransactionOptions(orderId: String) {
        val options = arrayOf(
            getString(R.string.option_bluetooth_print),
            getString(R.string.option_wifi_print),
            getString(R.string.option_generate_pdf),
            getString(R.string.option_share_whatsapp),
            getString(R.string.option_done)
        )

        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.transaction_complete)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> handleBluetoothPrint(orderId)
                    1 -> handleWiFiPrint(orderId)
                    2 -> handlePdfGeneration(orderId)
                    3 -> handleWhatsAppShare(orderId)
                }
            }
            .setCancelable(false)
            .show()
    }

    @SuppressLint("MissingPermission")
    private fun handleBluetoothPrint(orderId: String) {
        lifecycleScope.launch {
            val orderWithItems = viewModel.getOrderWithItems(orderId)
            val shop = viewModel.getShop(shopId)
            if (shop != null) {
                val bluetoothManager = getSystemService(BLUETOOTH_SERVICE) as BluetoothManager
                val bluetoothAdapter: BluetoothAdapter? = bluetoothManager.adapter
                val bondedDevices = bluetoothAdapter?.bondedDevices

                if (bondedDevices.isNullOrEmpty()) {
                    Toast.makeText(this@POSActivity, R.string.no_paired_printers, Toast.LENGTH_SHORT).show()
                    return@launch
                }

                val deviceNames = bondedDevices.map { it.name }.toTypedArray()
                val deviceAddresses = bondedDevices.map { it.address }.toTypedArray()

                MaterialAlertDialogBuilder(this@POSActivity)
                    .setTitle(R.string.select_bt_printer)
                    .setItems(deviceNames) { _, idx ->
                        lifecycleScope.launch {
                            val success = try {
                                printManager.printBluetooth(deviceAddresses[idx], shop, orderWithItems)
                            } catch (e: SecurityException) {
                                e.printStackTrace()
                                false
                            }
                            if (success) {
                                Toast.makeText(this@POSActivity, R.string.printing, Toast.LENGTH_SHORT).show()
                            } else {
                                HapticUtil.vibrateError(binding.root)
                                Toast.makeText(this@POSActivity, R.string.print_failed, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }.show()
            }
        }
    }

    private fun handleWiFiPrint(orderId: String) {
        val input = EditText(this).apply {
            hint = getString(R.string.hint_printer_ip)
            inputType = android.text.InputType.TYPE_CLASS_TEXT
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.wifi_printer_ip)
            .setView(input)
            .setPositiveButton(R.string.btn_print) { _, _ ->
                val ip = input.text.toString()
                if (ip.isNotEmpty()) {
                    lifecycleScope.launch {
                        val orderWithItems = viewModel.getOrderWithItems(orderId)
                        val shop = viewModel.getShop(shopId)
                        if (shop != null) {
                            val success = printManager.printWiFi(ip, 9100, shop, orderWithItems)
                            if (success) {
                                Toast.makeText(this@POSActivity, R.string.printing, Toast.LENGTH_SHORT).show()
                            } else {
                                HapticUtil.vibrateError(binding.root)
                                Toast.makeText(this@POSActivity, R.string.print_failed, Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }.show()
    }

    private fun handlePdfGeneration(orderId: String) {
        lifecycleScope.launch {
            val orderWithItems = viewModel.getOrderWithItems(orderId)
            val shop = viewModel.getShop(shopId)
            if (shop != null) {
                exportManager.generateBillPdf(shop, orderWithItems)?.let { file ->
                    Toast.makeText(this@POSActivity, getString(R.string.pdf_generated, file.name), Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    private fun handleWhatsAppShare(orderId: String) {
        val input = EditText(this).apply {
            hint = getString(R.string.customer_phone_optional)
            inputType = android.text.InputType.TYPE_CLASS_PHONE
        }
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.share_via_whatsapp)
            .setView(input)
            .setPositiveButton(R.string.share) { _, _ ->
                lifecycleScope.launch {
                    val orderWithItems = viewModel.getOrderWithItems(orderId)
                    val shop = viewModel.getShop(shopId)
                    if (shop != null) {
                        val file = exportManager.generateBillPdf(shop, orderWithItems)
                        if (file != null) {
                            exportManager.shareBillOnWhatsApp(file, input.text.toString())
                        }
                    }
                }
            }.show()
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.switch_shop)
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                sharedViewModel.setSelectedShop(selectedShop)
                Toast.makeText(this, getString(R.string.switched_to, selectedShop.name), Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    private fun updateCategoryList() {
        val categorySales = allMenuItems.groupBy { it.item.category }
            .mapValues { entry -> entry.value.sumOf { it.salesCount } }

        val sortedCategories = allMenuItems.asSequence().map { it.item.category }
            .distinct()
            .sortedWith(compareByDescending<String> { categorySales[it] ?: 0 }.thenBy { it })
            .toList()

        val categories = mutableListOf<String?>()
        categories.add(null)
        categories.addAll(sortedCategories)

        categoryAdapter.submitList(categories, selectedCategories)
    }

    private fun filterMenu() {
        val filtered = if (selectedCategories.isEmpty()) {
            allMenuItems
        } else {
            allMenuItems.filter { selectedCategories.contains(it.item.category) }
        }
        menuAdapter.submitList(filtered.sortedByDescending { it.salesCount })
    }

    private fun updateTableSelectionUI(selectedType: String, selectedTable: String?) {
        val selected = if (selectedType == SERVICE_TYPE_STANDING) "S" else selectedTable

        val items = (0..tableCount).map { i ->
            val tableNumber = if (i == 0) "S" else i.toString()
            TableButtonAdapter.TableItem(tableNumber, tableNumber == selected)
        }
        tableButtonAdapter.submitList(items)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🍽️", "Menu") {
                val intent = Intent(this, ItemMasterActivity::class.java).apply {
                    putExtra(EXTRA_SHOP_ID, shopId)
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📊", "POS Report") {
                val intent = Intent(this, PosReportActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", shopName)
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("🛠️", "Layout") {
                binding.llControls.isVisible = !binding.llControls.isVisible
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🍽️", "Menu") {
                val intent = Intent(this, ItemMasterActivity::class.java).apply {
                    putExtra(EXTRA_SHOP_ID, shopId)
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📊", "POS Report") {
                val intent = Intent(this, PosReportActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", shopName)
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("🛠️", "Layout") {
                binding.llControls.isVisible = !binding.llControls.isVisible
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    companion object {
        private const val EXTRA_SHOP_ID = "SHOP_ID"
        private const val EXTRA_SHOP_NAME = "SHOP_NAME"
        private const val EXTRA_TABLE_COUNT = "TABLE_COUNT"
        private const val SERVICE_TYPE_STANDING = "STANDING"
        private const val SERVICE_TYPE_TABLE = "TABLE"
    }
}