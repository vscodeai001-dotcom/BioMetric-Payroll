package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.Exclude
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class Employee(
    @get:PropertyName("employeeId") @set:PropertyName("employeeId")
    var employeeId: String = "",
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("phone") @set:PropertyName("phone")
    var phone: String = "",

    @get:PropertyName("email") @set:PropertyName("email")
    var email: String? = null,

    @get:PropertyName("biometricId") @set:PropertyName("biometricId")
    var biometricId: String = "",

    @get:PropertyName("role") @set:PropertyName("role")
    var role: String = "Staff",
    
    @get:PropertyName("salaryType") @set:PropertyName("salaryType")
    var salaryType: String = "MONTHLY_FIXED",
    
    @get:PropertyName("salaryRate") @set:PropertyName("salaryRate")
    var salaryRate: Double = 0.0,

    @get:PropertyName("salaryCalculationMethod") @set:PropertyName("salaryCalculationMethod")
    var salaryCalculationMethod: String = "Pro-Rata Hourly",
    
    @get:PropertyName("shiftStart") @set:PropertyName("shiftStart")
    var shiftStart: String = "10:00",
    
    @get:PropertyName("shiftEnd") @set:PropertyName("shiftEnd")
    var shiftEnd: String = "22:00",
    
    @get:PropertyName("breakHours") @set:PropertyName("breakHours")
    var breakHours: Double = 0.0,
    
    @get:PropertyName("shift2Start") @set:PropertyName("shift2Start")
    var shift2Start: String? = null,
    
    @get:PropertyName("shift2End") @set:PropertyName("shift2End")
    var shift2End: String? = null,
    
    @get:PropertyName("weekendShiftStart") @set:PropertyName("weekendShiftStart")
    var weekendShiftStart: String? = null,
    
    @get:PropertyName("weekendShiftEnd") @set:PropertyName("weekendShiftEnd")
    var weekendShiftEnd: String? = null,
    
    @get:PropertyName("weekendBreakHours") @set:PropertyName("weekendBreakHours")
    var weekendBreakHours: Double? = null,

    @get:PropertyName("weekendShift2Start") @set:PropertyName("weekendShift2Start")
    var weekendShift2Start: String? = null,

    @get:PropertyName("weekendShift2End") @set:PropertyName("weekendShift2End")
    var weekendShift2End: String? = null,

    @get:PropertyName("compOffDayOfWeek") @set:PropertyName("compOffDayOfWeek")
    var compOffDayOfWeek: Int? = null,
    
    @get:PropertyName("otRule") @set:PropertyName("otRule")
    var otRule: String = "No Overtime",

    @get:PropertyName("otFlatRate") @set:PropertyName("otFlatRate")
    var otFlatRate: Double = 0.0,

    @get:PropertyName("otRateMultiplier") @set:PropertyName("otRateMultiplier")
    var otRateMultiplier: Double = 1.0,
    
    @get:PropertyName("dailyAllowance") @set:PropertyName("dailyAllowance")
    var dailyAllowance: Double = 0.0,
    
    @get:PropertyName("nightShiftAllowance") @set:PropertyName("nightShiftAllowance")
    var nightShiftAllowance: Double = 0.0,

    @get:PropertyName("allowanceEffectiveDate") @set:PropertyName("allowanceEffectiveDate")
    var allowanceEffectiveDate: Long = System.currentTimeMillis(),
    
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true,
    
    @get:PropertyName("hireDate") @set:PropertyName("hireDate")
    var hireDate: Long = System.currentTimeMillis(),

    @get:PropertyName("dob") @set:PropertyName("dob")
    var dob: Long? = null,
    
    @get:PropertyName("terminateDate") @set:PropertyName("terminateDate")
    var terminateDate: Long? = null,

    @get:PropertyName("enableShiftRotation") @set:PropertyName("enableShiftRotation")
    var enableShiftRotation: Boolean = false,

    @get:PropertyName("rotationGroup") @set:PropertyName("rotationGroup")
    var rotationGroup: String? = null,

    @get:PropertyName("shiftRotationPattern") @set:PropertyName("shiftRotationPattern")
    var shiftRotationPattern: String? = null,
    
    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis(),

    @get:PropertyName("isBonusEligibleRule") @set:PropertyName("isBonusEligibleRule")
    var isBonusEligibleRule: Boolean = true,

    @get:PropertyName("isPaidLeaveEligibleRule") @set:PropertyName("isPaidLeaveEligibleRule")
    var isPaidLeaveEligibleRule: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekdays") @set:PropertyName("paidLeaveOnWeekdays")
    var paidLeaveOnWeekdays: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekends") @set:PropertyName("paidLeaveOnWeekends")
    var paidLeaveOnWeekends: Boolean = false,

    @get:PropertyName("monthlyBonusOverrides") @set:PropertyName("monthlyBonusOverrides")
    var monthlyBonusOverrides: Map<String, Boolean> = HashMap(),

    @get:PropertyName("monthlyPaidLeaveOverrides") @set:PropertyName("monthlyPaidLeaveOverrides")
    var monthlyPaidLeaveOverrides: Map<String, Boolean> = HashMap(),

    @get:PropertyName("salaryRulesOverride") @set:PropertyName("salaryRulesOverride")
    var salaryRulesOverride: SalaryRules? = null,

    @get:PropertyName("bankAccountNumber") @set:PropertyName("bankAccountNumber")
    var bankAccountNumber: String? = null,

    @get:PropertyName("bankIfscCode") @set:PropertyName("bankIfscCode")
    var bankIfscCode: String? = null,

    @get:PropertyName("bankName") @set:PropertyName("bankName")
    var bankName: String? = null,

    @get:PropertyName("uanNumber") @set:PropertyName("uanNumber")
    var uanNumber: String? = null,

    @get:PropertyName("esiNumber") @set:PropertyName("esiNumber")
    var esiNumber: String? = null,

    @get:PropertyName("enablePf") @set:PropertyName("enablePf")
    var enablePf: Boolean = false,

    @get:PropertyName("enableEsi") @set:PropertyName("enableEsi")
    var enableEsi: Boolean = false,

    @get:PropertyName("tdsRatePercent") @set:PropertyName("tdsRatePercent")
    var tdsRatePercent: Double = 0.0,

    @get:Exclude @set:Exclude
    var lastActive: Long? = null
) : Serializable
