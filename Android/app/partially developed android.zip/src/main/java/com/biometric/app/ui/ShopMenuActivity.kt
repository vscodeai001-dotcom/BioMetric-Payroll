package com.biometric.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.biometric.app.databinding.ActivityShopMenuBinding
import com.biometric.app.domain.BrandingManager
import com.biometric.app.domain.FeatureManager
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class ShopMenuActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityShopMenuBinding
    private val viewModel: MainViewModel by viewModels()

    @Inject lateinit var featureManager: FeatureManager
    @Inject lateinit var brandingManager: BrandingManager
    @Inject lateinit var sharedViewModel: SharedViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityShopMenuBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val shopId = intent.getStringExtra("SHOP_ID") ?: ""
        viewModel.setManagementShopId(shopId)

        setupUI()

        // Observe branding and update header
        lifecycleScope.launch {
            viewModel.currentShop.collectLatest { shop ->
                shop?.let {
                    // Update branding
                    brandingManager.updateBranding(
                        BrandingManager.BrandingConfig(
                            appName = it.brandingName ?: it.name,
                            logoUrl = it.brandingLogoUrl
                        )
                    )
                    updateToolbarTitle(it.name)
                }
            }
        }

        // Feature control for screens
        if (!featureManager.isFeatureEnabled(FeatureManager.Feature.POS)) {
            Toast.makeText(this, "POS feature is disabled", Toast.LENGTH_SHORT).show()
            finish()
        }
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Shop Menu")
    }

    private fun setupUI() {
        // Implementation for Shop Menu UI click listeners (POS, Staff, etc.)
        // These can be added as needed based on the activity_shop_menu.xml IDs
    }
}
