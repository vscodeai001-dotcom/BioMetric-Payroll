package com.biometric.app.domain

import com.biometric.app.data.entity.FixedExpense
import java.util.*

object FinancialCalculator {
    /**
     * Calculates prorated fixed expenses for a given period.
     * Optimized to avoid redundant object allocations and nested filtering.
     */
    fun calculateProratedExpenses(
        expenses: List<FixedExpense>,
        start: Long,
        end: Long,
        shopOpeningDates: Map<String, Long> = emptyMap()
    ): Double {
        if (start > end) return 0.0
        
        // Group by shop and name to handle different versions of the same expense
        val expensesByShopAndName = expenses.groupBy { it.shopId to it.name }
        
        // Pre-sort versions for each expense group once
        val preparedExpenses = expensesByShopAndName.map { (key, versions) ->
            // Normalize opening date to midnight to ensure the full opening day is included
            val normalizedOpening = shopOpeningDates[key.first]?.let { getMidnight(it) } ?: 0L
            Triple(key.first, normalizedOpening, versions.filter { !it.isArchived }.sortedBy { it.effectiveFrom })
        }.filter { it.third.isNotEmpty() }

        var totalExpense = 0.0
        val tempCal = Calendar.getInstance()
        
        // Loop through each day in the range
        var currentDay = start
        while (currentDay <= end) {
            tempCal.timeInMillis = currentDay
            val daysInMonth = tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)
            
            if (daysInMonth > 0) {
                preparedExpenses.forEach { (_, _, versions) ->
                    // Find the version that was active on this specific day
                    val activeExpense = versions.findLast { it.effectiveFrom <= currentDay }
                    if (activeExpense != null) {
                        totalExpense += activeExpense.monthlyAmount / daysInMonth
                    }
                }
            }
            
            tempCal.add(Calendar.DAY_OF_YEAR, 1)
            currentDay = tempCal.timeInMillis
        }

        return totalExpense
    }

    /**
     * Returns a map of day timestamps to their prorated fixed expense amount.
     * Extremely efficient for building day-wise reports.
     */
    fun calculateDailyProratedExpenses(
        expenses: List<FixedExpense>,
        start: Long,
        end: Long,
        shopOpeningDates: Map<String, Long> = emptyMap()
    ): Map<Long, Double> {
        if (start > end) return emptyMap()

        val expensesByShopAndName = expenses.groupBy { it.shopId to it.name }
        val preparedExpenses = expensesByShopAndName.map { (key, versions) ->
            val normalizedOpening = shopOpeningDates[key.first]?.let { getMidnight(it) } ?: 0L
            Triple(key.first, normalizedOpening, versions.filter { !it.isArchived }.sortedBy { it.effectiveFrom })
        }.filter { it.third.isNotEmpty() }

        val resultMap = mutableMapOf<Long, Double>()
        val tempCal = Calendar.getInstance()
        
        var currentDay = start
        while (currentDay <= end) {
            tempCal.timeInMillis = currentDay
            val dayKey = getMidnight(currentDay)
            
            val daysInMonth = tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)
            var dayTotal = 0.0
            
            if (daysInMonth > 0) {
                preparedExpenses.forEach { (_, _, versions) ->
                    val activeExpense = versions.findLast { it.effectiveFrom <= currentDay }
                    if (activeExpense != null) {
                        dayTotal += activeExpense.monthlyAmount / daysInMonth
                    }
                }
            }
            resultMap[dayKey] = dayTotal
            
            tempCal.add(Calendar.DAY_OF_YEAR, 1)
            currentDay = tempCal.timeInMillis
        }
        return resultMap
    }

    private fun getMidnight(ts: Long): Long = Calendar.getInstance().apply {
        timeInMillis = ts
        set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis
}
