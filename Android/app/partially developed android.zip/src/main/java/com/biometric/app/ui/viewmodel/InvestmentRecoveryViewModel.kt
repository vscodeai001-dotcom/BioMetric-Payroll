package com.biometric.app.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.*
import com.biometric.app.data.entity.*
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

enum class InvestmentFilterType {
    DAY, WEEKLY, MONTHLY, QUARTERLY, HALF_YEARLY, YEARLY, CUSTOM
}

data class InvestmentFilterState(
    val filterType: InvestmentFilterType = InvestmentFilterType.MONTHLY,
    val startDate: Long = 0L,
    val endDate: Long = System.currentTimeMillis(),
    val isDefaultMode: Boolean = true,
)

data class RecoverySummary(
    val totalInvestment: Double = 0.0,
    val totalProfitEarned: Double = 0.0,
    val averageMonthlyProfit: Double = 0.0,
    val monthlyProfits: Map<String, Double> = emptyMap(),
    val cumulativeProfits: Map<String, Double> = emptyMap(),
    val projectedProfits: Map<String, Double> = emptyMap(),
    val breakEvenMonth: String? = null,
    val isDataSufficient: Boolean = false,
)

@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
@HiltViewModel
class InvestmentRecoveryViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel,
) : ViewModel() {

    val selectedShop: StateFlow<Shop?> = sharedViewModel.selectedShop
    
    val allShops: StateFlow<List<Shop>> = repository.getAllShops()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _manualShopId = MutableStateFlow<String?>(null)
    private val _isGlobalMode = MutableStateFlow(value = false)
    private val _filterState = MutableStateFlow(InvestmentFilterState())
    val filterState: StateFlow<InvestmentFilterState> = _filterState.asStateFlow()

    private val _isLoading = MutableStateFlow(value = true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    // Parameters for data fetching
    private val calculationParams = combine(
        selectedShop, 
        _filterState, 
        _manualShopId, 
        allShops, 
        _isGlobalMode,
    ) { shop, filter, manualId, shops, isGlobal ->
        val sId = if (isGlobal) null else (manualId ?: shop?.shopId)
        Triple(sId, filter, shops)
    }.distinctUntilChanged()

    // 1. Investments List Flow
    val investments: StateFlow<List<Investment>> = calculationParams
        .flatMapLatest { (shopId, _, _) ->
            repository.getInvestments(shopId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 2. Summary & Chart Data Flow
    val summary: StateFlow<RecoverySummary> = calculationParams
        .flatMapLatest { (shopId, filter, shops) ->
            if (!_isGlobalMode.value && (shopId == null)) return@flatMapLatest flowOf(RecoverySummary())
            if (_isGlobalMode.value && shops.isEmpty()) return@flatMapLatest flowOf(RecoverySummary())

            calculateProfitFlow(shopId, filter, shops)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RecoverySummary())

    init {
        // Track summary to handle internal loading state
        viewModelScope.launch {
            summary.collect {
                _isLoading.value = false
            }
        }
    }

    fun setGlobalMode(global: Boolean) {
        _isGlobalMode.value = global
        if (global) {
            _manualShopId.value = null
        }
    }

    fun onShopSelected(shop: Shop) {
        _isGlobalMode.value = false
        _manualShopId.value = shop.shopId
        sharedViewModel.setSelectedShop(shop)
    }

    fun updateFilter(type: InvestmentFilterType, start: Long? = null, end: Long? = null) {
        _isLoading.value = true
        val current = _filterState.value
        _filterState.value = current.copy(
            filterType = type,
            startDate = start ?: current.startDate,
            endDate = end ?: current.endDate,
            isDefaultMode = false
        )
    }

    fun resetToDefault() {
        _isLoading.value = true
        _filterState.value = InvestmentFilterState(isDefaultMode = true)
    }

    private fun calculateProfitFlow(shopId: String?, filter: InvestmentFilterState, shops: List<Shop>): Flow<RecoverySummary> = flow {
        val cacheKey = "investment_recovery_${shopId ?: "global"}_${filter.filterType}_${filter.startDate}_${filter.endDate}"
        
        // OPTIMISTIC UI: Load last known state
        val cachedSummary = repository.getListCache<RecoverySummary>(cacheKey).firstOrNull()
        
        // UNIFORM LOADING: Always set loading true when filter changes
        _isLoading.value = true
        
        if (cachedSummary != null) {
            emit(cachedSummary)
        }

        try {
            // Get investments (Take 1 for base calculation)
            val invList = repository.getInvestments(shopId).first()
            val totalInv = invList.asSequence().filterNot {
                it.category.equals("Deposit", ignoreCase = true) ||
                it.itemName.contains("Advance", ignoreCase = true)
            }.sumOf { it.amount }

            // Determine Start/End
            val earliestDate = if (invList.isNotEmpty()) invList.minOf { it.date } else System.currentTimeMillis()
            val earliestShopDate = if (shopId == null) {
                shops.filter { it.openingDate > 0 }.minOfOrNull { it.openingDate } ?: earliestDate
            } else {
                shops.find { it.shopId == shopId }?.openingDate?.takeIf { it > 0 } ?: earliestDate
            }

            val rangeStart = minOf(earliestDate, earliestShopDate)

            val calendar = Calendar.getInstance().apply {
                timeInMillis = rangeStart
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
            val actualStartTime = calendar.timeInMillis
            val actualEndTime = if (filter.isDefaultMode) System.currentTimeMillis() else filter.endDate

            // PERFORMANCE BOOSTER: Fetch the ENTIRE dataset in one single combined flow
            // Instead of N flows (one per month), we get all day-wise data once.
            repository.getFullDayWiseDataFlow(shopId, actualStartTime, actualEndTime, includeBonus = true)
                .collect { allDayData ->

                    val profitsMap = LinkedHashMap<String, Double>()
                    val cumulativeMap = LinkedHashMap<String, Double>()
                    var totalAccumulated = 0.0

                    // Group day data into period keys
                    val groupedData = allDayData.groupBy { day ->
                        getGroupKey(day.calendar, filter.filterType)
                    }

                    // Iterate through calendar from start to end to ensure all periods (including zero profit ones) are present
                    val iterCal = (calendar.clone() as Calendar)
                    val currentMonthStartTs = Calendar.getInstance().apply {
                        set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                    }.timeInMillis

                    while (iterCal.timeInMillis <= actualEndTime) {
                        val key = getGroupKey(iterCal, filter.filterType)
                        val periodDays = groupedData[key] ?: emptyList()

                        val mProfit = periodDays.sumOf { it.totalIn - (it.salaryEarned + it.totalOut + it.fixedExpense) }

                        // Safety: Don't show negative profit for current in-progress month in recovery view
                        // as it might be early days with only expenses recorded.
                        val isCurrentMonth = iterCal.timeInMillis >= currentMonthStartTs
                        val displayedProfit = if (isCurrentMonth && (filter.filterType == InvestmentFilterType.MONTHLY || filter.isDefaultMode)) {
                            maxOf(0.0, mProfit)
                        } else {
                            mProfit
                        }

                        if (!profitsMap.containsKey(key)) {
                            profitsMap[key] = displayedProfit
                            totalAccumulated += displayedProfit
                            cumulativeMap[key] = totalAccumulated
                        }

                        // Advance calendar based on filter
                        when(filter.filterType) {
                            InvestmentFilterType.DAY -> iterCal.add(Calendar.DAY_OF_YEAR, 1)
                            InvestmentFilterType.WEEKLY -> iterCal.add(Calendar.WEEK_OF_YEAR, 1)
                            InvestmentFilterType.MONTHLY -> iterCal.add(Calendar.MONTH, 1)
                            else -> iterCal.add(Calendar.MONTH, 1) // Default to monthly
                        }
                    }

                    val daysActive = ((actualEndTime - actualStartTime) / 86400000L).coerceAtLeast(1L).toDouble()
                    val dailyAvg = if (daysActive > 0) totalAccumulated / daysActive else 0.0
                    val projectedMonthly = dailyAvg * 30.44

                    // AI Projections
                    val projectedProfits = mutableMapOf<String, Double>()
                    var breakEvenMonthName: String? = null

                    if (projectedMonthly > 0 && totalAccumulated < totalInv) {
                        val projCal = Calendar.getInstance()
                        var runningTotal = totalAccumulated
                        val sdf = SimpleDateFormat("MMM yy", Locale.getDefault())
                        repeat(12) {
                            projCal.add(Calendar.MONTH, 1)
                            val key = "Proj " + sdf.format(projCal.time)
                            runningTotal += projectedMonthly
                            projectedProfits[key] = runningTotal
                            if (breakEvenMonthName == null && runningTotal >= totalInv) {
                                breakEvenMonthName = sdf.format(projCal.time)
                            }
                        }
                    }

                    val result = RecoverySummary(
                        totalInvestment = totalInv,
                        totalProfitEarned = totalAccumulated,
                        averageMonthlyProfit = if (projectedMonthly > 0) projectedMonthly else 0.0,
                        monthlyProfits = profitsMap,
                        cumulativeProfits = cumulativeMap,
                        projectedProfits = projectedProfits,
                        breakEvenMonth = breakEvenMonthName,
                        isDataSufficient = (daysActive >= 3) && (projectedMonthly > 0)
                    )

                    // Cache the result
                    repository.saveListCache(cacheKey, listOf(result))
                    emit(result)
                    _isLoading.value = false
                }

        } catch (e: Exception) {
            Log.e("InvestmentVM", "Calculation failed", e)
            emit(RecoverySummary())
            _isLoading.value = false
        }
    }.flowOn(Dispatchers.Default)

    private fun getGroupKey(calendar: Calendar, type: InvestmentFilterType): String {
        return when (type) {
            InvestmentFilterType.DAY -> SimpleDateFormat("dd MMM", Locale.getDefault()).format(calendar.time)
            InvestmentFilterType.WEEKLY -> {
                val cal = calendar.clone() as Calendar
                cal[Calendar.DAY_OF_WEEK] = cal.firstDayOfWeek
                val start = SimpleDateFormat("dd MMM", Locale.getDefault()).format(cal.time)
                cal.add(Calendar.DAY_OF_YEAR, 6)
                val end = SimpleDateFormat("dd MMM", Locale.getDefault()).format(cal.time)
                "$start - $end"
            }
            InvestmentFilterType.MONTHLY -> SimpleDateFormat("MMM yy", Locale.getDefault()).format(calendar.time)
            InvestmentFilterType.QUARTERLY -> {
                val month = calendar[Calendar.MONTH]
                val quarter = (month / 3) + 1
                "Q$quarter ${calendar[Calendar.YEAR]}"
            }
            InvestmentFilterType.HALF_YEARLY -> {
                val month = calendar[Calendar.MONTH]
                val half = if (month < 6) "H1" else "H2"
                "$half ${calendar[Calendar.YEAR]}"
            }
            InvestmentFilterType.YEARLY -> SimpleDateFormat("yyyy", Locale.getDefault()).format(calendar.time)
            InvestmentFilterType.CUSTOM -> SimpleDateFormat("dd MMM yy", Locale.getDefault()).format(calendar.time)
        }
    }

    fun addInvestment(name: String, amount: Double, date: Long, category: String) {
        val sId = if (_isGlobalMode.value) null else (_manualShopId.value ?: selectedShop.value?.shopId)
        if (sId == null && !_isGlobalMode.value) return
        viewModelScope.launch {
            repository.insertInvestment(Investment(shopId = sId ?: "GLOBAL", itemName = name, amount = amount, date = date, category = category))
        }
    }

    fun updateInvestment(investment: Investment) {
        viewModelScope.launch {
            repository.updateInvestment(investment)
        }
    }

    fun deleteInvestment(investment: Investment) {
        viewModelScope.launch {
            repository.deleteInvestment(investment)
        }
    }
}
