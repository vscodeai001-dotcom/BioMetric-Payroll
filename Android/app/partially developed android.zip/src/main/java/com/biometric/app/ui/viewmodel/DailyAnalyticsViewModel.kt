package com.biometric.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.DayData
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Shop
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

data class AnalyticsInsight(
    val title: String,
    val description: String,
    val type: InsightType,
)

enum class InsightType {
    POSITIVE, NEGATIVE, NEUTRAL
}

data class AnalyticsState(
    val dayDataList: List<DayData> = emptyList(),
    val totalSales: Double = 0.0,
    val totalPurchases: Double = 0.0,
    val totalSalary: Double = 0.0,
    val netProfit: Double = 0.0,
    val insights: List<AnalyticsInsight> = emptyList(),
    val isLoading: Boolean = true,
    val selectedShop: Shop? = null,
    val periodLabel: String = ""
)

@HiltViewModel
class DailyAnalyticsViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel
) : ViewModel() {

    private val _state = MutableStateFlow(AnalyticsState())
    val state: StateFlow<AnalyticsState> = _state.asStateFlow()

    private val _monthOffset = MutableStateFlow(0)
    val monthOffset: StateFlow<Int> = _monthOffset.asStateFlow()

    init {
        viewModelScope.launch {
            combine(sharedViewModel.selectedShop, _monthOffset) { shop, offset ->
                Pair(shop, offset)
            }.collect { (shop, offset) ->
                shop?.let { loadAnalytics(it, offset) }
            }
        }
    }

    fun changeMonth(offset: Int) {
        _monthOffset.value += offset
    }

    private fun loadAnalytics(shop: Shop, offset: Int) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true, selectedShop = shop) }

            val calendar = Calendar.getInstance()
            calendar.add(Calendar.MONTH, offset)
            calendar[Calendar.DAY_OF_MONTH] = 1
            calendar[Calendar.HOUR_OF_DAY] = 0; calendar[Calendar.MINUTE] = 0
            calendar[Calendar.SECOND] = 0; calendar[Calendar.MILLISECOND] = 0
            val startTime = calendar.timeInMillis

            val endCalendar = calendar.clone() as Calendar
            endCalendar[Calendar.DAY_OF_MONTH] = endCalendar.getActualMaximum(Calendar.DAY_OF_MONTH)
            endCalendar[Calendar.HOUR_OF_DAY] = 23; endCalendar[Calendar.MINUTE] = 59
            endCalendar[Calendar.SECOND] = 59; endCalendar[Calendar.MILLISECOND] = 999
            val endTime = endCalendar.timeInMillis

            val periodLabel = java.text.SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.time)
            val cacheKey = "analytics_${shop.shopId}_${startTime}_${endTime}"
            
            // OPTIMISTIC UI: Try to load from cache first
            val cached = repository.getListCache<AnalyticsState>(cacheKey).firstOrNull()
            
            // UNIFORM LOADING: Only set loading true if no cache available
            _state.value = (cached ?: AnalyticsState()).copy(isLoading = cached == null, periodLabel = periodLabel, selectedShop = shop)

            repository.getFullDayWiseDataFlow(shop.shopId, startTime, endTime).collect { dayDataList ->
                val sortedData = dayDataList.sortedBy { it.calendar.timeInMillis }

                val totalSales = sortedData.sumOf { it.totalIn }
                val totalPurchases = sortedData.sumOf { it.totalOut }
                val totalSalary = sortedData.sumOf { it.salaryEarned }
                val totalFixed = sortedData.sumOf { it.fixedExpense }
                val netProfit = totalSales - (totalPurchases + totalSalary + totalFixed)

                val insights = generateInsights(sortedData, totalSales, netProfit)

                val newState = AnalyticsState(
                    dayDataList = sortedData,
                    totalSales = totalSales,
                    totalPurchases = totalPurchases,
                    totalSalary = totalSalary,
                    netProfit = netProfit,
                    insights = insights,
                    isLoading = false,
                    selectedShop = shop,
                    periodLabel = periodLabel
                )

                _state.value = newState
                repository.saveListCache(cacheKey, listOf(newState))
            }
        }
    }

    private fun generateInsights(data: List<DayData>, totalSales: Double, netProfit: Double): List<AnalyticsInsight> {
        val insights = mutableListOf<AnalyticsInsight>()
        if (data.isEmpty()) return insights

        val bestDay = data.maxByOrNull { it.totalIn }
        bestDay?.let {
            insights.add(
                AnalyticsInsight(
                    "Peak Performance",
                    "${it.displayDate} was your best day with ₹${String.format(Locale.getDefault(), "%.0f", it.totalIn)} in sales.",
                    InsightType.POSITIVE
                )
            )
        }

        val weekendSales = data.asSequence().filter { 
            val day = it.calendar[Calendar.DAY_OF_WEEK]
            (day == Calendar.SATURDAY) || (day == Calendar.SUNDAY)
        }.sumOf { it.totalIn }
        
        val weekdaySales = totalSales - weekendSales
        if (weekendSales > weekdaySales * 0.5) {
            insights.add(AnalyticsInsight(
                "Weekend Surge",
                "Weekends contribute significantly to your revenue. Plan stock accordingly.",
                InsightType.POSITIVE
            ))
        }

        val highExpenseDays = data.filter { it.totalOut > it.totalIn * 0.8 }
        if (highExpenseDays.isNotEmpty()) {
            insights.add(AnalyticsInsight(
                "Expense Alert",
                "There were ${highExpenseDays.size} days where expenses were nearly equal to sales.",
                InsightType.NEGATIVE
            ))
        }

        if (netProfit > totalSales * 0.2) {
            insights.add(AnalyticsInsight(
                "Healthy Margins",
                "Your net profit margin is above 20%. Great job!",
                InsightType.POSITIVE
            ))
        }

        return insights
    }
}
