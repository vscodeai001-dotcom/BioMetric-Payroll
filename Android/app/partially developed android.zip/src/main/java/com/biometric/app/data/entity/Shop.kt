package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class SalaryRules(
    @get:PropertyName("newJoineeCutoffDay") @set:PropertyName("newJoineeCutoffDay")
    var newJoineeCutoffDay: Int = 5,
    
    @get:PropertyName("maxAbsencesForPaidLeave") @set:PropertyName("maxAbsencesForPaidLeave")
    var maxAbsencesForPaidLeave: Int = 3,
    
    @get:PropertyName("maxAbsencesForBonus") @set:PropertyName("maxAbsencesForBonus")
    var maxAbsencesForBonus: Int = 0,
    
    @get:PropertyName("maxShortfallMinutesForBonus") @set:PropertyName("maxShortfallMinutesForBonus")
    var maxShortfallMinutesForBonus: Int = 6,

    @get:PropertyName("paidLeaveDaysPool") @set:PropertyName("paidLeaveDaysPool")
    var paidLeaveDaysPool: Int = 1,

    @get:PropertyName("defaultShiftStart") @set:PropertyName("defaultShiftStart")
    var defaultShiftStart: String = "10:00",

    @get:PropertyName("defaultShiftEnd") @set:PropertyName("defaultShiftEnd")
    var defaultShiftEnd: String = "22:00",

    @get:PropertyName("defaultShift2Start") @set:PropertyName("defaultShift2Start")
    var defaultShift2Start: String? = null,

    @get:PropertyName("defaultShift2End") @set:PropertyName("defaultShift2End")
    var defaultShift2End: String? = null,

    @get:PropertyName("defaultBreakHours") @set:PropertyName("defaultBreakHours")
    var defaultBreakHours: Double = 0.0,

    @get:PropertyName("defaultOtMultiplier") @set:PropertyName("defaultOtMultiplier")
    var defaultOtMultiplier: Double = 1.0,

    @get:PropertyName("isBonusEligibleDefault") @set:PropertyName("isBonusEligibleDefault")
    var isBonusEligibleDefault: Boolean = true,

    @get:PropertyName("isPaidLeaveEligibleDefault") @set:PropertyName("isPaidLeaveEligibleDefault")
    var isPaidLeaveEligibleDefault: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekdaysDefault") @set:PropertyName("paidLeaveOnWeekdaysDefault")
    var paidLeaveOnWeekdaysDefault: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekendsDefault") @set:PropertyName("paidLeaveOnWeekendsDefault")
    var paidLeaveOnWeekendsDefault: Boolean = false
)

@Keep
data class Shop(
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("location") @set:PropertyName("location")
    var location: String = "",
    
    @get:PropertyName("openingDate") @set:PropertyName("openingDate")
    var openingDate: Long = System.currentTimeMillis(),
    
    @get:PropertyName("openingCashBalance") @set:PropertyName("openingCashBalance")
    var openingCashBalance: Double = 0.0,
    
    @get:PropertyName("tableCount") @set:PropertyName("tableCount")
    var tableCount: Int = 0,
    
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true,
    
    @get:PropertyName("brandingName") @set:PropertyName("brandingName")
    var brandingName: String? = null,
    
    @get:PropertyName("brandingLogoUrl") @set:PropertyName("brandingLogoUrl")
    var brandingLogoUrl: String? = null,
    
    @get:PropertyName("salaryRules") @set:PropertyName("salaryRules")
    var salaryRules: SalaryRules = SalaryRules(),
    
    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis(),
    
    @get:PropertyName("updatedAt") @set:PropertyName("updatedAt")
    var updatedAt: Long = System.currentTimeMillis()
)
