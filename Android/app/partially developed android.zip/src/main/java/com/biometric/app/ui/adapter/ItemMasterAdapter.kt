package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.data.entity.Item
import com.biometric.app.data.entity.ShopMenuItem
import com.biometric.app.databinding.ItemMasterRowBinding
import java.util.Locale

class ItemMasterAdapter(
    private val onSetPriceClick: (Item) -> Unit,
    private val onEditClick: (Item) -> Unit,
    private val onDeleteClick: (Item) -> Unit
) : ListAdapter<ShopMenuItem, ItemMasterAdapter.ItemViewHolder>(ItemDiffCallback()) {

    private var fullList: List<ShopMenuItem> = emptyList()

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        val binding = ItemMasterRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ItemViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    fun updateData(list: List<ShopMenuItem>) {
        fullList = list
        submitList(list)
    }

    fun filter(query: String) {
        val filtered = if (query.isEmpty()) {
            fullList
        } else {
            fullList.filter {
                it.item.name.contains(query, ignoreCase = true) || it.item.category.contains(query, ignoreCase = true)
            }
        }
        submitList(filtered)
    }

    inner class ItemViewHolder(private val binding: ItemMasterRowBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(menuItem: ShopMenuItem) {
            val item = menuItem.item
            binding.tvItemName.text = item.name
            binding.tvCategory.text = item.category
            
            binding.tvPriceDisplay.text = String.format(Locale.getDefault(), "₹%.2f", menuItem.finalPrice)
            
            binding.btnSetPrice.setOnClickListener { onSetPriceClick(item) }
            binding.btnEdit.setOnClickListener { onEditClick(item) }
            binding.btnDelete.setOnClickListener { onDeleteClick(item) }
            
            binding.root.setOnClickListener { onSetPriceClick(item) }
        }
    }

    class ItemDiffCallback : DiffUtil.ItemCallback<ShopMenuItem>() {
        override fun areItemsTheSame(oldItem: ShopMenuItem, newItem: ShopMenuItem) = oldItem.item.itemId == newItem.item.itemId
        override fun areContentsTheSame(oldItem: ShopMenuItem, newItem: ShopMenuItem) = oldItem == newItem
    }
}
