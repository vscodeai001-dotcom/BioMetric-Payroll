package com.biometric.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityRiskAlertsBinding
import com.biometric.app.databinding.ItemRiskAlertBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.RiskAlert
import com.biometric.app.ui.viewmodel.RiskAlertViewModel
import com.biometric.app.ui.viewmodel.RiskPriority
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class RiskAlertActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityRiskAlertsBinding
    private val viewModel: RiskAlertViewModel by viewModels()

    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter

    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRiskAlertsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Risk Assistant")

        if (isGlobal) shopId = ""

        setupToolbar(shopName)
        setupUI()
        setupChart()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(name: String) {
        setupDualHeader(binding.toolbar, name, "Risk Analysis")
    }



    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        binding.rvRiskAlerts.layoutManager = LinearLayoutManager(this)

        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate,
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadRisks(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun setupChart() {
        ChartStyleManager.applyChartStyle(binding.riskTrendChart, this)
        binding.riskTrendChart.apply {
            axisLeft.axisMaximum = 100f
            animateXY(1200, 1200, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            if (it.shopId != shopId) {
                                shopId = it.shopId
                                isGlobal = false
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // Strict Anti-Flicker Logic
                        val isDataZero = (state.alerts.isEmpty()) && (state.summary.total == 0)
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.RISK, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                        
                        // Update Summary
                        binding.tvTotalRisks.text = state.summary.total.toString()
                        binding.tvHighRisks.text = state.summary.high.toString()
                        binding.tvMediumRisks.text = state.summary.medium.toString()
                        binding.tvLowRisks.text = state.summary.low.toString()

                        if (state.alerts.isEmpty() && !state.isLoading) {
                            binding.llNoAlerts.visibility = View.VISIBLE
                            binding.rvRiskAlerts.visibility = View.GONE
                        } else {
                            binding.llNoAlerts.visibility = View.GONE
                            binding.rvRiskAlerts.visibility = View.VISIBLE
                            binding.rvRiskAlerts.adapter = RiskAlertAdapter(state.alerts)
                        }

                        if (state.trendData.isNotEmpty()) {
                            updateTrendChart(state.trendData)
                        }
                    }
                }
            }
        }
    }

    private fun updateTrendChart(data: List<com.biometric.app.ui.viewmodel.RiskTrendData>) {
        val entries = data.mapIndexed { index, item ->
            Entry(index.toFloat(), item.riskScore.toFloat())
        }

        val dataSet = LineDataSet(entries, "Risk Index").apply {
            color = ContextCompat.getColor(this@RiskAlertActivity, R.color.red)
            setCircleColor(ContextCompat.getColor(this@RiskAlertActivity, R.color.red))
            lineWidth = 2f
            circleRadius = 4f
            setDrawCircleHole(false)
            valueTextSize = 10f
            setDrawFilled(true)
            fillColor = ContextCompat.getColor(this@RiskAlertActivity, R.color.red)
            fillAlpha = 30
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        binding.riskTrendChart.apply {
            xAxis.valueFormatter = IndexAxisValueFormatter(data.map { it.label })
            this.data = LineData(dataSet)
            animateXY(1200, 1200, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)
            invalidate()
        }
    }

    class RiskAlertAdapter(private val alerts: List<RiskAlert>) : RecyclerView.Adapter<RiskAlertAdapter.ViewHolder>() {
        class ViewHolder(val binding: ItemRiskAlertBinding) : RecyclerView.ViewHolder(binding.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
            ViewHolder(ItemRiskAlertBinding.inflate(LayoutInflater.from(parent.context), parent, false))
        
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val alert = alerts[position]
            val context = holder.itemView.context
            
            holder.binding.tvAlertTitle.text = alert.title
            holder.binding.tvAlertChange.text = alert.changeText
            holder.binding.tvAlertCategory.text = alert.category.uppercase()
            holder.binding.tvAlertReason.text = alert.reason ?: "Unusual pattern detected"
            
            val details = StringBuilder()
            alert.impact?.let { details.append("⚠ Impact: $it\n") }
            alert.affectedDays?.let { details.append("📅 Affected days: $it") }
            
            holder.binding.tvAlertImpact.text = details.toString().trim()
            holder.binding.tvAlertImpact.visibility = if (details.isEmpty()) View.GONE else View.VISIBLE
            
            holder.binding.tvAlertSuggestion.text = alert.suggestion
            
            val colorRes = when(alert.priority) {
                RiskPriority.HIGH -> R.color.red
                RiskPriority.MEDIUM -> R.color.amber
                RiskPriority.LOW -> R.color.blue
            }
            
            val color = ContextCompat.getColor(context, colorRes)
            holder.binding.viewPrioritySide.setBackgroundColor(color)
            holder.binding.tvAlertChange.setTextColor(color)
            holder.binding.tvAlertImpact.setTextColor(color)
            
            // Set light background for impact
            val alphaColor = ColorUtils.setAlphaComponent(color, 25)
            holder.binding.tvAlertImpact.setBackgroundColor(alphaColor)
        }
        override fun getItemCount() = alerts.size
    }
}