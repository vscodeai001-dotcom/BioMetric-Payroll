package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class SalarySnapshot(
    @get:PropertyName("snapshotId") @set:PropertyName("snapshotId")
    var snapshotId: String = "", // Format: employeeId_periodEndTs
    
    @get:PropertyName("employeeId") @set:PropertyName("employeeId")
    var employeeId: String = "",
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("periodStart") @set:PropertyName("periodStart")
    var periodStart: Long = 0L,
    
    @get:PropertyName("periodEnd") @set:PropertyName("periodEnd")
    var periodEnd: Long = 0L,
    
    @get:PropertyName("totalNormalWorkedHours") @set:PropertyName("totalNormalWorkedHours")
    var totalNormalWorkedHours: Double = 0.0,
    
    @get:PropertyName("totalOTHours") @set:PropertyName("totalOTHours")
    var totalOTHours: Double = 0.0,
    
    @get:PropertyName("presentDaysCount") @set:PropertyName("presentDaysCount")
    var presentDaysCount: Int = 0,
    
    @get:PropertyName("closedShopDaysCount") @set:PropertyName("closedShopDaysCount")
    var closedShopDaysCount: Int = 0,
    
    @get:PropertyName("totalAllowanceMoney") @set:PropertyName("totalAllowanceMoney")
    var totalAllowanceMoney: Double = 0.0,
    
    @get:PropertyName("paidClosedDaysSalary") @set:PropertyName("paidClosedDaysSalary")
    var paidClosedDaysSalary: Double = 0.0,
    
    @get:PropertyName("paidClosedDaysHours") @set:PropertyName("paidClosedDaysHours")
    var paidClosedDaysHours: Double = 0.0,
    
    @get:PropertyName("upToDateRequiredHrs") @set:PropertyName("upToDateRequiredHrs")
    var upToDateRequiredHrs: Double = 0.0,
    
    @get:PropertyName("dayWiseEarningsJson") @set:PropertyName("dayWiseEarningsJson")
    var dayWiseEarningsJson: String = "{}",
    
    @get:PropertyName("dayWiseOTEarningsJson") @set:PropertyName("dayWiseOTEarningsJson")
    var dayWiseOTEarningsJson: String = "{}",
    
    @get:PropertyName("dayWiseAllowancesJson") @set:PropertyName("dayWiseAllowancesJson")
    var dayWiseAllowancesJson: String = "{}",
    
    @get:PropertyName("dayWiseWorkedHoursJson") @set:PropertyName("dayWiseWorkedHoursJson")
    var dayWiseWorkedHoursJson: String = "{}",
    
    @get:PropertyName("dayWiseBonusJson") @set:PropertyName("dayWiseBonusJson")
    var dayWiseBonusJson: String = "{}",
    
    @get:PropertyName("dayWisePaidLeaveJson") @set:PropertyName("dayWisePaidLeaveJson")
    var dayWisePaidLeaveJson: String = "{}",
    
    @get:PropertyName("dayShortfallsJson") @set:PropertyName("dayShortfallsJson")
    var dayShortfallsJson: String = "{}",
    
    @get:PropertyName("personalAbsenceDaysJson") @set:PropertyName("personalAbsenceDaysJson")
    var personalAbsenceDaysJson: String = "[]",
    
    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis()
) : Serializable
