package com.biometric.app.data.repository

import com.biometric.app.data.entity.UserProfile
import com.biometric.app.data.entity.UserRole
import com.google.firebase.database.FirebaseDatabase
import kotlinx.coroutines.tasks.await
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class AuthRepository @Inject constructor() {
    private val database = FirebaseDatabase.getInstance().reference
    private val profilesRef = database.child("user_profiles")

    suspend fun verifyEmployeeCredentials(employeeId: String, password: String): UserProfile? {
        val snapshot = profilesRef.orderByChild("employeeId").equalTo(employeeId).get().await()
        for (child in snapshot.children) {
            val profile = child.getValue(UserProfile::class.java)
            if (profile != null && profile.password == password) {
                return profile
            }
        }
        return null
    }

    suspend fun getProfileByPhone(phone: String): UserProfile? {
        val digitsOnly = phone.filter { it.isDigit() }
        val formats = listOf(phone, "+91$digitsOnly", digitsOnly, digitsOnly.takeLast(10))
        
        for (f in formats.distinct()) {
            val snapshot = profilesRef.orderByChild("phone").equalTo(f).get().await()
            val profile = snapshot.children.firstOrNull()?.getValue(UserProfile::class.java)
            if (profile != null) return profile
        }
        return null
    }

    suspend fun getProfileByEmployeeId(empId: String): UserProfile? {
        val snapshot = profilesRef.orderByChild("employeeId").equalTo(empId).get().await()
        return snapshot.children.firstOrNull()?.getValue(UserProfile::class.java)
    }

    suspend fun checkDeviceBinding(uid: String, deviceId: String): Boolean {
        val snapshot = profilesRef.child(uid).get().await()
        val registeredDeviceId = snapshot.child("deviceId").getValue(String::class.java)
        return registeredDeviceId == null || registeredDeviceId == deviceId
    }

    suspend fun updateDeviceBinding(uid: String, deviceId: String, deviceModel: String, androidVersion: Int) {
        val updates = mapOf(
            "deviceId" to deviceId,
            "deviceModel" to deviceModel,
            "androidVersion" to androidVersion,
            "registeredAt" to System.currentTimeMillis()
        )
        profilesRef.child(uid).updateChildren(updates).await()
    }

    suspend fun getUserRole(uid: String): UserRole {
        val snapshot = profilesRef.child(uid).child("role").get().await()
        val roleStr = snapshot.getValue(String::class.java) ?: UserRole.STAFF.name
        return try {
            UserRole.valueOf(roleStr)
        } catch (e: Exception) {
            UserRole.STAFF
        }
    }

    suspend fun getUserProfile(uid: String): UserProfile {
        return profilesRef.child(uid).get().await().getValue(UserProfile::class.java) ?: UserProfile(uid = uid)
    }
}
