package com.biometric.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.Log
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.core.view.isVisible
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.util.MotionManager
import com.biometric.app.util.NaturalLanguageEngine
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.DayData
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.databinding.ActivityDetailedReportBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.ReportsViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.viewmodel.StaffViewModel
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.ui.adapter.CashbookPagingAdapter
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.PremiumLoader
import com.biometric.app.util.PickerHelper
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.biometric.app.utils.PremiumUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class DetailedReportActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityDetailedReportBinding
    private val reportsViewModel: ReportsViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    private val staffViewModel: StaffViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var repository: MainRepository
    private lateinit var ledgerAdapter: LedgerAdapter
    private val pagingAdapter = CashbookPagingAdapter()
    private var selectedDate: Calendar = Calendar.getInstance()
    private var shopId: String? = null
    private var currentFilter = "Up To Date"
    private var customEndDate: Long? = null
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var isGlobal: Boolean = false
    private var isChartExpanded: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityDetailedReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = if (isGlobal) "" else intent.getStringExtra("SHOP_ID")
        val shopName = intent.getStringExtra("SHOP_NAME")
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        updateToolbarTitle(if (isGlobal) "All Shops" else (shopName ?: "Detailed Report"))
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }

        val specificDateMillis = intent.getLongExtra("SPECIFIC_DATE", -1L)
        if (specificDateMillis != -1L) {
            selectedDate.timeInMillis = specificDateMillis
            currentFilter = "Daily"
        }
        
        val filterFromIntent = intent.getStringExtra("FILTER_TYPE")
        filterFromIntent?.let {
            currentFilter = it
        }

        val startTimeIntent = intent.getLongExtra("START_TIME", -1L)
        val endTimeIntent = intent.getLongExtra("END_TIME", -1L)
        
        if (startTimeIntent != -1L) {
            selectedDate.timeInMillis = startTimeIntent
        }
        
        if (endTimeIntent != -1L) {
            customEndDate = endTimeIntent
        }
        
        if (!isGlobal && !shopId.isNullOrEmpty()) {
            staffViewModel.setShop(shopId!!)
        }
        
        setupUI()
        setupChart()
        setupChartToggle()
        observeViewModel()
        
        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        if ((currentFilter == "Custom") && (startTimeIntent != -1L) && (endTimeIntent != -1L)) {
            reportsViewModel.loadReportsForPeriod(shopId, startTimeIntent, endTimeIntent, includeBonus = true)
            binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel("Custom", startTimeIntent, endTimeIntent)
            filterAdapter.setSelected("Custom", selectedDate.timeInMillis)
        } else {
            refreshReport()
        }
    }

    private fun setupChartToggle() {
        binding.llChartHeader.setOnClickListener {
            isChartExpanded = !isChartExpanded
            binding.lineChart.visibility = if (isChartExpanded) View.VISIBLE else View.GONE
            binding.ivChartExpand.rotation = if (isChartExpanded) 270f else 90f
            if (isChartExpanded && (binding.lineChart.data != null)) {
                binding.lineChart.post {
                    binding.lineChart.animateX(500)
                }
            }
        }
    }

    private fun setupChart() {
        binding.lineChart.apply {
            description.isEnabled = false
            setTouchEnabled(true)
            isDragEnabled = true
            setScaleEnabled(true)
            setPinchZoom(true)
            setDrawGridBackground(false)
            
            val textColor = ContextCompat.getColor(context, R.color.text_secondary)
            val gridColor = ContextCompat.getColor(context, R.color.divider)

            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                this.textColor = textColor
                this.gridColor = gridColor
                valueFormatter = object : ValueFormatter() {
                    private val mFormat = SimpleDateFormat("dd MMM", Locale.getDefault())
                    override fun getFormattedValue(value: Float): String {
                        return mFormat.format(Date(value.toLong()))
                    }
                }
            }
            
            axisLeft.apply {
                setDrawGridLines(true)
                this.textColor = textColor
                this.gridColor = gridColor
            }
            
            axisRight.isEnabled = false
            legend.isEnabled = false
            animateX(1000)
        }
    }

    private var chartBaseTimestamp: Long = 0L

    private fun updateChartDataFromDayData(data: List<DayData>) {
        if (data.isEmpty()) {
            binding.cardProfitChart.visibility = View.GONE
            return
        }

        val sortedData = data.sortedBy { it.calendar.timeInMillis }
        chartBaseTimestamp = sortedData.first().calendar.timeInMillis
        binding.cardProfitChart.visibility = View.VISIBLE

        val chartEntries = sortedData.map { day ->
            val net = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
            val offset = (day.calendar.timeInMillis - chartBaseTimestamp).toFloat()
            Entry(offset, net.toFloat())
        }

        if (chartEntries.size < 2) {
            binding.cardProfitChart.visibility = View.GONE
            return
        }

        setupAndRefreshChart(chartEntries)
    }

    private fun updateChartData(entries: List<Cashbook>) {
        if (entries.isEmpty()) {
            binding.cardProfitChart.visibility = View.GONE
            return
        }

        val base = entries.minOf { it.transactionDate }
        val calBase = Calendar.getInstance().apply { 
            timeInMillis = base
            this[Calendar.HOUR_OF_DAY] = 0; this[Calendar.MINUTE] = 0; this[Calendar.SECOND] = 0; this[Calendar.MILLISECOND] = 0
        }
        chartBaseTimestamp = calBase.timeInMillis
        
        binding.cardProfitChart.visibility = View.VISIBLE

        // Grouping logic based on filter
        val groupedProfit = when (currentFilter) {
            "Annually", "Quarterly", "Half Yearly" -> {
                entries.groupBy {
                    val cal = Calendar.getInstance().apply { timeInMillis = it.transactionDate }
                    cal.set(Calendar.DAY_OF_MONTH, 1)
                    cal.set(Calendar.HOUR_OF_DAY, 0)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    cal.timeInMillis
                }
            }
            else -> {
                entries.groupBy {
                    val cal = Calendar.getInstance().apply { timeInMillis = it.transactionDate }
                    cal.set(Calendar.HOUR_OF_DAY, 0)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    cal.timeInMillis
                }
            }
        }.mapValues { (_, dayEntries) ->
            dayEntries.sumOf { if (it.transactionType == "IN") it.amount else -it.amount }
        }.toSortedMap()

        val chartEntries = groupedProfit.map { (timestamp, profit) ->
            val offset = (timestamp - chartBaseTimestamp).toFloat()
            Entry(offset, profit.toFloat())
        }

        if (chartEntries.size < 2) {
            binding.cardProfitChart.visibility = View.GONE
            return
        }

        setupAndRefreshChart(chartEntries)
    }

    private fun setupAndRefreshChart(chartEntries: List<Entry>) {
        binding.lineChart.setOnChartValueSelectedListener(
            object : OnChartValueSelectedListener {
                override fun onValueSelected(e: Entry?, h: Highlight?) {
                    e?.let {
                        val timestamp = it.x.toLong() + chartBaseTimestamp
                        val dateStr = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(timestamp))
                        val amount = String.format(Locale.getDefault(), "%.2f", it.y)
                        PremiumUI.showSuccess(this@DetailedReportActivity, "Profit Detail", "$dateStr: ₹$amount")
                    }
                }

                override fun onNothingSelected() {}
            },
        )

        // Update ValueFormatter based on grouping
        binding.lineChart.xAxis.valueFormatter = object : ValueFormatter() {
            private val dayFormat = SimpleDateFormat("dd MMM", Locale.getDefault())
            private val monthFormat = SimpleDateFormat("MMM yy", Locale.getDefault())
            override fun getFormattedValue(value: Float): String {
                val timestamp = value.toLong() + chartBaseTimestamp
                return if ((currentFilter == "Annually") || (currentFilter == "Quarterly")) {
                    monthFormat.format(Date(timestamp))
                } else {
                    dayFormat.format(Date(timestamp))
                }
            }
        }

        val primaryColor = ContextCompat.getColor(this, R.color.colorPrimary)
        val textPrimaryColor = ContextCompat.getColor(this, R.color.text_primary)

        val dataSet = LineDataSet(chartEntries, "Net Profit").apply {
            color = primaryColor
            setCircleColor(primaryColor)
            lineWidth = 2f
            circleRadius = 4f
            setDrawCircleHole(true)
            setDrawValues(true)
            valueTextColor = textPrimaryColor
            valueTextSize = 10f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "₹%.0f".format(value)
                }
            }
            setDrawFilled(true)
            fillDrawable = ContextCompat.getDrawable(this@DetailedReportActivity, R.drawable.chart_gradient)
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        binding.lineChart.data = LineData(dataSet)
        binding.lineChart.notifyDataSetChanged()
        binding.lineChart.invalidate()
        if (isChartExpanded) {
            binding.lineChart.animateX(800)
        }
    }

    private fun updateToolbarTitle(name: String) {
        val shopName = sharedViewModel.selectedShop.value?.name ?: name
        val line1 = if (isGlobal) "Global Insights 🌏" else shopName
        val line2 = if (name.contains("Report", ignoreCase = true)) "Financial Ledger" else "Detailed Report"
        setupDualHeader(binding.toolbar, line1, line2)
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🔄", "Resync") {
                reportsViewModel.reSyncSnapshots(shopId, selectedDate.timeInMillis)
                Toast.makeText(this@DetailedReportActivity, "Re-calculating metrics...", Toast.LENGTH_SHORT).show()
            },
            GlobalSwitcherDelegate.ActionItem("📊", "Export Excel") {
                Toast.makeText(this@DetailedReportActivity, "Generating Excel Report...", Toast.LENGTH_SHORT).show()
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🔄", "Resync") {
                reportsViewModel.reSyncSnapshots(shopId, selectedDate.timeInMillis)
                Toast.makeText(this@DetailedReportActivity, "Re-calculating metrics...", Toast.LENGTH_SHORT).show()
            },
            GlobalSwitcherDelegate.ActionItem("📊", "Export Excel") {
                Toast.makeText(this@DetailedReportActivity, "Generating Excel Report...", Toast.LENGTH_SHORT).show()
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        ledgerAdapter = LedgerAdapter(::updateFilteredSum)
        binding.rvDetailedBreakdown.layoutManager = LinearLayoutManager(this)
        binding.rvDetailedBreakdown.adapter = pagingAdapter // Start with paging adapter

        filterAdapter = HorizontalFilterAdapter(showCustom = true) { selected: String ->
            if (selected == "Custom") {
                showDateRangePicker()
            } else {
                currentFilter = selected
                customEndDate = null // Clear custom end date when switching to other filters
                refreshReport()
            }
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 8)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            if (currentFilter.equals("Custom", ignoreCase = true)) {
                showDateRangePicker()
            } else {
                PickerHelper.showSmartPicker(
                    this, currentFilter, selectedDate
                ) { newDate ->
                    selectedDate.timeInMillis = newDate.timeInMillis
                    refreshReport()
                }
            }
        }

        // Ensure search box is visible
        binding.etSearch.visibility = View.VISIBLE
        (binding.etSearch.parent.parent as? View)?.visibility = View.VISIBLE

        binding.etSearch.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val query = s.toString()
                    if (query.isEmpty()) {
                        binding.rvDetailedBreakdown.adapter = pagingAdapter
                        updateFilteredSum(0.0, isFilterActive = false)
                    } else {
                        // Check for global time commands (e.g. "milk last week")
                        NaturalLanguageEngine.parseGlobalTimeCommand(query)?.let { (newPeriod, start, _) ->
                            val newCal = Calendar.getInstance().apply { timeInMillis = start }
                            if (newPeriod != currentFilter || !isSameDay(newCal, selectedDate)) {
                                currentFilter = newPeriod
                                selectedDate = newCal
                                refreshReport()
                                // The query will be applied to the NEW list once it loads
                                return@onTextChanged
                            }
                        }

                        binding.rvDetailedBreakdown.adapter = ledgerAdapter
                        ledgerAdapter.filter(query)
                    }
                }

                override fun afterTextChanged(s: Editable?) {}
            }
        )
    }

    private fun showDateRangePicker() {
        val picker = com.google.android.material.datepicker.MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText("Select Custom Range")
            .build()

        picker.addOnPositiveButtonClickListener { range ->
            val start = range.first ?: System.currentTimeMillis()
            val end = range.second ?: System.currentTimeMillis()

            currentFilter = "Custom"
            selectedDate.timeInMillis = start
            customEndDate = end

            reportsViewModel.loadReportsForPeriod(shopId, start, end, includeBonus = true)
            binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel("Custom", start, end)
            filterAdapter.setSelected("Custom", start)
        }
        picker.show(supportFragmentManager, "date_range_picker")
    }

    private fun isSameDay(c1: Calendar, c2: Calendar): Boolean {
        return c1[Calendar.YEAR] == c2[Calendar.YEAR] &&
               c1[Calendar.DAY_OF_YEAR] == c2[Calendar.DAY_OF_YEAR]
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshReport()
    }

    private fun refreshReport() {
        lifecycleScope.launch {
            try {
                val range = DateRangeUtil.getRangeForPeriod(currentFilter, selectedDate.timeInMillis, endDate = customEndDate)
                val startMillis = range.first
                val endMillis = range.second

                binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis, customEndDate)
                filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)

                // Hide navigation arrows in Custom mode to maintain centering
                val isCustom = currentFilter.equals("Custom", ignoreCase = true)
                binding.layoutFilterIcons.btnPrevDate.visibility = if (isCustom) View.INVISIBLE else View.VISIBLE
                binding.layoutFilterIcons.btnNextDate.visibility = if (isCustom) View.INVISIBLE else View.VISIBLE

                reportsViewModel.loadReportsForPeriod(shopId, startMillis, endMillis, includeBonus = true)
            } catch (e: Exception) {
                Log.e("DetailedReportActivity", "Error refreshing report", e)
            }
        }
    }

    private var currentNetResult: Double = 0.0

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                staffViewModel.setShop(it.shopId)
                                refreshReport()
                            }
                        }
                    }
                }

                launch {
                    staffViewModel.employeeStats.collectLatest { stats ->
                        val map = stats.mapValues { it.value.employee?.name ?: "Unknown" }
                        ledgerAdapter.setEmployeeMap(map)
                        pagingAdapter.setEmployeeMap(map)
                    }
                }

                launch {
                    combine(
                        reportsViewModel.isLoading,
                        pagingAdapter.loadStateFlow,
                    ) { viewModelLoading, pagingLoadStates ->
                        // Zero-Flicker Logic: If metrics are zero and we are still in initial/silent load,
                        // we stay in "Brewing" state to avoid showing 0.00 flicker.
                        val state = reportsViewModel.reportData.value
                        val isDataZero = currentNetResult == 0.0 && state.cashbookEntries.isEmpty() && state.dayWiseReport.isEmpty()
                        val isLoading = viewModelLoading || (pagingLoadStates.refresh is androidx.paging.LoadState.Loading)

                        isLoading && isDataZero
                    }.collectLatest { showBrewing ->
                        if (showBrewing) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
                            binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                    }
                }

                launch {
                    reportsViewModel.pagedCashbookEntries.collectLatest {
                        pagingAdapter.submitData(it)
                    }
                }

                launch {
                    reportsViewModel.isLoading.collectLatest { loading ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = reportsViewModel.reportData.value.dayWiseReport.isEmpty() && reportsViewModel.reportData.value.cashbookEntries.isEmpty()
                        if (loading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                    }
                }

                launch {
                    reportsViewModel.reportData.collectLatest { state ->
                        ledgerAdapter.updateList(state.cashbookEntries, binding.etSearch.text.toString())
                        if (state.dayWiseReport.isNotEmpty()) {
                            updateChartDataFromDayData(state.dayWiseReport)
                        } else {
                            updateChartData(state.cashbookEntries)
                        }
                        updateSummary(state)
                    }
                }
            }
        }
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) {
            Toast.makeText(this, "Loading shops...", Toast.LENGTH_SHORT).show()
            return
        }

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                isGlobal = false
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                staffViewModel.setShop(selectedShop.shopId)
                refreshReport()
            }
            .show()
    }


    private fun updateSummary(state: ReportsViewModel.DetailedReportState) {
        val totalIn = state.cashFlow?.totalIn ?: 0.0
        val totalOut = state.cashFlow?.totalOut ?: 0.0
        val salary = state.totalSalary
        val fixedExpenses = state.cashFlow?.fixedExpenses ?: 0.0
        val result = totalIn - totalOut - salary - fixedExpenses
        currentNetResult = result

        binding.tvTotalIn.text = String.format(Locale.getDefault(), "₹ %.2f", totalIn)
        binding.tvTotalOut.text = String.format(Locale.getDefault(), "₹ %.2f", totalOut)
        binding.tvTotalSalary.text = String.format(Locale.getDefault(), "₹ %.2f", salary)
        binding.tvFixedExpenses.text = String.format(Locale.getDefault(), "₹ %.2f", fixedExpenses)
        binding.tvNetResult.text = String.format(Locale.getDefault(), "₹ %.2f", result)
        val colorRes = if (result >= 0) R.color.green else R.color.red
        binding.tvNetResult.setTextColor(ContextCompat.getColor(this, colorRes))

        // Adaptive Motion - Pulse based on net result
        MotionManager.startPulse(binding.tvNetResult, isPositive = result >= 0)
    }

    private fun updateFilteredSum(sum: Double, isFilterActive: Boolean) {
        if (isFilterActive) {
            binding.llFilteredSum.visibility = View.VISIBLE
            binding.tvFilteredSum.text = String.format(Locale.getDefault(), "₹ %.2f", sum)
        } else {
            binding.llFilteredSum.visibility = View.GONE
        }
    }

    class LedgerAdapter(private val onFilter: (Double, Boolean) -> Unit) :
        RecyclerView.Adapter<LedgerAdapter.ViewHolder>() {
        private var items: List<Cashbook> = listOf()
        private var filteredItems: List<Cashbook> = listOf()
        private var employeeMap: Map<String, String> = mapOf()

        class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvDate: TextView = itemView.findViewById(R.id.tvDate)
            val tvEmoji: TextView = itemView.findViewById(R.id.tvEmoji)
            val tvParticulars: TextView = itemView.findViewById(R.id.tvParticulars)
            val tvDebit: TextView = itemView.findViewById(R.id.tvDebit)
            val tvCredit: TextView = itemView.findViewById(R.id.tvCredit)
        }

        fun updateList(newItems: List<Cashbook>, currentQuery: String = "") {
            items = newItems
            filter(currentQuery)
        }

        fun setEmployeeMap(map: Map<String, String>) {
            employeeMap = map
            notifyDataSetChanged()
        }

        fun filter(query: String) {
            filteredItems = if (query.isEmpty()) {
                items
            } else {
                com.biometric.app.util.NaturalLanguageEngine.filterLedger(items, query)
            }
            val sum = filteredItems.sumOf { if (it.transactionType == "IN") it.amount else -it.amount }
            onFilter(sum, query.isNotEmpty())
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_ledger_row, parent, false)
            return ViewHolder(view)
        }

        private fun getEmojiForEntry(category: String, description: String?): String {
            val searchText = "$category ${description.orEmpty()}"
            return when {
                searchText.contains("MILK", ignoreCase = true) -> "🥛"
                searchText.contains("BREAD", ignoreCase = true) -> "🍞"
                searchText.contains("FOOD", ignoreCase = true) -> "🍔"
                category.equals("DAILY SALES (CASH)", ignoreCase = true) -> "💵"
                category.equals("DAILY SALES (QR)", ignoreCase = true) -> "📱"
                category.equals("OPENING CASH", ignoreCase = true) -> "💰"
                category.equals("PURCHASE", ignoreCase = true) -> "🛒"
                category.equals("SALARY", ignoreCase = true) -> "🧑\u200D💼"
                category.equals("ADVANCE", ignoreCase = true) -> "💸"
                category.equals("RENT", ignoreCase = true) -> "🏠"
                category.equals("EB/GAS", ignoreCase = true) -> "💡"
                category.equals("MAINTENANCE", ignoreCase = true) -> "🔧"
                else -> "💲"
            }
        }

        fun getParticulars(item: Cashbook) : String {
            val description = item.description
            var particulars = if (description.isNullOrEmpty()) {
                item.category
            } else {
                if (description.startsWith(item.category, ignoreCase = true)) {
                    description
                } else {
                    "${item.category} - $description"
                }
            }
            if (item.category.equals("ADVANCE", ignoreCase = true) || item.category.equals("SALARY", ignoreCase = true)) {
                item.referenceId?.let { refId ->
                    employeeMap[refId]?.let {
                        particulars = "${item.category} to $it"
                    }
                }
            }
            return particulars
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = filteredItems[position]
            val dateFormat = SimpleDateFormat("dd/MM/yy", Locale.getDefault())
            holder.tvDate.text = dateFormat.format(Date(item.transactionDate))
            holder.tvEmoji.text = getEmojiForEntry(item.category, item.description)
            holder.tvParticulars.text = getParticulars(item)

            if (item.transactionType == "IN") {
                holder.tvCredit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvCredit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.green))
                holder.tvDebit.text = ""
            } else {
                holder.tvDebit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvDebit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.red))
                holder.tvCredit.text = ""
            }

            holder.itemView.setOnClickListener {
                val fullDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                val transDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.transactionDate))
                val entryTime = fullDateFormat.format(Date(item.createdAt))

                MaterialAlertDialogBuilder(holder.itemView.context)
                    .setTitle("Entry Details 📋")
                    .setMessage("This entry was recorded on **$entryTime** for the date of **$transDate**.\n\n" +
                            "Category: ${item.category}\n" +
                            "Description: ${item.description ?: "N/A"}\n" +
                            "Amount: ₹${String.format(Locale.getDefault(), "%.2f", item.amount)}")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
        override fun getItemCount() = filteredItems.size
    }
}
