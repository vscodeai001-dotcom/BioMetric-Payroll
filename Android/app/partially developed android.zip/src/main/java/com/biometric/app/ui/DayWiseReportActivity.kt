package com.biometric.app.ui

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.DayData
import com.biometric.app.data.MainRepository
import com.biometric.app.databinding.ActivityDayWiseReportBinding
import com.biometric.app.databinding.ItemDayWiseRowBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.ReportsViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import android.view.View
import com.biometric.app.util.MotionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class DayWiseReportActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityDayWiseReportBinding
    private val mainViewModel: MainViewModel by viewModels()
    private val viewModel: ReportsViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var repository: MainRepository
    
    private var selectedCalendar: Calendar = Calendar.getInstance()
    private var shopId: String? = null
    private var shopName: String? = null
    private var isGlobal: Boolean = false
    private lateinit var reportAdapter: DayWiseAdapter
    private lateinit var filterAdapter: HorizontalFilterAdapter

    enum class ReportPeriod { DAILY, UP_TO_DATE, WEEKLY, MONTHLY, QUARTERLY, HALF_YEARLY, ANNUALLY }
    private var currentPeriod = ReportPeriod.UP_TO_DATE

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityDayWiseReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopId = intent.getStringExtra("SHOP_ID")
        shopName = intent.getStringExtra("SHOP_NAME")
        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        
        if (isGlobal) {
            shopId = null
            shopName = "All Shops"
        }
        
        val monthTime = intent.getLongExtra("monthTime", -1L)
        if (monthTime != -1L) {
            selectedCalendar.timeInMillis = monthTime
        }

        // Load initial data
        setupToolbar()
        setupFilterNavigation()
        setupRecyclerView()
        observeViewModelData()
        
        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        // Set initial shop name from intent
        binding.toolbar.title = shopName
        
        // Initial load
        onPeriodChanged(ReportPeriod.UP_TO_DATE)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        
        val line1 = if (isGlobal) "Global Insights 🌏" else (shopName ?: "Daily Report")
        val line2 = if (line1.contains("Report", ignoreCase = true)) "Daily Analysis" else "Daily Report"
        setupDualHeader(binding.toolbar, line1, line2)
    }
    
    private var currentHeaderLine1: android.widget.TextView? = null
    private var currentHeaderLine2: android.widget.TextView? = null

    private fun setupFilterNavigation() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            val period = when (selected) {
                "Daily" -> ReportPeriod.DAILY
                "Weekly" -> ReportPeriod.WEEKLY
                "Monthly" -> ReportPeriod.MONTHLY
                "Quarterly" -> ReportPeriod.QUARTERLY
                "Half Yearly" -> ReportPeriod.HALF_YEARLY
                "Annually" -> ReportPeriod.ANNUALLY
                else -> ReportPeriod.UP_TO_DATE
            }
            onPeriodChanged(period)
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentPeriod.name.replace("_", " "), selectedCalendar
            ) { newDate: Calendar ->
                selectedCalendar.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun onPeriodChanged(period: ReportPeriod) {
        currentPeriod = period

        // Normalize selectedCalendar to the start of the selected period
        when (period) {
            ReportPeriod.DAILY, ReportPeriod.UP_TO_DATE -> {}
            ReportPeriod.WEEKLY -> selectedCalendar.set(Calendar.DAY_OF_WEEK, selectedCalendar.firstDayOfWeek)
            ReportPeriod.MONTHLY -> selectedCalendar.set(Calendar.DAY_OF_MONTH, 1)
            ReportPeriod.QUARTERLY -> {
                val quarter = selectedCalendar[Calendar.MONTH] / 3
                selectedCalendar[Calendar.MONTH] = quarter * 3
                selectedCalendar[Calendar.DAY_OF_MONTH] = 1
            }
            ReportPeriod.HALF_YEARLY -> {
                val half = if (selectedCalendar[Calendar.MONTH] < 6) 0 else 6
                selectedCalendar[Calendar.MONTH] = half
                selectedCalendar[Calendar.DAY_OF_MONTH] = 1
            }
            ReportPeriod.ANNUALLY -> {
                selectedCalendar[Calendar.MONTH] = 0
                selectedCalendar[Calendar.DAY_OF_MONTH] = 1
            }
        }

        updateFilterText()
        refreshData()
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentPeriod.name.replace("_", " "), selectedCalendar, amount)
        updateFilterText()
        refreshData()
    }

    private fun updateFilterText() {
        val periodName = currentPeriod.name.replace("_", " ").lowercase(Locale.getDefault())
            .split(" ").joinToString(" ") { it.replaceFirstChar { char -> char.uppercase() } }
        
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(periodName, selectedCalendar.timeInMillis)
        filterAdapter.setSelected(periodName, selectedCalendar.timeInMillis)
    }

    private fun showDatePicker() {
        PickerHelper.showSmartPicker(this, "Day", selectedCalendar) { selectedCal ->
            selectedCalendar.timeInMillis = selectedCal.timeInMillis
            onPeriodChanged(currentPeriod)
        }
    }

    private fun setupRecyclerView() {
        reportAdapter = DayWiseAdapter()
        binding.rvDailyBreakdown.apply {
            layoutManager = LinearLayoutManager(this@DayWiseReportActivity)
            adapter = reportAdapter
        }
    }

    private fun observeViewModelData() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.reportData.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.dayWiseReport.isEmpty() && (state.cashFlow?.totalIn ?: 0.0) == 0.0
                        
                        if (viewModel.isLoading.value) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                            
                            val todayMidnight = Calendar.getInstance().apply {
                                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                            }.timeInMillis

                            val filteredReport = state.dayWiseReport.filter { day ->
                                val isTodayOrFuture = day.calendar.timeInMillis >= todayMidnight
                                val hasNoSales = day.totalIn < 0.01
                                !(isTodayOrFuture && hasNoSales)
                            }

                            reportAdapter.submitList(filteredReport)
                            updateSummary(state)
                        }
                    }
                }

                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                shopName = it.name
                                setupDualHeader(binding.toolbar, shopName!!, "Daily Report")
                                refreshData()
                            }
                        }
                    }
                }
            }
        }
    }

    private fun refreshData() {
        val range = getSelectedRange()
        val sId = if (isGlobal) null else (shopId ?: sharedViewModel.selectedShop.value?.shopId)
        viewModel.loadReportsForPeriod(sId, range.first, range.second, includeBonus = true)
    }

    private fun getSelectedRange(): Pair<Long, Long> {
        val start = selectedCalendar.clone() as Calendar
        val end = selectedCalendar.clone() as Calendar

        when (currentPeriod) {
            ReportPeriod.DAILY -> {
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.UP_TO_DATE -> {
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.WEEKLY -> {
                start.set(Calendar.DAY_OF_WEEK, start.firstDayOfWeek)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.timeInMillis = start.timeInMillis
                end.add(Calendar.DAY_OF_WEEK, 6)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.MONTHLY -> {
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.QUARTERLY -> {
                val quarter = start.get(Calendar.MONTH) / 3
                start.set(Calendar.MONTH, quarter * 3)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, (quarter * 3) + 2)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.HALF_YEARLY -> {
                val half = if (start.get(Calendar.MONTH) < 6) 0 else 6
                start.set(Calendar.MONTH, half)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, half + 5)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.ANNUALLY -> {
                start.set(Calendar.MONTH, 0)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, 11)
                end.set(Calendar.DAY_OF_MONTH, 31)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
        }
        return start.timeInMillis to end.timeInMillis
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) {
            Toast.makeText(this, "Loading shops...", Toast.LENGTH_SHORT).show()
            return
        }

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                shopName = selectedShop.name
                binding.toolbar.title = shopName // Explicitly update toolbar title
                sharedViewModel.setSelectedShop(selectedShop)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        menu?.findItem(R.id.action_kitchen)?.isVisible = true
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val visualAnalyticsAction = GlobalSwitcherDelegate.ActionItem(
            emoji = "🎬",
            label = "Animated Financial Dashboard",
            onClick = {
                val intent = Intent(this, DailyAnalyticsActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", shopName)
                }
                startActivity(intent)
            }
        )

        val patternLedgerAction = GlobalSwitcherDelegate.ActionItem(
            emoji = "📆",
            label = "Day Week Pattern",
            onClick = {
                val intent = Intent(this, DayOfWeekLedgerActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", shopName)
                }
                startActivity(intent)
            }
        )

        if (GlobalSwitcherDelegate.handleOptionsItemSelected(
                this, item, sharedViewModel,
                extraActions = listOf(visualAnalyticsAction, patternLedgerAction)
            )) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateSummary(state: ReportsViewModel.DetailedReportState) {
        val report = state.dayWiseReport
        val totalSales = state.cashFlow?.totalIn ?: 0.0
        val totalCash = report.sumOf { it.cashIn }
        val totalQr = report.sumOf { it.qrIn }
        val totalSalary = state.totalSalary
        val totalFixed = state.cashFlow?.fixedExpenses ?: 0.0
        val totalOtherOut = state.cashFlow?.totalOut ?: 0.0

        val totalExpense = totalSalary + totalFixed + totalOtherOut
        val net = totalSales - totalExpense

        binding.tvTotalSalesMonth.text = getString(R.string.currency_format_decimal, totalSales)

        val periodName = currentPeriod.name.replace("_", " ").uppercase()
        binding.tvPerformanceHeader.text = getString(R.string.performance_header_format, periodName)
        binding.tvTotalSalesLabel.text = getString(R.string.total_period_sales_label, periodName)

        binding.tvTotalCashMonth.text = getString(R.string.currency_format_decimal, totalCash)
        binding.tvTotalQrMonth.text = getString(R.string.currency_format_decimal, totalQr)
        binding.tvTotalSalaryMonth.text = getString(R.string.currency_format_decimal, totalSalary)
        binding.tvTotalFixedMonth.text = getString(R.string.currency_format_decimal, totalFixed)

        if (net >= 0) {
            binding.tvTotalProfitMonth.text = getString(R.string.currency_format, net)
            binding.tvTotalLossMonth.text = getString(R.string.currency_format, 0.0)
            binding.tvPerformanceRating.text = "PROFITABLE"
            binding.tvPerformanceRating.backgroundTintList = ContextCompat.getColorStateList(this, R.color.green)
            binding.tvPerformanceRating.visibility = android.view.View.VISIBLE
            MotionManager.startPulse(binding.tvPerformanceRating, isPositive = true)
        } else {
            binding.tvTotalProfitMonth.text = getString(R.string.currency_format, 0.0)
            binding.tvTotalLossMonth.text = getString(R.string.currency_format, kotlin.math.abs(net))
            binding.tvPerformanceRating.text = "LOSS"
            binding.tvPerformanceRating.backgroundTintList = ContextCompat.getColorStateList(this, R.color.red)
            binding.tvPerformanceRating.visibility = View.VISIBLE
            MotionManager.startPulse(binding.tvPerformanceRating, isPositive = false)
        }

        // Additional insights
        // UNIFORM CALCULATION: Divisor is the number of logical days in the range.
        // This ensures the average reflects the true daily performance based on the specific filter.
        val todayTs = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
        }.timeInMillis

        // Recalculate range for divisor
        val range = getSelectedRange()
        val startTs = range.first
        val endTs = range.second
        
        val actualCalcEnd = if (startTs <= todayTs) kotlin.math.min(endTs, todayTs) else endTs
        val totalDaysInRange = ((actualCalcEnd - startTs) / 86400000L).toInt() + 1
        val divisor = totalDaysInRange.toDouble().coerceAtLeast(1.0)
        
        val avgSales = totalSales / divisor
        val avgExp = totalExpense / divisor
        binding.tvAvgSales.text = "₹%.0f".format(avgSales)
        binding.tvAvgExp.text = "₹%.0f".format(avgExp)
        binding.tvAvgProfit.text = "₹%.2f".format(net / divisor)

        val profitableDays = report.count { it.totalIn > (it.totalOut + it.salaryEarned + it.fixedExpense) && (it.totalIn > 0 || it.totalOut > 0) }
        val lossDays = report.count { it.totalIn < (it.totalOut + it.salaryEarned + it.fixedExpense) && (it.totalIn > 0 || it.totalOut > 0) }
        binding.tvProfitableDays.text = getString(R.string.days_count_format, profitableDays)
        binding.tvLossDays.text = getString(R.string.days_count_format, lossDays)

        val bestDay = report.maxByOrNull { it.totalIn }
        val worstDay = report.asSequence().filter { it.totalIn > 0 }.minByOrNull { it.totalIn }

        binding.tvBestDay.text = bestDay?.let { "${it.displayDate.split(",")[0]} (₹%.0f)".format(it.totalIn) } ?: "N/A"
        binding.tvWorstDay.text = worstDay?.let { "${it.displayDate.split(",")[0]} (₹%.0f)".format(it.totalIn) } ?: "N/A"
    }

    inner class DayWiseAdapter : androidx.recyclerview.widget.ListAdapter<DayData, DayWiseAdapter.ViewHolder>(DayDataDiffCallback()) {

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemDayWiseRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            holder.bind(getItem(position))
        }

        inner class ViewHolder(private val binding: ItemDayWiseRowBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(data: DayData) {
                val dailyExp = data.totalOut + data.salaryEarned + data.fixedExpense
                val net = data.totalIn - dailyExp

                binding.tvDate.text = data.displayDate
                val prefix = if (net >= 0) "+" else "-"
                binding.tvProfit.text = String.format(Locale.getDefault(), "%s₹%.0f", prefix, kotlin.math.abs(net))
                binding.tvProfit.setTextColor(ContextCompat.getColor(itemView.context, if (net >= 0) R.color.green else R.color.red))

                binding.tvStatusEmoji.text = when {
                    net > 5000 -> "🚀 Outstanding Day"
                    net > 2000 -> "⭐ Great Day"
                    net > 0 -> "✅ Profitable"
                    data.totalIn == 0.0 && dailyExp == 0.0 -> "⚪ No Activity"
                    else -> "⚠️ Loss Day"
                }

                binding.tvTotalSales.text = "📈 Total Sales: ₹%.0f".format(data.totalIn)
                binding.tvByCash.text = "💵 By Cash: ₹%.0f".format(data.cashIn)
                binding.tvByQR.text = "📱 By QR: ₹%.0f".format(data.qrIn)
                binding.tvCashOut.text = "💸 Daily Expenses: ₹%.0f".format(data.totalOut)
                binding.tvSalary.text = "🧑‍💼 Staff Salary: ₹%.0f".format(data.salaryEarned)
                binding.tvFixedExpense.text = "🏢 Fixed Expenses: ₹%.0f".format(data.fixedExpense)

                binding.root.setOnClickListener {
                    val intent = Intent(this@DayWiseReportActivity, DetailedReportActivity::class.java).apply {
                        putExtra("SHOP_ID", shopId)
                        putExtra("SHOP_NAME", shopName)
                        putExtra("SPECIFIC_DATE", data.calendar.timeInMillis)
                        putExtra("FILTER_TYPE", "Daily")
                    }
                    startActivity(intent)
                }
            }
        }
    }

    class DayDataDiffCallback : androidx.recyclerview.widget.DiffUtil.ItemCallback<DayData>() {
        override fun areItemsTheSame(oldItem: DayData, newItem: DayData) = oldItem.calendar.timeInMillis == newItem.calendar.timeInMillis
        override fun areContentsTheSame(oldItem: DayData, newItem: DayData) = oldItem == newItem
    }
}
