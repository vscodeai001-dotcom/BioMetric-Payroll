package com.biometric.app.data

import com.biometric.app.data.entity.ExpenseCategory

object FinancialCategory {
    const val DAILY_SALES_CASH = "DAILY SALES (CASH)"
    const val DAILY_SALES_QR = "DAILY SALES (QR)"
    const val OPENING_CASH = "OPENING CASH"
    const val PURCHASE = "PURCHASE"
    const val EXPENSE = "EXPENSE"
    const val SALARY = "SALARY"
    const val ADVANCE = "ADVANCE"
    const val EB_GAS = "EB/GAS"
    const val RENT = "RENT"
    const val MAINTENANCE = "MAINTENANCE"
    const val OTHER = "OTHER"

    fun matches(input: String?, target: String): Boolean {
        if (input == null) return false
        val normalized = input.trim().uppercase()
        val targetNormalized = target.trim().uppercase()
        return (normalized == targetNormalized) || (normalized.replace("/", " ") == targetNormalized.replace("/", " "))
    }

    fun isSalary(category: String?, description: String? = null): Boolean {
        if (category == null) return false
        val cat = category.trim().uppercase()
        val desc = description?.trim()?.uppercase() ?: ""
        
        fun check(s: String): Boolean {
            return s == "SAL" || s.startsWith("SAL ") || s.contains("SALARY") || s.contains("STAFF SAL")
        }
        
        return check(cat) || check(desc)
    }

    fun isAdvance(category: String?): Boolean {
        if (category == null) return false
        return category.trim().uppercase().contains("ADVANCE")
    }

    fun isFixed(category: String?, dynamicCategories: List<ExpenseCategory> = emptyList()): Boolean {
        if (category == null) return false
        val cat = category.trim().uppercase()
        
        return dynamicCategories.find { it.name.uppercase() == cat }?.isFixed
            ?: (cat == "RENT" || cat == "EB_GAS" || cat == "EB/GAS" || cat == "MAINTENANCE")
    }

    fun getEmoji(category: String, description: String? = null, dynamicCategories: List<ExpenseCategory> = emptyList()): String {
        val normalized = category.trim().uppercase()
        val desc = description?.trim()?.uppercase() ?: ""
        
        // Check dynamic categories first
        val dynamicEmoji = dynamicCategories.find { it.name.uppercase() == normalized }?.emoji
        if (dynamicEmoji != null) return dynamicEmoji

        return when {
            desc.contains("MILK") -> "🥛"
            desc.contains("BREAD") -> "🍞"
            desc.contains("FOOD") -> "🍔"
            normalized == DAILY_SALES_CASH -> "💵"
            normalized == DAILY_SALES_QR -> "📱"
            normalized == OPENING_CASH -> "💰"
            normalized == PURCHASE -> "🛒"
            isSalary(normalized, desc) -> "🧑‍💼"
            isAdvance(normalized) -> "💸"
            normalized == RENT -> "🏠"
            normalized == "EB/GAS" || normalized == "EB GAS" -> "💡"
            normalized == MAINTENANCE -> "🔧"
            else -> "₹"
        }
    }
}
