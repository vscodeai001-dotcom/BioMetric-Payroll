package com.biometric.app.ui

import android.os.Bundle
import android.transition.Fade
import android.transition.Slide
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.Window
import android.view.animation.AnticipateOvershootInterpolator
import android.widget.TextView
import androidx.appcompat.widget.Toolbar
import com.biometric.app.R
import com.biometric.app.util.MotionManager

import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.biometric.app.util.ThemeManager

abstract class MotionBaseActivity : SecurityBaseActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        // Task: Remove Black Flash - Set a theme-consistent background for the window IMMEDIATELY
        window.setBackgroundDrawableResource(R.color.window_background)
        
        // Enable Activity Transitions for a cinematic feel
        window.requestFeature(Window.FEATURE_ACTIVITY_TRANSITIONS)
        
        // Premium Transitions: Fade & Smooth Shift
        val enterTransition = android.transition.TransitionSet().apply {
            addTransition(Fade())
            addTransition(Slide(Gravity.BOTTOM))
            duration = 300
            interpolator = android.view.animation.AccelerateDecelerateInterpolator()
        }
        val exitTransition = android.transition.TransitionSet().apply {
            addTransition(Fade())
            addTransition(Slide(Gravity.TOP))
            duration = 250
        }
        
        window.enterTransition = enterTransition
        window.exitTransition = exitTransition
        window.reenterTransition = Fade().apply { duration = 300 }
        
        // Allow transitions to overlap for a more fluid feel
        window.allowEnterTransitionOverlap = true
        window.allowReturnTransitionOverlap = true
        
        // REQUIREMENT: System Bar Safety (Edge-to-Edge)
        val decorView = window.decorView
        ViewCompat.setOnApplyWindowInsetsListener(decorView) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.updatePadding(left = systemBars.left, right = systemBars.right)
            insets
        }
        
        super.onCreate(savedInstanceState)
    }

    /**
     * Staggered entry animation for all children of a layout.
     * Use this when the loader is hidden and the complete screen is shown.
     */
    protected fun animateContentEntry(viewGroup: ViewGroup) {
        val count = viewGroup.childCount
        for (i in 0 until count) {
            val child = viewGroup.getChildAt(i)
            child.alpha = 0f
            child.translationY = 30f // Subtle rise
            child.animate()
                .alpha(1f)
                .translationY(0f)
                .setDuration(450)
                .setStartDelay((i * 30).toLong()) // Staggered entry
                .setInterpolator(AnticipateOvershootInterpolator(0.8f))
                .start()
        }
    }

    /**
     * Applies standard premium touch feedback to a list of views
     */
    protected fun setupMotionFeedback(vararg views: View) {
        views.forEach { MotionManager.applyTouchScale(it) }
    }

    /**
     * Sets up a stylish dual-line header in the toolbar
     * Returns: HeaderRefs(Line1, Line2, Status, Line3, ThemeToggle, ShopToggle)
     */
    protected fun setupDualHeader(toolbar: Toolbar, line1: String, line2: String): HeaderRefs {
        // DEFENSIVE: Completely kill the default titles to prevent overlapping
        toolbar.title = ""
        toolbar.subtitle = ""
        
        // Handle Action Bar if it's already attached
        supportActionBar?.let {
            it.title = ""
            it.subtitle = ""
            it.setDisplayShowTitleEnabled(false)
        }
        
        // Find existing header or inflate new one
        var headerView = toolbar.findViewById<View>(R.id.llHeaderContainer)
        if (headerView == null) {
            headerView = layoutInflater.inflate(R.layout.layout_toolbar_dual, toolbar, false)
            // REQUIREMENT: match_parent width to support right alignment
            val lp = Toolbar.LayoutParams(Toolbar.LayoutParams.MATCH_PARENT, Toolbar.LayoutParams.WRAP_CONTENT)
            toolbar.addView(headerView, lp)
        }
        
        val tvLine1 = headerView.findViewById<TextView>(R.id.tvHeaderLine1)
        val tvLine2 = headerView.findViewById<TextView>(R.id.tvHeaderLine2)
        val tvStatus = headerView.findViewById<TextView>(R.id.tvHeaderStatus)
        val tvLine3 = headerView.findViewById<TextView>(R.id.tvHeaderLine3)
        
        val btnTheme = headerView.findViewById<android.widget.ImageButton>(R.id.btnThemeToggle)
        val btnShop = headerView.findViewById<android.widget.ImageButton>(R.id.btnShopToggle)
        
        tvLine1.text = line1
        tvLine2.text = line2
        
        // BIND ACTIONS: These reference GlobalSwitcherDelegate for consistent logic
        btnTheme?.setOnClickListener {
            ThemeManager.toggleTheme(this)
            MotionManager.playClickBlast(it)
        }
        
        btnShop?.setOnClickListener {
            MotionManager.playClickBlast(it)
            // Retrieve SharedViewModel from known activities
            val sharedVM = (this as? MainActivity)?.sharedViewModel 
                ?: (this as? ShopDashboardActivity)?.sharedViewModel
                ?: (this as? POSActivity)?.sharedViewModel
                ?: (this as? StaffActivity)?.sharedViewModel
                ?: (this as? FinanceEntryActivity)?.sharedViewModel
                ?: (this as? DetailedReportActivity)?.sharedViewModel
                ?: (this as? ReportsActivity)?.sharedViewModel
                ?: (this as? DayWiseReportActivity)?.sharedViewModel
                ?: (this as? InventoryActivity)?.sharedViewModel
                ?: (this as? StaffPerformanceActivity)?.sharedViewModel
                ?: (this as? BusinessHealthActivity)?.sharedViewModel
                ?: (this as? AuditTrailActivity)?.sharedViewModel
                ?: (this as? StaffPermissionActivity)?.sharedViewModel
                ?: (this as? DayOfWeekLedgerActivity)?.sharedViewModel
                ?: (this as? SalesPatternActivity)?.sharedViewModel
                ?: (this as? SpendAnalysisActivity)?.sharedViewModel
                ?: (this as? InvestmentRecoveryActivity)?.sharedViewModel
                ?: (this as? DailyAnalyticsActivity)?.sharedViewModel
                ?: (this as? FinancialPredictionActivity)?.sharedViewModel
                ?: (this as? FuturePredictionActivity)?.sharedViewModel
                ?: (this as? StaffDetailActivity)?.sharedViewModel
                ?: (this as? RiskAlertActivity)?.sharedViewModel
                ?: (this as? FixedExpensesActivity)?.sharedViewModel

            sharedVM?.let { vm ->
                GlobalSwitcherDelegate.handleShopSwitch(this, vm)
            }
        }
        
        return HeaderRefs(tvLine1, tvLine2, tvStatus, tvLine3, btnTheme, btnShop)
    }

    data class HeaderRefs(
        val line1: TextView,
        val line2: TextView,
        val status: TextView,
        val line3: TextView,
        val btnTheme: android.widget.ImageButton? = null,
        val btnShop: android.widget.ImageButton? = null,
    )
}
