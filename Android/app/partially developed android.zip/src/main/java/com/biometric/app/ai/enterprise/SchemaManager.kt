package com.biometric.app.ai.enterprise

object SchemaManager {

    val schemaPrompt = """
        VIRTUAL DATABASE SCHEMA (SQLite):
        
        TABLE shops (
            shopId TEXT PRIMARY KEY,
            name TEXT,
            location TEXT,
            openingDate INTEGER, -- timestamp
            isActive INTEGER -- 1 for true, 0 for false
        );

        TABLE items (
            itemId TEXT PRIMARY KEY,
            name TEXT,
            category TEXT,
            globalPrice REAL,
            isActive INTEGER
        );

        TABLE orders (
            orderId TEXT PRIMARY KEY,
            shopId TEXT,
            totalAmount REAL,
            paymentMethod TEXT, -- CASH, ONLINE, SPLIT
            status TEXT, -- PAID, HOLD, OPEN
            closedAt INTEGER -- timestamp
        );

        TABLE order_items (
            orderItemId TEXT PRIMARY KEY,
            orderId TEXT,
            itemId TEXT,
            itemName TEXT,
            quantity REAL,
            unitPrice REAL,
            createdAt INTEGER
        );

        TABLE cashbook (
            entryId TEXT PRIMARY KEY,
            shopId TEXT,
            transactionType TEXT, -- IN, OUT
            category TEXT, -- SALES, EXPENSE, PURCHASE, SALARY, ADVANCE, EB/GAS, RENT, MAINTENANCE, OTHER
            amount REAL,
            quantity REAL,
            unit TEXT,
            description TEXT,
            transactionDate INTEGER -- timestamp
        );

        TABLE employees (
            employeeId TEXT PRIMARY KEY,
            name TEXT,
            shopId TEXT,
            salaryType TEXT, -- MONTHLY_FIXED, HOURLY
            salaryRate REAL,
            hireDate INTEGER,
            isActive INTEGER
        );

        TABLE attendance (
            attendanceId TEXT PRIMARY KEY,
            employeeId TEXT,
            shopId TEXT,
            checkInTime INTEGER,
            checkOutTime INTEGER,
            type TEXT -- WORK, GAP
        );

        TABLE fixed_expenses (
            id TEXT PRIMARY KEY,
            shopId TEXT,
            name TEXT,
            monthlyAmount REAL,
            isArchived INTEGER
        );

        TABLE investments (
            investmentId TEXT PRIMARY KEY,
            shopId TEXT,
            itemName TEXT,
            amount REAL,
            date INTEGER
        );

        TABLE inventory (
            name TEXT,
            shopId TEXT,
            totalQuantity REAL,
            totalCost REAL,
            lastPrice REAL,
            unitType TEXT,
            PRIMARY KEY (name, shopId)
        );

        BUSINESS RULES:
        1. Sales can be found in both 'orders' table (total bill) and 'cashbook' table (category='SALES'). Use 'orders' for item-wise sales and 'cashbook' for overall cashflow.
        2. Profit = Sum(cashbook where type='IN') - Sum(cashbook where type='OUT').
        3. Salary expenses are in 'cashbook' with category='SALARY' or 'ADVANCE'.
        4. Attendance 'type' is 'WORK' for presence.
        5. 'isActive' flag is used for soft-deletion.
        6. IMPORTANT: All timestamps are in MILLISECONDS. For SQLite date functions, divide by 1000 (e.g., closedAt/1000).
        7. Days of week for strftime: 0=Sunday, 1=Monday, 2=Tuesday, 3=Wednesday, 4=Thursday, 5=Friday, 6=Saturday.
    """.trimIndent()
}
