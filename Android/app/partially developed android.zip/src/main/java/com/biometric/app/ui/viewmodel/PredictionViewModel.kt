package com.biometric.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.ForecastInsight
import com.biometric.app.data.MainRepository
import com.biometric.app.data.RawMetrics
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.FinanceEngine
import com.biometric.app.util.PredictionEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

data class PredictionMetricRow(
    val title: String,
    val previousValue: Double,
    val currentValue: Double,
    val expectedValue: Double,
    val growthPercent: Double,
)

data class RangeInfo(
    val label: String,
    val dateString: String,
    val start: Long,
    val end: Long
)

data class PredictionState(
    val prevRange: RangeInfo? = null,
    val currentRange: RangeInfo? = null,
    val expectedRange: RangeInfo? = null,
    val metrics: List<PredictionMetricRow> = emptyList(),
    val insights: List<String> = emptyList(),
    val forecast: ForecastInsight = ForecastInsight(),
    val isLoading: Boolean = true
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class PredictionViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val initTime = System.currentTimeMillis()
    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    val state: StateFlow<PredictionState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        val normalizedPeriod = period.lowercase().replace("-", " ").trim()
        val useMatching = (normalizedPeriod == "up to date") || (normalizedPeriod == "day") || (normalizedPeriod == "daily")
        
        val currentRange = DateRangeUtil.getRangeForPeriod(period, date, isMatchingDays = useMatching)
        val currentStart = currentRange.first
        val currentEnd = currentRange.second
        
        val p1Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -1); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p2Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -2); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p3Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -3); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }

        val p1RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p1Range.second)
        val p2RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p2Range.second)
        val p3RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p3Range.second)

        val nextRange = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, 1); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }

        val sdf = SimpleDateFormat("dd MMM", Locale.getDefault())
        val rangeStr = { s: Long, e: Long -> "${sdf.format(Date(s))} – ${sdf.format(Date(e))}" }

        val currentInfo = RangeInfo("Current", rangeStr(currentStart, currentEnd), currentStart, currentEnd)
        val prevInfo = RangeInfo("Prev Avg (3P)", "${sdf.format(Date(p3Range.first))} – ${sdf.format(Date(p1Range.second))}", p3Range.first, p1Range.second)
        val expectedInfo = RangeInfo("Expected", rangeStr(nextRange.first, nextRange.second), nextRange.first, nextRange.second)

        val cacheKey = "prediction_${shopId}_${period}_${currentStart}_${currentEnd}"
        val cached = repository.getListCache<PredictionState>(cacheKey).firstOrNull()

        flow {
            // UNIFORM LOADING: Emit initial state (cached or true-loading)
            val initialState = (cached ?: PredictionState()).copy(
                isLoading = cached == null, 
                prevRange = prevInfo, 
                currentRange = currentInfo, 
                expectedRange = expectedInfo
            )
            emit(initialState)

            val currentMetricsFlow = repository.getShopMetricsFlow(shopId, currentStart, currentEnd)
            val backgroundDataFlow: Flow<BackgroundData> = combine(
                repository.getShopMetricsFlow(shopId, p1Range.first, p1Range.second),
                repository.getShopMetricsFlow(shopId, p2Range.first, p2Range.second),
                repository.getShopMetricsFlow(shopId, p3Range.first, p3Range.second),
                repository.getShopMetricsFlow(shopId, p1RemRange.first, p1RemRange.second),
                repository.getShopMetricsFlow(shopId, p2RemRange.first, p2RemRange.second),
                repository.getShopMetricsFlow(shopId, p3RemRange.first, p3RemRange.second)
            ) { args ->
                BackgroundData(
                    p1 = args[0] as RawMetrics, p2 = args[1] as RawMetrics, p3 = args[2] as RawMetrics,
                    p1Rem = args[3] as RawMetrics, p2Rem = args[4] as RawMetrics, p3Rem = args[5] as RawMetrics
                )
            }

            emitAll(combine(currentMetricsFlow, backgroundDataFlow) { curr, bg ->
                val forecastResult = PredictionEngine.calculateForecast(curr, bg.p1, bg.p2, bg.p3)
                val monthEndForecast = if (normalizedPeriod.contains("up to date")) {
                    val selected = Calendar.getInstance().apply { timeInMillis = date }
                    val remainingDays = selected.getActualMaximum(Calendar.DAY_OF_MONTH) - selected[Calendar.DAY_OF_MONTH]
                    if (remainingDays > 0) {
                        val remRolling = FinanceEngine.calculateRollingPast(bg.p1Rem, bg.p2Rem, bg.p3Rem)
                        ForecastInsight(remainingDays = remainingDays, isVisible = true, remainingSales = remRolling.sales, remainingCashOut = remRolling.expense, remainingSalary = remRolling.salary, remainingFixed = remRolling.fixed, remainingProfit = remRolling.profit, avgSales = remRolling.sales / remainingDays, avgExpense = (remRolling.expense + remRolling.salary + remRolling.fixed) / remainingDays, avgProfit = remRolling.profit / remainingDays, upToDateProfit = curr.profit, finalEstimatedProfit = curr.profit + remRolling.profit)
                    } else ForecastInsight(isVisible = false)
                } else ForecastInsight(isVisible = false)

                val metrics = listOf(
                    PredictionMetricRow("Sales", forecastResult.pastValue.sales, curr.sales, forecastResult.aiExpected.sales, calculatePercentChange(forecastResult.pastValue.sales, curr.sales)),
                    PredictionMetricRow("Expenses", forecastResult.pastValue.expense, curr.expense, forecastResult.aiExpected.expense, calculatePercentChange(forecastResult.pastValue.expense, curr.expense)),
                    PredictionMetricRow("Salary", forecastResult.pastValue.salary, curr.salary, forecastResult.aiExpected.salary, calculatePercentChange(forecastResult.pastValue.salary, curr.salary)),
                    PredictionMetricRow("Fixed", forecastResult.pastValue.fixed, curr.fixed, forecastResult.aiExpected.fixed, 0.0),
                    PredictionMetricRow("Profit", forecastResult.pastValue.profit, curr.profit, forecastResult.aiExpected.profit, calculatePercentChange(forecastResult.pastValue.profit, curr.profit))
                )
                
                // NEW INSTALL DEFENSE
                val isDataZero = curr.sales == 0.0 && curr.profit == 0.0 && forecastResult.pastValue.sales == 0.0
                val stayLoading = isDataZero && (System.currentTimeMillis() - initTime < 5000)
                
                // ATOMIC: Ensure loader hides only when EVERYTHING is ready.
                // We add a tiny delay to ensure background data is fully processed.
                kotlinx.coroutines.delay(100.milliseconds)
                
                val result = PredictionState(
                    prevRange = prevInfo, currentRange = currentInfo, expectedRange = expectedInfo, 
                    metrics = metrics, insights = generateForecastInsights(metrics), 
                    forecast = monthEndForecast, isLoading = stayLoading
                )
                repository.saveListCache(cacheKey, listOf(result))
                result
            })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), PredictionState())

    fun loadPredictions(shopId: String, period: String, date: Long) {
        _params.value = Triple(shopId, period, date)
    }

    private fun calculatePercentChange(old: Double, new: Double): Double = if (old != 0.0) ((new - old) / kotlin.math.abs(old)) * 100.0 else 0.0

    private fun generateForecastInsights(rows: List<PredictionMetricRow>): List<String> {
        val insights = mutableListOf<String>()
        val sales = rows.find { it.title == "Sales" }; val profit = rows.find { it.title == "Profit" }
        sales?.let { if (it.growthPercent > 5) insights.add(String.format(Locale.getDefault(), "📈 Growth trend: Sales are up %.1f%% compared to the 3-period baseline.", it.growthPercent)) }
        profit?.let { if (it.expectedValue > 0) insights.add(String.format(Locale.getDefault(), "🎯 Target: Predicted profit based on rolling average is ₹%,.0f.", it.expectedValue)) }
        if (insights.isEmpty()) insights.add("📊 Stability: Your financial metrics are consistent with the previous rolling 3-period averages.")
        return insights
    }

    private data class BackgroundData(
        val p1: RawMetrics,
        val p2: RawMetrics,
        val p3: RawMetrics,
        val p1Rem: RawMetrics,
        val p2Rem: RawMetrics,
        val p3Rem: RawMetrics
    )
}
