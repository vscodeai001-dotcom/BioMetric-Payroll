package com.biometric.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.DayData
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Shop
import com.biometric.app.util.DateRangeUtil
import com.github.mikephil.charting.data.Entry
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Calendar
import java.util.Locale
import javax.inject.Inject

data class ShopComparisonMetrics(
    val shop: Shop,
    val totalSales: Double,
    val staffSalary: Double,
    val fixedExpenses: Double,
    val otherOutflow: Double,
    val netProfit: Double,
    val totalExpenses: Double,
    val growthPercentage: Double = 0.0,
    // Daywise screen metrics
    val avgSales: Double = 0.0,
    val avgExp: Double = 0.0,
    val bestDay: String = "N/A",
    val slowestDay: String = "N/A",
    val profitableDays: Int = 0,
    val lossDays: Int = 0,
    val avgDailyProfit: Double = 0.0,
    
    // Efficiency Metrics
    val profitPerStaff: Double = 0.0,
    val salesPerHour: Double = 0.0,
    val ebCostPer100: Double = 0.0,
    val efficiencyScore: Double = 0.0,
)

data class GlobalComparisonSummary(
    val totalSales: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val totalSalary: Double = 0.0,
    val totalFixed: Double = 0.0,
    val totalProfit: Double = 0.0,
    val totalOtherOutflow: Double = 0.0,
    // Aggregated Performance metrics
    val avgDailySales: Double = 0.0,
    val avgDailyExp: Double = 0.0,
    val avgDailyProfit: Double = 0.0,
    val bestDay: String = "N/A",
    val slowestDay: String = "N/A",
    val totalProfitableDays: Int = 0,
    val totalLossDays: Int = 0,
)

data class ExpenseDistribution(
    val category: String,
    val amount: Double
)

data class ShopTrend(
    val shopName: String,
    val dailyProfits: List<Entry> // Using Float for chart
)

data class ShopComparisonState(
    val shopMetrics: List<ShopComparisonMetrics> = emptyList(),
    val summary: GlobalComparisonSummary = GlobalComparisonSummary(),
    val expenseDistribution: List<ExpenseDistribution> = emptyList(),
    val shopTrends: List<ShopTrend> = emptyList(),
    val dateLabels: List<String> = emptyList(),
    val isLoading: Boolean = true,
    val currentPeriod: String = "Up To Date",
    val currentDate: Long = System.currentTimeMillis()
)

@HiltViewModel
class ShopComparisonViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(ShopComparisonState())
    val state: StateFlow<ShopComparisonState> = _state.asStateFlow()

    fun setFilter(period: String, date: Long) {
        _state.update { it.copy(currentPeriod = period, currentDate = date) }
        loadComparisonData()
    }

    fun loadComparisonData() {
        viewModelScope.launch(Dispatchers.Default) {
            val period = _state.value.currentPeriod
            val date = _state.value.currentDate
            val (start, end) = getTimestampsForPeriod(period, date)
            val cacheKey = "comparison_${period}_${start}_${end}"
            
            // OPTIMISTIC UI: Try to load from cache first
            val cached = repository.getListCache<ShopComparisonState>(cacheKey).firstOrNull()
            
            // UNIFORM LOADING: Only set loading true if no cache available
            _state.update { (cached ?: it).copy(isLoading = cached == null, currentPeriod = period, currentDate = date) }

            try {
                val shops = repository.getAllShops().first()
                val currentState = _state.value
                
                val (prevStart, prevEnd) = getPreviousPeriodTimestamps(period, date)
                
                val todayTs = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                val actualCalcEnd = if (start <= todayTs) minOf(end, todayTs) else end
                val occurredDays = ((actualCalcEnd - start) / 86400000L).toInt() + 1
                
                // Like-for-like comparison: cap previous period at the same relative day
                val relativePrevEnd = Calendar.getInstance().apply {
                    timeInMillis = prevStart
                    add(Calendar.DAY_OF_YEAR, occurredDays - 1)
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                val finalPrevEnd = minOf(prevEnd, relativePrevEnd)

                // OPTIMIZATION: Process all shops in parallel
                val metricsList = coroutineScope {
                    shops.map { shop ->
                        async {
                            val current = calculateMetricsForShop(shop, start, end)
                            val previous = calculateMetricsForShop(shop, prevStart, finalPrevEnd)
                            
                            val growth = if (previous.netProfit != 0.0) {
                                ((current.netProfit - previous.netProfit) / kotlin.math.abs(previous.netProfit)) * 100
                            } else if (current.netProfit > 0) 100.0 else 0.0

                            current.copy(growthPercentage = growth)
                        }
                    }.awaitAll()
                }

                // Granular Trend Analysis: Top 5 Shops
                val topShops = metricsList.asSequence().sortedByDescending { it.netProfit }.take(5).map { it.shop }.toList()
                val shopTrendsList = mutableListOf<ShopTrend>()
                val dateLabelsList = mutableListOf<String>()
                val daySdf = java.text.SimpleDateFormat("dd MMM", Locale.getDefault())

                if (topShops.isNotEmpty()) {
                    coroutineScope {
                        topShops.map { shop ->
                            async { 
                                val dailyData = repository.getFullDayWiseData(shop.shopId, start, actualCalcEnd)
                                val entries = dailyData.mapIndexed { index, day ->
                                    val net = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
                                    Entry(index.toFloat(), net.toFloat())
                                }
                                val labels = dailyData.map { daySdf.format(it.calendar.time) }
                                ShopTrend(shop.name.split(",").lastOrNull()?.trim() ?: shop.name, entries) to labels
                            }
                        }.awaitAll().forEach { (trend, labels) -> 
                            shopTrendsList.add(trend)
                            if (dateLabelsList.isEmpty()) dateLabelsList.addAll(labels)
                        }
                    }
                }

                val totalSalary = metricsList.sumOf { it.staffSalary }
                val totalFixed = metricsList.sumOf { it.fixedExpenses }
                val totalOther = metricsList.sumOf { it.otherOutflow }
                val totalSales = metricsList.sumOf { it.totalSales }
                val totalProfit = metricsList.sumOf { it.netProfit }
                val totalExpenses = metricsList.sumOf { it.totalExpenses }

                // OPTIMIZATION: Process Day Wise data in parallel
                val combinedDaysMap = mutableMapOf<String, DayData>()
                val sdf = java.text.SimpleDateFormat("yyyyMMdd", Locale.getDefault())
                
                coroutineScope {
                    shops.map { shop ->
                        async { repository.getFullDayWiseData(shop.shopId, start, actualCalcEnd) }
                    }.awaitAll().forEach { days ->
                        days.forEach { day ->
                            val key = sdf.format(day.calendar.time)
                            val existing = combinedDaysMap[key]
                            if (existing == null) {
                                combinedDaysMap[key] = day.copy()
                            } else {
                                existing.totalIn += day.totalIn
                                existing.cashIn += day.cashIn
                                existing.qrIn += day.qrIn
                                existing.totalOut += day.totalOut
                                existing.salaryEarned += day.salaryEarned
                                existing.fixedExpense += day.fixedExpense
                            }
                        }
                    }
                }

                val allDaysFull = combinedDaysMap.values.toList()
                
                // UNIFORM CALCULATION: Divisor is the total number of days in the selected filter range.
                // Data Fetching however is capped at 'Today' to avoid future projected expenses.
                val fullRangeDays = ((end - start) / 86400000L).toInt() + 1
                val divisor = fullRangeDays.toDouble().coerceAtLeast(1.0)
                
                // Filter allDays to only include occurred days for P/L and Best/Slowest day calculation
                val allDays = allDaysFull.filter { it.calendar.timeInMillis <= actualCalcEnd }
                
                val bestDay = allDays.maxByOrNull { it.totalIn }
                val slowestDay = allDays.asSequence().filter { it.totalIn > 0 }.minByOrNull { it.totalIn } ?: allDays.minByOrNull { it.totalIn }
                
                var totalProfitable = 0
                var totalLoss = 0
                allDays.forEach { day ->
                    if ((day.totalIn > 0) || (day.totalOut > 0) || (day.salaryEarned > 0)) {
                        val dayProfit = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
                        if (dayProfit >= 0) totalProfitable++ else totalLoss++
                    }
                }

                val result = currentState.copy(
                    shopMetrics = metricsList.sortedByDescending { it.netProfit },
                    summary = GlobalComparisonSummary(
                        totalSales = totalSales,
                        totalExpenses = totalExpenses,
                        totalSalary = totalSalary,
                        totalFixed = totalFixed,
                        totalProfit = totalProfit,
                        totalOtherOutflow = totalOther,
                        avgDailySales = totalSales / divisor,
                        avgDailyExp = totalExpenses / divisor,
                        avgDailyProfit = totalProfit / divisor,
                        bestDay = bestDay?.let { "${it.displayDate.split(",")[0]} (₹${String.format(Locale.getDefault(), "%.0f", it.totalIn)})" } ?: "N/A",
                        slowestDay = slowestDay?.let { "${it.displayDate.split(",")[0]} (₹${String.format(Locale.getDefault(), "%.0f", it.totalIn)})" } ?: "N/A",
                        totalProfitableDays = totalProfitable,
                        totalLossDays = totalLoss
                    ),
                    expenseDistribution = listOf(
                        ExpenseDistribution("Staff Salary 👨‍💼", totalSalary),
                        ExpenseDistribution("Fixed Expenses 🏠", totalFixed),
                        ExpenseDistribution("Other Outflow 🛒", totalOther)
                    ).filter { it.amount > 0 },
                    shopTrends = shopTrendsList,
                    dateLabels = dateLabelsList,
                    isLoading = false
                )
                
                _state.value = result
                repository.saveListCache(cacheKey, listOf(result))

            } catch (e: Exception) {
                Log.e("ShopComparisonVM", "Error loading comparison data", e)
            } finally {
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    private suspend fun calculateMetricsForShop(shop: Shop, start: Long, end: Long): ShopComparisonMetrics {
        val todayTs = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
        }.timeInMillis
        val actualCalcEnd = if (start <= todayTs) minOf(end, todayTs) else end

        // ONE SOURCE OF TRUTH: Reuse the same metrics logic/cache as the Dashboard
        // We fetch data only up to 'actualCalcEnd' to avoid future projections/negative profit issues
        val metrics = repository.getShopMetricsFlow(shop.shopId, start, actualCalcEnd).first()
        val dayDataList = repository.getFullDayWiseData(shop.shopId, start, actualCalcEnd)
        val employees = repository.getShopEmployees(shop.shopId).first()

        val totalIn = metrics.sales
        val otherOut = metrics.expense
        val salary = metrics.salary
        val fixed = metrics.fixed
        val profit = metrics.profit
        val totalExp = otherOut + salary + fixed

        // Divisor is the full period (e.g., 31 days for Month) as per requirement
        val fullRangeDays = ((end - start) / 86400000L).toInt() + 1
        val divisor = fullRangeDays.toDouble().coerceAtLeast(1.0)
        
        val bestDay = dayDataList.maxByOrNull { it.totalIn }
        val slowestDay = dayDataList.filter { it.totalIn > 0 }.minByOrNull { it.totalIn } ?: dayDataList.minByOrNull { it.totalIn }

        var profitableDays = 0
        var lossDays = 0
        dayDataList.forEach { day ->
            if (day.totalIn > 0 || day.totalOut > 0 || day.salaryEarned > 0) {
                val dayProfit = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
                if (dayProfit >= 0) profitableDays++ else lossDays++
            }
        }

        val bestDayFormatted = bestDay?.let {
            val dateStr = it.displayDate.split(",")[0]
            String.format(Locale.getDefault(), "%s (₹%.0f)", dateStr, it.totalIn)
        } ?: "N/A"

        val slowestDayFormatted = slowestDay?.let {
            val dateStr = it.displayDate.split(",")[0]
            String.format(Locale.getDefault(), "%s (₹%.0f)", dateStr, it.totalIn)
        } ?: "N/A"

        val sCount = employees.size
        
        // 1. Profit per Employee
        val pStaff = if (sCount > 0) profit / sCount else profit
        
        // 2. Sales per Hour (Using shift hours as total open time)
        val sParts = shop.salaryRules.defaultShiftStart.split(":")
        val eParts = shop.salaryRules.defaultShiftEnd.split(":")
        val startDecimal = (sParts.getOrNull(0)?.toInt() ?: 0) + (sParts.getOrNull(1)?.toInt() ?: 0) / 60.0
        var endDecimal = (eParts.getOrNull(0)?.toInt() ?: 0) + (eParts.getOrNull(1)?.toInt() ?: 0) / 60.0
        if (endDecimal < startDecimal) endDecimal += 24.0
        val shiftDuration = (endDecimal - startDecimal - shop.salaryRules.defaultBreakHours).coerceAtLeast(1.0)
        
        // Efficiency uses occurred days, not the full period divisor
        val occurredDays = ((actualCalcEnd - start) / 86400000L).toInt() + 1
        val totalHoursOpen = occurredDays * shiftDuration
        val sHour = if (totalHoursOpen > 0.0) totalIn / totalHoursOpen else 0.0

        // 3. Electricity Cost per ₹100 Earned
        // Filter specifically for EB categories in cashbook
        val cashbook = repository.getCashbookEntriesForPeriod(shop.shopId, start, end).first()
        val ebCost = cashbook.filter { FinancialCategory.matches(it.category, "EB/GAS") }.sumOf { it.amount }
        val eb100 = if (totalIn > 0) (ebCost / totalIn) * 100 else 0.0

        // 4. Efficiency Score (Multi-Pillar Normalized Model - Statistically Tuned)
        // A. Financial Efficiency (35% weight) - Target ₹12k per staff
        val financialScore = (pStaff / 12000.0).coerceIn(0.0, 1.0) * 35.0
        
        // B. Operational Velocity (35% weight) - Target ₹500 per hour
        val velocityScore = (sHour / 500.0).coerceIn(0.0, 1.0) * 35.0
        
        // C. Resource Discipline (20% weight) - Penalty for EB cost > 10% revenue (Standard in POS)
        val resourceScore = (1.0 - (eb100 / 10.0).coerceIn(0.0, 1.0)) * 20.0

        // D. Consistency Score (10% weight) - Reward for high profitable days ratio
        val consistencyRatio = if (divisor > 0) profitableDays.toDouble() / divisor else 0.0
        val consistencyScore = consistencyRatio * 10.0
        
        val score = financialScore + velocityScore + resourceScore + consistencyScore

        return ShopComparisonMetrics(
            shop = shop,
            totalSales = totalIn,
            staffSalary = salary,
            fixedExpenses = fixed,
            otherOutflow = otherOut,
            netProfit = profit,
            totalExpenses = totalExp,
            avgSales = totalIn / divisor,
            avgExp = totalExp / divisor,
            bestDay = bestDayFormatted,
            slowestDay = slowestDayFormatted,
            profitableDays = profitableDays,
            lossDays = lossDays,
            avgDailyProfit = profit / divisor,
            
            profitPerStaff = pStaff,
            salesPerHour = sHour,
            ebCostPer100 = eb100,
            efficiencyScore = score
        )
    }

    private fun getTimestampsForPeriod(period: String, date: Long): Pair<Long, Long> {
        val start = Calendar.getInstance().apply { timeInMillis = date }
        val end = Calendar.getInstance().apply { timeInMillis = date }

        when (period) {
            "Daily" -> { }
            "Up To Date" -> start[Calendar.DAY_OF_MONTH] = 1
            "Weekly" -> {
                start[Calendar.DAY_OF_WEEK] = start.firstDayOfWeek
                end[Calendar.DAY_OF_WEEK] = start.firstDayOfWeek + 6
            }
            "Monthly" -> {
                start[Calendar.DAY_OF_MONTH] = 1
                end[Calendar.DAY_OF_MONTH] = end.getActualMaximum(Calendar.DAY_OF_MONTH)
            }
            "Quarterly" -> {
                val quarter = start[Calendar.MONTH] / 3
                start[Calendar.MONTH] = quarter * 3
                start[Calendar.DAY_OF_MONTH] = 1
                end[Calendar.MONTH] = (quarter * 3) + 2
                end[Calendar.DAY_OF_MONTH] = end.getActualMaximum(Calendar.DAY_OF_MONTH)
            }
            "Half Yearly" -> {
                val half = if (start[Calendar.MONTH] < 6) 0 else 1
                start[Calendar.MONTH] = half * 6
                start[Calendar.DAY_OF_MONTH] = 1
                end[Calendar.MONTH] = (half * 6) + 5
                end[Calendar.DAY_OF_MONTH] = end.getActualMaximum(Calendar.DAY_OF_MONTH)
            }
            "Annually" -> {
                start[Calendar.DAY_OF_YEAR] = 1
                end[Calendar.MONTH] = 11
                end[Calendar.DAY_OF_MONTH] = 31
            }
        }

        start[Calendar.HOUR_OF_DAY] = 0; start[Calendar.MINUTE] = 0; start[Calendar.SECOND] = 0; start[Calendar.MILLISECOND] = 0
        end[Calendar.HOUR_OF_DAY] = 23; end[Calendar.MINUTE] = 59; end[Calendar.SECOND] = 59; end[Calendar.MILLISECOND] = 999

        return start.timeInMillis to end.timeInMillis
    }

    private fun getPreviousPeriodTimestamps(period: String, date: Long): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply { timeInMillis = date }
        DateRangeUtil.adjustDate(period, cal, -1)
        return getTimestampsForPeriod(period, cal.timeInMillis)
    }
}
