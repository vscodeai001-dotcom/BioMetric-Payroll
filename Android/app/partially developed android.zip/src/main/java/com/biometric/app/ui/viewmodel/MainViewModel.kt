package com.biometric.app.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.*
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.domain.MasterDataSyncUseCase
import com.biometric.app.util.PredictionEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

/**
 * The primary ViewModel for the application's dashboard and main management screens.
 *
 * Responsibilities include:
 * 1. Orchestrating multi-shop profit and performance metrics calculation.
 * 2. Managing global and shop-specific master data (Expense Categories, Descriptions).
 * 3. Handling subscription status and trial period logic.
 * 4. Coordinating background synchronization and manual refresh triggers.
 * 5. Providing high-level management functions (Adding/Deleting shops, expenses, categories).
 *
 * Performance Note: Uses a "Lazy Loading" strategy for dashboard metrics where current month
 * data is loaded first, followed by historical comparisons and AI projections in the background.
 */
@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class MainViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel,
    private val masterDataSync: MasterDataSyncUseCase,
) : ViewModel() {

    private var profitRecalcJob: Job? = null

    val allShops: StateFlow<List<Shop>> = sharedViewModel.allShops

    private val _managementShopId = MutableStateFlow<String?>(null)

    val expenseCategories: StateFlow<List<ExpenseCategory>> = _managementShopId.flatMapLatest { sId ->
        repository.getExpenseCategories(sId)
    }.catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val descriptionMaster: StateFlow<List<DescriptionMaster>> = _managementShopId.flatMapLatest { sId ->
        repository.getDescriptionMaster(sId)
    }.catch { emit(emptyList()) }
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun setManagementShopId(id: String?) {
        _managementShopId.value = if (id.isNullOrEmpty()) null else id
    }

    val currentShop = _managementShopId.flatMapLatest { sId ->
        if (sId == null) flowOf(null) else repository.getShopBranding(sId)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), null)


    private val _shopsWithProfit = MutableStateFlow<List<ShopWithProfit>>(emptyList())
    val shopsWithProfit: StateFlow<List<ShopWithProfit>> = _shopsWithProfit.asStateFlow()

    private val _currentPeriod = MutableStateFlow("Up To Date")
    val currentPeriod: StateFlow<String> = _currentPeriod.asStateFlow()

    private val _currentDate = MutableStateFlow(System.currentTimeMillis())
    val currentDate: StateFlow<Long> = _currentDate.asStateFlow()

    private val _customEndDate = MutableStateFlow<Long?>(null)
    val customEndDate: StateFlow<Long?> = _customEndDate.asStateFlow()

    private val _globalProfit = MutableStateFlow(0.0)
    val globalProfit: StateFlow<Double> = _globalProfit.asStateFlow()

    private val _globalPastProfit = MutableStateFlow(0.0)
    val globalPastProfit: StateFlow<Double> = _globalPastProfit.asStateFlow()


    private val _globalPredictedProfit = MutableStateFlow(0.0)
    val globalPredictedProfit: StateFlow<Double> = _globalPredictedProfit.asStateFlow()

    private val _isSubscribed = MutableStateFlow(value = true)
    val isSubscribed: StateFlow<Boolean> = _isSubscribed.asStateFlow()

    private val _hasCachedShops = MutableStateFlow(value = false)
    val hasCachedShops: StateFlow<Boolean> = _hasCachedShops.asStateFlow()

    private val _isLoading = MutableStateFlow(value = true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    init {
        checkSubscription()
        ensureUserProfileExists()
        
        // OPTIMISTIC UI: Load last known dashboard state for instant (0ms) display
        val cachedShops = repository.getCachedShops()
        if (cachedShops.isNotEmpty()) {
            _shopsWithProfit.value = cachedShops
        }

        val cachedMetrics = repository.getCachedGlobalMetrics()
        if ((cachedMetrics != null) && (cachedMetrics.profit != 0.0)) {
            _globalProfit.value = cachedMetrics.profit
            _globalPastProfit.value = cachedMetrics.past
            _globalPredictedProfit.value = cachedMetrics.expected
            _hasCachedShops.value = cachedMetrics.shopCount > 0
            
            // PERFORMANCE: Instant hide of loader if cache exists
            _isLoading.value = false
        } else {
            _isLoading.value = true
        }

        viewModelScope.launch {
            sharedViewModel.refreshRequested.collect {
                // Background refresh should be silent
                triggerRefresh()
            }
        }

        viewModelScope.launch {
            combine(allShops, sharedViewModel.shopData, _isLoading) { shops, shopData, loading ->
                val shopsWithProfit = shops.map { shop ->
                    shopData[shop.shopId] ?: ShopWithProfit(shop)
                }
                
                // ATOMIC DATA READY LOGIC:
                // 1. If technical 'loading' is false, it means recalculateAllProfits is 100% finished.
                // 2. We also verify that we have data for ALL registered shops.
                // 3. This prevents "partial 0.00" where some shops are ready and others are XML defaults.
                val isDataComplete = (shops.isNotEmpty()) && (shopData.size >= shops.size) && (shopData.keys.containsAll(shops.map { it.shopId }))
                
                if (!loading && isDataComplete) {
                    shopsWithProfit
                } else if (!loading && shops.isEmpty()) {
                    emptyList() // No shops yet
                } else {
                    null
                }
            }.filterNotNull()
            .collect { shopsWithProfit ->
                _shopsWithProfit.value = shopsWithProfit
                _globalProfit.value = shopsWithProfit.sumOf { it.profit.current }
                _globalPastProfit.value = shopsWithProfit.sumOf { it.profit.past }
                _globalPredictedProfit.value = shopsWithProfit.sumOf { it.profit.expected }

                // SAVE CACHE for next launch speed
                repository.saveDashboardCache(
                    shops = shopsWithProfit,
                    global = MainRepository.CachedMetrics(
                        profit = _globalProfit.value,
                        past = _globalPastProfit.value,
                        expected = _globalPredictedProfit.value,
                        shopCount = shopsWithProfit.size,
                    ),
                )
            }
        }

        viewModelScope.launch {
            allShops.collectLatest { shops ->
                if (shops.isEmpty()) {
                    // Check if it's still empty after 5 seconds - if so, it's likely a new account
                    kotlinx.coroutines.delay(5000.milliseconds)
                    if (allShops.value.isEmpty()) {
                        _isLoading.value = false
                    }
                }
            }
        }

        viewModelScope.launch {
            combine(allShops, _currentPeriod, _currentDate, _customEndDate) { shops, period, date, endDate ->
                recalculateAllProfits(shops, period, date, endDate)
            }.catch { e -> Log.e("MainViewModel", "Error in profit trigger flow", e) }
            .collect()
        }
    }

    fun triggerRefresh() {
        viewModelScope.launch {
            recalculateAllProfits(allShops.value, _currentPeriod.value, _currentDate.value, _customEndDate.value)
        }
    }

    fun syncMasterData() {
        viewModelScope.launch {
            try {
                masterDataSync.syncMasterData(_managementShopId.value)
            } catch (e: Exception) {
                Log.e("MainViewModel", "Master data sync failed", e)
            }
        }
    }

    private fun recalculateAllProfits(shops: List<Shop>, period: String, date: Long, endDate: Long?) {
        profitRecalcJob?.cancel()

        if (shops.isEmpty()) return
        
        // SILENT REFRESH: Only show loader if we have zero data. 
        // If switching periods, keep old data visible until new data arrives.
        if (_shopsWithProfit.value.isEmpty()) {
            _isLoading.value = true
        }

        profitRecalcJob = viewModelScope.launch(kotlinx.coroutines.Dispatchers.Default) {
            try {
                // Add a failsafe timeout to prevent infinite loading
                val timeoutJob = launch(kotlinx.coroutines.Dispatchers.Main) {
                    kotlinx.coroutines.delay(7000)
                    if (_isLoading.value) _isLoading.value = false
                }

                val currentRange = DateRangeUtil.getRangeForPeriod(period, date, endDate = endDate)
                
                // PERFORMANCE: Clear data only for specific shop to avoid 0.00 flash across entire list
                // but ensure UI knows we are recalculating.
                
                coroutineScope {
                    shops.forEach { shop ->
                        launch {
                            // OPTIMIZED LAZY LOADING: Use the new comprehensive flow
                            repository.getComprehensiveShopMetrics(shop.shopId, period, currentRange.first, currentRange.second)
                                .collect { metrics ->
                                    val current = metrics.current

                                    val forecast = PredictionEngine.calculateForecast(
                                        current = metrics.current,
                                        p1 = metrics.p1,
                                        p2 = metrics.p2,
                                        p3 = metrics.p3
                                    )

                                    val detailedData = ShopWithProfit(
                                        shop = shop,
                                        profit = MetricData(current.profit, forecast.rollingAverage.profit, forecast.pastValue.profit, forecast.aiExpected.profit),
                                        sales = MetricData(current.sales, forecast.rollingAverage.sales, forecast.pastValue.sales, forecast.aiExpected.sales),
                                        salary = MetricData(current.salary, forecast.rollingAverage.salary, forecast.pastValue.salary, forecast.aiExpected.salary),
                                        expense = MetricData(current.expense, forecast.rollingAverage.expense, forecast.pastValue.expense, forecast.aiExpected.expense),
                                        fixed = MetricData(current.fixed, forecast.rollingAverage.fixed, forecast.pastValue.fixed, forecast.aiExpected.fixed)
                                    )

                                    sharedViewModel.updateShopData(shop.shopId, detailedData)
                                    
                                    // Perceivable Speed: Stop loading as soon as we have enough data to show
                                    if (sharedViewModel.shopData.value.size >= shops.size) {
                                        _isLoading.value = false
                                        timeoutJob.cancel()
                                    }
                                }
                        }
                    }
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Profit recalculation failed", e)
                _isLoading.value = false
            }
        }
    }


    private fun ensureUserProfileExists() {
        viewModelScope.launch {
            try {
                val currentUser = com.google.firebase.auth.FirebaseAuth.getInstance().currentUser
                if (currentUser != null) {
                    val profile = repository.getProfileFlow().firstOrNull()
                    if (profile == null) {
                        val newProfile = UserProfile(
                            uid = currentUser.uid,
                            phone = currentUser.phoneNumber ?: "",
                            name = currentUser.displayName ?: "Business Owner",
                            role = UserProfile.ROLE_OWNER
                        )
                        repository.pushProfileByUid(newProfile)
                    }
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Failed to ensure user profile", e)
            }
        }
    }

    private fun checkSubscription() {
        viewModelScope.launch {
            repository.getProfileFlow().catch { e ->
                Log.e("MainViewModel", "Subscription check failed", e)
                emit(null)
            }.collectLatest { profile ->
                if (profile != null) {
                    val sevenDays = 7 * 24 * 60 * 60 * 1000L
                    val isTrialOver = System.currentTimeMillis() > (profile.joinDate + sevenDays)
                    _isSubscribed.value = profile.isPremium || !isTrialOver
                } else {
                    _isSubscribed.value = true
                }
            }
        }
    }


    fun upgradeToPremium(profile: UserProfile) {
        viewModelScope.launch {
            try { repository.updateProfile(profile) } catch (e: Exception) { Log.e("MainViewModel", "Profile update failed", e) }
        }
    }

    fun addShop(shop: Shop) {
        viewModelScope.launch { try { repository.insertShop(shop) } catch (e: Exception) { Log.e("MainViewModel", "Insert shop failed", e) } }
    }

    fun deleteShop(shop: Shop) {
        viewModelScope.launch { try { repository.deleteShop(shop) } catch (e: Exception) { Log.e("MainViewModel", "Delete shop failed", e) } }
    }


    fun addExpenseCategory(cat: ExpenseCategory) {
        viewModelScope.launch { try { repository.insertExpenseCategory(cat) } catch (e: Exception) { Log.e("MainViewModel", "Insert category failed", e) } }
    }

    fun deleteExpenseCategory(cat: ExpenseCategory) {
        viewModelScope.launch { try { repository.deleteExpenseCategory(cat) } catch (e: Exception) { Log.e("MainViewModel", "Delete category failed", e) } }
    }

    fun deleteDescriptionMaster(item: DescriptionMaster) {
        viewModelScope.launch { try { repository.deleteDescriptionMaster(item) } catch (e: Exception) { Log.e("MainViewModel", "Delete description failed", e) } }
    }

    fun renameDescriptionGlobally(oldName: String, newName: String) {
        viewModelScope.launch {
            try {
                repository.renameDescriptionGlobally(oldName, newName, _managementShopId.value)
            } catch (e: Exception) {
                Log.e("MainViewModel", "Rename description failed", e)
            }
        }
    }

    fun setFilter(period: String, date: Long = System.currentTimeMillis(), endDate: Long? = null) {
        _isLoading.value = true // UNIFORM LOADING
        _currentPeriod.value = period
        _currentDate.value = date
        _customEndDate.value = endDate
    }

    fun syncDefaultItems(items: List<Item>) {
        viewModelScope.launch {
            try {
                val existingItems = repository.getActiveItems().first()
                val existingIds = existingItems.asSequence().map { it.itemId }.toSet()
                val existingNames = existingItems.asSequence().map { it.name.lowercase().trim() }.toSet()

                val newItems = items.filter {
                    !existingIds.contains(it.itemId) && !existingNames.contains(it.name.lowercase().trim())
                }

                if (newItems.isNotEmpty()) {
                    newItems.forEach { repository.insertItem(it) }
                    Log.d("MainViewModel", "Synced ${newItems.size} new default items")
                }
            } catch (e: Exception) {
                Log.e("MainViewModel", "Default item sync failed", e)
            }
        }
    }

    fun startRealtimeSync() {
        try { repository.startSync() } catch (e: Exception) { Log.e("MainViewModel", "Start sync failed", e) }
    }


}
