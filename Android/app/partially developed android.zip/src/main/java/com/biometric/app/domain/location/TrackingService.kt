package com.biometric.app.domain.location

import android.annotation.SuppressLint
import android.app.*
import android.content.Context
import android.content.Intent
import android.location.Location
import android.os.*
import android.util.Log
import androidx.core.app.NotificationCompat
import com.biometric.app.R
import com.biometric.app.data.dao.LocationDao
import com.biometric.app.data.entity.LocationTrack
import com.google.android.gms.location.*
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.*
import javax.inject.Inject

@AndroidEntryPoint
class TrackingService : Service() {

    @Inject
    lateinit var locationDao: LocationDao
    
    @Inject
    lateinit var qualityManager: LocationQualityManager

    private lateinit var fusedLocationClient: FusedLocationProviderClient
    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private var trackingMode = "SHIFT" // SHIFT, 24/7, CUSTOM
    private var staffId: String = "unknown"

    private var lastLocation: Location? = null
    private var isMoving = false
    private var currentInterval = 120000L // 2 minutes

    companion object {
        private const val CHANNEL_ID = "tracking_channel"
        private const val NOTIFICATION_ID = 1001
        
        const val ACTION_START = "ACTION_START"
        const val ACTION_STOP = "ACTION_STOP"
        const val EXTRA_STAFF_ID = "EXTRA_STAFF_ID"
        const val EXTRA_MODE = "EXTRA_MODE"
    }

    override fun onCreate() {
        super.onCreate()
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> {
                staffId = intent.getStringExtra(EXTRA_STAFF_ID) ?: "unknown"
                trackingMode = intent.getStringExtra(EXTRA_MODE) ?: "SHIFT"
                startForegroundService()
                startLocationUpdates()
            }
            ACTION_STOP -> {
                stopForeground(STOP_FOREGROUND_REMOVE)
                stopSelf()
            }
        }
        return START_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "Location Tracking",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Used for background location tracking for payroll purposes"
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }
    }

    private fun startForegroundService() {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle("Tracking Active")
            .setContentText("Capturing location for payroll verification...")
            .setSmallIcon(R.drawable.ic_launcher_foreground) // Replace with valid icon
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()
        
        startForeground(NOTIFICATION_ID, notification)
    }

    @SuppressLint("MissingPermission")
    private fun startLocationUpdates() {
        fusedLocationClient.removeLocationUpdates(locationCallback)

        val request = LocationRequest.Builder(Priority.PRIORITY_BALANCED_POWER_ACCURACY, currentInterval)
            .setMinUpdateIntervalMillis(60000)
            .build()

        fusedLocationClient.requestLocationUpdates(
            request,
            locationCallback,
            Looper.getMainLooper()
        )
    }

    private val locationCallback = object : LocationCallback() {
        override fun onLocationResult(result: LocationResult) {
            result.lastLocation?.let { location ->
                handleLocationUpdate(location)
            }
        }
    }

    private fun handleLocationUpdate(location: Location) {
        if (qualityManager.isMockLocation(location)) {
            Log.w("TrackingService", "Mock location detected, skipping save.")
            return
        }

        if (qualityManager.isSuspiciousMovement(lastLocation, location)) {
            Log.w("TrackingService", "Suspicious movement detected (impossible speed), skipping save.")
            return
        }

        // Detect movement
        val distance = lastLocation?.distanceTo(location) ?: 100f
        isMoving = distance > 10 // Consider moving if > 10 meters

        lastLocation = location

        saveLocationToLocalQueue(location)

        // Adjust interval if needed (Adaptive)
        adjustIntervalBasedOnActivity()
    }

    private fun saveLocationToLocalQueue(location: Location) {
        val batteryManager = getSystemService(BATTERY_SERVICE) as BatteryManager
        val batteryLevel = batteryManager.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)

        serviceScope.launch {
            val track = LocationTrack(
                staffId = staffId,
                timestamp = System.currentTimeMillis(),
                latitude = location.latitude,
                longitude = location.longitude,
                accuracy = location.accuracy,
                speed = location.speed,
                batteryLevel = batteryLevel
            )
            locationDao.insert(track)
            Log.d("TrackingService", "Saved location: ${location.latitude}, ${location.longitude}")
        }
    }

    private fun adjustIntervalBasedOnActivity() {
        val newInterval = if (isMoving) 120000L else 600000L // 2 min vs 10 min
        if (newInterval != currentInterval) {
            currentInterval = newInterval
            startLocationUpdates()
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onDestroy() {
        super.onDestroy()
        fusedLocationClient.removeLocationUpdates(locationCallback)
        serviceScope.cancel()
    }
}
