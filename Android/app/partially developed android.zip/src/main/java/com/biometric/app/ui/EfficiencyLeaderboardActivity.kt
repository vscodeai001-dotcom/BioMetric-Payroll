package com.biometric.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.Menu
import android.view.MenuItem
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ActivityEfficiencyLeaderboardBinding
import com.biometric.app.databinding.ItemEfficiencyCardBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.viewmodel.ShopComparisonMetrics
import com.biometric.app.ui.viewmodel.ShopComparisonViewModel
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class EfficiencyLeaderboardActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityEfficiencyLeaderboardBinding
    private val viewModel: ShopComparisonViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityEfficiencyLeaderboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupRecyclerView()
        observeViewModel()

        val period = intent.getStringExtra("PERIOD") ?: "Up To Date"
        val date = intent.getLongExtra("DATE", System.currentTimeMillis())
        viewModel.setFilter(period, date)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        setupDualHeader(binding.toolbar, "Global Insights 🏆", "Efficiency Leaderboard")
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, showShopSwitcher = false)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupRecyclerView() {
        binding.rvEfficiencyLeaderboard.layoutManager = LinearLayoutManager(this)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collectLatest { state ->
                    // UNIFORM LOADING: Use Smart Delay Loader
                    val isDataZero = state.shopMetrics.isEmpty()
                    if (state.isLoading) {
                        PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope)
                        if (isDataZero) binding.contentLayout.visibility = View.GONE
                    } else {
                        PremiumLoader.hide(binding.brewingLoader)
                        binding.contentLayout.visibility = View.VISIBLE
                    }

                    // Rank by efficiency score
                    val rankedMetrics = state.shopMetrics.sortedByDescending { it.efficiencyScore }
                    binding.rvEfficiencyLeaderboard.adapter = EfficiencyAdapter(rankedMetrics)
                }
            }
        }
    }

    inner class EfficiencyAdapter(private val items: List<ShopComparisonMetrics>) :
        RecyclerView.Adapter<EfficiencyAdapter.ViewHolder>() {

        inner class ViewHolder(val binding: ItemEfficiencyCardBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemEfficiencyCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            val context = holder.itemView.context
            val locale = Locale.forLanguageTag("en-IN")

            holder.binding.tvRank.text = String.format(locale, "#%d", position + 1)
            val shopLocation = item.shop.name.split(",").lastOrNull()?.trim() ?: item.shop.name
            holder.binding.tvShopName.text = shopLocation
            
            holder.binding.tvProfitPerStaff.text = String.format(locale, "₹%,.0f / %s", item.profitPerStaff, context.getString(R.string.staff))
            holder.binding.tvSalesPerHour.text = String.format(locale, "₹%,.0f / %s", item.salesPerHour, context.getString(R.string.filter_day))
            holder.binding.tvEbPerRevenue.text = String.format(locale, "₹%.2f / ₹100", item.ebCostPer100)
            
            val totalDays = item.profitableDays + item.lossDays
            holder.binding.tvProfitableDays.text = String.format(locale, "%d / %d %s", item.profitableDays, totalDays, context.getString(R.string.filter_yearly).take(4))
            
            // Normalized score to percentage (clamped 0-100)
            val displayScore = (item.efficiencyScore * 4).coerceIn(0.0, 100.0).toInt()
            holder.binding.tvEfficiencyScore.text = String.format(locale, "%d%%", displayScore)

            val badge = holder.binding.tvEfficiencyBadge
            val tipIcon = holder.binding.tvTipIcon
            val tipText = holder.binding.tvEfficiencyTip
            
            when {
                item.efficiencyScore > 20 -> {
                    badge.text = context.getString(R.string.indicator_very_high).uppercase()
                    badge.backgroundTintList = ContextCompat.getColorStateList(context, R.color.green)
                    tipIcon.text = "🏆"
                    tipText.setText(R.string.tip_exceptional)
                }
                item.efficiencyScore > 10 -> {
                    badge.text = context.getString(R.string.indicator_high).uppercase()
                    badge.backgroundTintList = ContextCompat.getColorStateList(context, R.color.colorPrimary)
                    tipIcon.text = "⭐"
                    tipText.setText(R.string.tip_stable)
                }
                item.efficiencyScore > 0 -> {
                    badge.text = context.getString(R.string.indicator_average).uppercase()
                    badge.backgroundTintList = ContextCompat.getColorStateList(context, R.color.amber)
                    tipIcon.text = "💡"
                    tipText.setText(R.string.tip_improvement)
                }
                else -> {
                    badge.text = context.getString(R.string.indicator_low).uppercase()
                    badge.backgroundTintList = ContextCompat.getColorStateList(context, R.color.red)
                    tipIcon.text = "🚨"
                    tipText.setText(R.string.tip_action_required)
                }
            }
        }

        override fun getItemCount() = items.size
    }
}
