package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.paging.PagingDataAdapter
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.data.entity.Cashbook
import java.text.SimpleDateFormat
import java.util.*

class CashbookPagingAdapter : PagingDataAdapter<Cashbook, CashbookPagingAdapter.ViewHolder>(DiffCallback) {

    private var employeeMap: Map<String, String> = mapOf()

    fun setEmployeeMap(map: Map<String, String>) {
        this.employeeMap = map
        notifyDataSetChanged()
    }

    class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val tvDate: TextView = itemView.findViewById(R.id.tvDate)
        val tvEmoji: TextView = itemView.findViewById(R.id.tvEmoji)
        val tvParticulars: TextView = itemView.findViewById(R.id.tvParticulars)
        val tvDebit: TextView = itemView.findViewById(R.id.tvDebit)
        val tvCredit: TextView = itemView.findViewById(R.id.tvCredit)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_ledger_row, parent, false)
        return ViewHolder(view)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        getItem(position)?.let { item ->
            val dateFormat = SimpleDateFormat("dd/MM/yy", Locale.getDefault())
            holder.tvDate.text = dateFormat.format(Date(item.transactionDate))
            holder.tvEmoji.text = getEmojiForEntry(item.category, item.description)
            holder.tvParticulars.text = getParticulars(item)

            if (item.transactionType == "IN") {
                holder.tvCredit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvCredit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.green))
                holder.tvDebit.text = ""
            } else {
                holder.tvDebit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvDebit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.red))
                holder.tvCredit.text = ""
            }

            holder.itemView.setOnClickListener {
                val fullDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                val transDate = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(item.transactionDate))
                val entryTime = fullDateFormat.format(Date(item.createdAt))
                
                com.google.android.material.dialog.MaterialAlertDialogBuilder(holder.itemView.context)
                    .setTitle("Entry Details 📋")
                    .setMessage("This entry was recorded on **$entryTime** for the date of **$transDate**.\n\n" +
                            "Category: ${item.category}\n" +
                            "Description: ${item.description ?: "N/A"}\n" +
                            "Amount: ₹${item.amount}")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    private fun getEmojiForEntry(category: String, description: String?): String {
        val searchText = "$category ${description.orEmpty()}"
        return when {
            searchText.contains("MILK", ignoreCase = true) -> "🥛"
            searchText.contains("BREAD", ignoreCase = true) -> "🍞"
            searchText.contains("FOOD", ignoreCase = true) -> "🍔"
            category.equals("DAILY SALES (CASH)", ignoreCase = true) -> "💵"
            category.equals("DAILY SALES (QR)", ignoreCase = true) -> "📱"
            category.equals("OPENING CASH", ignoreCase = true) -> "💰"
            category.equals("PURCHASE", ignoreCase = true) -> "🛒"
            category.equals("SALARY", ignoreCase = true) -> "🧑\u200D💼"
            category.equals("ADVANCE", ignoreCase = true) -> "💸"
            category.equals("RENT", ignoreCase = true) -> "🏠"
            category.equals("EB/GAS", ignoreCase = true) -> "💡"
            category.equals("MAINTENANCE", ignoreCase = true) -> "🔧"
            else -> "💲"
        }
    }

    private fun getParticulars(item: Cashbook): String {
        val description = item.description
        var particulars = if (description.isNullOrEmpty()) {
            item.category
        } else {
            if (description.startsWith(item.category, ignoreCase = true)) {
                description
            } else {
                "${item.category} - $description"
            }
        }
        if (item.category.equals("ADVANCE", ignoreCase = true) || item.category.equals("SALARY", ignoreCase = true)) {
            item.referenceId?.let { refId ->
                employeeMap[refId]?.let {
                    particulars = "${item.category} to $it"
                }
            }
        }
        return particulars
    }

    companion object {
        private val DiffCallback = object : DiffUtil.ItemCallback<Cashbook>() {
            override fun areItemsTheSame(oldItem: Cashbook, newItem: Cashbook): Boolean {
                return oldItem.entryId == newItem.entryId
            }

            override fun areContentsTheSame(oldItem: Cashbook, newItem: Cashbook): Boolean {
                return oldItem == newItem
            }
        }
    }
}
