package com.biometric.app.ui

import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Gravity
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import com.github.mikephil.charting.components.Legend
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityStaffPerformanceBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.viewmodel.StaffPerformanceMetrics
import com.biometric.app.ui.viewmodel.StaffPerformanceViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class StaffPerformanceActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityStaffPerformanceBinding
    private val viewModel: StaffPerformanceViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter

    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Monthly"
    private var shopId: String = ""
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStaffPerformanceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Staff")
        
        if (isGlobal) {
            shopId = ""
        }

        setupToolbar(shopName)
        setupUI()
        setupChart()
        observeViewModel()
        
        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Star Staff")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        menu?.findItem(R.id.action_kitchen)?.isVisible = true
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val insightsAction = GlobalSwitcherDelegate.ActionItem(
            emoji = "🔍",
            label = "Staff Insights",
            onClick = {
                val eligibleStaff = viewModel.state.value.metrics.filter { it.employee.employeeId.isNotEmpty() }
                if (eligibleStaff.isNotEmpty()) {
                    val intent = Intent(this, StaffDetailActivity::class.java).apply {
                        putExtra("EMPLOYEE_ID", eligibleStaff.first().employee.employeeId)
                        putExtra("SHOP_ID", shopId)
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "No staff available for insights", Toast.LENGTH_SHORT).show()
                }
            }
        )

        if (GlobalSwitcherDelegate.handleOptionsItemSelected(
                this, item, sharedViewModel,
                extraActions = listOf(insightsAction)
            )) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadPerformance(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun setupChart() {
        ChartStyleManager.applyChartStyle(binding.barChartPerformance, this)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        val isDataZero = state.metrics.isEmpty() && state.topStaff == null
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.STAFF, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                        
                        if (!state.isLoading && state.metrics.isNotEmpty()) {
                            binding.tvPeriodRange.text = state.periodLabel
                            updateTopPerformer(state.topStaff)
                            updateTable(state.metrics)
                            updateChart(state.metrics)
                            updateInsights(state.insights)
                        }
                    }
                }
            }
        }
    }

    private fun updateTopPerformer(top: StaffPerformanceMetrics?) {
        if (top != null) {
            binding.cardTopPerformer.visibility = View.VISIBLE
            binding.tvTopStaffName.text = top.employee.name
            val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
            binding.tvTopStaffDetail.text = String.format(
                Locale.getDefault(),
                "%.1f Hours Worked • %s Total Earnings",
                top.workedHours, currencyFormat.format(top.totalEarnings)
            )
        } else {
            binding.cardTopPerformer.visibility = View.GONE
        }
    }

    private fun updateTable(metrics: List<StaffPerformanceMetrics>) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        
        // Clear all tables
        val clearTable = { table: TableLayout ->
            val count = table.childCount
            if (count > 2) table.removeViews(2, count - 2)
        }
        clearTable(binding.tableFixedLeft)
        clearTable(binding.tablePerformance)
        clearTable(binding.tableFixedRight)

        var totalHoursAll = 0.0
        var totalBaseAll = 0.0
        var totalOTAll = 0.0
        var totalLateAll = 0.0
        var totalEarlyAll = 0.0
        var totalGapAll = 0.0
        var totalLeaveAll = 0.0
        var totalPLAll = 0.0
        var totalBonusAll = 0.0
        var totalAllowanceAll = 0.0
        var totalAdvanceAll = 0.0
        var totalDebitAll = 0.0
        var totalCreditAll = 0.0
        var totalEarningsAll = 0.0
        var totalDueAll = 0.0

        val emeraldGreen = Color.parseColor("#10B981")
        val brightEmerald = Color.parseColor("#34D399")
        val vibrantIndigo = Color.parseColor("#818CF8")
        val redColor = ContextCompat.getColor(this, R.color.red)
        val amberColor = ContextCompat.getColor(this, R.color.amber)

        metrics.forEach { m ->
            totalHoursAll += m.workedHours
            totalBaseAll += m.baseSalaryRate
            totalOTAll += m.otAmt
            totalLateAll += m.lateAmt
            totalEarlyAll += m.earlyAmt
            totalGapAll += m.gapAmt
            totalLeaveAll += m.leaveAmt
            totalPLAll += m.paidLeaveAmt
            totalBonusAll += m.bonus
            totalAllowanceAll += m.allowance
            totalAdvanceAll += m.advanceAmt
            totalDebitAll += m.totalDebit
            totalCreditAll += m.totalCredit
            totalEarningsAll += m.totalEarnings
            totalDueAll += m.salaryDue

            val rowStyle = { row: TableRow ->
                row.setPadding(0, 12, 0, 12)
                row.background = ContextCompat.getDrawable(this@StaffPerformanceActivity, R.drawable.item_selectable_background_rounded)
            }

            fun createCell(text: String, isBold: Boolean = false, color: Int? = null, gravity: Int = Gravity.END): TextView {
                return TextView(this).apply {
                    this.text = text
                    this.gravity = gravity
                    if (isBold) setTypeface(null, Typeface.BOLD)
                    if (color != null) setTextColor(color)
                    setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                    setPadding(8, 0, 8, 0)
                }
            }

            // Left Table
            val rowLeft = TableRow(this).also(rowStyle)
            rowLeft.addView(createCell(m.employee.name, gravity = Gravity.START, isBold = true))
            binding.tableFixedLeft.addView(rowLeft)

            // Middle Table
            val rowMid = TableRow(this).also(rowStyle)
            rowMid.addView(createCell("₹%.0f".format(m.baseSalaryRate)))
            rowMid.addView(createCell("%.1fh".format(m.workedHours)))
            rowMid.addView(createCell("₹%.0f".format(m.otAmt), color = emeraldGreen))
            rowMid.addView(createCell("₹%.0f".format(m.lateAmt), color = redColor))
            rowMid.addView(createCell("₹%.0f".format(m.earlyAmt), color = amberColor))
            rowMid.addView(createCell("₹%.0f".format(m.gapAmt), color = redColor))
            rowMid.addView(createCell("₹%.0f".format(m.leaveAmt), color = redColor))
            rowMid.addView(createCell("₹%.0f".format(m.paidLeaveAmt), color = emeraldGreen))
            rowMid.addView(createCell("₹%.0f".format(m.bonus), color = emeraldGreen))
            rowMid.addView(createCell("₹%.0f".format(m.allowance), color = emeraldGreen))
            rowMid.addView(createCell("₹%.0f".format(m.advanceAmt), color = redColor))
            rowMid.addView(createCell("₹%.0f".format(m.totalDebit), color = redColor))
            rowMid.addView(createCell("₹%.0f".format(m.totalCredit), color = emeraldGreen))
            rowMid.addView(createCell(currencyFormat.format(m.totalEarnings), isBold = true, color = vibrantIndigo))
            binding.tablePerformance.addView(rowMid)

            // Right Table
            val rowRight = TableRow(this).also(rowStyle)
            rowRight.addView(createCell(currencyFormat.format(m.salaryDue), isBold = true, color = brightEmerald))
            binding.tableFixedRight.addView(rowRight)
        }

        // Add Summary Footer Rows
        val addSeparator = { table: TableLayout ->
            val row = TableRow(this)
            val sep = View(this).apply {
                layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, 2).apply {
                    span = 20
                }
                setBackgroundColor(ContextCompat.getColor(this@StaffPerformanceActivity, android.R.color.darker_gray))
            }
            row.addView(sep)
            table.addView(row)
        }
        addSeparator(binding.tableFixedLeft)
        addSeparator(binding.tablePerformance)
        addSeparator(binding.tableFixedRight)

        fun createFooterCell(text: String, color: Int? = null, gravity: Int = Gravity.END): TextView {
            return TextView(this).apply {
                this.text = text
                this.gravity = gravity
                setTypeface(null, Typeface.BOLD)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setPadding(8, 0, 8, 0)
                if (color != null) setTextColor(color)
            }
        }

        val footerLeft = TableRow(this).apply { setPadding(0, 16, 0, 16) }
        footerLeft.addView(createFooterCell(getString(R.string.total_sum), gravity = Gravity.START))
        binding.tableFixedLeft.addView(footerLeft)

        val footerMid = TableRow(this).apply { setPadding(0, 16, 0, 16) }
        footerMid.addView(createFooterCell("₹%.0f".format(totalBaseAll)))
        footerMid.addView(createFooterCell("%.1fh".format(totalHoursAll)))
        footerMid.addView(createFooterCell("₹%.0f".format(totalOTAll), color = emeraldGreen))
        footerMid.addView(createFooterCell("₹%.0f".format(totalLateAll), color = redColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalEarlyAll), color = amberColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalGapAll), color = redColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalLeaveAll), color = redColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalPLAll), color = emeraldGreen))
        footerMid.addView(createFooterCell("₹%.0f".format(totalBonusAll), color = emeraldGreen))
        footerMid.addView(createFooterCell("₹%.0f".format(totalAllowanceAll), color = emeraldGreen))
        footerMid.addView(createFooterCell("₹%.0f".format(totalAdvanceAll), color = redColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalDebitAll), color = redColor))
        footerMid.addView(createFooterCell("₹%.0f".format(totalCreditAll), color = emeraldGreen))
        footerMid.addView(createFooterCell(currencyFormat.format(totalEarningsAll), color = vibrantIndigo))
        binding.tablePerformance.addView(footerMid)

        val footerRight = TableRow(this).apply { setPadding(0, 16, 0, 16) }
        footerRight.addView(createFooterCell(currencyFormat.format(totalDueAll), color = brightEmerald))
        binding.tableFixedRight.addView(footerRight)
    }

    private fun updateChart(metrics: List<StaffPerformanceMetrics>) {
        val entries = metrics.mapIndexed { index, m ->
            BarEntry(index.toFloat(), m.workedHours.toFloat())
        }

        val dataSet = BarDataSet(entries, "Worked Hours").apply {
            colors = metrics.map { getIndicatorColor(it.productivityIndicator) }
            valueTextSize = 10f
            valueTextColor = ContextCompat.getColor(this@StaffPerformanceActivity, R.color.text_primary)
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return String.format(Locale.getDefault(), "%.0fh", value)
                }
            }
        }

        binding.barChartPerformance.apply {
            // Fix: Move legend to top to avoid overlap with X-axis labels
            legend.verticalAlignment = Legend.LegendVerticalAlignment.TOP
            legend.horizontalAlignment = Legend.LegendHorizontalAlignment.RIGHT
            legend.orientation = Legend.LegendOrientation.HORIZONTAL
            legend.setDrawInside(false)
            legend.yOffset = 5f

            xAxis.valueFormatter = IndexAxisValueFormatter(metrics.map { it.employee.name })
            xAxis.labelRotationAngle = -45f
            xAxis.granularity = 1f
            xAxis.isGranularityEnabled = true
            xAxis.setDrawGridLines(false)

            data = BarData(dataSet)
            extraBottomOffset = 40f // More space for rotated labels
            animateY(1000)
            invalidate()
        }
    }

    private fun updateInsights(insights: List<String>) {
        binding.llInsights.removeAllViews()
        insights.forEach { text ->
            val textView = TextView(this).apply {
                this.text = text
                setPadding(0, 8, 0, 8)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(ContextCompat.getColor(this@StaffPerformanceActivity, R.color.text_primary))
            }
            binding.llInsights.addView(textView)
        }
    }

    private fun getIndicatorColor(indicator: String): Int = when (indicator) {
        "Very High" -> ContextCompat.getColor(this, R.color.green)
        "High" -> ContextCompat.getColor(this, R.color.green)
        "Medium" -> ContextCompat.getColor(this, R.color.amber)
        else -> ContextCompat.getColor(this, R.color.red)
    }
}
