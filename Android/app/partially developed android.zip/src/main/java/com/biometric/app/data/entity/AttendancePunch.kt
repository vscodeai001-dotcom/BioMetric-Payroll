package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class AttendancePunch(
    @get:PropertyName("punchId") @set:PropertyName("punchId")
    var punchId: String = "",
    
    @get:PropertyName("staffId") @set:PropertyName("staffId")
    var staffId: String = "",
    
    @get:PropertyName("date") @set:PropertyName("date")
    var date: String = "", // yyyy-MM-dd
    
    @get:PropertyName("type") @set:PropertyName("type")
    var type: String = "IN", // IN, OUT, BREAK_IN, BREAK_OUT
    
    @get:PropertyName("timestamp") @set:PropertyName("timestamp")
    var timestamp: Long = 0,
    
    @get:PropertyName("latitude") @set:PropertyName("latitude")
    var latitude: Double = 0.0,
    
    @get:PropertyName("longitude") @set:PropertyName("longitude")
    var longitude: Double = 0.0,
    
    @get:PropertyName("accuracy") @set:PropertyName("accuracy")
    var accuracy: Float = 0f,
    
    @get:PropertyName("geofenceId") @set:PropertyName("geofenceId")
    var geofenceId: String? = null,
    
    @get:PropertyName("distanceFromGeofence") @set:PropertyName("distanceFromGeofence")
    var distanceFromGeofence: Double = 0.0,
    
    @get:PropertyName("photoId") @set:PropertyName("photoId")
    var photoId: String? = null,
    
    @get:PropertyName("deviceId") @set:PropertyName("deviceId")
    var deviceId: String = "",
    
    @get:PropertyName("source") @set:PropertyName("source")
    var source: String = "GEOFENCE", // GEOFENCE, MANUAL, ADMIN, SYSTEM
    
    @get:PropertyName("status") @set:PropertyName("status")
    var status: String = "PENDING" // PENDING, APPROVED, REJECTED
) : Serializable
