package com.biometric.app.data

import com.biometric.app.data.entity.*
import com.biometric.app.sync.FirebaseSyncManager
import com.biometric.app.domain.FinancialCalculator
import com.biometric.app.util.StringUtil
import com.biometric.app.ui.viewmodel.ShopWithProfit
import com.google.firebase.auth.FirebaseAuth
import android.util.Log
import androidx.core.content.edit
import com.biometric.app.backup.BackupWorker
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.tasks.await
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.SimpleDateFormat
import java.util.*
import com.biometric.app.domain.attendance.AttendanceEngine
import com.biometric.app.domain.attendance.AttendanceResult

@OptIn(ExperimentalCoroutinesApi::class)
class MainRepository(
    private val context: android.content.Context,
    val firebaseSync: FirebaseSyncManager,
    val dataSafety: DataSafetyManager,
) {
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    // --- SHARED DATA FLOWS (PREVENTS MULTIPLE LISTENERS) ---
    private val allShopsFlow = firebaseSync.getDataFlow<Shop>("shops")
        .map { list -> list.map { it.copy(name = StringUtil.toTitleCase(it.name)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val allHistoryFlow = firebaseSync.getDataFlow<EmployeeHistory>("employee_history")
        .map { list -> list.map { it.copy(changeReason = StringUtil.toTitleCase(it.changeReason)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val allClosedDaysFlow = firebaseSync.getDataFlow<ShopClosedDay>("shop_closed_days")
        .map { list -> list.map { it.copy(reason = StringUtil.toTitleCase(it.reason)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val allAdvancesFlow = firebaseSync.getDataFlow<AdvancePayment>("advance_payments")
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val allFixedExpensesFlow = firebaseSync.getDataFlow<FixedExpense>("fixed_expenses")
        .map { list -> list.map { it.copy(name = StringUtil.toTitleCase(it.name)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    val allEmployeesFlow = firebaseSync.getDataFlow<Employee>("employees")
        .map { list -> list.map { it.copy(name = StringUtil.toTitleCase(it.name)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    val allOrdersFlow = firebaseSync.getDataFlow<Order>("orders")
        .map { list -> list.map { it.copy(serviceType = StringUtil.toTitleCase(it.serviceType)) } }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    val allAttendanceFlow = firebaseSync.getDataFlow<Attendance>("attendance")
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    val allCashbookFlow = firebaseSync.getDataFlow<Cashbook>("cashbook")
        .map { list ->
            list.map {
                it.copy(
                    category = StringUtil.toTitleCase(it.category),
                    description = StringUtil.toTitleCase(it.description),
                )
            }
        }
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val allSalarySnapshotsFlow = firebaseSync.getDataFlow<SalarySnapshot>("salary_snapshots")
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    val allPunchesFlow = firebaseSync.getDataFlow<AttendancePunch>("attendance_punches")
        .stateIn(repositoryScope, SharingStarted.Eagerly, emptyList())

    private val dayWiseCache = MutableStateFlow<Map<String, Flow<List<DayData>>>>(emptyMap())

    // --- DASHBOARD OPTIMISTIC CACHE ---

    val dashboardPrefs: android.content.SharedPreferences by lazy { context.getSharedPreferences("dashboard_optimistic_cache", android.content.Context.MODE_PRIVATE) }

    fun saveDashboardCache(shops: List<ShopWithProfit>, global: CachedMetrics) {
        val json = com.google.gson.Gson().toJson(shops)
        dashboardPrefs.edit {
            putString("cached_shops_list", json)
            putLong("cached_profit", java.lang.Double.doubleToRawLongBits(global.profit))
            putLong("cached_past", java.lang.Double.doubleToRawLongBits(global.past))
            putLong("cached_expected", java.lang.Double.doubleToRawLongBits(global.expected))
            putInt("cached_shop_count", global.shopCount)
        }
    }

    fun getCachedShops(): List<ShopWithProfit> {
        val json = dashboardPrefs.getString("cached_shops_list", null) ?: return emptyList()
        return try {
            val type = object : com.google.gson.reflect.TypeToken<List<ShopWithProfit>>() {}.type
            com.google.gson.Gson().fromJson(json, type)
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun getCachedGlobalMetrics(): CachedMetrics? {
        if (!dashboardPrefs.contains("cached_profit")) return null
        return CachedMetrics(
            profit = java.lang.Double.longBitsToDouble(dashboardPrefs.getLong("cached_profit", 0L)),
            past = java.lang.Double.longBitsToDouble(dashboardPrefs.getLong("cached_past", 0L)),
            expected = java.lang.Double.longBitsToDouble(dashboardPrefs.getLong("cached_expected", 0L)),
            shopCount = dashboardPrefs.getInt("cached_shop_count", 0),
        )
    }

    data class CachedMetrics(val profit: Double, val past: Double, val expected: Double, val shopCount: Int)

    // --- GENERIC LIST CACHING (ROCKET SPEED) ---

    fun <T> saveListCache(key: String, list: List<T>) {
        val json = com.google.gson.Gson().toJson(list)
        dashboardPrefs.edit { putString("list_cache_$key", json) }
    }

    inline fun <reified T> getListCache(key: String): List<T> {
        val json = dashboardPrefs.getString("list_cache_$key", null) ?: return emptyList()
        return try {
            val type = object : com.google.gson.reflect.TypeToken<List<T>>() {}.type
            com.google.gson.Gson().fromJson(json, type)
        } catch (_: Exception) {
            emptyList()
        }
    }

    // --- COMPUTATION CACHE ---

    private fun triggerBackup() {
        BackupWorker.trigger(context)
    }

    private fun notifyDataChanged() {
        repositoryScope.launch {
            try {
                val profile = getProfileFlow().firstOrNull() ?: return@launch
                profile.dataLastModified = System.currentTimeMillis()
                updateProfile(profile)
            } catch (e: Exception) {
                Log.e("MainRepository", "Failed to update dataLastModified", e)
            }
        }
        triggerBackup()
    }

    private val auth = FirebaseAuth.getInstance()

    // ---------------- USER PROFILE ----------------
    fun getProfileFlow(): Flow<UserProfile?> {
        val uid = auth.currentUser?.uid ?: return flowOf(null)
        return firebaseSync.getGlobalItemFlow<UserProfile>("user_profiles/$uid")
    }
    suspend fun updateProfile(profile: UserProfile) = firebaseSync.pushProfile(profile)
    
    fun getAllUserProfiles(): Flow<List<UserProfile>> = firebaseSync.getQueryFlow(firebaseSync.getGlobalRef().child("user_profiles"))

    suspend fun fetchProfileByPhone(phone: String): UserProfile? {
        val digitsOnly = phone.filter { it.isDigit() }
        
        // Formats to try:
        // 1. +91XXXXXXXXXX (International standard)
        // 2. 91XXXXXXXXXX (With country code, no plus)
        // 3. XXXXXXXXXX (Just 10 digits)
        val formats = mutableListOf<String>()
        if (digitsOnly.length == 10) {
            formats.add("+91$digitsOnly")
            formats.add(digitsOnly)
        } else if (digitsOnly.length == 12) {
            formats.add("+$digitsOnly")
            formats.add(digitsOnly)
            formats.add(digitsOnly.substring(2)) // last 10
        } else {
            formats.add(phone)
            formats.add("+$digitsOnly")
        }

        val ref = firebaseSync.getGlobalRef().child("user_profiles")
        
        // Try to match any of the common formats
        for (f in formats.distinct()) {
            val snapshot = ref.orderByChild("phone").equalTo(f).get().await()
            val profile = snapshot.children.firstOrNull()?.getValue(UserProfile::class.java)
            if (profile != null) return profile
        }

        // Final fallback: fetch all (only if list is likely small) and filter manually
        // For SaaS we should avoid this, but if the above fails and it's a critical path:
        val allSnapshot = ref.get().await()
        return allSnapshot.children.mapNotNull { it.getValue(UserProfile::class.java) }
            .find { it.phone.filter { char -> char.isDigit() }.contains(digitsOnly.takeLast(10)) }
    }

    suspend fun pushProfileByUid(profile: UserProfile) {
        firebaseSync.getGlobalRef().child("user_profiles").child(profile.uid).setValue(profile).await()
    }
    
    // Feature & Branding Integration
    fun getShopBranding(shopId: String): Flow<Shop?> = firebaseSync.getItemFlow("shops", shopId)

    // ---------------- SHOP ----------------
    fun getAllShops(): Flow<List<Shop>> = allShopsFlow
        .map { shops -> shops.filter { it.isActive } }
        .flowOn(Dispatchers.Default)

    suspend fun insertShop(shop: Shop) {
        shop.name = StringUtil.toTitleCase(shop.name)
        firebaseSync.pushShop(shop)
        notifyDataChanged()
    }

    suspend fun deleteShop(shop: Shop) {
        // ATOMIC SOFT-DELETE: We mark as inactive instead of hard deleting from Firebase
        // This ensures linked records (orders, attendance) remain perfectly linked
        val deletedShop = shop.copy(isActive = false)
        dataSafety.recordDeletion("SHOP", shop.shopId, shop, "Shop: ${shop.name}")
        firebaseSync.pushShop(deletedShop)
        notifyDataChanged()
    }

    // ---------------- MENU & ITEMS ----------------
    fun getActiveItems(): Flow<List<Item>> = firebaseSync.getDataFlow<Item>("items")
        .map { items -> items.asSequence().filter { it.isActive }.map { it.copy(name = StringUtil.toTitleCase(it.name), category = StringUtil.toTitleCase(it.category)) }.toList() }
        .flowOn(Dispatchers.Default)

    fun getItem(itemId: String): Flow<Item?> = firebaseSync.getItemFlow<Item>("items", itemId)
        .map { it?.apply { name = StringUtil.toTitleCase(name); category = StringUtil.toTitleCase(category) } }

    fun getShopMenu(shopId: String): Flow<List<ShopMenuItem>> {
        // Optimization: Use a 30-day window for popularity sorting to avoid full order_items download
        val thirtyDaysAgo = System.currentTimeMillis() - (30L * 24 * 60 * 60 * 1000)
        val recentSalesQuery = firebaseSync.getOwnerRef()?.child("order_items")
            ?.orderByChild("timestamp")
            ?.startAt(thirtyDaysAgo.toDouble())

        val recentSalesFlow = if (recentSalesQuery == null) flowOf(emptyList())
                              else firebaseSync.getQueryFlow<OrderItem>(recentSalesQuery)

        return combine(
            getActiveItems(),
            firebaseSync.getDataFlow<ShopItemPrice>("prices"),
            recentSalesFlow,
        ) { items, prices, recentOrderItems ->
            items.asSequence()
                .map { item ->
                    val price = prices.find { ((it.shopId == shopId) && (it.itemId == item.itemId)) }?.sellingPrice ?: item.globalPrice
                    val sales = recentOrderItems.count { it.itemId == item.itemId }
                    ShopMenuItem(item, price, sales)
                }
                .groupBy { menuItem ->
                    // Normalize name for grouping: lowercase and keep only base characters (ignore emojis/punctuation)
                    menuItem.item.name.lowercase()
                        .filter { it.isLetterOrDigit() || it.isWhitespace() }
                        .trim()
                }
                .map { (_, itemsWithName) ->
                    // Merge logic: Keep the item with the highest price (hiked price wins)
                    itemsWithName.maxWith(
                        compareBy<ShopMenuItem> { it.finalPrice }
                            .thenBy { it.salesCount }
                    )
                }
                .groupBy { menuItem ->
                    // Normalize category for consistent grouping in the UI
                    menuItem.item.category.lowercase()
                        .filter { it.isLetterOrDigit() || it.isWhitespace() }
                        .trim()
                }
                .flatMap { (_, itemsInCat) ->
                    // Use a consistent category name (the one with an emoji is usually preferred)
                    // We pick the category string from the item with the highest sales in that group
                    val consistentCategory = itemsInCat.maxByOrNull { it.salesCount }?.item?.category
                        ?: itemsInCat.first().item.category

                    itemsInCat.map { it.copy(item = it.item.copy(category = consistentCategory)) }
                }
                .sortedByDescending { it.salesCount }
                .toList()
        }.flowOn(Dispatchers.Default)
    }

    suspend fun insertItem(item: Item) {
        item.name = StringUtil.toTitleCase(item.name)
        item.category = StringUtil.toTitleCase(item.category)
        firebaseSync.pushItem(item)
        notifyDataChanged()
    }
    suspend fun updateItem(item: Item) {
        firebaseSync.pushItem(item)
        notifyDataChanged()
    }
    suspend fun deleteItem(item: Item) {
        dataSafety.recordDeletion("ITEM", item.itemId, item, "Item: ${item.name}")
        firebaseSync.pushItem(item.copy(isActive = false))
        notifyDataChanged()
    }
    suspend fun updateShopItemPrice(price: ShopItemPrice) {
        firebaseSync.pushPrice(price)
        notifyDataChanged()
    }

    // ---------------- ORDERS ----------------
    fun getHeldOrders(shopId: String): Flow<List<Order>> {
        // Optimization: Server-side status filtering
        val query = firebaseSync.getOwnerRef()?.child("orders")
            ?.orderByChild("status")
            ?.equalTo("HOLD")

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<Order>(query)
            .map { orders -> orders.filter { it.shopId == shopId } }
            .flowOn(Dispatchers.Default)
    }

    fun getOrderWithItems(orderId: String): Flow<OrderWithItems> {
        return combine(
            firebaseSync.getItemFlow<Order>("orders", orderId),
            firebaseSync.getDataFlow<OrderItem>("order_items")
        ) { order, items ->
            OrderWithItems(order ?: Order(orderId = orderId), items.filter { it.orderId == orderId })
        }.flowOn(Dispatchers.Default)
    }

    fun getHeldOrdersWithItems(shopId: String): Flow<List<OrderWithItems>> {
        return getHeldOrders(shopId).flatMapLatest { orders ->
            val orderFlows = orders.map { order ->
                getOrderWithItems(order.orderId)
            }
            if (orderFlows.isEmpty()) {
                flowOf(emptyList())
            } else {
                combine(orderFlows) { it.toList() }
            }
        }.flowOn(Dispatchers.Default)
    }

    fun getOrdersWithItemsForPeriod(shopId: String, start: Long, end: Long): Flow<List<OrderWithItems>> {
        val query = firebaseSync.getOwnerRef()?.child("orders")
            ?.orderByChild("closedAt")
            ?.startAt(start.toDouble())
            ?.endAt(end.toDouble() + 999.0)

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<Order>(query).map { orders ->
            orders.filter { it.shopId == shopId }
        }.flatMapLatest { orders ->
            if (orders.isEmpty()) return@flatMapLatest flowOf(emptyList())
            val orderFlows = orders.map { order ->
                getOrderWithItems(order.orderId)
            }
            combine(orderFlows) { it.toList() }
        }.flowOn(Dispatchers.Default)
    }

    suspend fun insertOrder(order: Order) {
        firebaseSync.pushOrder(order)
        order.closedAt?.let { ts ->
            val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(ts))
            clearMonthlySnapshot(order.shopId, monthKey)
        }
        notifyDataChanged()
    }
    suspend fun updateOrder(order: Order) {
        firebaseSync.pushOrder(order)
        order.closedAt?.let { ts ->
            val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(ts))
            clearMonthlySnapshot(order.shopId, monthKey)
        }
        notifyDataChanged()
    }
    suspend fun deleteOrder(order: Order) = withContext(Dispatchers.IO) {
        dataSafety.recordDeletion("ORDER", order.orderId, order, "Order: ${order.orderId}")
        order.closedAt?.let { ts ->
            val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(ts))
            clearMonthlySnapshot(order.shopId, monthKey)
        }
        firebaseSync.deleteOrderItemsByOrderId(order.orderId)
        firebaseSync.deleteOrder(order.orderId)
        notifyDataChanged()
    }
    suspend fun insertOrderItem(item: OrderItem) {
        firebaseSync.pushOrderItem(item)
        notifyDataChanged()
    }
    fun deleteOrderItemsByOrderId(orderId: String) = firebaseSync.deleteOrderItemsByOrderId(orderId)

    // ---------------- CASHBOOK ----------------
    fun insertCashbookEntry(entry: Cashbook) {
        firebaseSync.pushCashbookEntry(entry)
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(entry.transactionDate))
        clearMonthlySnapshot(entry.shopId, monthKey)

        // Dynamic Requirement: Update Description Master
        entry.description?.let { desc ->
            if (desc.isNotBlank()) {
                repositoryScope.launch {
                    updateDescriptionInMaster(desc, entry.shopId)
                }
            }
        }

        notifyDataChanged()
    }

    suspend fun deleteCashbookEntry(entry: Cashbook) {
        dataSafety.recordDeletion("CASHBOOK", entry.entryId, entry, "${entry.transactionType}: ₹${entry.amount}")
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(entry.transactionDate))
        clearMonthlySnapshot(entry.shopId, monthKey)
        firebaseSync.deleteCashbookEntry(entry.entryId)
        notifyDataChanged()
    }

      private val cashbookFlowCache = MutableStateFlow<Map<String, Flow<List<Cashbook>>>>(emptyMap())

    // OPTIMIZED: Leverages the warm in-memory list for instant UI feedback.
    // If the full list is already synced, we filter locally (0ms delay).
    // If not, we fallback to windowed flow for large datasets.
    fun getCashbookEntriesForPeriod(shopId: String?, start: Long, end: Long): Flow<List<Cashbook>> {
        return allCashbookFlow.map { entries ->
            entries.asSequence()
                .filter { (shopId.isNullOrEmpty() || it.shopId == shopId) && it.transactionDate in start..end }
                .sortedByDescending { it.transactionDate }
                .toList()
        }.flowOn(Dispatchers.Default)
    }

    fun getAttendanceForPeriod(shopId: String?, start: Long, end: Long): Flow<List<Attendance>> {
        return allAttendanceFlow.map { list ->
            list.filter { (shopId.isNullOrEmpty() || it.shopId == shopId) && it.checkInTime in start..end }
        }.flowOn(Dispatchers.Default)
    }

    fun getAttendancePunchesForPeriod(staffId: String?, start: Long, end: Long): Flow<List<AttendancePunch>> {
        return allPunchesFlow.map { list ->
            list.filter { (staffId.isNullOrEmpty() || it.staffId == staffId) && it.timestamp in start..end }
        }.flowOn(Dispatchers.Default)
    }

    fun getAdvancesForPeriod(shopId: String?, start: Long, end: Long): Flow<List<AdvancePayment>> {
        return allAdvancesFlow.map { list ->
            list.filter { (shopId.isNullOrEmpty() || it.shopId == shopId) && it.date in start..end }
        }.flowOn(Dispatchers.Default)
    }

    fun getRecentCashbookEntries(shopId: String?, limit: Int): Flow<List<Cashbook>> = allCashbookFlow
        .map { entries ->
            entries.asSequence().filter { shopId.isNullOrEmpty() || it.shopId == shopId }
                .sortedByDescending { it.transactionDate }
                .take(limit)
                .toList()
        }.flowOn(Dispatchers.Default)

    fun getCashbookEntryById(id: String): Flow<Cashbook?> =
        firebaseSync.getItemFlow("cashbook", id)

    // ---------------- AGGREGATED SUMMARIES (SNAPSHOTS) ----------------
    fun getMonthlySnapshot(shopId: String, monthKey: String): Flow<MonthlySnapshot?> =
        firebaseSync.getItemFlow("monthly_snapshots", "${shopId}_$monthKey")

    suspend fun insertMonthlySnapshot(snapshot: MonthlySnapshot) {
        firebaseSync.pushMonthlySnapshot(snapshot)
    }

    fun getShopEmployees(shopId: String?): Flow<List<Employee>> = allEmployeesFlow
        .map { employees ->
            employees.filter { emp ->
                val isDeleted = !emp.isActive && emp.terminateDate == null
                !isDeleted && (shopId.isNullOrEmpty() || emp.shopId == shopId)
            }
        }.flowOn(Dispatchers.Default)

    fun getAllEmployees(): Flow<List<Employee>> = allEmployeesFlow
        .map { employees ->
            employees.filter { emp ->
                val isDeleted = !emp.isActive && emp.terminateDate == null
                !isDeleted
            }
        }

    fun getEmployee(employeeId: String): Flow<Employee?> = firebaseSync.getItemFlow("employees", employeeId)
    suspend fun insertEmployee(employee: Employee) {
        employee.name = StringUtil.toTitleCase(employee.name)
        firebaseSync.pushEmployee(employee)
        notifyDataChanged()
    }
    suspend fun updateEmployee(employee: Employee) {
        // Fetch old version for history if possible, or just push.
        // For premium safety, we record update
        firebaseSync.pushEmployee(employee)
        notifyDataChanged()
    }
    suspend fun deleteEmployee(employee: Employee) {
        // ATOMIC SOFT-DELETE for Staff: Move to Bin
        // We set isActive = false and terminateDate = null to ensure they are hidden from the staff list
        // and moved to the recycle bin for potential restoration.
        val deletedEmployee = employee.copy(isActive = false, terminateDate = null)
        dataSafety.recordDeletion("STAFF", employee.employeeId, employee, "Staff: ${employee.name}")
        firebaseSync.pushEmployee(deletedEmployee)
        notifyDataChanged()
    }
    suspend fun deleteEmployeeHistory(history: EmployeeHistory) {
        dataSafety.recordDeletion("STAFF_HISTORY", history.historyId, history, "History Update")
        firebaseSync.deleteHistory(history.historyId)
        notifyDataChanged()
    }

    fun pushHistoryAtomic(history: EmployeeHistory) {
        firebaseSync.pushHistoryAtomic(history)
    }
    fun getEmployeeHistoryFlow(employeeId: String): Flow<List<EmployeeHistory>> =
        firebaseSync.getDataFlow<EmployeeHistory>("employee_history").map { history ->
            history.filter { it.employeeId == employeeId }.sortedBy { it.version }
        }.flowOn(Dispatchers.Default)

    // ---------------- ATTENDANCE & PAYMENTS ----------------
    fun getAttendanceFlow(employeeId: String, start: Long, end: Long): Flow<List<Attendance>> {
        val query = firebaseSync.getOwnerRef()?.child("attendance")
            ?.orderByChild("checkInTime")
            ?.startAt(start.toDouble())
            ?.endAt(end.toDouble())

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<Attendance>(query).map { records ->
            records.filter { it.employeeId == employeeId }
                .sortedByDescending { it.checkInTime }
        }.flowOn(Dispatchers.Default)
    }

    suspend fun insertAttendance(att: Attendance) {
        if (att.attendanceId.isBlank()) {
            att.attendanceId = UUID.randomUUID().toString()
        }
        firebaseSync.pushAttendance(att)
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(att.checkInTime))
        clearMonthlySnapshot(att.shopId, monthKey)
        clearSalarySnapshots(att.employeeId)
        notifyDataChanged()
    }

    suspend fun markAttendance(employee: Employee, date: Date = Date()) {
        val todayStart = Calendar.getInstance().apply {
            time = date
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val records = getAttendanceFlow(employee.employeeId, todayStart, todayStart + 86400000).first()
        val lastRecord = records.filter { it.type == "WORK" }.maxByOrNull { it.checkInTime }

        if (lastRecord != null && lastRecord.checkOutTime == null) {
            updateAttendance(
                lastRecord.copy(
                    checkOutTime = date.time,
                    hoursWorked = (date.time - lastRecord.checkInTime) / 3600000.0
                )
            )
        } else {
            val cal = Calendar.getInstance().apply { time = date }
            val isWeekend = cal[Calendar.DAY_OF_WEEK] == Calendar.SATURDAY || cal[Calendar.DAY_OF_WEEK] == Calendar.SUNDAY

            val start = if (isWeekend && employee.weekendShiftStart != null) employee.weekendShiftStart!! else employee.shiftStart
            val end = if (isWeekend && employee.weekendShiftEnd != null) employee.weekendShiftEnd!! else employee.shiftEnd
            val s2Start = if (isWeekend && employee.weekendShift2Start != null) employee.weekendShift2Start else employee.shift2Start
            val s2End = if (isWeekend && employee.weekendShift2End != null) employee.weekendShift2End else employee.shift2End
            val bHrs = if (isWeekend && employee.weekendBreakHours != null) employee.weekendBreakHours!! else employee.breakHours

            insertAttendance(Attendance(
                attendanceId = UUID.randomUUID().toString(),
                employeeId = employee.employeeId,
                shopId = employee.shopId,
                checkInTime = date.time,
                type = "WORK",
                shiftStart = start,
                shiftEnd = end,
                shift2Start = s2Start,
                shift2End = s2End,
                breakHours = bHrs,
                salaryType = employee.salaryType,
                salaryRate = employee.salaryRate,
                createdAt = System.currentTimeMillis()
            ))
        }
    }
    suspend fun updateAttendance(att: Attendance) {
        firebaseSync.pushAttendance(att)
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(att.checkInTime))
        clearMonthlySnapshot(att.shopId, monthKey)
        clearSalarySnapshots(att.employeeId)
        notifyDataChanged()
    }
    suspend fun deleteAttendance(att: Attendance) {
        dataSafety.recordDeletion("ATTENDANCE", att.attendanceId, att, "Attendance Record")
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(Date(att.checkInTime))
        clearMonthlySnapshot(att.shopId, monthKey)
        clearSalarySnapshots(att.employeeId)
        firebaseSync.deleteAttendance(att.attendanceId)
        notifyDataChanged()
    }

    suspend fun insertPunch(punch: AttendancePunch) {
        if (punch.punchId.isBlank()) {
            punch.punchId = UUID.randomUUID().toString()
        }
        firebaseSync.pushAttendancePunch(punch)
        notifyDataChanged()
    }

    suspend fun deletePunch(punch: AttendancePunch) {
        dataSafety.recordDeletion("PUNCH", punch.punchId, punch, "Punch: ${punch.type}")
        firebaseSync.deleteAttendancePunch(punch.punchId)
        notifyDataChanged()
    }

    fun getAttendanceResultFlow(
        staffId: String,
        date: String,
        shiftStart: String,
        shiftEnd: String
    ): Flow<AttendanceResult> {
        return allPunchesFlow.map { punches ->
            val staffPunches = punches.filter { it.staffId == staffId && it.date == date }
            AttendanceEngine.processAttendance(date, staffPunches, shiftStart, shiftEnd)
        }.flowOn(Dispatchers.Default)
    }

    fun getPendingAdvance(employeeId: String, start: Long? = null, end: Long? = null): Flow<Double> = allAdvancesFlow
        .map { advances ->
            advances.filter {
                it.employeeId == employeeId &&
                !it.isRecovered &&
                (start == null || it.date >= start) &&
                (end == null || it.date <= end)
            }.sumOf { it.amount }
        }.flowOn(Dispatchers.Default)

    fun getAdvanceRecords(employeeId: String, start: Long, end: Long): Flow<List<AdvancePayment>> = allAdvancesFlow
        .map { advances ->
            advances.filter { it.employeeId == employeeId && it.date in start..end }
                .sortedByDescending { it.date }
        }.flowOn(Dispatchers.Default)

    suspend fun insertAdvance(adv: AdvancePayment) {
        firebaseSync.pushAdvance(adv)
        notifyDataChanged()
    }
    suspend fun updateAdvance(adv: AdvancePayment) {
        firebaseSync.pushAdvance(adv)
        notifyDataChanged()
    }
    suspend fun deleteAdvance(adv: AdvancePayment) {
        dataSafety.recordDeletion("ADVANCE", adv.advanceId, adv, "Advance: ₹${adv.amount}")
        firebaseSync.deleteAdvance(adv.advanceId)
        notifyDataChanged()
    }

    fun insertSalaryPayment(payment: SalaryPayment) = firebaseSync.pushSalaryPayment(payment)
    fun getClosedDays(shopId: String?, start: Long, end: Long): Flow<List<ShopClosedDay>> = allClosedDaysFlow
        .map { days ->
            days.filter { (shopId.isNullOrEmpty() || it.shopId == shopId) && it.date in start..end }
        }.flowOn(Dispatchers.Default)

    suspend fun insertClosedDay(day: ShopClosedDay) {
        day.reason = StringUtil.toTitleCase(day.reason)
        firebaseSync.pushClosedDay(day)
        notifyDataChanged()
    }
    suspend fun deleteClosedDay(day: ShopClosedDay) {
        dataSafety.recordDeletion("CLOSED_DAY", day.id, day, "Closed Day")
        firebaseSync.deleteClosedDay(day.id)
        notifyDataChanged()
    }

    // ---------------- FIXED EXPENSES ----------------
    fun getFixedExpensesForShop(shopId: String?): Flow<List<FixedExpense>> = allFixedExpensesFlow
        .map { expenses ->
            expenses.filter { !it.isArchived && (shopId.isNullOrEmpty() || it.shopId == shopId) }
        }.flowOn(Dispatchers.Default)

    fun getAllFixedExpenses(): Flow<List<FixedExpense>> = allFixedExpensesFlow
        .map { list -> list.filter { !it.isArchived } }

    suspend fun insertFixedExpense(expense: FixedExpense) {
        expense.name = StringUtil.toTitleCase(expense.name)
        firebaseSync.pushFixedExpense(expense)
        notifyDataChanged()
    }
    suspend fun deleteFixedExpense(expense: FixedExpense) {
        dataSafety.recordDeletion("EXPENSE", expense.id, expense, "Expense: ${expense.name}")
        firebaseSync.deleteFixedExpense(expense.id)
        notifyDataChanged()
    }

    // ---------------- SALARY ENGINE UNIFICATION ----------------

    fun getEmployeeStatsFlow(
        employee: Employee,
        start: Long,
        end: Long,
        selDayStart: Long? = null,
        selDayEnd: Long? = null,
    ): Flow<EmployeeStats> {
        // Fetch slightly wider range of attendance to handle any month-boundary edge cases
        val buffer = 86400000L // 1 day
        return combine(
            getAttendanceFlow(employee.employeeId, start - buffer, end + buffer),
            allClosedDaysFlow,
            allAdvancesFlow,
            getEmployeeHistoryFlow(employee.employeeId),
            allShopsFlow
        ) { args: Array<Any?> ->
            @Suppress("UNCHECKED_CAST")
            val allAttendance = args[0] as List<Attendance>
            @Suppress("UNCHECKED_CAST")
            val closedDays = args[1] as List<ShopClosedDay>
            @Suppress("UNCHECKED_CAST")
            val allAdvances = args[2] as List<AdvancePayment>
            @Suppress("UNCHECKED_CAST")
            val history = args[3] as List<EmployeeHistory>
            @Suppress("UNCHECKED_CAST")
            val shops = args[4] as List<Shop>

            val shop = shops.find { it.shopId == employee.shopId }
            val empAdvances = allAdvances.filter { it.employeeId == employee.employeeId }
            val totalPending = empAdvances.filter { !it.isRecovered }.sumOf { it.amount }
            val monthAdvance = empAdvances.filter { it.date in start..end }.sumOf { it.amount }

            val (stats, _) = SalaryEngine.calculateStats(
                employee = employee,
                monthStart = start,
                monthEnd = end,
                allAttendance = allAttendance,
                closedDays = closedDays.filter { it.shopId == employee.shopId },
                pendingAdvance = totalPending,
                history = history,
                selDayStart = selDayStart ?: start,
                selDayEnd = selDayEnd ?: end,
                rules = shop?.salaryRules ?: SalaryRules(),
                snapshot = null
            )

            stats.monthlyAdvance = monthAdvance
            stats
        }.flowOn(Dispatchers.Default)
    }

    fun getBatchEmployeeStatsFlow(
        employees: List<Employee>,
        start: Long,
        end: Long,
        selDayStart: Long,
        selDayEnd: Long,
    ): Flow<Map<String, EmployeeStats>> {
        if (employees.isEmpty()) return flowOf(emptyMap())

        val buffer = 86400000L
        val employeeIds = employees.map { it.employeeId }.toSet()

        // Filtered Attendance
        val attendanceFlow = firebaseSync.getDataFlow<Attendance>("attendance")
            .map { it.filter { a -> a.checkInTime in (start - buffer)..(end + buffer) } }

        return combine(
            attendanceFlow,
            allClosedDaysFlow,
            allAdvancesFlow,
            allHistoryFlow,
            allShopsFlow
        ) { args: Array<Any?> ->
            @Suppress("UNCHECKED_CAST")
            val allAttendance = args[0] as List<Attendance>
            @Suppress("UNCHECKED_CAST")
            val allClosedDays = args[1] as List<ShopClosedDay>
            @Suppress("UNCHECKED_CAST")
            val allAdvances = args[2] as List<AdvancePayment>
            @Suppress("UNCHECKED_CAST")
            val allHistory = args[3] as List<EmployeeHistory>
            @Suppress("UNCHECKED_CAST")
            val shops = args[4] as List<Shop>

            val attendanceByEmp = allAttendance.filter { employeeIds.contains(it.employeeId) }.groupBy { it.employeeId }
            val advancesByEmp = allAdvances.filter { employeeIds.contains(it.employeeId) }.groupBy { it.employeeId }
            val historyByEmp = allHistory.groupBy { it.employeeId }
            val shopMap = shops.associateBy { it.shopId }

            employees.associate { employee ->
                val empAdvances = advancesByEmp[employee.employeeId] ?: emptyList()
                val totalPending = empAdvances.filter { !it.isRecovered }.sumOf { it.amount }
                val monthAdvance = empAdvances.filter { it.date in start..end }.sumOf { it.amount }

                val (stats, _) = SalaryEngine.calculateStats(
                    employee = employee,
                    monthStart = start,
                    monthEnd = end,
                    allAttendance = attendanceByEmp[employee.employeeId] ?: emptyList(),
                    closedDays = allClosedDays.filter { it.shopId == employee.shopId },
                    pendingAdvance = totalPending,
                    history = historyByEmp[employee.employeeId]?.sortedBy { it.version } ?: emptyList(),
                    selDayStart = selDayStart,
                    selDayEnd = selDayEnd,
                    rules = shopMap[employee.shopId]?.salaryRules ?: SalaryRules(),
                    snapshot = null
                )
                stats.monthlyAdvance = monthAdvance
                employee.employeeId to stats
            }
        }.flowOn(Dispatchers.Default)
    }

    @Suppress("UNCHECKED_CAST")
    fun getProjectedSalaryFlow(
        shopId: String?,
        start: Long,
        end: Long,
        includeBonus: Boolean = true
    ): Flow<Double> {
        return combine(
            getCashbookEntriesForPeriod(shopId, start, end), // Add back manual entries
            getShopEmployees(shopId),
            firebaseSync.getDataFlow<Attendance>("attendance").map { it.filter { a -> a.checkInTime in (start - 86400000L)..(end + 86400000L) } },
            allClosedDaysFlow,
            allAdvancesFlow,
            allHistoryFlow,
            allShopsFlow
        ) { args: Array<Any?> ->
            @Suppress("UNCHECKED_CAST")
            val entries = args[0] as List<Cashbook>
            @Suppress("UNCHECKED_CAST")
            val employees = args[1] as List<Employee>
            @Suppress("UNCHECKED_CAST")
            val allAttendance = args[2] as List<Attendance>
            @Suppress("UNCHECKED_CAST")
            val allClosedDays = args[3] as List<ShopClosedDay>
            @Suppress("UNCHECKED_CAST")
            val allAdvances = args[4] as List<AdvancePayment>
            @Suppress("UNCHECKED_CAST")
            val allHistory = args[5] as List<EmployeeHistory>
            @Suppress("UNCHECKED_CAST")
            val allShops = args[6] as List<Shop>

            // ONE SOURCE OF TRUTH: Include manual salary payouts NOT linked to an employee reference
            val manualSalaries = entries.filter {
                it.transactionType == "OUT" &&
                FinancialCategory.isSalary(it.category, it.description) &&
                it.referenceId == null
            }.sumOf { it.amount }

            var totalStaffLiability = manualSalaries

            if (employees.isEmpty()) return@combine totalStaffLiability

            val attendanceMap = allAttendance.groupBy { it.employeeId }
            val closedDaysMap = allClosedDays.groupBy { it.shopId }
            val advancesMap = allAdvances.groupBy { it.employeeId }
            val historyMap = allHistory.groupBy { it.employeeId }
            val shopMap = allShops.associateBy { it.shopId }

            // Determine all unique months touched by the range [start, end]
            val touchedMonths = mutableListOf<Pair<Long, Long>>()
            val calMonth = Calendar.getInstance().apply { timeInMillis = start }
            while (calMonth.timeInMillis <= end) {
                val mStart = (calMonth.clone() as Calendar).apply {
                    set(Calendar.DAY_OF_MONTH, 1)
                    set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
                }.timeInMillis
                val mEnd = (calMonth.clone() as Calendar).apply {
                    set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                    set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
                }.timeInMillis
                touchedMonths.add(mStart to mEnd)

                // Move to next month
                calMonth.timeInMillis = mEnd
                calMonth.add(Calendar.MILLISECOND, 1)
            }

            touchedMonths.forEach { (monthStart, monthEnd) ->
                val intersectStart = maxOf(start, monthStart)
                val intersectEnd = minOf(end, monthEnd)

                employees.forEach { employee ->
                    val empAttendance = attendanceMap[employee.employeeId] ?: emptyList()
                    val empClosedDays = closedDaysMap[employee.shopId] ?: emptyList()
                    val empAdvances = advancesMap[employee.employeeId] ?: emptyList()
                    val empHistory = (historyMap[employee.employeeId] ?: emptyList()).sortedBy { it.version }
                    val shop = shopMap[employee.shopId]

                    val pendingAdvanceAmt = empAdvances.filter {
                        !it.isRecovered && it.date in intersectStart..intersectEnd
                    }.sumOf { it.amount }

                    // ONE SOURCE OF TRUTH: Use Live calculation (snapshot = null) to match Star Staff screen
                    val (stats, _) = SalaryEngine.calculateStats(
                        employee = employee,
                        monthStart = monthStart,
                        monthEnd = monthEnd,
                        allAttendance = empAttendance,
                        closedDays = empClosedDays,
                        pendingAdvance = pendingAdvanceAmt,
                        history = empHistory,
                        selDayStart = intersectStart,
                        selDayEnd = intersectEnd,
                        rules = shop?.salaryRules ?: SalaryRules(),
                        snapshot = null
                    )

                    totalStaffLiability += stats.getRoundedPeriodLiability(intersectStart, intersectEnd, includeBonus)
                }
            }
            totalStaffLiability
        }.flowOn(Dispatchers.Default)
    }

    suspend fun calculateProjectedSalary(
        shopId: String?,
        start: Long,
        end: Long,
        includeBonus: Boolean = true
    ): Double = getProjectedSalaryFlow(shopId, start, end, includeBonus).firstOrNull() ?: 0.0

    internal suspend fun calculateProratedExpenses(
        expenses: List<FixedExpense>,
        start: Long,
        end: Long,
        shopOpeningDates: Map<String, Long> = emptyMap()
    ): Double {
        val openingDates = shopOpeningDates.ifEmpty {
            getAllShops().first().associateBy({ it.shopId }) { it.openingDate }
        }
        return FinancialCalculator.calculateProratedExpenses(expenses, start, end, openingDates)
    }

    fun getCashFlowSummary(shopId: String?, start: Long, end: Long, salary: Double = 0.0): Flow<CashFlowSummary?> {
        val cashbookFlow = getCashbookEntriesForPeriod(shopId, start, end)
        val expensesFlow = getFixedExpensesForShop(shopId)

        return combine(cashbookFlow, expensesFlow, allShopsFlow) { entries, expenses, shops ->
            val totalIn = entries.filter { it.transactionType == "IN" }.sumOf { it.amount }

            // ONE SOURCE OF TRUTH: Fixed expenses are calculated from Master + Manual Cashbook entries.
            val fixedFromCashbook = entries.filter {
                it.transactionType == "OUT" && FinancialCategory.isFixed(it.category)
            }.sumOf { it.amount }

            val totalOut = entries.filter {
                it.transactionType == "OUT" &&
                !FinancialCategory.isSalary(it.category, it.description) &&
                !FinancialCategory.isAdvance(it.category) &&
                !FinancialCategory.isFixed(it.category)
            }.sumOf { it.amount }

            val openingDates = shops.associateBy({ it.shopId }, { it.openingDate })
            val fixedExpenses = calculateProratedExpenses(expenses, start, end, openingDates)
            CashFlowSummary(totalIn, totalOut, salary, fixedExpenses + fixedFromCashbook)
        }.flowOn(Dispatchers.Default)
    }

    private val metricsFlowCache = MutableStateFlow<Map<String, Flow<RawMetrics>>>(emptyMap())

    private val compMetricsCache = MutableStateFlow<Map<String, Flow<ComprehensiveMetrics>>>(emptyMap())

    /**
     * PERFORMANCE POWERHOUSE: Returns a single flow containing both current and historical comparison metrics.
     * Uses internal shared flows to prevent redundant network listeners.
     */
    fun getComprehensiveShopMetrics(
        shopId: String,
        period: String,
        currentStart: Long,
        currentEnd: Long
    ): Flow<ComprehensiveMetrics> {
        val cacheKey = "comp_${shopId}_${period}_${currentStart}_$currentEnd"
        compMetricsCache.value[cacheKey]?.let { return it }

        val p1Range = getPastRangeInternal(period, currentEnd, 1)
        val p2Range = getPastRangeInternal(period, currentEnd, 2)
        val p3Range = getPastRangeInternal(period, currentEnd, 3)

        val newFlow = combine(
            getShopMetricsFlow(shopId, currentStart, currentEnd),
            getShopMetricsFlow(shopId, p1Range.first, p1Range.second),
            getShopMetricsFlow(shopId, p2Range.first, p2Range.second),
            getShopMetricsFlow(shopId, p3Range.first, p3Range.second)
        ) { current, p1, p2, p3 ->
            ComprehensiveMetrics(current, p1, p2, p3)
        }.flowOn(Dispatchers.Default)
        .shareIn(repositoryScope, SharingStarted.WhileSubscribed(60000), 1)

        compMetricsCache.value += (cacheKey to newFlow)
        return newFlow
    }

    private fun getPastRangeInternal(period: String, start: Long, offset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        com.biometric.app.util.DateRangeUtil.shiftPeriod(period, cal, -offset)
        return com.biometric.app.util.DateRangeUtil.getRangeForPeriod(period, cal.timeInMillis)
    }

    data class ComprehensiveMetrics(
        val current: RawMetrics,
        val p1: RawMetrics,
        val p2: RawMetrics,
        val p3: RawMetrics
    )

    fun getShopMetricsFlow(shopId: String?, start: Long, end: Long): Flow<RawMetrics> {
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        val monthKey = SimpleDateFormat("yyyyMM", Locale.getDefault()).format(cal.time)

        // Ensure accurate millisecond ranges for the query
        val queryStart = Calendar.getInstance().apply {
            timeInMillis = start
            this[Calendar.HOUR_OF_DAY] = 0; this[Calendar.MINUTE] = 0; this[Calendar.SECOND] = 0; this[Calendar.MILLISECOND] = 0
        }.timeInMillis

        val queryEnd = Calendar.getInstance().apply {
            timeInMillis = end
            this[Calendar.HOUR_OF_DAY] = 23; this[Calendar.MINUTE] = 59; this[Calendar.SECOND] = 59; this[Calendar.MILLISECOND] = 999
        }.timeInMillis

        // Cache key for the specific shop and range
        val cacheKey = "${shopId ?: "global"}_${queryStart}_$queryEnd"

        metricsFlowCache.value[cacheKey]?.let { return it }

        // Determine if we should auto-snapshot (only for full past months and specific shop)
        val isFullMonth = (cal[Calendar.DAY_OF_MONTH] == 1) &&
                         (Calendar.getInstance().apply { timeInMillis = end }[Calendar.DAY_OF_MONTH] == cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        val isPastMonth = queryEnd < System.currentTimeMillis()
        val snapshotMonth = if (isFullMonth && isPastMonth && !shopId.isNullOrEmpty()) monthKey else null

        val newFlow = calculateMetricsLive(shopId, queryStart, queryEnd, snapshotMonth)
            .shareIn(repositoryScope, SharingStarted.WhileSubscribed(60000), 1)
            .distinctUntilChanged()

        metricsFlowCache.value += (cacheKey to newFlow)
        return newFlow
    }

    private fun calculateMetricsLive(shopId: String?, start: Long, end: Long, autoSnapshotMonth: String?): Flow<RawMetrics> = callbackFlow {
        // PERFORMANCE ACCELERATION: Check for pre-calculated snapshots for past periods
        if (autoSnapshotMonth != null && !shopId.isNullOrEmpty()) {
            val snapshot = getMonthlySnapshot(shopId, autoSnapshotMonth).first()
            val profile = getProfileFlow().firstOrNull()
            
            // ATOMIC FRESHNESS CHECK: Only use snapshot if it was updated AFTER the last data change
            val isFresh = snapshot != null && profile != null && snapshot.lastUpdated >= profile.dataLastModified
            
            if (snapshot != null && snapshot.isFinalized && isFresh) {
                send(RawMetrics(snapshot.totalSales, snapshot.totalSalary, snapshot.totalExpense, snapshot.fixedExpenses, snapshot.netProfit))
                close()
                return@callbackFlow
            }
        }

        val job = launch {
            getFullDayWiseDataFlow(shopId, start, end, includeBonus = true)
                .map { dayData ->
                    val sales = dayData.sumOf { it.totalIn }
                    val salary = dayData.sumOf { it.salaryEarned }
                    val expense = dayData.sumOf { it.totalOut }
                    val fixed = dayData.sumOf { it.fixedExpense }
                    val profit = sales - (salary + expense + fixed)
                    RawMetrics(sales, salary, expense, fixed, profit)
                }.collect { metrics ->
                    send(metrics)

                if (autoSnapshotMonth != null && !shopId.isNullOrEmpty()) {
                    // Background update snapshot - this part can use repositoryScope if we want it to survive
                    repositoryScope.launch {
                        insertMonthlySnapshot(MonthlySnapshot(
                            snapshotId = "${shopId}_$autoSnapshotMonth",
                            shopId = shopId,
                            monthKey = autoSnapshotMonth,
                            totalSales = metrics.sales,
                            totalSalary = metrics.salary,
                            totalExpense = metrics.expense,
                            fixedExpenses = metrics.fixed,
                            netProfit = metrics.profit,
                            isFinalized = true,
                            lastUpdated = System.currentTimeMillis()
                        ))
                    }
                }
            }
        }
        awaitClose { job.cancel() }
    }.flowOn(Dispatchers.Default)

    // ---------------- PURCHASES ----------------
    fun getShopSuppliers(shopId: String): Flow<List<Supplier>> {
        val query = if (shopId.isEmpty()) {
            firebaseSync.getOwnerRef()?.child("suppliers")
        } else {
            firebaseSync.getOwnerRef()?.child("suppliers")?.orderByChild("shopId")?.equalTo(shopId)
        }

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<Supplier>(query).flowOn(Dispatchers.Default)
    }

    suspend fun insertSupplier(supplier: Supplier) {
        supplier.name = StringUtil.toTitleCase(supplier.name)
        firebaseSync.pushSupplier(supplier)
        notifyDataChanged()
    }

    // ---------------- STOCK ----------------

    // ---------------- EXPENSE CATEGORIES ----------------
    fun getExpenseCategories(shopId: String? = null): Flow<List<ExpenseCategory>> = firebaseSync.getDataFlow<ExpenseCategory>("expense_categories")
        .map { list ->
            list.filter { it.isActive && (it.shopId == null || it.shopId == shopId) }
                .map { it.copy(name = StringUtil.toTitleCase(it.name)) }
        }
        .flowOn(Dispatchers.Default)

    suspend fun insertExpenseCategory(cat: ExpenseCategory) {
        cat.name = StringUtil.toTitleCase(cat.name)
        firebaseSync.pushExpenseCategory(cat)
        notifyDataChanged()
    }

    suspend fun deleteExpenseCategory(cat: ExpenseCategory) {
        // Mark as inactive for safety, or hard delete if user prefers.
        // For master data, setting isActive=false is usually safer.
        firebaseSync.pushExpenseCategory(cat.copy(isActive = false))
        notifyDataChanged()
    }

    // ---------------- DESCRIPTION MASTER ----------------
    fun getDescriptionMaster(shopId: String? = null): Flow<List<DescriptionMaster>> = firebaseSync.getDataFlow<DescriptionMaster>("description_master")
        .map { list ->
            list.filter { it.shopId == null || it.shopId == shopId }
                .map { it.copy(name = StringUtil.toTitleCase(it.name)) }
                .sortedByDescending { it.lastUsed }
        }
        .flowOn(Dispatchers.Default)

    private suspend fun updateDescriptionInMaster(name: String, shopId: String? = null) {
        val normalized = name.trim().uppercase()
        if (normalized.isBlank()) return

        val masters = getDescriptionMaster(shopId).first()
        val existing = masters.find { it.name.trim().uppercase() == normalized }

        val titleCaseName = StringUtil.toTitleCase(name)

        if (existing != null) {
            firebaseSync.pushDescriptionMaster(existing.copy(name = titleCaseName, lastUsed = System.currentTimeMillis()))
        } else {
            firebaseSync.pushDescriptionMaster(DescriptionMaster(name = titleCaseName, lastUsed = System.currentTimeMillis(), shopId = shopId))
        }
    }

    suspend fun deleteDescriptionMaster(item: DescriptionMaster) {
        firebaseSync.getOwnerRef()?.child("description_master")?.child(item.id)?.removeValue()?.await()
        notifyDataChanged()
    }

    suspend fun renameDescriptionGlobally(oldName: String, newName: String, shopId: String? = null) = withContext(Dispatchers.IO) {
        val normalizedOld = oldName.trim().uppercase()
        val normalizedNew = newName.trim().uppercase()

        if (normalizedOld == normalizedNew) return@withContext

        if (normalizedOld.isNotEmpty()) {
            val ownerRef = firebaseSync.getOwnerRef() ?: return@withContext

            // 1. Update Cashbook Entries using a more reliable direct query
            val cashbookSnapshot = ownerRef.child("cashbook").get().await()
            val affectedShops = mutableSetOf<String>()

            cashbookSnapshot.children.forEach { child ->
                val entry = child.getValue(Cashbook::class.java)
                if (entry != null && entry.description?.trim()?.uppercase() == normalizedOld) {
                    if (shopId == null || entry.shopId == shopId) {
                        affectedShops.add(entry.shopId)
                        val updated = entry.copy(description = normalizedNew)
                        child.ref.setValue(updated)
                    }
                }
            }

            // 2. Update Price History using direct query
            val historySnapshot = ownerRef.child("price_history").orderByChild("itemName").equalTo(normalizedOld).get().await()

            historySnapshot.children.forEach { child ->
                val hist = child.getValue(PriceHistory::class.java)
                if (hist != null && (shopId == null || hist.shopId == shopId)) {
                    affectedShops.add(hist.shopId)
                    val updated = hist.copy(itemName = normalizedNew)
                    child.ref.setValue(updated)
                }
            }

            // 3. Delete old Inventory records
            if (shopId == null) {
                firebaseSync.deleteInventoryItem(oldName)
            } else {
                // If specific shop, we rebuild it below which will overwrite/update
            }

            // 4. Rebuild Inventory for the new and old names in all affected shops
            affectedShops.forEach { sId ->
                rebuildInventoryItem(sId, normalizedNew)
                rebuildInventoryItem(sId, normalizedOld)
            }
        }

        // 5. Update Description Master
        val masters = getDescriptionMaster().firstOrNull() ?: emptyList()
        val oldMaster = if (normalizedOld.isNotEmpty()) masters.find { it.name.trim().uppercase() == normalizedOld } else null
        val newMaster = masters.find { it.name.trim().uppercase() == normalizedNew }

        if (oldMaster != null) {
            if (newMaster != null) {
                // Merge into existing: Update lastUsed and delete old
                val updatedNew = newMaster.copy(lastUsed = maxOf(newMaster.lastUsed, oldMaster.lastUsed))
                firebaseSync.pushDescriptionMaster(updatedNew)
                firebaseSync.getOwnerRef()?.child("description_master")?.child(oldMaster.id)?.removeValue()
            } else {
                // Rename existing
                val updatedOld = oldMaster.copy(name = StringUtil.toTitleCase(newName))
                firebaseSync.pushDescriptionMaster(updatedOld)
            }
        } else if (newMaster == null) {
            // Add new if it doesn't exist
            firebaseSync.pushDescriptionMaster(DescriptionMaster(name = StringUtil.toTitleCase(newName)))
        }

        if (normalizedOld.isNotEmpty()) {
            logAction(null, "RENAME", "DESCRIPTION", oldName, newName)
        } else {
            logAction(null, "ADD", "DESCRIPTION", null, newName)
        }
        notifyDataChanged()
    }

    suspend fun rebuildInventoryItem(shopId: String, name: String, defaultUnit: String = "Piece") {
        if (name.isEmpty()) return

        getPriceHistory(shopId, name).first().let { itemHistory ->
            if (itemHistory.isEmpty()) {
                // No history left for this name in this shop
                // Note: deleteInventoryItem in firebaseSync deletes by name (which is the key)
                // If it's unique across shops, this is fine. If not, we might need per-shop keys.
                // Looking at firebaseSync.pushInventoryItem, it uses uppercase name as key.
                // This means inventory is GLOBAL by name across all shops?
                // Wait, if it's global, then shopId in InventoryItem is just the "last updated" shop?
                // Let's check FirebaseSyncManager.pushInventoryItem again.
                firebaseSync.deleteInventoryItem(name)
                return@let
            }

            val sortedHistory = itemHistory.sortedBy { it.date }
            val totalQty = sortedHistory.sumOf { it.quantity }
            val totalCost = sortedHistory.sumOf { it.price * it.quantity }
            val lastPrice = sortedHistory.last().price
            val lastUnit = sortedHistory.last().unit ?: defaultUnit

            val item = InventoryItem(
                shopId = shopId,
                name = name,
                unitType = lastUnit,
                totalQuantity = totalQty,
                totalCost = totalCost,
                lastPrice = lastPrice,
                lastUpdate = System.currentTimeMillis()
            )

            firebaseSync.pushInventoryItem(item)
        }
    }

    // ---------------- INVESTMENTS ----------------
    fun getInvestments(shopId: String?): Flow<List<Investment>> {
        val query = if (shopId.isNullOrEmpty()) {
            firebaseSync.getOwnerRef()?.child("investments")
        } else {
            firebaseSync.getOwnerRef()?.child("investments")
                ?.orderByChild("shopId")
                ?.equalTo(shopId)
        }

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<Investment>(query)
            .map { list -> list.sortedByDescending { it.date } }
            .flowOn(Dispatchers.Default)
    }

    suspend fun insertInvestment(investment: Investment) {
        investment.itemName = StringUtil.toTitleCase(investment.itemName)
        firebaseSync.pushInvestment(investment)
        notifyDataChanged()
    }
    suspend fun updateInvestment(investment: Investment) {
        firebaseSync.pushInvestment(investment)
        notifyDataChanged()
    }
    suspend fun deleteInvestment(investment: Investment) {
        dataSafety.recordDeletion("INVESTMENT", investment.investmentId, investment, "Investment: ${investment.itemName}")
        firebaseSync.deleteInvestment(investment.investmentId)
        notifyDataChanged()
    }

    // ---------------- AUDIT TRAIL ----------------
    fun getAuditLogs(shopId: String?, start: Long, end: Long): Flow<List<AuditLog>> {
        val query = firebaseSync.getOwnerRef()?.child("audit_logs")
            ?.orderByChild("timestamp")
            ?.startAt(start.toDouble())
            ?.endAt(end.toDouble() + 999.0)
            ?.limitToLast(1000) // Increase limit for more accurate summary counts

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<AuditLog>(query).map { logs ->
            logs.filter { (shopId.isNullOrEmpty() || it.shopId == shopId) }
                .sortedByDescending { it.timestamp }
        }.flowOn(Dispatchers.Default)
    }

    fun getAuditLogsPaged(shopId: String?, start: Long, end: Long): Flow<androidx.paging.PagingData<AuditLog>> {
        return androidx.paging.Pager(
            config = androidx.paging.PagingConfig(
                pageSize = 50,
                enablePlaceholders = false,
                initialLoadSize = 100
            ),
            pagingSourceFactory = { AuditPagingSource(firebaseSync, shopId, start, end) }
        ).flow
    }

    fun getAuditLogsSummary(shopId: String?, start: Long, end: Long): Flow<List<AuditLog>> {
        val limit = if (shopId.isNullOrEmpty()) 100 else 50 // Even faster for specific shops
        val query = firebaseSync.getOwnerRef()?.child("audit_logs")
            ?.orderByChild("timestamp")
            ?.startAt(start.toDouble())
            ?.endAt(end.toDouble() + 999.0)
            ?.limitToLast(limit)

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<AuditLog>(query).map { logs ->
            logs.filter { (shopId.isNullOrEmpty() || it.shopId == shopId) }
        }.flowOn(Dispatchers.Default)
    }

    fun clearMonthlySnapshot(shopId: String, monthKey: String) {
        firebaseSync.getOwnerRef()?.child("monthly_snapshots")?.child("${shopId}_$monthKey")?.removeValue()
    }

    fun clearSalarySnapshots(employeeId: String) {
        firebaseSync.getOwnerRef()?.child("salary_snapshots")?.orderByChild("employeeId")?.equalTo(employeeId)
            ?.addListenerForSingleValueEvent(object : com.google.firebase.database.ValueEventListener {
                override fun onDataChange(snapshot: com.google.firebase.database.DataSnapshot) {
                    snapshot.children.forEach { it.ref.removeValue() }
                }
                override fun onCancelled(error: com.google.firebase.database.DatabaseError) {}
            })
    }

    // ---------------- RECYCLE BIN ----------------
    fun getRecentRecycleBinItems(limit: Int = 100): Flow<List<RecycleBinItem>> {
        val query = firebaseSync.getOwnerRef()?.child("recycle_bin")
            ?.orderByChild("timestamp")
            ?.limitToLast(limit)

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<RecycleBinItem>(query)
            .map { items -> items.sortedByDescending { it.timestamp } }
            .flowOn(Dispatchers.Default)
    }

    suspend fun logAction(shopId: String?, action: String, module: String, oldVal: String?, newVal: String?) {
        val user = auth.currentUser
        val log = AuditLog(
            shopId = shopId ?: "GLOBAL",
            action = action,
            module = module,
            oldValue = oldVal,
            newValue = newVal,
            userId = user?.uid ?: "unknown",
            userDisplayName = user?.displayName ?: user?.phoneNumber ?: "Admin"
        )
        firebaseSync.pushAuditLog(log)
    }

    suspend fun getFullDayWiseDataFlow(
        shopId: String?,
        start: Long,
        end: Long,
        includeBonus: Boolean = true
    ): Flow<List<DayData>> = withContext(Dispatchers.Default) {
        // SINGLE SOURCE OF TRUTH: Normalize to full day boundaries centrally.
        // This ensures the 31st (and all other days) are fully included, regardless of Picker offset.
        val normStart = Calendar.getInstance().apply {
            timeInMillis = start
            this[Calendar.HOUR_OF_DAY] = 0; this[Calendar.MINUTE] = 0; this[Calendar.SECOND] = 0; this[Calendar.MILLISECOND] = 0
        }.timeInMillis

        val normEnd = Calendar.getInstance().apply {
            timeInMillis = end
            this[Calendar.HOUR_OF_DAY] = 23; this[Calendar.MINUTE] = 59; this[Calendar.SECOND] = 59; this[Calendar.MILLISECOND] = 999
        }.timeInMillis

        val cacheKey = "${shopId ?: "global"}_${normStart}_${normEnd}_$includeBonus"
        dayWiseCache.value[cacheKey]?.let { return@withContext it }

        val buffer = 86400000L // 1-day buffer for boundary intersection

        val dayWiseFlow = combine(
            getCashbookEntriesForPeriod(shopId, normStart, normEnd),
            getShopEmployees(shopId),
            getFixedExpensesForShop(shopId),
            getAttendanceForPeriod(shopId, normStart - buffer, normEnd + buffer),
            allClosedDaysFlow,
            getAdvancesForPeriod(shopId, normStart - buffer, normEnd + buffer),
            allHistoryFlow,
            allShopsFlow
        ) { args: Array<Any?> ->
            // BATCH COMPUTATION: Perform all grouping and derived calculations in parallel
            @Suppress("UNCHECKED_CAST")
            val entries = args[0] as List<Cashbook>
            @Suppress("UNCHECKED_CAST")
            val employees = args[1] as List<Employee>
            @Suppress("UNCHECKED_CAST")
            val fixedExpenses = args[2] as List<FixedExpense>
            @Suppress("UNCHECKED_CAST")
            val allAttendance = args[3] as List<Attendance>
            @Suppress("UNCHECKED_CAST")
            val allClosedDays = args[4] as List<ShopClosedDay>
            @Suppress("UNCHECKED_CAST")
            val allAdvances = args[5] as List<AdvancePayment>
            @Suppress("UNCHECKED_CAST")
            val allHistory = args[6] as List<EmployeeHistory>
            @Suppress("UNCHECKED_CAST")
            val allShops = args[7] as List<Shop>

            // PERFORMANCE: Group by only once here before passing to calculation engine
            val attendanceByEmp = allAttendance.groupBy { it.employeeId }
            val closedByShop = allClosedDays.groupBy { it.shopId }
            val advancesByEmp = allAdvances.groupBy { it.employeeId }
            val historyByEmp = allHistory.groupBy { it.employeeId }
            val shopMap = allShops.associateBy { it.shopId }
            val snapshotsByEmp = allSalarySnapshotsFlow.value.groupBy { it.employeeId }

            calculateDayWiseReport(
                normStart, normEnd, includeBonus,
                entries, employees, fixedExpenses,
                attendanceByEmp, closedByShop, advancesByEmp, historyByEmp,
                shopMap, snapshotsByEmp
            )
        }.flowOn(Dispatchers.Default)
        .shareIn(repositoryScope, SharingStarted.WhileSubscribed(60000), 1)
        .distinctUntilChanged()

        dayWiseCache.value += (cacheKey to dayWiseFlow)
        dayWiseFlow
    }

    suspend fun getFullDayWiseData(shopId: String?, start: Long, end: Long, includeBonus: Boolean = true): List<DayData> =
        getFullDayWiseDataFlow(shopId, start, end, includeBonus).firstOrNull() ?: emptyList()

    suspend fun calculateDayWiseReport(
        start: Long,
        end: Long,
        includeBonus: Boolean,
        entries: List<Cashbook>,
        employees: List<Employee>,
        fixedExpenses: List<FixedExpense>,
        attendanceMap: Map<String, List<Attendance>>,
        closedDaysMap: Map<String, List<ShopClosedDay>>,
        advancesMap: Map<String, List<AdvancePayment>>,
        historyMap: Map<String, List<EmployeeHistory>>,
        shopMap: Map<String, Shop>,
        snapshotsMap: Map<String, List<SalarySnapshot>> = emptyMap()
    ): List<DayData> = withContext(Dispatchers.Default) {
        val daysMap = mutableMapOf<String, DayData>()
        val sdf = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val displayFormat = SimpleDateFormat("dd MMM, EEE", Locale.getDefault())

        val calendar = Calendar.getInstance().apply { timeInMillis = start }

        // SINGLE SOURCE OF TRUTH: Do not cap at 'today'. Calculate for the full requested range
        // so that projections and fixed expenses match the Dashboard perfectly.
        val limitMillis = end

        // OPTIMIZATION: Calculate daily prorated fixed expenses once for the whole range
        val openingDates = shopMap.mapValues { it.value.openingDate }
        val dailyFixed = FinancialCalculator.calculateDailyProratedExpenses(fixedExpenses, start, limitMillis, openingDates)

        while (calendar.timeInMillis <= limitMillis) {
            val key = sdf.format(calendar.time)
            val dayData = DayData(calendar.clone() as Calendar, displayFormat.format(calendar.time))

            // Fast lookup
            val dayStartTs = calendar.clone() as Calendar
            dayStartTs[Calendar.HOUR_OF_DAY] = 0; dayStartTs[Calendar.MINUTE] = 0; dayStartTs[Calendar.SECOND] = 0; dayStartTs[Calendar.MILLISECOND] = 0
            dayData.fixedExpense = dailyFixed[dayStartTs.timeInMillis] ?: 0.0

            daysMap[key] = dayData
            calendar.add(Calendar.DAY_OF_YEAR, 1)
        }

        entries.forEach { entry ->
            val key = sdf.format(Date(entry.transactionDate))
            val dayData = daysMap[key] ?: return@forEach
            if (entry.transactionType == "IN") {
                dayData.totalIn += entry.amount
                if (entry.category.contains("QR", ignoreCase = true)) dayData.qrIn += entry.amount else dayData.cashIn += entry.amount
            } else if (entry.transactionType == "OUT") {
                // ONE SOURCE OF TRUTH: Categories handled by Master/Engine (Salary, Rent, EB, etc)
                // add manual entries to the breakdown but carefully.
                val isSalary = FinancialCategory.isSalary(entry.category, entry.description)
                val isFixedCategory = FinancialCategory.isFixed(entry.category)

                if (isSalary) {
                    if (entry.referenceId == null) {
                        dayData.salaryEarned += entry.amount
                    }
                } else if (isFixedCategory) {
                    dayData.fixedExpense += entry.amount
                } else if (entry.category != "ADVANCE") {
                    dayData.totalOut += entry.amount
                }
            }
        }

        // Determine all unique months touched by the range [start, limitMillis]
        val touchedMonths = mutableListOf<Pair<Long, Long>>()
        val calMonth = Calendar.getInstance().apply { timeInMillis = start }
        while (calMonth.timeInMillis <= limitMillis) {
            val mStart = (calMonth.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val mEnd = (calMonth.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }.timeInMillis
            touchedMonths.add(mStart to mEnd)

            // Move to next month
            calMonth.timeInMillis = mEnd
            calMonth.add(Calendar.MILLISECOND, 1)
        }

        touchedMonths.forEach { (monthStart, monthEnd) ->
            val intersectStart = maxOf(start, monthStart)
            val intersectEnd = minOf(limitMillis, monthEnd)

            employees.forEach { emp ->
                val empAttendance = attendanceMap[emp.employeeId] ?: emptyList()
                val empClosedDays = closedDaysMap[emp.shopId] ?: emptyList()
                val empAdvances = advancesMap[emp.employeeId] ?: emptyList()
                val empHistory = (historyMap[emp.employeeId] ?: emptyList()).sortedBy { it.version }
                val shop = shopMap[emp.shopId]

                val pendingAdvanceAmt = empAdvances.filter {
                    !it.isRecovered && it.date in intersectStart..intersectEnd
                }.sumOf { it.amount }

                // ONE SOURCE OF TRUTH: Always use Live calculation (snapshot = null) to match Star Staff screen
                val (stats, _) = SalaryEngine.calculateStats(
                    employee = emp,
                    monthStart = monthStart,
                    monthEnd = monthEnd,
                    allAttendance = empAttendance,
                    closedDays = empClosedDays,
                    pendingAdvance = pendingAdvanceAmt,
                    history = empHistory,
                    selDayStart = intersectStart,
                    selDayEnd = intersectEnd,
                    rules = shop?.salaryRules ?: SalaryRules(),
                    snapshot = null
                )

                // Distribute rounded daily liability to daysMap for ONLY the intersection of month and requested range
                val allDaysTs = (stats.dayWiseEarnings.keys + stats.dayWiseOTEarnings.keys + stats.dayWiseBonus.keys + stats.dayWisePaidLeave.keys + stats.dayWiseAllowances.keys).distinct()

                allDaysTs.filter { it in intersectStart..intersectEnd }.forEach { ts ->
                    val key = sdf.format(Date(ts))
                    val dayData = daysMap[key] ?: return@forEach

                    val work = stats.dayWiseEarnings[ts] ?: BigDecimal.ZERO
                    val ot = stats.dayWiseOTEarnings[ts] ?: BigDecimal.ZERO
                    val allowance = stats.dayWiseAllowances[ts] ?: BigDecimal.ZERO
                    val bonus = if (includeBonus) stats.dayWiseBonus[ts] ?: BigDecimal.ZERO else BigDecimal.ZERO
                    val pl = stats.dayWisePaidLeave[ts] ?: BigDecimal.ZERO

                    val dailyLiability = work.add(ot).add(bonus).add(pl).setScale(0, RoundingMode.HALF_UP).add(allowance)
                    dayData.salaryEarned += dailyLiability.toDouble()
                }
            }
        }

        daysMap.values.sortedByDescending { it.calendar.timeInMillis }
    }


    // ---------------- INVENTORY ----------------
    fun getShopInventory(shopId: String): Flow<List<InventoryItem>> = getInventoryItems(shopId)

    fun getInventoryItems(shopId: String): Flow<List<InventoryItem>> {
        val query = firebaseSync.getOwnerRef()?.child("inventory")
            ?.orderByChild("shopId")
            ?.equalTo(shopId)

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<InventoryItem>(query)
            .map { items -> items.sortedBy { it.name } }
            .flowOn(Dispatchers.Default)
    }

    suspend fun insertInventoryItem(item: InventoryItem) {
        item.name = StringUtil.toTitleCase(item.name)
        firebaseSync.pushInventoryItem(item)
        notifyDataChanged()
    }

    suspend fun pushStockAudit(audit: StockAudit) {
        firebaseSync.pushStockAudit(audit)

        // Dynamic Requirement: Record this action in the Audit Trail
        logAction(audit.shopId, "AUDIT", "INVENTORY", null, "Variance: ₹${audit.totalVariance}")
        notifyDataChanged()
    }

    fun getPriceHistory(shopId: String, itemName: String): Flow<List<PriceHistory>> {
        // Optimization: Filter by itemName server-side (likely faster than shopId for popular items)
        // OR better: use limit to only get recent history
        val query = firebaseSync.getOwnerRef()?.child("price_history")
            ?.orderByChild("itemName")
            ?.equalTo(itemName.uppercase().trim())

        return if (query == null) flowOf(emptyList())
        else firebaseSync.getQueryFlow<PriceHistory>(query)
            .map { history ->
                history.asSequence()
                    .filter { it.shopId == shopId }
                    .sortedByDescending { it.date }
                    .toList()
            }
            .flowOn(Dispatchers.Default)
    }

    suspend fun deletePriceHistoryByReference(referenceId: String) = firebaseSync.deletePriceHistoryByReference(referenceId)

    fun startSync() {
        firebaseSync.startSync()
    }
}
