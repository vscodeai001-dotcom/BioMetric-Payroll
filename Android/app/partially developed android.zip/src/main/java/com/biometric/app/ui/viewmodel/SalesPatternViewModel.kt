package com.biometric.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.R
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class DayPattern(
    val dayName: String,
    val dayOfWeek: Int, // Calendar.MONDAY etc.
    var totalSales: Double = 0.0,
    var occurrenceCount: Int = 0,
    var averageSales: Double = 0.0,
    var maxSalesValue: Double = 0.0,
    var maxSalesDate: String = "",
    var minSalesValue: Double = Double.MAX_VALUE,
    var minSalesDate: String = "",
    var indicator: String = "Average" // Low, Below Average, Average, High, Very High
)

data class SalesPatternState(
    val periodLabel: String = "",
    val fromToLabel: String = "",
    val currentAvg: Double = 0.0,
    val previousAvg: Double = 0.0,
    val avgChangePercent: Double = 0.0,
    val totalSales: Double = 0.0,
    val totalChangeAmount: Double = 0.0,
    val patterns: List<DayPattern> = emptyList(),
    val veryHighDays: List<DayPattern> = emptyList(),
    val highDays: List<DayPattern> = emptyList(),
    val averageDays: List<DayPattern> = emptyList(),
    val belowAverageDays: List<DayPattern> = emptyList(),
    val lowDays: List<DayPattern> = emptyList(),
    val insights: List<String> = emptyList(),
    val isLoading: Boolean = false
)

@HiltViewModel
class SalesPatternViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<SalesPatternState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        // ... (existing range logic)
        val normalizedPeriod = period.lowercase().replace("-", " ").trim()
        val isUptoDate = normalizedPeriod == "up to date"
        val useMatching = isUptoDate || normalizedPeriod == "day" || normalizedPeriod == "daily"

        val currentRange = DateRangeUtil.getRangeForPeriod(period, date, isMatchingDays = useMatching)
        val start = currentRange.first
        val end = currentRange.second

        val p1Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -1); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p2Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -2); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p3Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -3); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }

        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val fromToLabel = "${sdf.format(Date(start))} → ${sdf.format(Date(end))}"

        val dynamicTitle = when (period.lowercase().trim()) {
            "weekly", "week" -> "Weekly Sales Pattern"
            "monthly", "month", "up to date" -> "Monthly Sales Pattern"
            "quarterly", "quarter" -> "Quarterly Sales Pattern"
            "half yearly", "half year" -> "Half-Yearly Sales Pattern"
            "annually", "annual" -> "Yearly Sales Pattern"
            "daily", "day" -> "Daily Sales Pattern"
            else -> "Sales Pattern Analysis"
        }

        val cacheKey = "sales_pattern_${shopId}_${period}_${start}_${end}"
        val cached = repository.getListCache<SalesPatternState>(cacheKey).firstOrNull()

        // PERFORMANCE FIX: emit loading state immediately
        flow {
            // UNIFORM LOADING: Only set loading true if no cache available
            emit((cached ?: SalesPatternState()).copy(isLoading = cached == null, periodLabel = dynamicTitle, fromToLabel = fromToLabel))

            emitAll(combine(
                repository.getCashbookEntriesForPeriod(shopId, start, end),
                repository.getCashbookEntriesForPeriod(shopId, p1Range.first, p1Range.second),
                repository.getCashbookEntriesForPeriod(shopId, p2Range.first, p2Range.second),
                repository.getCashbookEntriesForPeriod(shopId, p3Range.first, p3Range.second)
            ) { currentAll, p1All, p2All, p3All ->
                // ... (existing mapping logic)
                kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.Default) {
                    val currentEntries = currentAll.filter { it.transactionType == "IN" }
                    val currentPatterns = calculatePatterns(currentEntries, start, end)
                    val totalSales = currentEntries.sumOf { it.amount }
                    val currentAvg = totalSales / currentPatterns.sumOf { it.occurrenceCount }.toDouble().coerceAtLeast(1.0)

                    // Calculate 3-period average baseline
                    val p1Sales = p1All.filter { it.transactionType == "IN" }.sumOf { it.amount }
                    val p2Sales = p2All.filter { it.transactionType == "IN" }.sumOf { it.amount }
                    val p3Sales = p3All.filter { it.transactionType == "IN" }.sumOf { it.amount }
                    
                    val p1Patterns = calculatePatterns(p1All.filter { it.transactionType == "IN" }, p1Range.first, p1Range.second)
                    val p2Patterns = calculatePatterns(p2All.filter { it.transactionType == "IN" }, p2Range.first, p2Range.second)
                    val p3Patterns = calculatePatterns(p3All.filter { it.transactionType == "IN" }, p3Range.first, p3Range.second)
                    
                    val p1Avg = p1Sales / p1Patterns.sumOf { it.occurrenceCount }.toDouble().coerceAtLeast(1.0)
                    val p2Avg = p2Sales / p2Patterns.sumOf { it.occurrenceCount }.toDouble().coerceAtLeast(1.0)
                    val p3Avg = p3Sales / p3Patterns.sumOf { it.occurrenceCount }.toDouble().coerceAtLeast(1.0)
                    
                    val baselineAvg = (p1Avg + p2Avg + p3Avg) / 3.0
                    val baselineTotal = (p1Sales + p2Sales + p3Sales) / 3.0

                    val avgChange = if (baselineAvg > 0) ((currentAvg - baselineAvg) / baselineAvg) * 100 else 0.0
                    
                    val sortedByAvg = currentPatterns.sortedByDescending { it.averageSales }
                    val veryHighDaysList = sortedByAvg.take(1)
                    val highDaysList = sortedByAvg.drop(1).take(1)
                    val averageDaysList = sortedByAvg.drop(2).take(2)
                    val belowAverageDaysList = sortedByAvg.drop(4).take(2)
                    val lowDaysList = sortedByAvg.drop(6).take(1)

                    val resources = getApplication<Application>().resources
                    currentPatterns.forEach { p ->
                        when {
                            veryHighDaysList.any { it.dayOfWeek == p.dayOfWeek } -> p.indicator = resources.getString(R.string.indicator_very_high)
                            highDaysList.any { it.dayOfWeek == p.dayOfWeek } -> p.indicator = resources.getString(R.string.indicator_high)
                            averageDaysList.any { it.dayOfWeek == p.dayOfWeek } -> p.indicator = resources.getString(R.string.indicator_average)
                            belowAverageDaysList.any { it.dayOfWeek == p.dayOfWeek } -> p.indicator = resources.getString(R.string.indicator_below_average)
                            lowDaysList.any { it.dayOfWeek == p.dayOfWeek } -> p.indicator = resources.getString(R.string.indicator_low)
                        }
                    }

                    val result = SalesPatternState(
                        periodLabel = dynamicTitle,
                        fromToLabel = fromToLabel,
                        currentAvg = currentAvg,
                        previousAvg = baselineAvg,
                        avgChangePercent = avgChange,
                        totalSales = totalSales,
                        totalChangeAmount = totalSales - baselineTotal,
                        patterns = currentPatterns,
                        veryHighDays = veryHighDaysList,
                        highDays = highDaysList,
                        averageDays = averageDaysList,
                        belowAverageDays = belowAverageDaysList,
                        lowDays = lowDaysList,
                        insights = generateInsights(totalSales, baselineTotal, veryHighDaysList.firstOrNull(), lowDaysList, currentPatterns),
                        isLoading = false
                    )
                    repository.saveListCache(cacheKey, listOf(result))
                    result
                }
            })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), SalesPatternState(isLoading = true))

    fun loadAnalysis(shopId: String, period: String, date: Long) {
        viewModelScope.launch {
            try { repository.logAction(shopId, "VIEW", "Reports", "Sales Patterns", period) } catch (_: Exception) {}
            _params.value = Triple(shopId, period, date)
        }
    }

    private fun calculatePatterns(entries: List<Cashbook>, start: Long, end: Long): List<DayPattern> {
        val daysMap = mutableMapOf<Int, DayPattern>()
        val dayNames = arrayOf("", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday")
        for (i in 1..7) daysMap[i] = DayPattern(dayNames[i], i)

        val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
        val displayDateFormat = SimpleDateFormat("dd MMM", Locale.getDefault())
        val salesByDate = entries.groupBy { dateFormat.format(Date(it.transactionDate)) }
            .mapValues { it.value.sumOf { entry -> entry.amount } }

        val startCal = Calendar.getInstance().apply { timeInMillis = start; set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }
        val endCal = Calendar.getInstance().apply { timeInMillis = end; set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }

        val tempCal = Calendar.getInstance()
        tempCal.timeInMillis = startCal.timeInMillis
        while (tempCal.timeInMillis <= endCal.timeInMillis) {
            val dayOfWeek = tempCal.get(Calendar.DAY_OF_WEEK)
            val dateStr = dateFormat.format(tempCal.time)
            val dailyTotal = salesByDate[dateStr] ?: 0.0
            
            daysMap[dayOfWeek]?.let { pattern ->
                pattern.totalSales += dailyTotal
                pattern.occurrenceCount++
                
                if (dailyTotal >= pattern.maxSalesValue) {
                    pattern.maxSalesValue = dailyTotal
                    pattern.maxSalesDate = displayDateFormat.format(tempCal.time)
                }
                
                if (dailyTotal <= pattern.minSalesValue) {
                    pattern.minSalesValue = dailyTotal
                    pattern.minSalesDate = displayDateFormat.format(tempCal.time)
                }
            }
            tempCal.add(Calendar.DAY_OF_YEAR, 1)
        }

        val allPatterns = daysMap.values.toList().sortedBy { if (it.dayOfWeek == Calendar.SUNDAY) 8 else it.dayOfWeek }
        allPatterns.forEach { 
            if (it.occurrenceCount > 0) {
                it.averageSales = it.totalSales / it.occurrenceCount
                if (it.minSalesValue == Double.MAX_VALUE) it.minSalesValue = 0.0
            } else {
                it.minSalesValue = 0.0
            }
        }
        return allPatterns
    }

    private fun generateInsights(total: Double, prevTotal: Double, best: DayPattern?, weakDays: List<DayPattern>, allPatterns: List<DayPattern>): List<String> {
        val resources = getApplication<Application>().resources
        val insights = mutableListOf<String>()
        val trendIcon = if (total >= prevTotal) "📈" else "📉"
        val diff = kotlin.math.abs(total - prevTotal)
        
        val trendMsg = if (total >= prevTotal) {
            resources.getString(R.string.insight_trend_increasing, trendIcon, diff)
        } else {
            resources.getString(R.string.insight_trend_decreasing, trendIcon, diff)
        }
        insights.add(trendMsg)
        
        best?.let { 
            insights.add(resources.getString(R.string.insight_strongest_day, it.dayName, it.averageSales))
            if (it.maxSalesValue > 0) {
                insights.add(resources.getString(R.string.insight_peak_performance, it.maxSalesValue, it.maxSalesDate))
            }
        }
        
        if (weakDays.isNotEmpty()) {
            val weakest = weakDays.lastOrNull()
            weakest?.let {
                if (it.minSalesValue < it.averageSales) {
                    insights.add(resources.getString(R.string.insight_weakest_consistency, it.dayName, it.minSalesValue, it.minSalesDate))
                }
            }
        }

        // Compare weekends vs weekdays
        val weekends = allPatterns.filter { it.dayOfWeek == Calendar.SATURDAY || it.dayOfWeek == Calendar.SUNDAY }
        val weekdays = allPatterns.filter { it.dayOfWeek != Calendar.SATURDAY && it.dayOfWeek != Calendar.SUNDAY }
        
        val weekendAvg = if (weekends.isNotEmpty()) weekends.sumOf { it.averageSales } / weekends.size else 0.0
        val weekdayAvg = if (weekdays.isNotEmpty()) weekdays.sumOf { it.averageSales } / weekdays.size else 0.0
        
        if (weekdayAvg > 0 && weekendAvg > weekdayAvg * 1.05) {
            val percent = ((weekendAvg - weekdayAvg) / weekdayAvg) * 100
            insights.add(resources.getString(R.string.insight_weekend_outperform, percent))
        } else if (weekendAvg > 0 && weekdayAvg > weekendAvg * 1.05) {
            val percent = ((weekdayAvg - weekendAvg) / weekendAvg) * 100
            insights.add(resources.getString(R.string.insight_weekday_outperform, percent))
        }

        return insights
    }
}
