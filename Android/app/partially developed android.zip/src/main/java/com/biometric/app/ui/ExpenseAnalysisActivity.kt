package com.biometric.app.ui

import android.app.DatePickerDialog
import android.graphics.Color
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.PercentFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityExpenseAnalysisBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.ui.viewmodel.ExpenseAnalysisViewModel
import com.biometric.app.ui.viewmodel.ExpenseCategoryItem
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class ExpenseAnalysisActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityExpenseAnalysisBinding
    private val viewModel: ExpenseAnalysisViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel

    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Monthly"
    private var shopId: String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityExpenseAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: "Expense Analysis"

        setupToolbar(shopName)
        setupUI()
        setupCharts()
        observeViewModel()

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Expense Analysis")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        binding.btnDateFilter.setOnClickListener {
            DatePickerDialog(
                this, { _, year, month, day ->
                    selectedDate.set(year, month, day)
                    refreshData()
                },
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        binding.btnFilterType.setOnClickListener {
            val items = arrayOf("Daily", "Up To Date", "Weekly", "Monthly", "Quarterly", "Half Yearly", "Annually")
            MaterialAlertDialogBuilder(this)
                .setTitle("Select Period")
                .setItems(items) { _, which ->
                    currentFilter = items[which]
                    refreshData()
                }
                .show()
        }

        binding.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.btnNextDate.setOnClickListener { adjustDate(1) }
    }

    private fun adjustDate(amount: Int) {
        when (currentFilter) {
            "Daily", "Up To Date" -> selectedDate.add(Calendar.DAY_OF_MONTH, amount)
            "Weekly" -> selectedDate.add(Calendar.WEEK_OF_YEAR, amount)
            "Monthly" -> selectedDate.add(Calendar.MONTH, amount)
            "Quarterly" -> selectedDate.add(Calendar.MONTH, amount * 3)
            "Half Yearly" -> selectedDate.add(Calendar.MONTH, amount * 6)
            "Annually" -> selectedDate.add(Calendar.YEAR, amount)
        }
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadAnalysis(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.btnDateFilter.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        binding.btnFilterType.text = currentFilter
    }

    private fun setupCharts() {
        // Pie Chart
        ChartStyleManager.applyChartStyle(binding.pieChartExpenses, this)
        binding.pieChartExpenses.apply {
            setUsePercentValues(true)
            setExtraOffsets(5f, 10f, 5f, 5f)
            dragDecelerationFrictionCoef = 0.95f
            isDrawHoleEnabled = true
            holeRadius = 58f
            transparentCircleRadius = 61f
            setDrawCenterText(true)
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            setEntryLabelTextSize(10f)
        }

        // Bar Chart
        ChartStyleManager.applyChartStyle(binding.barChartExpenses, this)
        binding.barChartExpenses.apply {
            setDrawBarShadow(false)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            updateToolbarTitle(it.name)
                            refreshData()
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // Strict Anti-Flicker Logic
                        val isDataZero = state.categories.isEmpty() && state.totalExpense == 0.0
                        if (state.isLoading && isDataZero) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope)
                            binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                        
                        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
                        binding.tvTotalExpense.text = currencyFormat.format(state.totalExpense)

                        if (state.categories.isNotEmpty()) {
                            updateTable(state.categories)
                            updateCharts(state.categories)
                            updateInsights(state.insights)
                        } else {
                            val childCount = binding.tableExpenses.childCount
                            if (childCount > 2) {
                                binding.tableExpenses.removeViews(2, childCount - 2)
                            }
                            binding.pieChartExpenses.clear()
                            binding.barChartExpenses.clear()
                            binding.llInsights.removeAllViews()
                        }
                    }
                }
            }
        }
    }

    private fun updateTable(items: List<ExpenseCategoryItem>) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        
        // Keep header and divider
        val childCount = binding.tableExpenses.childCount
        if (childCount > 2) {
            binding.tableExpenses.removeViews(2, childCount - 2)
        }

        items.forEach { item ->
            val row = TableRow(this).apply {
                setPadding(0, 12, 0, 12)
            }

            val tvCategory = TextView(this).apply {
                text = item.category
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                textSize = 14f
            }

            val tvAmount = TextView(this).apply {
                text = currencyFormat.format(item.amount)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT)
                textSize = 14f
            }

            val tvPercent = TextView(this).apply {
                text = String.format(Locale.getDefault(), "%.1f%%", item.percentage)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.WRAP_CONTENT, TableRow.LayoutParams.WRAP_CONTENT)
                setPadding(16, 0, 0, 0)
                textSize = 12f
                setTextColor(ContextCompat.getColor(this@ExpenseAnalysisActivity, R.color.text_secondary))
            }

            row.addView(tvCategory)
            row.addView(tvAmount)
            row.addView(tvPercent)
            binding.tableExpenses.addView(row)
        }
    }

    private fun updateCharts(items: List<ExpenseCategoryItem>) {
        val colors = listOf(
            "#4F46E5".toColorInt(), "#10B981".toColorInt(), 
            "#F59E0B".toColorInt(), "#EF4444".toColorInt(),
            "#8B5CF6".toColorInt(), "#EC4899".toColorInt(),
            "#06B6D4".toColorInt(), "#71717A".toColorInt()
        )

        // Pie Chart
        val pieEntries = items.map { PieEntry(it.amount.toFloat(), it.category) }
        val pieDataSet = PieDataSet(pieEntries, "").apply {
            this.colors = colors
            sliceSpace = 3f
            selectionShift = 5f
            valueLinePart1OffsetPercentage = 80f
            valueLinePart1Length = 0.2f
            valueLinePart2Length = 0.4f
            yValuePosition = PieDataSet.ValuePosition.OUTSIDE_SLICE
        }
        val pieData = PieData(pieDataSet).apply {
            setValueFormatter(PercentFormatter(binding.pieChartExpenses))
            setValueTextSize(11f)
            setValueTextColor(ContextCompat.getColor(this@ExpenseAnalysisActivity, R.color.text_primary))
        }
        binding.pieChartExpenses.data = pieData
        binding.pieChartExpenses.invalidate()

        // Bar Chart
        val barEntries = items.take(5).mapIndexed { index, item ->
            BarEntry(index.toFloat(), item.amount.toFloat())
        }
        val barDataSet = BarDataSet(barEntries, "Amount").apply {
            this.colors = colors.take(items.size)
            valueTextSize = 10f
            valueFormatter = object : com.github.mikephil.charting.formatter.ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "₹" + value.toInt().toString()
                }
            }
        }
        binding.barChartExpenses.apply {
            xAxis.valueFormatter = IndexAxisValueFormatter(items.take(5).map { 
                if (it.category.length > 8) it.category.take(6) + ".." else it.category 
            })
            data = BarData(barDataSet)
            animateY(1000)
            invalidate()
        }
    }

    private fun updateInsights(insights: List<String>) {
        binding.llInsights.removeAllViews()
        insights.forEach { text ->
            val textView = TextView(this).apply {
                this.text = text
                setPadding(0, 12, 0, 12)
                textSize = 14f
                setTextColor(ContextCompat.getColor(this@ExpenseAnalysisActivity, R.color.text_primary))
            }
            binding.llInsights.addView(textView)
        }
    }
}