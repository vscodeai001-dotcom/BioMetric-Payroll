package com.biometric.app.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "location_tracks")
data class LocationTrack(
    @PrimaryKey(autoGenerate = true)
    val locationId: Long = 0,
    val staffId: String,
    val timestamp: Long,
    val latitude: Double,
    val longitude: Double,
    val accuracy: Float,
    val speed: Float,
    val batteryLevel: Int,
    val isSynced: Boolean = false
)
