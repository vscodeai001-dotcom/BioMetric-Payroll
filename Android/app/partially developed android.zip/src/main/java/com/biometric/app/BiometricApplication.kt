package com.biometric.app

import android.app.Application
import android.util.Log
import androidx.appcompat.app.AppCompatDelegate
import androidx.work.Configuration
import androidx.hilt.work.HiltWorkerFactory
import androidx.work.Constraints
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.NetworkType
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import com.google.firebase.FirebaseApp
import com.google.firebase.database.FirebaseDatabase
import com.biometric.app.data.MainRepository
import com.biometric.app.domain.location.LocationSyncManager
import dagger.hilt.android.HiltAndroidApp
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@HiltAndroidApp
class BiometricApplication : Application(), Configuration.Provider {

    @Inject lateinit var workerFactory: HiltWorkerFactory
    @Inject lateinit var locationSyncManager: LocationSyncManager

    override val workManagerConfiguration: Configuration
        get() = Configuration.Builder()
            .setWorkerFactory(workerFactory)
            .build()

    override fun onCreate() {
        // 1. Enable persistence safely
        try {
            val database = FirebaseDatabase.getInstance()
            database.setPersistenceEnabled(true)
        } catch (e: Exception) {
            Log.e("BiometricApplication", "Firebase Persistence init failed", e)
        }

        super.onCreate()

        com.biometric.app.util.ThemeManager.applyTheme(this)
        
        // 2. Schedule Periodic Backup (Every 2 Hours) - Use REPLACE to ensure latest logic is active
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .build()

        val request = PeriodicWorkRequestBuilder<com.biometric.app.backup.BackupWorker>(2, TimeUnit.HOURS)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "automated_business_backup_periodic",
            ExistingPeriodicWorkPolicy.REPLACE,
            request
        )

        // 3. Schedule Location Sync
        locationSyncManager.schedulePeriodicSync()

        // 4. Initial sync will be managed by the repository/viewmodels
    }
}
