package com.biometric.app.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.widget.addTextChangedListener
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.MainRepository
import com.biometric.app.data.OrderWithItems
import com.biometric.app.databinding.ActivityDailyBillsBinding
import com.biometric.app.databinding.ItemDailyBillRowBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import javax.inject.Inject

@AndroidEntryPoint
class DailyBillsActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityDailyBillsBinding
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    
    private var shopId: String? = null
    private var allBills: List<OrderWithItems> = emptyList()

    @Inject
    lateinit var repository: MainRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDailyBillsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fix Task bar overlap - Same as StaffActivity
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        shopId = intent.getStringExtra("SHOP_ID")
        val shopName = intent.getStringExtra("SHOP_NAME") ?: "Bills"
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(shopName)

        binding.rvBills.layoutManager = LinearLayoutManager(this)
        
        binding.etSearch.addTextChangedListener { text ->
            filterBills(text?.toString() ?: "")
        }

        observeViewModel()
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Daily Bills")
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    mainViewModel.isLoading.collectLatest { loading ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = allBills.isEmpty()
                        if (loading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.POS, lifecycleScope)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                    }
                }
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            updateToolbarTitle(it.name)
                            loadBills()
                        }
                    }
                }
            }
        }
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                sharedViewModel.setSelectedShop(selectedShop)
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun loadBills() {
        val sId = shopId ?: return
        
        lifecycleScope.launch {
            val todayStart = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            
            val todayEnd = Calendar.getInstance().apply {
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            }.timeInMillis

            repository.getOrdersWithItemsForPeriod(sId, todayStart, todayEnd).collectLatest { ordersWithItems ->
                allBills = ordersWithItems
                filterBills(binding.etSearch.text.toString())
            }
        }
    }

    private fun filterBills(query: String) {
        val filtered = if (query.isBlank()) {
            allBills
        } else {
            allBills.filter { 
                it.order.orderId.contains(query, ignoreCase = true) || 
                it.order.serviceType.contains(query, ignoreCase = true) ||
                "Table ${it.order.tableId}".contains(query, ignoreCase = true)
            }
        }
        binding.rvBills.adapter = BillsAdapter(filtered)
    }
    
    class BillsAdapter(private val bills: List<OrderWithItems>) : RecyclerView.Adapter<BillsAdapter.ViewHolder>() {
        class ViewHolder(val binding: ItemDailyBillRowBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemDailyBillRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val context = holder.itemView.context
            val bill = bills[position].order
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())

            holder.binding.tvBillId.text = context.getString(R.string.bill_id_format, bill.orderId.takeLast(4))
            holder.binding.tvTime.text = bill.closedAt?.let { timeFormat.format(Date(it)) } ?: "-"
            holder.binding.tvAmount.text = String.format(Locale.getDefault(), "₹ %.2f", bill.totalAmount)
            holder.binding.tvType.text = if (bill.serviceType == "TABLE") "Table ${bill.tableId}" else bill.serviceType

            holder.itemView.setOnClickListener {
                val fullDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                val closedTime = bill.closedAt?.let { fullDateFormat.format(Date(it)) } ?: "N/A"
                val createdTime = fullDateFormat.format(Date(bill.createdAt))
                
                MaterialAlertDialogBuilder(holder.itemView.context)
                    .setTitle("Bill Details 📋")
                    .setMessage("Bill ID: #${bill.orderId.takeLast(6)}\n" +
                            "Logical Close Time: $closedTime\n" +
                            "**Actual Recorded Time: $createdTime**\n\n" +
                            "Amount: ₹${bill.totalAmount}\n" +
                            "Type: ${holder.binding.tvType.text}")
                    .setPositiveButton("OK", null)
                    .show()
            }
        }

        override fun getItemCount() = bills.size
    }
}