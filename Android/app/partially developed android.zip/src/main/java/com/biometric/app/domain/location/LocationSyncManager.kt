package com.biometric.app.domain.location

import android.content.Context
import android.util.Log
import androidx.hilt.work.HiltWorker
import androidx.work.*
import com.biometric.app.data.dao.LocationDao
import com.biometric.app.data.entity.LocationTrack
import com.google.firebase.firestore.FirebaseFirestore
import dagger.assisted.Assisted
import dagger.assisted.AssistedInject
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class LocationSyncManager @Inject constructor(
    @ApplicationContext private val context: Context,
    private val locationDao: LocationDao
) {

    private val firestore = FirebaseFirestore.getInstance()

    fun schedulePeriodicSync() {
        val constraints = Constraints.Builder()
            .setRequiredNetworkType(NetworkType.CONNECTED)
            .setRequiresBatteryNotLow(true)
            .build()

        val syncRequest = PeriodicWorkRequestBuilder<LocationSyncWorker>(15, TimeUnit.MINUTES)
            .setConstraints(constraints)
            .build()

        WorkManager.getInstance(context).enqueueUniquePeriodicWork(
            "LocationSyncWork",
            ExistingPeriodicWorkPolicy.KEEP,
            syncRequest
        )
    }

    suspend fun syncNow() {
        val unsyncedTracks = locationDao.getUnsyncedTracksSync(100)
        if (unsyncedTracks.isEmpty()) return

        try {
            val batch = firestore.batch()
            unsyncedTracks.forEach { track ->
                val docRef = firestore.collection("location_tracking")
                    .document("${track.staffId}_${track.timestamp}")
                batch.set(docRef, track)
            }
            batch.commit().await()

            val ids = unsyncedTracks.map { it.locationId }.toTypedArray()
            locationDao.markAsSynced(ids)
            Log.d("LocationSyncManager", "Synced ${unsyncedTracks.size} tracks to Firestore")
        } catch (e: Exception) {
            Log.e("LocationSyncManager", "Sync failed", e)
        }
    }
}

@HiltWorker
class LocationSyncWorker @AssistedInject constructor(
    @Assisted context: Context,
    @Assisted params: WorkerParameters,
    private val locationSyncManager: LocationSyncManager
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        locationSyncManager.syncNow()
        return Result.success()
    }
}
