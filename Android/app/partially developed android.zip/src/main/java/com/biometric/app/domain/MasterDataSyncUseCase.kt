package com.biometric.app.domain

import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.DescriptionMaster
import com.biometric.app.data.entity.ExpenseCategory
import com.biometric.app.data.FinancialCategory
import kotlinx.coroutines.flow.first
import javax.inject.Inject

/**
 * UseCase responsible for ensuring that the local database has the necessary master data
 * and synchronizing it with the cloud.
 *
 * This includes:
 * 1. Seeding default expense categories if they don't exist.
 * 2. Backfilling the description master (auto-suggestions) from historical cashbook entries.
 */
class MasterDataSyncUseCase @Inject constructor(
    private val repository: MainRepository
) {
    /**
     * Synchronizes and seeds master data for a specific shop.
     *
     * @param shopId The unique identifier for the shop. If null, global data might be affected.
     */
    suspend fun syncMasterData(shopId: String? = null) {
        // 1. Seed Default Categories if empty (Global categories)
        val existingCats = repository.getExpenseCategories(shopId).first()
        if (existingCats.isEmpty()) {
            val defaults = listOf(
                ExpenseCategory(name = FinancialCategory.PURCHASE, emoji = "🛒", isFixed = false, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.EXPENSE, emoji = "📉", isFixed = false, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.EB_GAS, emoji = "💡", isFixed = true, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.RENT, emoji = "🏠", isFixed = true, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.MAINTENANCE, emoji = "🔧", isFixed = true, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.SALARY, emoji = "🧑‍💼", isFixed = false, shopId = shopId),
                ExpenseCategory(name = FinancialCategory.ADVANCE, emoji = "💸", isFixed = false, shopId = shopId)
            )
            defaults.forEach { repository.insertExpenseCategory(it) }
        }

        // 2. Backfill Descriptions from Cashbook
        val cashbookEntries = repository.getCashbookEntriesForPeriod(shopId, 0, Long.MAX_VALUE).first()
        val existingMasters = repository.getDescriptionMaster(shopId).first().map { it.name.trim().uppercase() }.toSet()
        
        val uniqueDescriptions = cashbookEntries.asSequence()
            .mapNotNull { it.description?.trim() }
            .filter { it.isNotBlank() }
            .groupBy { it.uppercase() }
            .map { (_, group) -> group.first() } // Keep original casing of the first occurrence
            .filter { !existingMasters.contains(it.uppercase()) }
            .toList()

        uniqueDescriptions.forEach { desc ->
            repository.firebaseSync.pushDescriptionMaster(DescriptionMaster(name = desc, shopId = shopId))
        }
    }
}
