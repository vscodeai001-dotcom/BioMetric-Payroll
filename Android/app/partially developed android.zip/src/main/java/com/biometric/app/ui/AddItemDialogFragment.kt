package com.biometric.app.ui

import android.app.Dialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.activityViewModels
import androidx.lifecycle.lifecycleScope
import com.biometric.app.databinding.DialogAddItemBinding
import com.biometric.app.ui.viewmodel.ItemMasterViewModel
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.KeyboardUtil
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds

class AddItemDialogFragment : DialogFragment() {

    private var _binding: DialogAddItemBinding? = null
    private val binding get() = _binding!!

    private val viewModel: ItemMasterViewModel by activityViewModels()
    private var itemId: String? = null

    companion object {
        const val TAG = "AddItemDialog"
        private const val ARG_ITEM_ID = "itemId"

        fun newInstance(itemId: String? = null): AddItemDialogFragment {
            val args = Bundle().apply {
                putString(ARG_ITEM_ID, itemId)
            }
            return AddItemDialogFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        itemId = arguments?.getString(ARG_ITEM_ID)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAddItemBinding.inflate(layoutInflater)

        if (itemId != null) {
            viewModel.loadItem(itemId!!)
            lifecycleScope.launch {
                viewModel.selectedItem.collectLatest {
                    if (it != null) {
                        binding.etItemName.setText(it.name)
                        binding.etCategory.setText(it.category)
                        binding.cbHasParcelCharge.isChecked = it.hasParcelCharge
                        binding.etParcelAmount.setText(it.defaultParcelCharge.toString())
                    }
                }
            }
        }

        binding.cbHasParcelCharge.setOnCheckedChangeListener { _, isChecked ->
            binding.tilParcelAmount.visibility = if (isChecked) View.VISIBLE else View.GONE
        }

        setupAutoFocus()

        return AlertDialog.Builder(requireActivity())
            .setTitle(if (itemId == null) "Add Global Item" else "Edit Item")
            .setView(binding.root)
            .setPositiveButton("Save") { _, _ ->
                val name = binding.etItemName.text.toString()
                val cat = binding.etCategory.text.toString()
                val hasParcel = binding.cbHasParcelCharge.isChecked
                val pAmt = binding.etParcelAmount.text.toString().toDoubleOrNull() ?: 0.0

                if (name.isNotEmpty()) {
                    HapticUtil.vibrateSuccess(binding.root)
                    if (itemId == null) {
                        viewModel.addItemWithParcel(name, if (cat.isEmpty()) "General" else cat, hasParcel, pAmt)
                    } else {
                        viewModel.selectedItem.value?.let {
                            viewModel.updateItem(it, name, if (cat.isEmpty()) "General" else cat, hasParcel, pAmt)
                        }
                    }
                    KeyboardUtil.hideKeyboard(requireActivity())
                    
                    // ZERO-FOCUS
                    binding.etItemName.clearFocus()
                    binding.etCategory.clearFocus()
                    binding.etParcelAmount.clearFocus()
                    binding.root.requestFocus()
                }
            }
            .setNegativeButton("Cancel", null)
            .create()
    }

    private var autoFocusJob: kotlinx.coroutines.Job? = null

    private fun setupAutoFocus() {
        binding.etItemName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (binding.etItemName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        delay(1500.milliseconds)
                        KeyboardUtil.showKeyboard(binding.etCategory)
                    }
                }
            }
        })

        binding.etCategory.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (binding.etCategory.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        delay(1500.milliseconds)
                        if (binding.cbHasParcelCharge.isChecked) {
                            KeyboardUtil.showKeyboard(binding.etParcelAmount)
                        } else {
                            KeyboardUtil.hideKeyboard(binding.etCategory)
                        }
                    }
                }
            }
        })
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
