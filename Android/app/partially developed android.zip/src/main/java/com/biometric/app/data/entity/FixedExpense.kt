package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.IgnoreExtraProperties
import com.google.firebase.database.PropertyName

@Keep
@IgnoreExtraProperties
data class FixedExpense(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = "",

    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",

    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",

    @get:PropertyName("monthlyAmount") @set:PropertyName("monthlyAmount")
    var monthlyAmount: Double = 0.0,

    @get:PropertyName("effectiveFrom") @set:PropertyName("effectiveFrom")
    var effectiveFrom: Long = System.currentTimeMillis(),

    @get:PropertyName("isArchived") @set:PropertyName("isArchived")
    var isArchived: Boolean = false,

    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis()
)
