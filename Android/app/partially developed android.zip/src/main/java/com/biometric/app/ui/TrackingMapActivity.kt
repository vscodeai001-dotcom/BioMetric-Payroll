package com.biometric.app.ui

import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.biometric.app.R
import com.biometric.app.data.entity.LocationTrack
import com.biometric.app.databinding.ActivityTrackingMapBinding
import com.google.android.gms.maps.CameraUpdateFactory
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.BitmapDescriptorFactory
import com.google.android.gms.maps.model.LatLng
import com.google.android.gms.maps.model.LatLngBounds
import com.google.android.gms.maps.model.MarkerOptions
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.Query
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

@AndroidEntryPoint
class TrackingMapActivity : AppCompatActivity(), OnMapReadyCallback {

    private lateinit var binding: ActivityTrackingMapBinding
    private var googleMap: GoogleMap? = null
    private val db = FirebaseFirestore.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTrackingMapBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)

        binding.fabRefresh.setOnClickListener {
            fetchLiveLocations()
        }
    }

    override fun onMapReady(map: GoogleMap) {
        googleMap = map
        fetchLiveLocations()
    }

    private fun fetchLiveLocations() {
        lifecycleScope.launch {
            try {
                // Fetch the latest location for each active staff member
                val snapshot = db.collection("location_tracking")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .limit(100)
                    .get()
                    .await()

                val tracks = snapshot.toObjects(LocationTrack::class.java)
                val latestByStaff = tracks.groupBy { it.staffId }.mapValues { it.value.first() }

                updateMapMarkers(latestByStaff.values.toList())
            } catch (e: Exception) {
                Log.e("Map", "Failed to load locations", e)
                Toast.makeText(this@TrackingMapActivity, "Failed to load locations: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun updateMapMarkers(locations: List<LocationTrack>) {
        val map = googleMap ?: return
        map.clear()

        if (locations.isEmpty()) return

        val builder = LatLngBounds.Builder()

        for (track in locations) {
            val position = LatLng(track.latitude, track.longitude)
            val isOnline = (System.currentTimeMillis() - track.timestamp) < 600000 // 10 mins

            val color = if (isOnline) {
                if (track.speed > 1.0) BitmapDescriptorFactory.HUE_GREEN else BitmapDescriptorFactory.HUE_ORANGE
            } else {
                BitmapDescriptorFactory.HUE_RED
            }

            map.addMarker(
                MarkerOptions()
                    .position(position)
                    .title("Staff ID: ${track.staffId}")
                    .snippet("Speed: ${track.speed} m/s, Battery: ${track.batteryLevel}%")
                    .icon(BitmapDescriptorFactory.defaultMarker(color))
            )
            builder.include(position)
        }

        try {
            val bounds = builder.build()
            map.animateCamera(CameraUpdateFactory.newLatLngBounds(bounds, 100))
        } catch (e: Exception) {
            Log.e("Map", "Error framing markers", e)
        }
    }
}
