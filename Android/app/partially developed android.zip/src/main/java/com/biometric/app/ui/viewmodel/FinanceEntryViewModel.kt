package com.biometric.app.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.*
import com.biometric.app.util.PredictionEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class FinanceEntryViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel,
) : ViewModel() {

    sealed class FinanceEvent {
        object Success : FinanceEvent()
        data class Risk(val message: String) : FinanceEvent()
        data class Error(val message: String) : FinanceEvent()
    }

    private val _events = MutableSharedFlow<FinanceEvent>()
    val events = _events.asSharedFlow()

    val allItems: StateFlow<List<InventoryItem>> = sharedViewModel.selectedShop.flatMapLatest { shop ->
        shop?.let { repository.getInventoryItems(it.shopId) } ?: flowOf(emptyList())
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _shopId = MutableStateFlow("")

    val recentPurchaseDescriptions: StateFlow<List<String>> = repository.getDescriptionMaster()
        .map { masters -> 
            masters.asSequence().map { it.name.trim().uppercase() }.distinct().toList()
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedDate = MutableStateFlow(System.currentTimeMillis())
    private val _isEntriesLoading = MutableStateFlow(value = true)
    val isEntriesLoading: StateFlow<Boolean> = _isEntriesLoading.asStateFlow()

    val recentEntries: StateFlow<List<Cashbook>> = combine(_shopId, _selectedDate) { shopId, date ->
        shopId to date
    }.flatMapLatest { (shopId, date) ->
        _isEntriesLoading.value = true
        val cal = Calendar.getInstance().apply { timeInMillis = date }
        val start = cal.apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0) }.timeInMillis
        val end = cal.apply { set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999) }.timeInMillis
        
        repository.getCashbookEntriesForPeriod(shopId, start, end)
            .onEach { _isEntriesLoading.value = false }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private val _selectedEntry = MutableStateFlow<Cashbook?>(null)
    val selectedEntry = _selectedEntry.asStateFlow()

    fun setShopId(shopId: String) {
        _shopId.value = shopId
    }

    fun setDate(date: Long) {
        _selectedDate.value = date
    }

    fun addFinancialEntry(
        shopId: String,
        amount: Double,
        type: String,
        category: String,
        description: String,
        transactionDate: Long = System.currentTimeMillis(),
        quantity: Double? = null,
        unit: String? = null,
    ) {
        viewModelScope.launch {
            val standardizedDesc = standardizeItemName(description.ifBlank { category })
            val entryId = UUID.randomUUID().toString()
            val entry = Cashbook(
                entryId = entryId,
                shopId = shopId,
                transactionType = type,
                category = category,
                amount = amount,
                quantity = quantity,
                unit = unit,
                description = standardizedDesc,
                transactionDate = transactionDate,
            )
            repository.insertCashbookEntry(entry)
            _events.emit(FinanceEvent.Success)
            
            // Auto Sync to Inventory
            val isNotSalaryOrAdvance = !FinancialCategory.isSalary(category, standardizedDesc) && !FinancialCategory.isAdvance(category)
            if (type == "OUT" && isNotSalaryOrAdvance && (quantity != null && quantity > 0)) {
                updateInventory(shopId, standardizedDesc, quantity, amount, transactionDate, entryId, unit ?: "Piece")
            }

            repository.logAction(shopId, "ADD", "Cashbook", null, "$category: ₹$amount")
            sharedViewModel.triggerDashboardRefresh()
        }
    }

    fun performDataCleanup() {
        val sId = _shopId.value
        if (sId.isEmpty()) return

        viewModelScope.launch(Dispatchers.IO) {
            _events.emit(FinanceEvent.Risk("Starting data cleanup and merging duplicates..."))
            try {
                // 1. Get all entries for this shop
                val allEntries = repository.getCashbookEntriesForPeriod(sId, 0, Long.MAX_VALUE).first()
                
                // 2. Identify entries needing trimming or standardization
                val entriesToFix = allEntries.filter { 
                    it.description != null && (it.description!!.contains("  ") || it.description != it.description!!.trim().uppercase())
                }

                if (entriesToFix.isEmpty()) {
                    _events.emit(FinanceEvent.Success)
                    return@launch
                }

                // 3. Update each entry
                entriesToFix.forEach { entry ->
                    val cleanDesc = entry.description!!.trim().uppercase()
                    val updatedEntry = entry.copy(description = cleanDesc)
                    repository.insertCashbookEntry(updatedEntry)
                    
                    // Update linked price history as well
                    val history = repository.getPriceHistory(sId, entry.description!!).first()
                    history.filter { it.referenceEntryId == entry.entryId }.forEach { h ->
                        repository.firebaseSync.pushPriceHistory(h.copy(itemName = cleanDesc))
                    }
                }

                // 4. Rebuild all unique inventory items affected
                val affectedNames = entriesToFix.asSequence().map { it.description!!.trim().uppercase() }.distinct().toList()
                affectedNames.forEach { name ->
                    repository.rebuildInventoryItem(sId, name)
                }

                _events.emit(FinanceEvent.Success)
                sharedViewModel.triggerDashboardRefresh()
            } catch (e: Exception) {
                Log.e("FinanceEntryVM", "Cleanup failed", e)
                _events.emit(FinanceEvent.Error("Cleanup failed: ${e.message}"))
            }
        }
    }

    private fun standardizeItemName(input: String): String {
        val cleanInput = input.trim().uppercase()
        // Aggressively remove extra internal spaces as well
        return cleanInput.replace("\\s+".toRegex(), " ")
    }

    fun updateFinancialEntry(
        entry: Cashbook,
        amount: Double,
        type: String,
        category: String,
        description: String,
        date: Long,
        quantity: Double? = null,
        unit: String? = null,
    ) {
        viewModelScope.launch {
            val oldVal = "${entry.category}: ₹${entry.amount}"
            val standardizedDesc = standardizeItemName(description.ifBlank { category })
            val newVal = "$category: ₹$amount"
            
            val updatedEntry = entry.copy(
                amount = amount,
                transactionType = type,
                category = category,
                quantity = quantity,
                unit = unit,
                description = standardizedDesc,
                transactionDate = date,
                lastModified = System.currentTimeMillis()
            )
            repository.insertCashbookEntry(updatedEntry)
            _events.emit(FinanceEvent.Success)

            // Re-sync inventory
            val isNotSalaryOrAdvance = !FinancialCategory.isSalary(category, standardizedDesc) && !FinancialCategory.isAdvance(category)
            
            if (type == "OUT" && isNotSalaryOrAdvance && (quantity != null && quantity > 0)) {
                repository.deletePriceHistoryByReference(entry.entryId)
                updateInventory(entry.shopId, standardizedDesc, quantity, amount, date, entry.entryId, unit ?: "Piece")
            } else {
                repository.deletePriceHistoryByReference(entry.entryId)
                repository.rebuildInventoryItem(entry.shopId, standardizedDesc.uppercase().trim())
                // Also rebuild old name if it changed
                val oldName = entry.description ?: entry.category
                if (oldName.uppercase().trim() != standardizedDesc.uppercase().trim()) {
                    repository.rebuildInventoryItem(entry.shopId, oldName.uppercase().trim())
                }
            }
            
            repository.logAction(entry.shopId, "UPDATE", "Cashbook", oldVal, newVal)
            sharedViewModel.triggerDashboardRefresh()
        }
    }

    fun deleteFinancialEntry(entry: Cashbook) {
        viewModelScope.launch {
            repository.deleteCashbookEntry(entry)
            repository.deletePriceHistoryByReference(entry.entryId)
            repository.rebuildInventoryItem(entry.shopId, (entry.description ?: entry.category).uppercase().trim())
            
            repository.logAction(entry.shopId, "DELETE", "Cashbook", "${entry.category}: ₹${entry.amount}", null)
            _events.emit(FinanceEvent.Success)
            sharedViewModel.triggerDashboardRefresh()
        }
    }

    fun updateInventoryIncremental(shopId: String, itemName: String, qty: Double, totalCost: Double, unit: String) {
        viewModelScope.launch {
            updateInventory(shopId, itemName, qty, totalCost, System.currentTimeMillis(), UUID.randomUUID().toString(), unit)
            sharedViewModel.triggerDashboardRefresh()
        }
    }

    fun getPriceHistory(shopId: String, itemName: String): Flow<List<PriceHistory>> = repository.getPriceHistory(shopId, itemName)

    private suspend fun updateInventory(shopId: String, itemName: String, qty: Double, totalCost: Double, date: Long, refId: String, unit: String) {
        val cleanName = itemName.uppercase().trim()
        if (cleanName.isEmpty()) return

        val price = totalCost / qty
        val history = PriceHistory(
            shopId = shopId,
            itemName = cleanName,
            price = price,
            quantity = qty,
            unit = unit,
            date = date,
            referenceEntryId = refId
        )

        // AI Anomaly Detection
        val pastHistory = repository.getPriceHistory(shopId, cleanName).first()
        val anomalyMsg = PredictionEngine.detectAnomaly(history, pastHistory)
        if (anomalyMsg != null) {
            repository.logAction(shopId, "AI_ALERT", "Finance", "Anomaly Detected", anomalyMsg)
            _events.emit(FinanceEvent.Risk(anomalyMsg))
        }

        repository.firebaseSync.pushPriceHistory(history)
        
        repository.rebuildInventoryItem(shopId, cleanName, unit)
    }
}
