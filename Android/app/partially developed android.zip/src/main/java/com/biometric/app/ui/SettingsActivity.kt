package com.biometric.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.edit
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.ExpenseCategory
import com.biometric.app.databinding.ActivitySettingsBinding
import com.biometric.app.databinding.DialogAddCategoryBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.HapticUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class SettingsActivity : MotionBaseActivity() {

    private lateinit var binding: ActivitySettingsBinding
    private val viewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    
    private var currentShopId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentShopId = intent.getStringExtra("SHOP_ID")
        viewModel.setManagementShopId(currentShopId)

        setupToolbar()
        loadSettings()
        setupListeners()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        val shopName = intent.getStringExtra("SHOP_NAME")
        binding.toolbar.title = if (shopName != null) "$shopName - Settings" else "Global Settings"
    }

    private fun loadSettings() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        binding.switchAutoShare.isChecked = prefs.getBoolean("auto_share_bill", false)
        binding.switchMaskProfits.isChecked = prefs.getBoolean("mask_profits", true)
        binding.switchAdminControls.isChecked = prefs.getBoolean("enable_admin_controls", false)
    }

    private fun setupListeners() {
        binding.btnManageCategories.setOnClickListener {
            val intent = android.content.Intent(this, ManageCategoriesActivity::class.java).apply {
                putExtra("SHOP_ID", currentShopId)
            }
            startActivity(intent)
        }

        binding.btnManageDescriptions.setOnClickListener {
            val intent = android.content.Intent(this, ManageDescriptionsActivity::class.java).apply {
                putExtra("SHOP_ID", currentShopId)
            }
            startActivity(intent)
        }

        binding.btnSyncMasterData.setOnClickListener {
            HapticUtil.vibrateClick(it)
            viewModel.syncMasterData()
            Toast.makeText(this, "Master Data Sync Started... Check lists in a moment.", Toast.LENGTH_SHORT).show()
        }

        binding.switchAutoShare.setOnCheckedChangeListener { _, isChecked ->
            getSharedPreferences("app_prefs", MODE_PRIVATE).edit {
                putBoolean("auto_share_bill", isChecked)
            }
            HapticUtil.vibrateClick(binding.switchAutoShare)
        }

        binding.switchMaskProfits.setOnCheckedChangeListener { _, isChecked ->
            getSharedPreferences("app_prefs", MODE_PRIVATE).edit {
                putBoolean("mask_profits", isChecked)
            }
            HapticUtil.vibrateClick(binding.switchMaskProfits)
        }

        binding.switchAdminControls.setOnCheckedChangeListener { _, isChecked ->
            getSharedPreferences("app_prefs", MODE_PRIVATE).edit {
                putBoolean("enable_admin_controls", isChecked)
            }
            HapticUtil.vibrateClick(binding.switchAdminControls)
        }

        binding.btnShareApp.setOnClickListener {
            HapticUtil.vibrateClick(it)
            GlobalSwitcherDelegate.shareApp(this)
        }
        
        setupMotionFeedback(binding.btnManageCategories, binding.btnManageDescriptions, binding.btnShareApp)
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, showShopSwitcher = false)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
