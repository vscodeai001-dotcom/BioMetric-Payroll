package com.biometric.app.ui

import android.animation.ValueAnimator
import android.content.res.ColorStateList
import android.graphics.Color
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.graphics.toColorInt
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.ValueFormatter
import com.github.mikephil.charting.highlight.Highlight
import com.github.mikephil.charting.listener.OnChartValueSelectedListener
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.DayData
import com.biometric.app.databinding.ActivityDailyAnalyticsBinding
import com.biometric.app.databinding.DialogDailyDetailBinding
import com.biometric.app.databinding.ItemAnalyticsInsightBinding
import com.biometric.app.ui.viewmodel.AnalyticsInsight
import com.biometric.app.ui.viewmodel.DailyAnalyticsViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class DailyAnalyticsActivity : MotionBaseActivity(), OnChartValueSelectedListener {

    private lateinit var binding: ActivityDailyAnalyticsBinding
    private val viewModel: DailyAnalyticsViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityDailyAnalyticsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupCharts()
        setupInsightsList()
        setupListeners()
        observeViewModel()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            val shops = mainViewModel.allShops.value
            if (shops.isNotEmpty()) {
                val names = shops.map { it.name }.toTypedArray()
                MaterialAlertDialogBuilder(this)
                    .setTitle("Switch Shop")
                    .setItems(names) { _, which ->
                        sharedViewModel.setSelectedShop(shops[which])
                    }.show()
            }
        }
        
        val shopName = intent.getStringExtra("SHOP_NAME") ?: sharedViewModel.selectedShop.value?.name ?: "Shop"
        updateToolbarTitle(shopName)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Financial Analytics")
    }

    private fun setupInsightsList() {
        binding.rvInsights.layoutManager = LinearLayoutManager(this)
        binding.rvInsights.isNestedScrollingEnabled = false
    }

    private fun setupCharts() {
        binding.combinedChart.apply {
            description.isEnabled = false
            setDrawGridBackground(false)
            setDrawBarShadow(false)
            isHighlightFullBarEnabled = false
            setOnChartValueSelectedListener(this@DailyAnalyticsActivity)
            
            xAxis.apply {
                position = XAxis.XAxisPosition.BOTTOM
                setDrawGridLines(false)
                granularity = 1f
                textColor = ContextCompat.getColor(context, R.color.text_secondary)
            }
            
            axisLeft.apply {
                setDrawGridLines(true)
                gridColor = ContextCompat.getColor(context, R.color.divider)
                textColor = ContextCompat.getColor(context, R.color.text_secondary)
            }
            
            axisRight.isEnabled = false
            legend.isEnabled = true
            animateXY(1000, 1000)
        }
    }

    private fun setupListeners() {
        binding.btnPrevMonth.setOnClickListener { 
            HapticUtil.vibrateClick(it)
            viewModel.changeMonth(-1) 
        }
        binding.btnNextMonth.setOnClickListener { 
            HapticUtil.vibrateClick(it)
            viewModel.changeMonth(1) 
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.state.collectLatest { state ->
                        updateUI(state)
                    }
                }
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let { updateToolbarTitle(it.name) }
                    }
                }
            }
        }
    }

    private fun updateUI(state: com.biometric.app.ui.viewmodel.AnalyticsState) {
        // UNIFORM LOADING: Use Smart Delay Loader
        val isDataZero = state.totalSales == 0.0 && state.netProfit == 0.0 && state.dayDataList.isEmpty()
        if (state.isLoading) {
            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
            if (isDataZero) binding.contentLayout.visibility = View.GONE
        } else {
            PremiumLoader.hide(binding.brewingLoader)
            binding.contentLayout.visibility = View.VISIBLE
            binding.contentLayout.alpha = 1f
        }
        binding.tvMonthLabel.text = state.periodLabel

        animateCounter(binding.tvTotalSales, state.totalSales)
        animateCounter(binding.tvTotalPurchases, state.totalPurchases)
        animateCounter(binding.tvTotalSalary, state.totalSalary)
        animateCounter(binding.tvNetProfit, state.netProfit)

        if (state.netProfit >= 0) {
            binding.cardProfit.setCardBackgroundColor(ContextCompat.getColor(this, R.color.tile_fixed_bg))
            binding.tvNetProfit.setTextColor(ContextCompat.getColor(this, R.color.green_700))
        } else {
            binding.cardProfit.setCardBackgroundColor(ContextCompat.getColor(this, R.color.tile_expense_bg))
            binding.tvNetProfit.setTextColor(ContextCompat.getColor(this, R.color.red_700))
        }

        updateCombinedChart(state.dayDataList)
        updateInsights(state.insights)
        updateHeatmap(state.dayDataList)
    }

    private fun animateCounter(view: TextView, target: Double) {
        val animator = ValueAnimator.ofFloat(0f, target.toFloat())
        animator.duration = 1000
        animator.interpolator = DecelerateInterpolator()
        animator.addUpdateListener { 
            view.text = currencyFormat.format(it.animatedValue as Float)
        }
        animator.start()
    }

    private fun updateCombinedChart(data: List<DayData>) {
        if (data.isEmpty()) {
            binding.combinedChart.clear()
            return
        }

        val salesEntries = mutableListOf<Entry>()
        val profitEntries = mutableListOf<Entry>()
        val expenseEntries = mutableListOf<BarEntry>()
        val labels = mutableListOf<String>()

        val sortedData = data.sortedBy { it.calendar.timeInMillis }
        sortedData.forEachIndexed { index, dayData ->
            salesEntries.add(Entry(index.toFloat(), dayData.totalIn.toFloat()))
            
            val net = dayData.totalIn - (dayData.totalOut + dayData.salaryEarned + dayData.fixedExpense)
            profitEntries.add(Entry(index.toFloat(), net.toFloat()))
            
            expenseEntries.add(BarEntry(index.toFloat(), floatArrayOf(dayData.totalOut.toFloat(), dayData.salaryEarned.toFloat())))
            labels.add(dayData.calendar[Calendar.DAY_OF_MONTH].toString())
        }

        val combinedData = CombinedData()

        val primaryColor = ContextCompat.getColor(this, R.color.colorPrimary)
        val textPrimaryColor = ContextCompat.getColor(this, R.color.text_primary)

        // Sales Line
        val salesSet = LineDataSet(salesEntries, "Sales").apply {
            color = primaryColor
            setCircleColor(primaryColor)
            lineWidth = 3f
            circleRadius = 4f
            setDrawCircleHole(true)
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillColor = primaryColor
            fillAlpha = 30
            setDrawValues(true)
            valueTextColor = textPrimaryColor
            valueTextSize = 9f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "₹%.0f".format(value)
                }
            }
        }

        // Profit Area
        val profitSet = LineDataSet(profitEntries, "Net Profit").apply {
            color = ContextCompat.getColor(this@DailyAnalyticsActivity, R.color.green)
            setCircleColor(ContextCompat.getColor(this@DailyAnalyticsActivity, R.color.green))
            lineWidth = 2f
            setDrawCircles(false)
            setDrawFilled(true)
            fillColor = ContextCompat.getColor(this@DailyAnalyticsActivity, R.color.green)
            fillAlpha = 50
            setDrawValues(true)
            valueTextColor = textPrimaryColor
            valueTextSize = 9f
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(value: Float): String {
                    return "₹%.0f".format(value)
                }
            }
        }

        // Expenses Bar (Stacked: Purchase + Salary)
        val expenseSet = BarDataSet(expenseEntries, "Expenses").apply {
            colors = listOf(
                ContextCompat.getColor(this@DailyAnalyticsActivity, R.color.red),
                ContextCompat.getColor(this@DailyAnalyticsActivity, R.color.amber),
            )
            stackLabels = arrayOf("Purchases", "Salary")
            setDrawValues(false)
        }

        combinedData.setData(LineData(salesSet, profitSet))
        combinedData.setData(BarData(expenseSet))

        binding.combinedChart.apply {
            this.data = combinedData
            xAxis.valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(v: Float): String {
                    val i = v.toInt()
                    return if ((i >= 0) && (i < labels.size)) labels[i] else ""
                }
            }
            invalidate()
        }
    }

    private fun updateInsights(insights: List<AnalyticsInsight>) {
        binding.rvInsights.adapter = object : RecyclerView.Adapter<InsightViewHolder>() {
            override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InsightViewHolder {
                val b = ItemAnalyticsInsightBinding.inflate(LayoutInflater.from(parent.context), parent, false)
                return InsightViewHolder(b)
            }

            override fun onBindViewHolder(holder: InsightViewHolder, position: Int) {
                val item = insights[position]
                holder.binding.tvInsightTitle.text = item.title
                holder.binding.tvInsightDesc.text = item.description
                
                val (color, emoji) = when(item.type) {
                    com.biometric.app.ui.viewmodel.InsightType.POSITIVE -> "#10B981" to "🚀"
                    com.biometric.app.ui.viewmodel.InsightType.NEGATIVE -> "#EF4444" to "⚠️"
                    com.biometric.app.ui.viewmodel.InsightType.NEUTRAL -> "#4F46E5" to "💡"
                }
                holder.binding.tvInsightEmoji.text = emoji
                holder.binding.tvInsightEmoji.backgroundTintList = ColorStateList.valueOf(color.toColorInt()).withAlpha(32)
                holder.binding.tvInsightTitle.setTextColor(color.toColorInt())
            }

            override fun getItemCount() = insights.size
        }
    }

    private fun updateHeatmap(data: List<DayData>) {
        binding.gridHeatmap.removeAllViews()
        data.forEach { day ->
            val view = View(this).apply {
                val size = (resources.displayMetrics.widthPixels - 120) / 7
                layoutParams = ViewGroup.LayoutParams(size, size)
                
                val net = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
                val alpha = (kotlin.math.abs(net) / 5000.0).coerceIn(0.3, 1.0).toFloat()
                
                val color = if (net >= 0) {
                    Color.argb((alpha * 255).toInt(), 16, 185, 129)
                } else {
                    Color.argb((alpha * 255).toInt(), 239, 68, 68)
                }
                setBackgroundColor(color)

                setOnClickListener { showDayDetail(day) }
            }
            binding.gridHeatmap.addView(view)
        }
    }

    private fun showDayDetail(day: DayData) {
        val b = DialogDailyDetailBinding.inflate(layoutInflater)
        val dialog = BottomSheetDialog(this, R.style.PremiumBottomSheetDialog)
        dialog.setContentView(b.root)

        b.tvDate.text = day.displayDate
        b.tvSales.text = currencyFormat.format(day.totalIn)
        b.tvPurchases.text = currencyFormat.format(day.totalOut)
        b.tvSalary.text = currencyFormat.format(day.salaryEarned)
        
        val net = day.totalIn - (day.totalOut + day.salaryEarned + day.fixedExpense)
        b.tvNet.text = currencyFormat.format(net)
        b.tvNet.setTextColor(if (net >= 0) "#10B981".toColorInt() else "#EF4444".toColorInt())

        dialog.show()
    }

    override fun onValueSelected(e: Entry?, h: Highlight?) {
        e?.let {
            val index = it.x.toInt()
            val state = viewModel.state.value
            if ((index >= 0) && (index < state.dayDataList.size)) {
                showDayDetail(state.dayDataList[index])
            }
        }
    }

    override fun onNothingSelected() {}

    class InsightViewHolder(val binding: ItemAnalyticsInsightBinding) : RecyclerView.ViewHolder(binding.root)
}
