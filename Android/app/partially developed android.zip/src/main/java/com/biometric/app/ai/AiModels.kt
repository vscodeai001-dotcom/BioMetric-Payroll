package com.biometric.app.ai

import com.biometric.app.data.RawMetrics
import com.biometric.app.data.OrderWithItems
import com.biometric.app.data.entity.Cashbook

enum class AiIntent {
    SALES_SUMMARY,
    PROFIT_SUMMARY,
    PROFIT_ANALYSIS,
    PURCHASE_ANALYSIS,
    ATTENDANCE_QUERY,
    SALARY_QUERY,
    INVESTMENT_QUERY,
    STOCK_QUERY,
    HEALTH_QUERY,
    PREDICTION_QUERY,
    GOAL_QUERY,
    SHOP_COMPARISON,
    TIME_COMPARISON,
    TREND_ANALYSIS,
    TOP_PERFORMER,
    LOW_PERFORMER,
    HELP,
    GENERAL,
}

data class BusinessDataBundle(
    val metrics: RawMetrics,
    val previousMetrics: RawMetrics?,
    val cashbookEntries: List<Cashbook>,
    val orders: List<OrderWithItems>,
    val topItems: List<Pair<String, Double>>,
    val topExpenses: List<Pair<String, Double>>,
    val periodLabel: String,
    val previousPeriodLabel: String?,
    val extraContext: Map<String, Any> = emptyMap(),
)

data class BusinessInsight(
    val title: String,
    val description: String,
    val impact: ImpactLevel,
    val trend: TrendDirection,
    val recommendation: String? = null,
    val reason: String? = null,
)

enum class ImpactLevel { HIGH, POSITIVE, NEGATIVE, NEUTRAL }
enum class TrendDirection { UP, DOWN, STABLE }
