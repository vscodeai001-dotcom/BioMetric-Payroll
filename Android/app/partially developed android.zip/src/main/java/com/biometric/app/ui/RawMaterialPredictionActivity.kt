package com.biometric.app.ui

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.databinding.ActivityRawMaterialPredictionBinding
import com.biometric.app.ui.adapter.RawMaterialPredictionAdapter
import com.biometric.app.ui.viewmodel.RawMaterialPredictionViewModel
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

@AndroidEntryPoint
class RawMaterialPredictionActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityRawMaterialPredictionBinding
    private val viewModel: RawMaterialPredictionViewModel by viewModels()

    private val urgentAdapter = RawMaterialPredictionAdapter()
    private val mediumAdapter = RawMaterialPredictionAdapter()
    private val safeAdapter = RawMaterialPredictionAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRawMaterialPredictionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.rvUrgent.layoutManager = LinearLayoutManager(this)
        binding.rvUrgent.adapter = urgentAdapter

        binding.rvMedium.layoutManager = LinearLayoutManager(this)
        binding.rvMedium.adapter = mediumAdapter

        binding.rvSafe.layoutManager = LinearLayoutManager(this)
        binding.rvSafe.adapter = safeAdapter

        binding.toggleRange.addOnButtonCheckedListener { _, checkedId, isChecked ->
            if (isChecked) {
                when (checkedId) {
                    binding.btn7Days.id -> viewModel.setFilterRange(7)
                    binding.btn30Days.id -> viewModel.setFilterRange(30)
                    binding.btn90Days.id -> viewModel.setFilterRange(90)
                }
            }
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collectLatest { state ->
                    // UNIFORM LOADING: Use Smart Delay Loader
                    val isDataZero = state.urgentItems.isEmpty() && state.mediumItems.isEmpty() && state.safeItems.isEmpty()
                    if (state.isLoading) {
                        PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.FORECAST, lifecycleScope)
                        if (isDataZero) binding.contentLayout.visibility = View.GONE
                    } else {
                        PremiumLoader.hide(binding.brewingLoader)
                        binding.contentLayout.visibility = View.VISIBLE
                    }
                    
                    urgentAdapter.submitList(state.urgentItems)
                    mediumAdapter.submitList(state.mediumItems)
                    safeAdapter.submitList(state.safeItems)

                    binding.tvUrgentHeader.visibility = if (state.urgentItems.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvUrgent.visibility = if (state.urgentItems.isNotEmpty()) View.VISIBLE else View.GONE

                    binding.tvMediumHeader.visibility = if (state.mediumItems.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvMedium.visibility = if (state.mediumItems.isNotEmpty()) View.VISIBLE else View.GONE

                    binding.tvSafeHeader.visibility = if (state.safeItems.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvSafe.visibility = if (state.safeItems.isNotEmpty()) View.VISIBLE else View.GONE
                }
            }
        }
    }
}
