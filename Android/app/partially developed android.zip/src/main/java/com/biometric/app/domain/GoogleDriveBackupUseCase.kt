package com.biometric.app.domain

import com.google.gson.Gson
import com.google.gson.GsonBuilder
import com.biometric.app.data.FullBackupData
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.*
import com.biometric.app.sync.FirebaseSyncManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Dispatchers
import java.util.*
import javax.inject.Inject

class GoogleDriveBackupUseCase @Inject constructor(
    private val repository: MainRepository,
    private val firebaseSync: FirebaseSyncManager,
) {
    suspend fun generateBackupJson(): String = withContext(Dispatchers.Default) {
        val backup = FullBackupData(
            timestamp = System.currentTimeMillis(),
            version = 2,
            shops = repository.getAllShops().first(),
            items = firebaseSync.getDataFlow<Item>("items").first(),
            prices = firebaseSync.getDataFlow<ShopItemPrice>("prices").first(),
            orders = firebaseSync.getDataFlow<Order>("orders").first(),
            orderItems = firebaseSync.getDataFlow<OrderItem>("order_items").first(),
            cashbook = firebaseSync.getDataFlow<Cashbook>("cashbook").first(),
            employees = firebaseSync.getDataFlow<Employee>("employees").first(),
            attendance = firebaseSync.getDataFlow<Attendance>("attendance").first(),
            advances = firebaseSync.getDataFlow<AdvancePayment>("advance_payments").first(),
            fixedExpenses = firebaseSync.getDataFlow<FixedExpense>("fixed_expenses").first(),
            investments = firebaseSync.getDataFlow<Investment>("investments").first(),
            suppliers = firebaseSync.getDataFlow<Supplier>("suppliers").first(),
            inventoryItems = firebaseSync.getDataFlow<InventoryItem>("inventory").first(),
            closedDays = firebaseSync.getDataFlow<ShopClosedDay>("shop_closed_days").first(),
            employeeHistory = firebaseSync.getDataFlow<EmployeeHistory>("employee_history").first(),
            priceHistory = firebaseSync.getDataFlow<PriceHistory>("price_history").first(),
            auditLogs = firebaseSync.getDataFlow<AuditLog>("audit_logs").first(),
            salaryPayments = firebaseSync.getDataFlow<SalaryPayment>("salary_payments").first(),
            reminders = firebaseSync.getDataFlow<Reminder>("reminders").first(),
            shopTables = firebaseSync.getDataFlow<ShopTable>("shop_tables").first(),
            recycleBin = firebaseSync.getDataFlow<RecycleBinItem>("recycle_bin").first(),
            purchases = firebaseSync.getDataFlow<Purchase>("purchases").first(),
            stockPatterns = firebaseSync.getDataFlow<StockPattern>("stock_patterns").first()
        )
        
        val gson = GsonBuilder().setPrettyPrinting().create()
        gson.toJson(backup)
    }

    suspend fun restoreFromJson(json: String): Result<String> = withContext(Dispatchers.IO) {
        try {
            val gson = Gson()
            val backup = gson.fromJson(json, FullBackupData::class.java) ?: return@withContext Result.failure(Exception("Failed to parse JSON backup"))

            if (backup.shops.isEmpty() && backup.orders.isEmpty() && backup.cashbook.isEmpty()) {
                return@withContext Result.failure(Exception("Backup file is empty or incompatible."))
            }

            android.util.Log.d("BackupRestore", "Starting Clean Bulk Restore: version=${backup.version}")

            // 1. CLEAR EXISTING TABLES (To prevent duplicates like the renamed staff issue)
            val tablesToClear = listOf(
                "shops", "items", "prices", "employees", "orders", "order_items", 
                "cashbook", "attendance", "advance_payments", "fixed_expenses", 
                "investments", "suppliers", "inventory", "shop_closed_days", 
                "employee_history", "price_history", "audit_logs", "salary_payments",
                "reminders", "shop_tables", "recycle_bin", "purchases", "stock_patterns"
            )
            tablesToClear.forEach { firebaseSync.clearTable(it) }

            val updates = mutableMapOf<String, Any?>()

            // 2. PREPARE UPDATES
            backup.shops.filter { it.shopId.isNotBlank() }.forEach { updates["shops/${it.shopId}"] = it }
            backup.items.filter { it.itemId.isNotBlank() }.forEach { updates["items/${it.itemId}"] = it }
            backup.prices.filter { it.shopId.isNotBlank() && it.itemId.isNotBlank() }.forEach { updates["prices/${it.shopId}_${it.itemId}"] = it }
            backup.employees.filter { it.employeeId.isNotBlank() }.forEach { updates["employees/${it.employeeId}"] = it }
            backup.orders.filter { it.orderId.isNotBlank() }.forEach { updates["orders/${it.orderId}"] = it }
            backup.orderItems.filter { it.orderItemId.isNotBlank() }.forEach { updates["order_items/${it.orderItemId}"] = it }
            backup.cashbook.filter { it.entryId.isNotBlank() }.forEach { updates["cashbook/${it.entryId}"] = it }
            
            // Attendance: CRITICAL SAFETY CHECK
            backup.attendance.forEach { 
                if (it.attendanceId.isBlank()) it.attendanceId = UUID.randomUUID().toString()
                updates["attendance/${it.attendanceId}"] = it 
            }
            
            // Fixed Expenses: Ensure ID exists
            backup.fixedExpenses.forEach { 
                if (it.id.isBlank()) it.id = UUID.randomUUID().toString()
                updates["fixed_expenses/${it.id}"] = it 
            }

            // Advances: Ensure ID exists
            backup.advances.forEach { 
                if (it.advanceId.isBlank()) it.advanceId = UUID.randomUUID().toString()
                updates["advance_payments/${it.advanceId}"] = it 
            }

            backup.investments.filter { it.investmentId.isNotBlank() }.forEach { updates["investments/${it.investmentId}"] = it }
            backup.suppliers.filter { it.supplierId.isNotBlank() }.forEach { updates["suppliers/${it.supplierId}"] = it }
            backup.inventoryItems.filter { it.name.isNotBlank() }.forEach { updates["inventory/${it.name.uppercase().trim()}"] = it }
            
            backup.closedDays.forEach { 
                if (it.id.isBlank()) it.id = UUID.randomUUID().toString()
                updates["shop_closed_days/${it.id}"] = it 
            }
            
            // History: Ensure ID exists
            backup.employeeHistory.forEach { 
                if (it.historyId.isBlank()) it.historyId = UUID.randomUUID().toString()
                updates["employee_history/${it.historyId}"] = it 
            }

            backup.priceHistory.forEach {
                val key = it.referenceEntryId.ifBlank { it.historyId }
                if (key.isNotBlank()) updates["price_history/$key"] = it
            }

            backup.auditLogs.forEach {
                if (it.logId.isBlank()) it.logId = UUID.randomUUID().toString()
                updates["audit_logs/${it.logId}"] = it
            }

            backup.salaryPayments.forEach {
                if (it.paymentId.isBlank()) it.paymentId = UUID.randomUUID().toString()
                updates["salary_payments/${it.paymentId}"] = it
            }

            backup.reminders.forEach {
                if (it.reminderId.isBlank()) it.reminderId = UUID.randomUUID().toString()
                updates["reminders/${it.reminderId}"] = it
            }

            backup.shopTables.forEach {
                if (it.shopId.isNotBlank() && it.tableId.isNotBlank()) {
                    updates["shop_tables/${it.shopId}_${it.tableId}"] = it
                }
            }

            backup.recycleBin.forEach {
                if (it.id.isBlank()) it.id = UUID.randomUUID().toString()
                updates["recycle_bin/${it.id}"] = it
            }

            backup.purchases.forEach {
                if (it.purchaseId.isBlank()) it.purchaseId = UUID.randomUUID().toString()
                updates["purchases/${it.purchaseId}"] = it
            }

            backup.stockPatterns.forEach {
                if (it.shopId.isNotBlank() && it.itemId.isNotBlank()) {
                    updates["stock_patterns/${it.shopId}_${it.itemId}"] = it
                }
            }

            android.util.Log.d("BackupRestore", "Prepared ${updates.size} updates. Total tables: ${tablesToClear.size}")

            // 3. APPLY UPDATES
            firebaseSync.bulkRestore(updates)

            // 4. CLEAR SNAPSHOTS
            firebaseSync.clearSnapshotsAndSummaries()

            val msg = StringBuilder("Recovered: ${backup.shops.size} shops, ${backup.employees.size} staff, ${backup.orders.size} orders")
            if (backup.employeeHistory.isNotEmpty()) msg.append(", ${backup.employeeHistory.size} salary records")
            if (backup.auditLogs.isNotEmpty()) msg.append(", ${backup.auditLogs.size} audit logs")
            
            if (backup.auditLogs.isEmpty() || backup.priceHistory.isEmpty()) {
                msg.append("\n\nNote: This backup file did not contain Audit Logs or Stock History. These screens will be empty until new data is generated.")
            }

            Result.success(msg.toString())
        } catch (e: Exception) {
            android.util.Log.e("BackupRestore", "Restore failed", e)
            Result.failure(e)
        }
    }
}
