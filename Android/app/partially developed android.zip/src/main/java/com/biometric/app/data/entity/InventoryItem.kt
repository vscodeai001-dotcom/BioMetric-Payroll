package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class InventoryItem(
    @get:PropertyName("itemId") @set:PropertyName("itemId")
    var itemId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("unitType") @set:PropertyName("unitType")
    var unitType: String = "Piece", // Litre, Kg, Piece
    
    @get:PropertyName("totalQuantity") @set:PropertyName("totalQuantity")
    var totalQuantity: Double = 0.0,
    
    @get:PropertyName("totalCost") @set:PropertyName("totalCost")
    var totalCost: Double = 0.0,
    
    @get:PropertyName("lastPrice") @set:PropertyName("lastPrice")
    var lastPrice: Double = 0.0,
    
    @get:PropertyName("lastUpdate") @set:PropertyName("lastUpdate")
    var lastUpdate: Long = System.currentTimeMillis()
)

@Keep
data class PriceHistory(
    @get:PropertyName("historyId") @set:PropertyName("historyId")
    var historyId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",

    @get:PropertyName("itemName") @set:PropertyName("itemName")
    var itemName: String = "",
    
    @get:PropertyName("price") @set:PropertyName("price")
    var price: Double = 0.0,
    
    @get:PropertyName("quantity") @set:PropertyName("quantity")
    var quantity: Double = 0.0,
    
    @get:PropertyName("unit") @set:PropertyName("unit")
    var unit: String? = null,

    @get:PropertyName("date") @set:PropertyName("date")
    var date: Long = System.currentTimeMillis(),
    
    @get:PropertyName("referenceEntryId") @set:PropertyName("referenceEntryId")
    var referenceEntryId: String = ""
)
