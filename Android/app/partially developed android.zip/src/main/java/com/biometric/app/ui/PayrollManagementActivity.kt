package com.biometric.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Payslip
import com.biometric.app.databinding.ActivityPayrollManagementBinding
import com.biometric.app.domain.attendance.AttendanceEngine
import com.biometric.app.ui.adapter.PayrollAdapter
import com.biometric.app.ui.viewmodel.StaffViewModel
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

import com.biometric.app.domain.payroll.PayrollCalculator
import com.biometric.app.domain.attendance.AttendanceResult
import java.time.YearMonth
import java.text.SimpleDateFormat
import android.util.Log

@AndroidEntryPoint
class PayrollManagementActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPayrollManagementBinding
    private val staffViewModel: StaffViewModel by viewModels()
    
    @Inject lateinit var repository: MainRepository

    private lateinit var adapter: PayrollAdapter
    private val payslips = mutableListOf<Payslip>()
    private var selectedDate = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPayrollManagementBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        binding.toolbar.setNavigationOnClickListener { finish() }

        setupRecyclerView()
        setupListeners()
        refreshData()
    }

    private fun setupRecyclerView() {
        adapter = PayrollAdapter(payslips) { payslip ->
            // Show detail flow
        }
        binding.rvStaffPayroll.layoutManager = LinearLayoutManager(this)
        binding.rvStaffPayroll.adapter = adapter
    }

    private fun setupListeners() {
        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(this, "Monthly", selectedDate) { newDate ->
                selectedDate = newDate
                refreshData()
            }
        }

        binding.btnLockPayroll.setOnClickListener {
            lockPayroll()
        }
    }

    private fun refreshData() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel("Monthly", selectedDate.timeInMillis)
        
        lifecycleScope.launch {
            try {
                // REAL-TIME Batch Calculation Logic
                val employees = repository.getAllEmployees().first()
                val year = selectedDate.get(Calendar.YEAR)
                val month = selectedDate.get(Calendar.MONTH) + 1
                val yearMonth = YearMonth.of(year, month)
                
                val range = DateRangeUtil.getRangeForPeriod("Monthly", selectedDate.timeInMillis)
                
                payslips.clear()
                for (emp in employees) {
                    // Fetch punches for the employee for this month
                    val punches = repository.getAttendancePunchesForPeriod(emp.employeeId, range.first, range.second).first()
                    
                    // Aggregate punches into daily AttendanceResults
                    val attendanceResults = mutableListOf<AttendanceResult>()
                    val cal = Calendar.getInstance().apply { timeInMillis = range.first }
                    while (cal.timeInMillis <= range.second) {
                        val dateStr = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
                        val dayPunches = punches.filter { it.date == dateStr }
                        val result = AttendanceEngine.processAttendance(
                            dateStr, dayPunches, emp.shiftStart, emp.shiftEnd
                        )
                        attendanceResults.add(result)
                        cal.add(Calendar.DAY_OF_MONTH, 1)
                    }

                    val payslip = PayrollCalculator.calculateMonthlyPayroll(emp, attendanceResults, yearMonth)
                    payslips.add(payslip)
                }
                adapter.notifyDataSetChanged()
            } catch (e: Exception) {
                Toast.makeText(this@PayrollManagementActivity, "Calculation failed: ${e.message}", Toast.LENGTH_SHORT).show()
                Log.e("Payroll", "Error calculating payroll", e)
            }
        }
    }

    private fun lockPayroll() {
        Toast.makeText(this, "Payroll Locked & Payslips Generated! 🔐", Toast.LENGTH_LONG).show()
        // Save payslips to Firestore and mark month as locked
    }
}
