package com.biometric.app.util

import com.biometric.app.data.entity.Cashbook
import java.util.*
import kotlin.math.abs

object SeasonalityEngine {

    /**
     * Calculates Day-of-Week seasonality coefficients based on provided transaction history.
     * Higher coefficient (> 1.0) means higher than average performance for that day.
     */
    fun calculateDaySeasonality(history: List<Cashbook>): Map<Int, Double> {
        if (history.isEmpty()) return emptyMap()

        // 1. Group income by day of year to get total daily sales
        val dailySales = history.filter { it.transactionType == "IN" }
            .groupBy { 
                val c = Calendar.getInstance().apply { timeInMillis = it.transactionDate }
                "${c.get(Calendar.YEAR)}_${c.get(Calendar.DAY_OF_YEAR)}" 
            }
            .mapValues { entry -> entry.value.sumOf { it.amount } }

        if (dailySales.isEmpty()) return emptyMap()

        val avgDailySales = dailySales.values.average()
        if (avgDailySales == 0.0) return emptyMap()

        // 2. Map day-of-year results to Day of Week (Calendar.SUNDAY, etc.)
        val dowPerformances = mutableMapOf<Int, MutableList<Double>>()
        dailySales.forEach { (key, sales) ->
            val parts = key.split("_")
            val cal = Calendar.getInstance().apply {
                set(Calendar.YEAR, parts[0].toInt())
                set(Calendar.DAY_OF_YEAR, parts[1].toInt())
            }
            val dow = cal.get(Calendar.DAY_OF_WEEK)
            dowPerformances.getOrPut(dow) { mutableListOf() }.add(sales / avgDailySales)
        }

        // 3. Return the average coefficient for each day
        return dowPerformances.mapValues { it.value.average() }
    }

    /**
     * Predicts daily sales for a specific date using a base average and seasonal coefficients.
     * Also applies a 'Holiday Boost' for known significant days.
     */
    fun predictDailySales(baseAvg: Double, date: Calendar, coefficients: Map<Int, Double>): Double {
        val dow = date.get(Calendar.DAY_OF_WEEK)
        val month = date.get(Calendar.MONTH)
        val day = date.get(Calendar.DAY_OF_MONTH)
        
        var coeff = coefficients[dow] ?: 1.0
        
        // --- 1. Known Holiday Boost Logic (Customizable) ---
        // Example: Jan 1 (New Year), Jan 26 (Republic Day), Aug 15 (Independence Day), Oct 2 (Gandhi Jayanti), Dec 25 (Christmas)
        val isMajorHoliday = (month == Calendar.JANUARY && (day == 1 || day == 26)) ||
                            (month == Calendar.AUGUST && day == 15) ||
                            (month == Calendar.OCTOBER && day == 2) ||
                            (month == Calendar.DECEMBER && day == 25)
        
        if (isMajorHoliday) {
            coeff *= 1.4 // Apply 40% boost for holidays
        }

        // --- 2. Seasonal Month Logic ---
        // Example: Summer (Apr-June) might have higher juice/shake sales
        val isSummer = month in Calendar.APRIL..Calendar.JUNE
        if (isSummer) {
            coeff *= 1.1 // 10% seasonal boost
        }

        return baseAvg * coeff
    }
}
