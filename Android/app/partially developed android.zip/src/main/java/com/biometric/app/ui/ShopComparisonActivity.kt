package com.biometric.app.ui

import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.PercentFormatter
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityShopComparisonBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.ui.adapter.ShopComparisonAdapter
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.ui.viewmodel.ExpenseDistribution
import com.biometric.app.ui.viewmodel.ShopComparisonMetrics
import com.biometric.app.ui.viewmodel.ShopComparisonViewModel
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class ShopComparisonActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityShopComparisonBinding
    private val viewModel: ShopComparisonViewModel by viewModels()
    private val mainViewModel: com.biometric.app.ui.viewmodel.MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: com.biometric.app.ui.viewmodel.SharedViewModel
    private val adapter = ShopComparisonAdapter()
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var selectedDate = Calendar.getInstance()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityShopComparisonBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupUI()
        observeViewModel()
        
        viewModel.loadComparisonData()
    }

    override fun onCreateOptionsMenu(menu: android.view.Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🏆", "Efficiency Leaderboard") {
                val intent = Intent(this, EfficiencyLeaderboardActivity::class.java)
                startActivity(intent)
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, showShopSwitcher = false, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: android.view.MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🏆", "Efficiency Leaderboard") {
                val intent = Intent(this, EfficiencyLeaderboardActivity::class.java).apply {
                    putExtra("PERIOD", viewModel.state.value.currentPeriod)
                    putExtra("DATE", viewModel.state.value.currentDate)
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📅", "Global Day Wise Analysis") {
                val intent = Intent(this, DayWiseReportActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("monthTime", viewModel.state.value.currentDate)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("💪", "Global Business Health") {
                val intent = Intent(this, BusinessHealthActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("🔮", "Global Financial Forecast") {
                val intent = Intent(this, FinancialPredictionActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📦", "Global Inventory Analysis") {
                val intent = Intent(this, InventoryActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📊", "Global Sales Pattern") {
                val intent = Intent(this, SalesPatternActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("📉", "Global Spend Analysis") {
                val intent = Intent(this, SpendAnalysisActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("💰", "Global Investment Recovery") {
                val intent = Intent(this, InvestmentRecoveryActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("⭐", "Global Staff Performance") {
                val intent = Intent(this, StaffPerformanceActivity::class.java).apply {
                    putExtra("IS_GLOBAL", true)
                    putExtra("SHOP_NAME", "Global Network")
                }
                startActivity(intent)
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        setupDualHeader(binding.toolbar, "Global Comparison ⚖️", "Shop Comparison")
    }

    private fun setupUI() {
        binding.rvShopComparison.layoutManager = LinearLayoutManager(this)
        binding.rvShopComparison.adapter = adapter

        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            viewModel.setFilter(selected, selectedDate.timeInMillis)
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, viewModel.state.value.currentPeriod, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                updateFilter()
            }
        }

        setupCharts()
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(viewModel.state.value.currentPeriod, selectedDate, amount)
        updateFilter()
    }

    private fun updateFilter() {
        viewModel.setFilter(viewModel.state.value.currentPeriod, selectedDate.timeInMillis)
    }

    private fun setupCharts() {
        // Bar Charts Setup
        listOf(binding.barChartSales, binding.barChartProfit).forEach { chart ->
            ChartStyleManager.applyChartStyle(chart, this)
            chart.setDrawValueAboveBar(true)
            chart.setMaxVisibleValueCount(60)
        }

        // Trend Chart Setup
        ChartStyleManager.applyChartStyle(binding.lineChartTrend, this)
        binding.lineChartTrend.apply {
            setDrawGridBackground(false)
            xAxis.position = com.github.mikephil.charting.components.XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            axisRight.isEnabled = false
            legend.isEnabled = true
            legend.textColor = ContextCompat.getColor(this@ShopComparisonActivity, R.color.text_secondary)
        }

        // Pie Chart Setup
        ChartStyleManager.applyChartStyle(binding.pieChartExpenses, this)
        binding.pieChartExpenses.apply {
            setUsePercentValues(true)
            setExtraOffsets(5f, 10f, 5f, 5f)
            dragDecelerationFrictionCoef = 0.95f
            isDrawHoleEnabled = true
            holeRadius = 58f
            transparentCircleRadius = 61f
            setDrawCenterText(true)
            centerText = "Outflow Breakdown"
            setCenterTextColor(ContextCompat.getColor(this@ShopComparisonActivity, R.color.red))
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            animateY(1400)
            
            legend.isEnabled = true
            legend.verticalAlignment = com.github.mikephil.charting.components.Legend.LegendVerticalAlignment.BOTTOM
            legend.horizontalAlignment = com.github.mikephil.charting.components.Legend.LegendHorizontalAlignment.CENTER
            legend.orientation = com.github.mikephil.charting.components.Legend.LegendOrientation.HORIZONTAL
            legend.setDrawInside(false)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.state.collectLatest { state ->
                        // Strict Anti-Flicker: Wait for shop metrics to be calculated
                        val isDataZero = state.shopMetrics.isEmpty() && state.summary.totalSales == 0.0
                        
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.COMPARISON, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }

                        filterAdapter.setSelected(state.currentPeriod, state.currentDate)
                        selectedDate.timeInMillis = state.currentDate
                        updateDateButtonText(state.currentPeriod)

                        val summary = state.summary
                        val locale = Locale.forLanguageTag("en-IN")
                        val currencyFormat = NumberFormat.getCurrencyInstance(locale)
                        
                        binding.tvGlobalSales.text = currencyFormat.format(summary.totalSales)
                        binding.tvGlobalExpenses.text = currencyFormat.format(summary.totalOtherOutflow)
                        binding.tvGlobalSalary.text = currencyFormat.format(summary.totalSalary)
                        binding.tvGlobalFixed.text = currencyFormat.format(summary.totalFixed)
                        binding.tvGlobalProfit.text = currencyFormat.format(summary.totalProfit)
                        
                        binding.tvAvgSales.text = currencyFormat.format(summary.avgDailySales)
                        binding.tvAvgExp.text = currencyFormat.format(summary.avgDailyExp)
                        binding.tvAvgProf.text = currencyFormat.format(summary.avgDailyProfit)
                        binding.tvBestDay.text = summary.bestDay
                        binding.tvSlowestDay.text = summary.slowestDay
                        binding.tvPLDays.text = String.format(locale, "%d / %d", summary.totalProfitableDays, summary.totalLossDays)

                        adapter.submitList(state.shopMetrics)
                        if (state.shopMetrics.isNotEmpty()) {
                            val topShop = state.shopMetrics.first()
                            val worstShop = state.shopMetrics.last()
                            adapter.updateHighlights(topShop.shop.shopId, worstShop.shop.shopId)
                            updateChartsData(state.shopMetrics)
                            updateTrendChart(state.shopTrends, state.dateLabels)
                        }

                        updatePieChart(state.expenseDistribution)
                    }
                }
            }
        }
    }

    private fun updateDateButtonText(period: String) {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(period, selectedDate.timeInMillis)
    }

    private fun updateChartsData(metrics: List<ShopComparisonMetrics>) {
        val shopNames = metrics.map { m ->
            m.shop.name.split(",").lastOrNull()?.trim() ?: m.shop.name
        }
        
        // Sales Bar Chart
        val salesEntries = metrics.mapIndexed { index, m -> BarEntry(index.toFloat(), m.totalSales.toFloat()) }
        val salesDataSet = BarDataSet(salesEntries, "Sales").apply {
            color = ContextCompat.getColor(this@ShopComparisonActivity, R.color.colorPrimary)
            valueTextColor = ContextCompat.getColor(this@ShopComparisonActivity, R.color.text_primary)
            valueTextSize = 10f
            valueFormatter = CurrencyValueFormatter()
        }
        
        binding.barChartSales.apply {
            xAxis.apply {
                valueFormatter = IndexAxisValueFormatter(shopNames)
                labelRotationAngle = 0f
                granularity = 1f
                isGranularityEnabled = true
            }
            data = BarData(salesDataSet)
            animateY(1000)
            invalidate()
        }

        // Profit Bar Chart
        val profitEntries = metrics.mapIndexed { index, m -> BarEntry(index.toFloat(), m.netProfit.toFloat()) }
        val profitDataSet = BarDataSet(profitEntries, "Net Profit").apply {
            colors = metrics.map { if (it.netProfit >= 0) ContextCompat.getColor(this@ShopComparisonActivity, R.color.green) else ContextCompat.getColor(this@ShopComparisonActivity, R.color.red) }
            valueTextColor = ContextCompat.getColor(this@ShopComparisonActivity, R.color.text_primary)
            valueTextSize = 10f
            valueFormatter = CurrencyValueFormatter()
        }

        binding.barChartProfit.apply {
            xAxis.apply {
                valueFormatter = IndexAxisValueFormatter(shopNames)
                labelRotationAngle = 0f
                granularity = 1f
                isGranularityEnabled = true
            }
            data = BarData(profitDataSet)
            animateY(1000)
            invalidate()
        }
    }

    private fun updatePieChart(distribution: List<ExpenseDistribution>) {
        val entries = distribution.map { PieEntry(it.amount.toFloat(), it.category) }
        val dataSet = PieDataSet(entries, "").apply {
            sliceSpace = 3f
            selectionShift = 5f
            colors = listOf(
                ContextCompat.getColor(this@ShopComparisonActivity, R.color.amber),
                ContextCompat.getColor(this@ShopComparisonActivity, R.color.blue),
                ContextCompat.getColor(this@ShopComparisonActivity, R.color.red),
            )
        }

        val data = PieData(dataSet).apply {
            setValueFormatter(PercentFormatter(binding.pieChartExpenses))
            setValueTextSize(11f)
            setValueTextColor(Color.WHITE)
        }

        binding.pieChartExpenses.data = data
        binding.pieChartExpenses.animateY(1200, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)
        binding.pieChartExpenses.invalidate()
    }

    private fun updateTrendChart(trends: List<com.biometric.app.ui.viewmodel.ShopTrend>, labels: List<String>) {
        if (trends.isEmpty()) return

        val dataSets = mutableListOf<LineDataSet>()
        val chartColors = listOf(
            R.color.colorPrimary, R.color.green, R.color.blue, R.color.amber, R.color.red
        )

        trends.forEachIndexed { idx, trend ->
            val set = LineDataSet(trend.dailyProfits, trend.shopName).apply {
                color = ContextCompat.getColor(this@ShopComparisonActivity, chartColors[idx % chartColors.size])
                setCircleColor(color)
                lineWidth = 2f
                circleRadius = 3f
                setDrawValues(false)
                mode = LineDataSet.Mode.CUBIC_BEZIER
                setDrawFilled(true)
                fillColor = color
                fillAlpha = 20
            }
            dataSets.add(set)
        }

        binding.lineChartTrend.apply {
            xAxis.valueFormatter = IndexAxisValueFormatter(labels)
            data = LineData(dataSets as List<com.github.mikephil.charting.interfaces.datasets.ILineDataSet>)
            animateX(1200)
            invalidate()
        }
    }

    class CurrencyValueFormatter : ValueFormatter() {
        override fun getFormattedValue(value: Float): String {
            return if (value >= 1000) "₹%.1fk".format(value / 1000) else "₹%.0f".format(value)
        }
    }
}
