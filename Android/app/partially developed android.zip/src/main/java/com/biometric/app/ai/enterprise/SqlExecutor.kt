package com.biometric.app.ai.enterprise

import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import com.biometric.app.data.entity.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SqlExecutor {

    private var db: SQLiteDatabase? = null

    private fun getDb(): SQLiteDatabase {
        if (db == null) {
            db = SQLiteDatabase.create(null)
            createTables(db!!)
        }
        return db!!
    }

    private fun createTables(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE shops (shopId TEXT PRIMARY KEY, name TEXT, location TEXT, openingDate INTEGER, isActive INTEGER)")
        db.execSQL("CREATE TABLE items (itemId TEXT PRIMARY KEY, name TEXT, category TEXT, globalPrice REAL, isActive INTEGER)")
        db.execSQL("CREATE TABLE orders (orderId TEXT PRIMARY KEY, shopId TEXT, totalAmount REAL, paymentMethod TEXT, status TEXT, closedAt INTEGER)")
        db.execSQL("CREATE TABLE order_items (orderItemId TEXT PRIMARY KEY, orderId TEXT, itemId TEXT, itemName TEXT, quantity REAL, unitPrice REAL, createdAt INTEGER)")
        db.execSQL("CREATE TABLE cashbook (entryId TEXT PRIMARY KEY, shopId TEXT, transactionType TEXT, category TEXT, amount REAL, quantity REAL, unit TEXT, description TEXT, transactionDate INTEGER)")
        db.execSQL("CREATE TABLE employees (employeeId TEXT PRIMARY KEY, name TEXT, shopId TEXT, salaryType TEXT, salaryRate REAL, hireDate INTEGER, isActive INTEGER)")
        db.execSQL("CREATE TABLE attendance (attendanceId TEXT PRIMARY KEY, employeeId TEXT, shopId TEXT, checkInTime INTEGER, checkOutTime INTEGER, type TEXT)")
        db.execSQL("CREATE TABLE fixed_expenses (id TEXT PRIMARY KEY, shopId TEXT, name TEXT, monthlyAmount REAL, isArchived INTEGER)")
        db.execSQL("CREATE TABLE investments (investmentId TEXT PRIMARY KEY, shopId TEXT, itemName TEXT, amount REAL, date INTEGER)")
        db.execSQL("CREATE TABLE inventory (name TEXT, shopId TEXT, totalQuantity REAL, totalCost REAL, lastPrice REAL, unitType TEXT, PRIMARY KEY (name, shopId))")
    }

    suspend fun populateAndExecute(
        sql: String,
        data: Map<String, List<Any>>,
    ): List<Map<String, Any?>> = withContext(Dispatchers.IO) {
        val db = getDb()
        db.beginTransaction()
        try {
            // Clear previous data
            db.execSQL("DELETE FROM shops")
            db.execSQL("DELETE FROM items")
            db.execSQL("DELETE FROM orders")
            db.execSQL("DELETE FROM order_items")
            db.execSQL("DELETE FROM cashbook")
            db.execSQL("DELETE FROM employees")
            db.execSQL("DELETE FROM attendance")
            db.execSQL("DELETE FROM fixed_expenses")
            db.execSQL("DELETE FROM investments")
            db.execSQL("DELETE FROM inventory")

            // Populate tables
            data["shops"]?.filterIsInstance<Shop>()?.forEach {
                db.execSQL("INSERT INTO shops VALUES (?, ?, ?, ?, ?)", arrayOf<Any?>(it.shopId, it.name, it.location, it.openingDate, if (it.isActive) 1 else 0))
            }
            data["items"]?.filterIsInstance<Item>()?.forEach {
                db.execSQL("INSERT INTO items VALUES (?, ?, ?, ?, ?)", arrayOf<Any?>(it.itemId, it.name, it.category, it.globalPrice, if (it.isActive) 1 else 0))
            }
            data["orders"]?.filterIsInstance<Order>()?.forEach {
                db.execSQL("INSERT INTO orders VALUES (?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.orderId, it.shopId, it.totalAmount, it.paymentMethod, it.status, it.closedAt))
            }
            data["order_items"]?.filterIsInstance<OrderItem>()?.forEach {
                db.execSQL("INSERT INTO order_items VALUES (?, ?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.orderItemId, it.orderId, it.itemId, it.itemName, it.quantity, it.unitPrice, it.createdAt))
            }
            data["cashbook"]?.filterIsInstance<Cashbook>()?.forEach {
                db.execSQL("INSERT INTO cashbook VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.entryId, it.shopId, it.transactionType, it.category, it.amount, it.quantity, it.unit, it.description, it.transactionDate))
            }
            data["employees"]?.filterIsInstance<Employee>()?.forEach {
                db.execSQL("INSERT INTO employees VALUES (?, ?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.employeeId, it.name, it.shopId, it.salaryType, it.salaryRate, it.hireDate, if (it.isActive) 1 else 0))
            }
            data["attendance"]?.filterIsInstance<Attendance>()?.forEach {
                db.execSQL("INSERT INTO attendance VALUES (?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.attendanceId, it.employeeId, it.shopId, it.checkInTime, it.checkOutTime, it.type))
            }
            data["fixed_expenses"]?.filterIsInstance<FixedExpense>()?.forEach {
                db.execSQL("INSERT INTO fixed_expenses VALUES (?, ?, ?, ?, ?)", arrayOf<Any?>(it.id, it.shopId, it.name, it.monthlyAmount, if (it.isArchived) 1 else 0))
            }
            data["investments"]?.filterIsInstance<Investment>()?.forEach {
                db.execSQL("INSERT INTO investments VALUES (?, ?, ?, ?, ?)", arrayOf<Any?>(it.investmentId, it.shopId, it.itemName, it.amount, it.date))
            }
            data["inventory"]?.filterIsInstance<InventoryItem>()?.forEach {
                db.execSQL("INSERT INTO inventory VALUES (?, ?, ?, ?, ?, ?)", arrayOf<Any?>(it.name, it.shopId, it.totalQuantity, it.totalCost, it.lastPrice, it.unitType))
            }

            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }

        // Execute query
        val results = mutableListOf<Map<String, Any?>>()
        var cursor: Cursor? = null
        try {
            cursor = db.rawQuery(sql, null)
            if (cursor.moveToFirst()) {
                val columnNames = cursor.columnNames
                do {
                    val row = mutableMapOf<String, Any?>()
                    columnNames.forEachIndexed { index, name ->
                        row[name] = when (cursor.getType(index)) {
                            Cursor.FIELD_TYPE_INTEGER -> cursor.getLong(index)
                            Cursor.FIELD_TYPE_FLOAT -> cursor.getDouble(index)
                            Cursor.FIELD_TYPE_STRING -> cursor.getString(index)
                            Cursor.FIELD_TYPE_BLOB -> cursor.getBlob(index)
                            else -> null
                        }
                    }
                    results.add(row)
                } while (cursor.moveToNext())
            }
        } catch (e: Exception) {
            results.add(mapOf("ERROR" to e.message))
        } finally {
            cursor?.close()
        }
        results
    }

    fun close() {
        db?.close()
        db = null
    }
}
