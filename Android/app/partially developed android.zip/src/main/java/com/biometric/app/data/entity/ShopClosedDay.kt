package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class ShopClosedDay(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = "",
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("date") @set:PropertyName("date")
    var date: Long = 0,
    
    @get:PropertyName("paySalary") @set:PropertyName("paySalary")
    var paySalary: Boolean = false,
    
    @get:PropertyName("reason") @set:PropertyName("reason")
    var reason: String? = null,
    
    @get:PropertyName("affectedEmployeeIds") @set:PropertyName("affectedEmployeeIds")
    var affectedEmployeeIds: List<String> = emptyList()
) : Serializable
