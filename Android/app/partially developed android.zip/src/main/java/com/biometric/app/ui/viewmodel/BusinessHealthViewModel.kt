package com.biometric.app.ui.viewmodel

import android.app.Application
import android.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.DayData
import com.biometric.app.data.ForecastInsight
import com.biometric.app.data.MainRepository
import com.biometric.app.data.RawMetrics
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PredictionEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlin.math.sqrt

data class HealthMetric(
    val label: String,
    val icon: String,
    val score: Int,
    val maxScore: Int,
    val value: String,
    val baselineValue: String,
    val status: String,
    val description: String = "",
)

data class FinancialSnapshot(
    val totalSales: Double = 0.0,
    val totalExpenses: Double = 0.0,
    val totalSalary: Double = 0.0,
    val fixedExpenses: Double = 0.0,
    val netProfit: Double = 0.0,
    val profitMargin: Double = 0.0,
    val expenseRatio: Double = 0.0,
    val salaryRatio: Double = 0.0
)

data class TrendPoint(
    val label: String,
    val icon: String,
    val current: Double,
    val previous: Double,
    val growth: Double,
    val predicted: Double = 0.0
)

data class BusinessHealthState(
    val totalScore: Int = 0,
    val status: String = "N/A",
    val statusColor: Int = Color.GRAY,
    val metrics: List<HealthMetric> = emptyList(),
    val trendPoints: Int = 0,
    val snapshot: FinancialSnapshot = FinancialSnapshot(),
    val trends: List<TrendPoint> = emptyList(),
    val bestDay: String = "N/A",
    val slowestDay: String = "N/A",
    val dayInsight: String = "",
    val riskImpacts: List<String> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val predictionScore: Int = 0,
    val forecast: ForecastInsight = ForecastInsight(),
    val isLoading: Boolean = true
)

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class BusinessHealthViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<BusinessHealthState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        val normalizedPeriod = period.lowercase().replace("-", " ").trim()
        val useMatching = (normalizedPeriod == "up to date") || (normalizedPeriod == "day") || (normalizedPeriod == "daily")

        val currentRange = DateRangeUtil.getRangeForPeriod(period, date, isMatchingDays = useMatching)

        val p1Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -1); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p2Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -2); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }
        val p3Range = run { val c = Calendar.getInstance().apply { timeInMillis = date }; DateRangeUtil.shiftPeriod(period, c, -3); DateRangeUtil.getRangeForPeriod(period, c.timeInMillis, isMatchingDays = useMatching) }

        val p1RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p1Range.second)
        val p2RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p2Range.second)
        val p3RemRange = DateRangeUtil.getRemainingRangeForPeriod(period, p3Range.second)

        val cacheKey = "health_${shopId}_${period}_${currentRange.first}_${currentRange.second}"
        val cached = repository.getListCache<BusinessHealthState>(cacheKey).firstOrNull()

        flow {
            if (cached != null) {
                emit(cached.copy(isLoading = false))
            }

            emitAll(combine(
                repository.getShopMetricsFlow(shopId, currentRange.first, currentRange.second),
                repository.getShopMetricsFlow(shopId, p1Range.first, p1Range.second),
                repository.getShopMetricsFlow(shopId, p2Range.first, p2Range.second),
                repository.getShopMetricsFlow(shopId, p3Range.first, p3Range.second),
                repository.getFullDayWiseDataFlow(shopId, currentRange.first, currentRange.second),
                repository.getCashbookEntriesForPeriod(shopId, currentRange.first, currentRange.second),
                repository.getShopMetricsFlow(shopId, p1RemRange.first, p1RemRange.second),
                repository.getShopMetricsFlow(shopId, p2RemRange.first, p2RemRange.second),
                repository.getShopMetricsFlow(shopId, p3RemRange.first, p3RemRange.second)
            ) { args: Array<Any?> ->
                val curr = args[0] as RawMetrics
                val p1 = args[1] as RawMetrics
                val p2 = args[2] as RawMetrics
                val p3 = args[3] as RawMetrics
                @Suppress("UNCHECKED_CAST") val dayData = args[4] as List<DayData>
                @Suppress("UNCHECKED_CAST") val currentCashbook = args[5] as List<Cashbook>

                val forecast = PredictionEngine.calculateForecast(
                    curr, p1, p2, p3
                )

                val healthMetrics = mutableListOf<HealthMetric>()

                // 1. Sales Performance (25%) - Compare vs Accurate Past (P)
                val salesRatio = if (forecast.pastValue.sales > 0) curr.sales / forecast.pastValue.sales else 1.0
                val salesScore = when {
                    salesRatio >= 1.05 -> 25
                    salesRatio >= 0.95 -> 22
                    salesRatio >= 0.85 -> 18
                    salesRatio >= 0.70 -> 12
                    else -> 8
                }
                healthMetrics.add(
                    HealthMetric(
                        "Sales Performance", "📈", salesScore, 25,
                        String.format(Locale.getDefault(), "₹%.0f", curr.sales),
                        String.format(Locale.getDefault(), "Past ₹%.0f", forecast.pastValue.sales),
                        getStatus(salesScore, 25), "vs previous period total"
                    )
                )

                // 2. Profit Margin (25%)
                val margin = if (curr.sales > 0) curr.profit / curr.sales else 0.0
                val baselineMargin = if (forecast.pastValue.sales > 0) forecast.pastValue.profit / forecast.pastValue.sales else 0.0
                val marginScore = (margin.coerceIn(0.0, 0.5) / 0.5 * 25).toInt()
                healthMetrics.add(HealthMetric("Profit Margin", "💰", marginScore, 25,
                    String.format(Locale.getDefault(), "%.1f%%", margin * 100),
                    String.format(Locale.getDefault(), "Past %.1f%%", baselineMargin * 100),
                    getStatus(marginScore, 25)))

                // 3. Expense Control (20%)
                val expRatio = if (curr.sales > 0) curr.expense / curr.sales else 1.0
                val expScore = ((1.0 - expRatio.coerceIn(0.0, 0.6)) / 1.0 * 20).toInt()
                healthMetrics.add(HealthMetric("Expense Control", "🛒", expScore, 20,
                    String.format(Locale.getDefault(), "%.1f%%", expRatio * 100),
                    "Limit 60%", getStatus(expScore, 20)))

                // 4. Salary Efficiency (15%)
                val salRatio = if (curr.sales > 0) curr.salary / curr.sales else 1.0
                val salScore = when {
                    salRatio <= 0.15 -> 15
                    salRatio <= 0.25 -> 12
                    salRatio <= 0.35 -> 8
                    else -> 4
                }
                healthMetrics.add(HealthMetric("Salary Efficiency", "👤", salScore, 15,
                    String.format(Locale.getDefault(), "%.1f%%", salRatio * 100),
                    String.format(Locale.getDefault(), "Past %.1f%%", (if (forecast.pastValue.sales > 0) forecast.pastValue.salary / forecast.pastValue.sales else 0.0) * 100),
                    getStatus(salScore, 15)))

                // 5. Sales Stability (15%)
                val stabilityScore = calculateStabilityScore(currentRange.first, currentRange.second, currentCashbook)
                healthMetrics.add(HealthMetric("Sales Stability", "⚖️", stabilityScore, 15, "Consistency", "Target 15%", getStatus(stabilityScore, 15)))

                val totalScore = healthMetrics.sumOf { it.score }.coerceIn(0, 100)

                // Compare score vs previous period (P1)
                val pastTotalScore = calculateScoreForMetrics(p1, p1.sales)

                val snapshot = FinancialSnapshot(
                    totalSales = curr.sales,
                    totalExpenses = curr.expense + curr.salary + curr.fixed,
                    totalSalary = curr.salary,
                    fixedExpenses = curr.fixed,
                    netProfit = curr.profit,
                    profitMargin = margin * 100,
                    expenseRatio = expRatio * 100,
                    salaryRatio = salRatio * 100
                )

                val trends = listOf(
                    TrendPoint("Sales", "📈", curr.sales, forecast.pastValue.sales, calculateGrowth(curr.sales, forecast.pastValue.sales), forecast.aiExpected.sales),
                    TrendPoint("Expenses", "💸", snapshot.totalExpenses, (forecast.pastValue.expense + forecast.pastValue.salary + forecast.pastValue.fixed), calculateGrowth(snapshot.totalExpenses, (forecast.pastValue.expense + forecast.pastValue.salary + forecast.pastValue.fixed)), forecast.aiExpected.expense + forecast.aiExpected.salary + forecast.aiExpected.fixed),
                    TrendPoint("Profit", "💎", curr.profit, forecast.pastValue.profit, calculateGrowth(curr.profit, forecast.pastValue.profit), forecast.aiExpected.profit)
                )

                val predictedScore = calculateScoreForMetrics(forecast.aiExpected, forecast.pastValue.sales)

                val slowest = dayData.asSequence().filter { it.totalIn > 0 }.minByOrNull { it.totalIn }
                val weakDayName = slowest?.let { SimpleDateFormat("EEEE", Locale.getDefault()).format(it.calendar.time) } ?: ""
                val sdfDayMonth = SimpleDateFormat("dd MMM", Locale.getDefault())

                val result = BusinessHealthState(
                    totalScore = totalScore,
                    status = if (totalScore >= 85) "EXCELLENT" else if (totalScore >= 70) "GOOD" else if (totalScore >= 50) "WARNING" else "RISK",
                    metrics = healthMetrics,
                    trendPoints = totalScore - pastTotalScore,
                    snapshot = snapshot,
                    trends = trends,
                    bestDay = dayData.maxByOrNull { it.totalIn }?.let { sdfDayMonth.format(it.calendar.time) } ?: "N/A",
                    slowestDay = slowest?.let { sdfDayMonth.format(it.calendar.time) } ?: "N/A",
                    dayInsight = if (weakDayName.isNotEmpty()) "Low performance on ${weakDayName}s affecting health" else "",
                    predictionScore = predictedScore,
                    isLoading = false
                )

                repository.saveListCache(cacheKey, listOf(result))
                result
            }.onStart {
                // UNIFORM LOADING: Only show loading if we don't have cached data
                if (cached == null) {
                    emit(BusinessHealthState(isLoading = true))
                } else {
                    emit(cached.copy(isLoading = true)) // Keep cached data but set loading true
                }
            })
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), BusinessHealthState())

    fun loadHealthScore(shopId: String, period: String, date: Long) {
        _params.value = Triple(shopId, period, date)
    }

    private fun calculateScoreForMetrics(m: RawMetrics, baselineSales: Double): Int {
        val sRatio = if (baselineSales > 0) m.sales / baselineSales else 1.0
        val sScore = when { sRatio >= 1.05 -> 25; sRatio >= 0.95 -> 22; sRatio >= 0.85 -> 18; sRatio >= 0.70 -> 12; else -> 8 }
        val margin = if (m.sales > 0) m.profit / m.sales else 0.0
        val mScore = (margin.coerceIn(0.0, 0.5) / 0.5 * 25).toInt()
        val eRatio = if (m.sales > 0) m.expense / m.sales else 1.0
        val eScore = ((1.0 - eRatio.coerceIn(0.0, 0.6)) / 1.0 * 20).toInt()
        val saRatio = if (m.sales > 0) m.salary / m.sales else 1.0
        val saScore = ((1.0 - saRatio.coerceIn(0.0, 0.4)) / 1.0 * 15).toInt()
        return sScore + mScore + eScore + saScore + 10
    }

    private fun calculateGrowth(curr: Double, prev: Double): Double = if (prev == 0.0) 0.0 else ((curr - prev) / kotlin.math.abs(prev)) * 100

    private fun calculateStabilityScore(start: Long, end: Long, periodCashbook: List<Cashbook>): Int {
        val inEntries = periodCashbook.filter { it.transactionDate in start..end && it.transactionType == "IN" }
        if (inEntries.size < 2) return 10
        val sdf = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
        val dailySales = inEntries.groupBy { sdf.format(Date(it.transactionDate)) }.mapValues { it.value.sumOf { e -> e.amount } }.values
        val avg = dailySales.average()
        val cv = if (avg > 0) sqrt(dailySales.map { (it - avg) * (it - avg) }.average()) / avg else 1.0
        return when { cv <= 0.15 -> 15; cv <= 0.3 -> 12; cv <= 0.5 -> 8; else -> 5 }
    }

    private fun getStatus(score: Int, max: Int): String { val ratio = score.toDouble() / max; return when { ratio >= 0.85 -> "Excellent"; ratio >= 0.7 -> "Good"; ratio >= 0.5 -> "Warning"; else -> "Risk" } }
}
