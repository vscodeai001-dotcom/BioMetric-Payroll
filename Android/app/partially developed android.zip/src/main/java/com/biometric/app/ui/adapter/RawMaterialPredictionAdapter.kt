package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ItemRawMaterialPredictionBinding
import com.biometric.app.ui.viewmodel.RawMaterialPredictionItem
import com.biometric.app.ui.viewmodel.RawMaterialPriority
import java.util.concurrent.TimeUnit

class RawMaterialPredictionAdapter : ListAdapter<RawMaterialPredictionItem, RawMaterialPredictionAdapter.ViewHolder>(DiffCallback) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        return ViewHolder(
            ItemRawMaterialPredictionBinding.inflate(
                LayoutInflater.from(parent.context),
                parent,
                false
            )
        )
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(getItem(position))
    }

    class ViewHolder(private val binding: ItemRawMaterialPredictionBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: RawMaterialPredictionItem) {
            binding.tvItemName.text = item.itemName
            binding.tvEmoji.text = item.emoji
            
            val daysAgo = item.daysPassed
            binding.tvPurchaseInfo.text = if (daysAgo == 0) "Bought today" else "Last bought $daysAgo days ago"
            binding.tvGapInfo.text = "Every ${item.avgGapDays} days"
            
            binding.tvPriorityTag.text = item.priority.name
            
            val context = binding.root.context
            when (item.priority) {
                RawMaterialPriority.URGENT -> {
                    binding.tvPriorityTag.setBackgroundResource(R.drawable.tag_bg_red)
                    binding.tvPriorityTag.text = "URGENT"
                }
                RawMaterialPriority.MEDIUM -> {
                    binding.tvPriorityTag.setBackgroundResource(R.drawable.tag_bg_amber)
                    binding.tvPriorityTag.text = "MEDIUM"
                }
                RawMaterialPriority.SAFE -> {
                    binding.tvPriorityTag.setBackgroundResource(R.drawable.tag_bg_green)
                    binding.tvPriorityTag.text = "SAFE"
                }
            }
        }
    }

    companion object DiffCallback : DiffUtil.ItemCallback<RawMaterialPredictionItem>() {
        override fun areItemsTheSame(oldItem: RawMaterialPredictionItem, newItem: RawMaterialPredictionItem): Boolean {
            return oldItem.itemName == newItem.itemName
        }

        override fun areContentsTheSame(oldItem: RawMaterialPredictionItem, newItem: RawMaterialPredictionItem): Boolean {
            return oldItem == newItem
        }
    }
}
