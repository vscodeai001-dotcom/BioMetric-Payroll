package com.biometric.app.domain

import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Employee
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.firstOrNull
import kotlinx.coroutines.withContext
import javax.inject.Inject

class GetSalaryReportUseCase @Inject constructor(
    private val repository: MainRepository
) {
    suspend fun execute(
        shopId: String?,
        start: Long,
        end: Long,
        includeBonus: Boolean = true,
        bonusSet: Set<String> = emptySet()
    ): Double = withContext(Dispatchers.Default) {
        val manualSalaries = repository.getCashbookEntriesForPeriod(shopId, start, end).firstOrNull()?.filter {
            it.transactionType == "OUT" &&
            (it.category.contains("SALARY", ignoreCase = true) || (it.description?.contains("SALARY", ignoreCase = true) == true)) &&
            it.referenceId == null
        }?.sumOf { it.amount } ?: 0.0

        val employees = repository.getShopEmployees(shopId).firstOrNull() ?: emptyList()
        if (employees.isEmpty()) return@withContext manualSalaries

        var totalStaffLiability = manualSalaries
        
        coroutineScope {
            val deferredStats = employees.map { employee ->
                async {
                    val stats = repository.getEmployeeStatsFlow(employee, start, end).firstOrNull()
                    if (stats != null) {
                        stats.getTotalCost()
                    } else 0.0
                }
            }
            totalStaffLiability += deferredStats.awaitAll().sum()
        }
        
        totalStaffLiability
    }
}
