package com.biometric.app.ai

import com.google.ai.client.generativeai.GenerativeModel
import java.util.*

class GeminiService(private val apiKey: String) {

    private val modelNames = listOf("gemini-1.5-flash-latest", "gemini-1.5-flash", "gemini-pro")

    suspend fun generateResponse(
        userQuery: String,
        intent: AiIntent,
        bundle: BusinessDataBundle,
        insights: List<BusinessInsight>
    ): String {
        val isKeyPlaceholder = apiKey.isBlank() || apiKey.contains("YOUR_API_KEY")
        if (isKeyPlaceholder) return generateFallbackResponse(intent, bundle, insights)

        val prompt = buildPrompt(userQuery, intent, bundle, insights)
        
        for (modelName in modelNames) {
            try {
                val model = GenerativeModel(modelName = modelName, apiKey = apiKey)
                val response = model.generateContent(prompt)
                if (response.text != null) return response.text!!
            } catch (e: Exception) {
                android.util.Log.e("BeastAI", "Model $modelName failed, trying next...")
            }
        }

        return generateFallbackResponse(intent, bundle, insights)
    }

    private fun buildPrompt(
        query: String,
        intent: AiIntent,
        bundle: BusinessDataBundle,
        insights: List<BusinessInsight>
    ): String {
        val m = bundle.metrics
        val pm = bundle.previousMetrics
        
        val days = listOf("monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday")
        val dayQuery = days.find { query.lowercase().contains(it) }
        val dayInfo = if (dayQuery != null) {
            val filtered = com.biometric.app.util.NaturalLanguageEngine.filterLedger(bundle.cashbookEntries, dayQuery)
            if (filtered.isNotEmpty()) {
                val total = filtered.sumOf { it.amount }
                "\nData for all ${dayQuery.uppercase()}s in this period: Found ${filtered.size} records totaling ₹$total."
            } else ""
        } else ""

        val entitiesRaw = bundle.extraContext["entities"]
        val entities = if (entitiesRaw is List<*>) entitiesRaw.filterIsInstance<String>() else emptyList()
        val subjectInfo = if (entities.isNotEmpty()) {
            val subject = entities.first()
            val filtered = com.biometric.app.util.NaturalLanguageEngine.filterLedger(bundle.cashbookEntries, subject)
            if (filtered.isNotEmpty()) {
                val total = filtered.sumOf { it.amount }
                "\nSpecific Data for '$subject': Found ${filtered.size} records totaling ₹$total. Breakdown: " + 
                filtered.take(5).joinToString { "${it.category} (₹${it.amount})" }
            } else ""
        } else ""

        val contextStr = """
            Shop Data for ${bundle.periodLabel}:
            - Sales: ₹${m.sales}
            - Profit: ₹${m.profit}
            - Expenses: ₹${m.expense}
            - Staff Salary: ₹${m.salary}
            - Fixed Costs: ₹${m.fixed}
            $dayInfo
            $subjectInfo
            
            Previous Period (${bundle.previousPeriodLabel}):
            - Sales: ₹${pm?.sales ?: 0.0}
            - Profit: ₹${pm?.profit ?: 0.0}
            
            Top Items: ${bundle.topItems.joinToString { "${it.first} (${it.second.toInt()} units)" }}
            Top Expenses: ${bundle.topExpenses.joinToString { "${it.first} (₹${it.second.toInt()})" }}
            
            Key Insights:
            ${insights.joinToString("\n") { "- ${it.title}: ${it.description} Reason: ${it.reason ?: "N/A"}" }}
        """.trimIndent()

        return """
            You are "Beast AI", a professional and friendly Business Intelligence Assistant for Biometric Payroll.
            Your goal is to help the shop owner understand their data, find trends, and give actionable advice.
            
            User Question: "$query"
            Detected Intent: $intent
            
            Business Context:
            $contextStr
            
            Rules:
            1. ONLY answer questions related to Biometric Payroll data, business, sales, staff, and analytics. 
            2. If the user asks a non-business question (e.g., about movies, jokes, or generic facts), politely decline and state that you are an AI Business Advisor for TeaShopPOS.
            3. Be conversational and human-like (ChatGPT/Gemini style).
            4. Explain "Why" something happened if possible using the context.
            5. Give actionable recommendations.
            6. If data is missing (₹0), explain what you searched and suggest what might be wrong or what else they can check.
            7. Use bullet points for readability.
            8. Keep it concise but detailed where it matters.
            
            Generate the response in natural language:
        """.trimIndent()
    }

    private fun generateFallbackResponse(
        intent: AiIntent,
        bundle: BusinessDataBundle,
        insights: List<BusinessInsight>
    ): String {
        val sb = StringBuilder()
        val m = bundle.metrics
        val period = bundle.periodLabel

        // 1. Logic for Empty or Minimal Data
        val hasMinimalData = m.sales > 0 || m.expense > 0 || bundle.cashbookEntries.isNotEmpty()
        
        if (!hasMinimalData) {
            sb.append("I looked into your records for **$period**, but I couldn't find any transactions yet. 🔍\n\n")
            sb.append("**What I searched:**\n")
            sb.append("• Sales bills (POS)\n")
            sb.append("• Cashbook entries (In/Out)\n")
            sb.append("• Staff attendance logs\n\n")
            sb.append("Try checking a broader date range or ensuring your data is synchronized.")
            return sb.toString()
        }

        // 2. Adaptive Header based on Intent
        when (intent) {
            AiIntent.ATTENDANCE_QUERY -> sb.append("Analysis of **Staff Attendance** for **$period**: 👤\n\n")
            AiIntent.SALARY_QUERY -> sb.append("Report on **Salary Liabilities** for **$period**: 💰\n\n")
            AiIntent.STOCK_QUERY -> sb.append("Status of **Stock & Inventory** for **$period**: 📦\n\n")
            AiIntent.INVESTMENT_QUERY -> sb.append("Update on **Investment Recovery** for **$period**: 🔄\n\n")
            AiIntent.HEALTH_QUERY -> sb.append("Review of **Business Health** for **$period**: 🏥\n\n")
            AiIntent.PROFIT_ANALYSIS, AiIntent.PROFIT_SUMMARY -> sb.append("Deep dive into **Profit & Loss** for **$period**: 💹\n\n")
            else -> sb.append("Business Intelligence Summary for **$period**: 📊\n\n")
        }

        // 3. CORE STATS (Dynamic color coding)
        sb.append(String.format(Locale.getDefault(), "• **Total Sales**: ₹%.0f\n", m.sales))
        val profitColor = if (m.profit >= 0) "#4ADE80" else "#FCA5A5"
        sb.append(String.format(Locale.getDefault(), "• **Net Result**: <font color='%s'>₹%.0f</font> (%s)\n\n", 
            profitColor, m.profit, if (m.profit >= 0) "Profit" else "Loss"))

        // 4. ENTITY-SPECIFIC FALLBACK (e.g. Milk, Grocery)
        val entitiesRaw = bundle.extraContext["entities"]
        if (entitiesRaw is List<*>) {
            val entities = entitiesRaw.filterIsInstance<String>()
            if (entities.isNotEmpty()) {
                val subject = entities.first().uppercase(Locale.getDefault())
                val filtered = com.biometric.app.util.NaturalLanguageEngine.filterLedger(bundle.cashbookEntries, subject)
                if (filtered.isNotEmpty()) {
                    val total = filtered.sumOf { it.amount }
                    sb.append(String.format(Locale.getDefault(), "Regarding **%s**: I found %d records totaling **₹%.0f**. I've listed the breakdown in the table below. 👇\n\n", 
                        subject, filtered.size, total))
                }
            }
        }

        // 5. INSIGHTS (The primary reasoning layer)
        if (insights.isNotEmpty()) {
            sb.append("**Key Business Observations:**\n")
            insights.forEach { insight ->
                val emoji = when(insight.impact) {
                    ImpactLevel.POSITIVE -> "✅"
                    ImpactLevel.NEGATIVE -> "⚠️"
                    else -> "ℹ️"
                }
                sb.append("• $emoji **${insight.title}**: ${insight.description}\n")
                insight.reason?.let { sb.append("  - _Reason_: $it\n") }
                insight.recommendation?.let { sb.append("  - 💡 _Recommendation_: $it\n") }
            }
        } else {
            sb.append("I've analyzed your data and everything looks stable. No critical risks or major anomalies were detected for this period.")
        }

        return sb.toString()
    }
}
