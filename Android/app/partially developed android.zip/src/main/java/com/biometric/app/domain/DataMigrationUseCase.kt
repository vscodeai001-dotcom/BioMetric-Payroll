package com.biometric.app.domain

import com.biometric.app.data.MainRepository
import com.biometric.app.sync.MonthSummary
import kotlinx.coroutines.flow.first
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

class DataMigrationUseCase @Inject constructor(
    private val repository: MainRepository
) {
    suspend fun migrateToSummaries() {
        val shops = repository.getAllShops().first()
        val sdf = SimpleDateFormat("yyyy_MM", Locale.getDefault())

        shops.forEach { shop ->
            val orders = repository.getOrdersWithItemsForPeriod(shop.shopId, 0, Long.MAX_VALUE).first()
            val cashbook = repository.getCashbookEntriesForPeriod(shop.shopId, 0, Long.MAX_VALUE).first()
            
            val summaries = mutableMapOf<String, MonthSummary>()

            orders.forEach { orderWithItems ->
                val order = orderWithItems.order
                order.closedAt?.let { timestamp ->
                    val monthKey = sdf.format(Date(timestamp))
                    val summary = summaries.getOrPut(monthKey) { MonthSummary() }
                    
                    summary.totalSales += order.totalAmount
                    if (order.paymentMethod == "ONLINE") summary.qrSales += order.totalAmount
                    else if (order.paymentMethod == "CASH") summary.cashSales += order.totalAmount
                    else if (order.paymentMethod == "SPLIT") {
                        summary.cashSales += order.cashAmount
                        summary.qrSales += order.onlineAmount
                    }
                }
            }

            cashbook.forEach { entry ->
                if (entry.transactionType == "OUT") {
                    val monthKey = sdf.format(Date(entry.transactionDate))
                    val summary = summaries.getOrPut(monthKey) { MonthSummary() }
                    summary.totalExpenses += entry.amount
                }
            }

            summaries.forEach { (monthKey, summary) ->
                repository.firebaseSync.updateMonthSummaryDirect(shop.shopId, monthKey, summary)
            }
        }
    }
}
