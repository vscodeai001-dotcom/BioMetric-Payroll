package com.biometric.app.ui.adapter

import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.data.entity.ShopMenuItem
import com.biometric.app.databinding.ItemMenuGridBinding

class MenuAdapter(private val onItemClick: (ShopMenuItem) -> Unit) :
    ListAdapter<ShopMenuItem, MenuAdapter.MenuViewHolder>(MenuDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MenuViewHolder {
        val binding = ItemMenuGridBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return MenuViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MenuViewHolder, position: Int) {
        val isPopular = position < 3 && getItem(position).salesCount > 0
        holder.bind(getItem(position), isPopular)
    }

    inner class MenuViewHolder(private val binding: ItemMenuGridBinding) :
        RecyclerView.ViewHolder(binding.root) {
        fun bind(menuItem: ShopMenuItem, isPopular: Boolean) {
            val context = binding.root.context
            binding.tvItemName.text = menuItem.item.name
            binding.tvItemPrice.text = context.getString(R.string.currency_format, menuItem.finalPrice)
            binding.tvPopularBadge.visibility = if (isPopular) android.view.View.VISIBLE else android.view.View.GONE
            
            binding.root.setOnClickListener {
                it.performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
                onItemClick(menuItem)
            }
        }
    }

    class MenuDiffCallback : DiffUtil.ItemCallback<ShopMenuItem>() {
        override fun areItemsTheSame(oldItem: ShopMenuItem, newItem: ShopMenuItem): Boolean {
            return oldItem.item.itemId == newItem.item.itemId
        }

        override fun areContentsTheSame(oldItem: ShopMenuItem, newItem: ShopMenuItem): Boolean {
            return oldItem == newItem
        }
    }
}
