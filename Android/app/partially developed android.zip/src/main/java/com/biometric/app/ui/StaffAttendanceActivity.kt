package com.biometric.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.ViewGroup
import androidx.activity.OnBackPressedCallback
import androidx.activity.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.data.entity.Attendance
import com.biometric.app.data.entity.Employee
import com.biometric.app.databinding.ActivityStaffAttendanceBinding
import com.biometric.app.databinding.ItemFinanceRowBinding
import com.biometric.app.ui.viewmodel.StaffViewModel
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import android.view.View
import java.text.SimpleDateFormat
import java.util.*

@AndroidEntryPoint
class StaffAttendanceActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityStaffAttendanceBinding
    private val viewModel: StaffViewModel by viewModels()
    private var employee: Employee? = null
    private var viewState = ViewState.MONTHS // MONTHS or DAYS

    enum class ViewState { MONTHS, DAYS }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityStaffAttendanceBinding.inflate(layoutInflater)
        setContentView(binding.root)

        @Suppress("DEPRECATION")
        employee = intent.getSerializableExtra("EMPLOYEE") as? Employee
        if (employee == null) return finish()

        setupUI()
        setupOnBackPressed()
        showMonths()
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { 
            if (viewState == ViewState.DAYS) showMonths()
            else finish()
        }
        updateToolbarTitle(employee?.name ?: "Staff")
        binding.rvAttendance.layoutManager = LinearLayoutManager(this)

        // REQUIREMENT: Instant data display. Loader only shows if genuinely waiting for core data.
        binding.contentLayout.visibility = View.VISIBLE
        PremiumLoader.hide(binding.brewingLoader)
    }

    private fun updateToolbarTitle(name: String) {
        setupDualHeader(binding.toolbar, name, "Attendance Logs")
    }

    private fun setupOnBackPressed() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (viewState == ViewState.DAYS) {
                    showMonths()
                } else {
                    isEnabled = false
                    onBackPressedDispatcher.onBackPressed()
                }
            }
        })
    }

    private fun showMonths() {
        viewState = ViewState.MONTHS
        binding.tvSelectionTitle.text = "Select Month"
        
        val months = (0..11).map { monthIndex ->
            val cal = Calendar.getInstance().apply { set(Calendar.MONTH, monthIndex) }
            SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(cal.time)
        }.reversed()

        binding.rvAttendance.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, v: Int) = object : RecyclerView.ViewHolder(
                ItemFinanceRowBinding.inflate(LayoutInflater.from(p.context), p, false).root
            ) {}
            override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                val monthName = months[pos]
                val b = ItemFinanceRowBinding.bind(h.itemView)
                b.tvParticulars.text = monthName
                b.tvCredit.text = ">"
                b.root.setOnClickListener {
                    val cal = Calendar.getInstance()
                    val targetMonth = 11 - pos // Since we reversed
                    cal.set(Calendar.MONTH, targetMonth)
                    showDays(cal)
                }
            }
            override fun getItemCount() = months.size
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("👤", "Add Staff") {
                AddStaffDialogFragment.newInstance().show(supportFragmentManager, AddStaffDialogFragment.TAG)
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("👤", "Add Staff") {
                AddStaffDialogFragment.newInstance().show(supportFragmentManager, AddStaffDialogFragment.TAG)
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, viewModel.sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showDays(cal: Calendar) {
        viewState = ViewState.DAYS
        val displayMonth = cal.clone() as Calendar
        
        cal.set(Calendar.DAY_OF_MONTH, 1)
        cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
        val start = cal.timeInMillis
        
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        cal.set(Calendar.HOUR_OF_DAY, 23); cal.set(Calendar.MINUTE, 59); cal.set(Calendar.SECOND, 59); cal.set(Calendar.MILLISECOND, 999)
        val end = cal.timeInMillis

        binding.tvSelectionTitle.text = "Log for ${SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(displayMonth.time)}"

        lifecycleScope.launch {
            viewModel.getAttendanceRecords(employee!!.employeeId, start, end).collectLatest { records: List<Attendance> ->
                if (viewState != ViewState.DAYS) return@collectLatest
                
                binding.rvAttendance.adapter = object : RecyclerView.Adapter<RecyclerView.ViewHolder>() {
                    override fun onCreateViewHolder(p: ViewGroup, v: Int) = object : RecyclerView.ViewHolder(
                        ItemFinanceRowBinding.inflate(LayoutInflater.from(p.context), p, false).root
                    ) {}
                    override fun onBindViewHolder(h: RecyclerView.ViewHolder, pos: Int) {
                        val r = records[pos]
                        val b = ItemFinanceRowBinding.bind(h.itemView)
                        val df = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault())
                        val outTime = if (r.checkOutTime != null) SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(r.checkOutTime!!)) else "IN"
                        b.tvDate.text = df.format(Date(r.checkInTime))
                        b.tvParticulars.text = "%s to %s".format(df.format(Date(r.checkInTime)), outTime)
                        b.tvCredit.text = "%.1fh (%s)".format(r.hoursWorked, r.type)

                        b.root.setOnClickListener {
                            ManualAttendanceDialogFragment.newInstance(employee!!, r)
                                .show(supportFragmentManager, ManualAttendanceDialogFragment.TAG)
                        }
                    }
                    override fun getItemCount() = records.size
                }
            }
        }
    }
}