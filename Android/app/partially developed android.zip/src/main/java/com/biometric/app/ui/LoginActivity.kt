package com.biometric.app.ui

import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.util.Log
import android.view.View
import android.widget.Toast
import androidx.activity.OnBackPressedCallback
import androidx.appcompat.app.AlertDialog
import androidx.core.content.edit
import androidx.lifecycle.lifecycleScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.UserProfile
import com.biometric.app.data.entity.UserRole
import com.biometric.app.data.repository.AuthRepository
import com.biometric.app.databinding.ActivityLoginBinding
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.MotionManager
import com.biometric.app.util.SignatureHelper
import com.google.firebase.FirebaseException
import com.google.firebase.auth.*
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class LoginActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityLoginBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var biometricAuthManager: BiometricAuthManager
    
    private var verificationId: String? = null
    private var loginMode = LoginMode.IDENTIFY
    private var identifiedProfile: UserProfile? = null
    private var identifiedPhone: String? = null

    enum class LoginMode { IDENTIFY, OTP, PASSWORD }

    @Inject lateinit var repository: MainRepository
    @Inject lateinit var authRepository: AuthRepository
    @Inject lateinit var sharedViewModel: SharedViewModel

    override fun isSecurityBypass(): Boolean = true

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()

        setupUI()
        setupListeners()
        
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (loginMode != LoginMode.IDENTIFY) {
                    resetLogin()
                } else {
                    finishAffinity()
                }
            }
        })

        biometricAuthManager = BiometricAuthManager(
            context = this,
            activity = this,
            onAuthSuccess = { 
                markAsVerified()
                getSharedPreferences("auth_prefs", MODE_PRIVATE).edit(commit = true) {
                    putBoolean("is_locked", false)
                    putLong("last_active_time", System.currentTimeMillis())
                }
                proceedToMain() 
            },
            onAuthError = { errString ->
                HapticUtil.vibrateError(binding.root)
                // If user cancels or clicks "Use Account Password", show the login fields
                if (loginMode == LoginMode.IDENTIFY && binding.llBiometricLogin.visibility == View.VISIBLE) {
                    resetLogin()
                }
                Toast.makeText(this, errString, Toast.LENGTH_SHORT).show()
            }
        )

        val hasLoggedInBefore = getSharedPreferences("auth_prefs", MODE_PRIVATE).getBoolean("has_logged_in_before", false)
        if (auth.currentUser != null && hasLoggedInBefore) {
            if (biometricAuthManager.canAuthenticate()) {
                showBiometricLogin()
            } else {
                // SECURITY NOT ENABLED ON DEVICE: Skip unlock screen if already logged in once
                markAsVerified()
                getSharedPreferences("auth_prefs", MODE_PRIVATE).edit(commit = true) {
                    putBoolean("is_locked", false)
                    putLong("last_active_time", System.currentTimeMillis())
                }
                proceedToMain()
            }
        }
    }

    private fun setupUI() {
        MotionManager.applyTouchScale(binding.btnLoginAction)
        MotionManager.applyTouchScale(binding.btnReset)
        MotionManager.applyTouchScale(binding.btnFingerprint)
    }

    private fun setupListeners() {
        binding.btnLoginAction.setOnClickListener {
            handleLoginAction()
        }

        binding.btnReset.setOnClickListener {
            resetLogin()
        }

        binding.btnFingerprint.setOnClickListener {
            if (biometricAuthManager.canAuthenticate()) {
                biometricAuthManager.authenticate()
            }
        }
    }

    private fun handleLoginAction() {
        val input = binding.etUserId.text.toString().trim().replace(" ", "")
        val dynamicInput = binding.etDynamic.text.toString().trim()

        if (input.isEmpty()) {
            Toast.makeText(this, "Please enter your ID or Mobile Number", Toast.LENGTH_SHORT).show()
            return
        }

        when (loginMode) {
            LoginMode.IDENTIFY -> identifyUser(input)
            LoginMode.OTP -> {
                if (dynamicInput.isNotEmpty()) verifyOtp(dynamicInput)
                else Toast.makeText(this, "Enter OTP", Toast.LENGTH_SHORT).show()
            }
            LoginMode.PASSWORD -> {
                if (dynamicInput.isNotEmpty()) handleEmployeeLogin(input, dynamicInput)
                else Toast.makeText(this, "Enter Password", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun identifyUser(rawInput: String) {
        val input = rawInput.replace(" ", "").replace("-", "")
        
        lifecycleScope.launch {
            try {
                setLoading(true)
                // Ensure anonymous sign-in to query database profiles
                if (auth.currentUser == null) {
                    try { auth.signInAnonymously().await() } catch (e: Exception) { Log.e("Login", "Anon Auth failed", e) }
                }

                // 1. Hardcoded Super Admin check (Always triggers OTP)
                if (input == "9629881598" || input == "+919629881598") {
                    val phone = if (input.startsWith("+")) input else "+91$input"
                    startOtpFlow(phone)
                    return@launch
                }

                // 2. Try to find profile by Phone
                val profileByPhone = authRepository.getProfileByPhone(input)
                if (profileByPhone != null && (profileByPhone.isAdmin() || profileByPhone.isSuperAdmin())) {
                    identifiedProfile = profileByPhone
                    val phone = if (input.startsWith("+")) input else "+91$input"
                    startOtpFlow(phone)
                    return@launch
                }

                // 3. Try to find profile by Employee ID
                val profileByEmpId = authRepository.getProfileByEmployeeId(input)
                if (profileByEmpId != null) {
                    identifiedProfile = profileByEmpId
                    startPasswordFlow()
                    return@launch
                }

                // 4. Fallback based on format
                if ((input.length == 10 && input.all { it.isDigit() }) || input.startsWith("+91")) {
                    startOtpFlow(if (input.startsWith("+")) input else "+91$input")
                } else {
                    startPasswordFlow()
                }

            } catch (e: Exception) {
                Log.e("Login", "Identification failed", e)
                val fallbackPhone = if (input.length == 10) "+91$input" else input
                if (fallbackPhone.startsWith("+")) startOtpFlow(fallbackPhone) else startPasswordFlow()
            } finally {
                setLoading(false)
            }
        }
    }

    private fun startOtpFlow(phone: String) {
        identifiedPhone = phone
        loginMode = LoginMode.OTP
        binding.tilUserId.isEnabled = false
        binding.btnReset.visibility = View.VISIBLE
        binding.btnLoginAction.text = "Requesting OTP..."
        binding.btnLoginAction.isEnabled = false
        
        startPhoneNumberVerification(phone)
    }

    private fun startPasswordFlow() {
        loginMode = LoginMode.PASSWORD
        binding.tilDynamic.visibility = View.VISIBLE
        binding.tilDynamic.hint = "Enter Password 🔑"
        binding.etDynamic.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        binding.tilUserId.isEnabled = false
        binding.btnReset.visibility = View.VISIBLE
        binding.btnLoginAction.text = "Login 🧑‍💼"
    }

    private fun resetLogin() {
        loginMode = LoginMode.IDENTIFY
        binding.tilUserId.isEnabled = true
        binding.tilDynamic.visibility = View.GONE
        binding.etDynamic.setText("")
        binding.btnReset.visibility = View.GONE
        binding.btnLoginAction.text = "Continue 🛡️"
        binding.btnLoginAction.isEnabled = true
        identifiedProfile = null
        identifiedPhone = null
        verificationId = null
    }

    private fun startPhoneNumberVerification(phone: String) {
        val options = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(phone)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(this)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    signInWithPhoneAuthCredential(credential)
                }
                override fun onVerificationFailed(e: FirebaseException) {
                    Log.e("Login", "Phone Verification Failed", e)
                    val appSha1 = SignatureHelper.getSHA1(this@LoginActivity)
                    
                    if (!isFinishing && !isDestroyed) {
                        AlertDialog.Builder(this@LoginActivity)
                            .setTitle("Login Refused")
                            .setMessage("Firebase rejected the request. \n\n1. Error: ${e.message}\n\n2. App SHA-1: $appSha1\n\nEnsure India (+91) region is allowed in Firebase Settings.")
                            .setPositiveButton("OK", null)
                            .show()
                    }
                    resetLogin()
                }
                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken) {
                    verificationId = id
                    binding.btnLoginAction.isEnabled = true
                    binding.btnLoginAction.text = "Verify & Login 🛡️"
                    binding.tilDynamic.visibility = View.VISIBLE
                    binding.tilDynamic.hint = "Enter OTP for $phone 🔢"
                    binding.etDynamic.inputType = InputType.TYPE_CLASS_NUMBER
                    binding.etDynamic.requestFocus()
                    Toast.makeText(this@LoginActivity, "OTP Sent to $phone", Toast.LENGTH_SHORT).show()
                }
            })
            .build()
        PhoneAuthProvider.verifyPhoneNumber(options)
    }

    private fun verifyOtp(code: String) {
        val id = verificationId ?: run {
            Toast.makeText(this, "OTP Session Missing. Please request again.", Toast.LENGTH_SHORT).show()
            resetLogin()
            return
        }
        val credential = PhoneAuthProvider.getCredential(id, code)
        signInWithPhoneAuthCredential(credential)
    }

    private fun signInWithPhoneAuthCredential(credential: PhoneAuthCredential) {
        setLoading(true)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    lifecycleScope.launch {
                        val profile = identifiedProfile ?: authRepository.getProfileByPhone(identifiedPhone ?: "")
                        if (profile != null) {
                            checkDeviceAndComplete(profile)
                        } else if (identifiedPhone?.contains("9629881598") == true) {
                            val superProfile = UserProfile(
                                uid = auth.currentUser!!.uid,
                                name = "Super Admin",
                                phone = identifiedPhone!!,
                                role = UserRole.SUPER_ADMIN.name
                            )
                            authRepository.updateDeviceBinding(superProfile.uid, getAndroidDeviceId(), Build.MODEL, Build.VERSION.SDK_INT)
                            repository.pushProfileByUid(superProfile)
                            completeLoginFlow(superProfile, getAndroidDeviceId())
                        } else {
                            setLoading(false)
                            Toast.makeText(this@LoginActivity, "Profile not found.", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    setLoading(false)
                    Toast.makeText(this, "Invalid OTP", Toast.LENGTH_SHORT).show()
                }
            }
    }

    private fun handleEmployeeLogin(empId: String, pass: String) {
        lifecycleScope.launch {
            try {
                setLoading(true)
                val profile = authRepository.verifyEmployeeCredentials(empId, pass)
                if (profile != null) {
                    checkDeviceAndComplete(profile)
                } else {
                    setLoading(false)
                    Toast.makeText(this@LoginActivity, "Invalid ID or Password", Toast.LENGTH_SHORT).show()
                }
            } catch (e: Exception) {
                setLoading(false)
                Toast.makeText(this@LoginActivity, "Error: ${e.message}", Toast.LENGTH_LONG).show()
            }
        }
    }

    private suspend fun checkDeviceAndComplete(profile: UserProfile) {
        val deviceId = getAndroidDeviceId()
        if (authRepository.checkDeviceBinding(profile.uid, deviceId)) {
            completeLoginFlow(profile, deviceId)
        } else {
            setLoading(false)
            showDeviceReplacementDialog(profile, deviceId)
        }
    }

    private fun showDeviceReplacementDialog(profile: UserProfile, newDeviceId: String) {
        AlertDialog.Builder(this)
            .setTitle("New Device")
            .setMessage("Replace previous binding with this device?")
            .setPositiveButton("Replace") { _, _ ->
                lifecycleScope.launch { completeLoginFlow(profile, newDeviceId) }
            }
            .setNegativeButton("Cancel") { _, _ -> auth.signOut() ; resetLogin() }
            .show()
    }

    private suspend fun completeLoginFlow(profile: UserProfile, deviceId: String) {
        authRepository.updateDeviceBinding(profile.uid, deviceId, Build.MODEL, Build.VERSION.SDK_INT)
        
        getSharedPreferences("user_prefs", MODE_PRIVATE).edit(commit = true) {
            putBoolean("is_logged_in", true)
        }
        
        getSharedPreferences("auth_prefs", MODE_PRIVATE).edit(commit = true) {
            putBoolean("has_logged_in_before", true)
            putBoolean("is_locked", false) // CRITICAL: Unlock the app
            putString("user_uid", profile.uid)
            putString("user_role", profile.role)
            putLong("last_active_time", System.currentTimeMillis())
        }
        markAsVerified()
        sharedViewModel.warmUpDashboard()
        proceedToMain()
    }

    private fun proceedToMain() {
        startActivity(Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        })
        finish()
    }

    private fun showBiometricLogin() {
        binding.llBiometricLogin.visibility = View.VISIBLE
        binding.tilUserId.visibility = View.GONE
        binding.btnLoginAction.visibility = View.GONE
        
        binding.root.post {
            if (!isFinishing && !isDestroyed && biometricAuthManager.canAuthenticate()) {
                biometricAuthManager.authenticate()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.btnLoginAction.isEnabled = !loading
    }

    private fun getAndroidDeviceId() = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID)
}
