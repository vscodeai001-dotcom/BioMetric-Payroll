package com.biometric.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.FixedExpense
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@HiltViewModel
class FixedExpensesViewModel @Inject constructor(
    private val repository: MainRepository
) : ViewModel() {

    private val _shopId = MutableStateFlow<String?>(null)

    val fixedExpenses: StateFlow<List<FixedExpense>> = _shopId
        .filterNotNull()
        .flatMapLatest { shopId ->
            repository.getFixedExpensesForShop(shopId)
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    fun loadFixedExpenses(shopId: String) {
        _shopId.value = shopId
    }

    fun addFixedExpense(expense: FixedExpense) {
        viewModelScope.launch {
            repository.insertFixedExpense(expense)
        }
    }

    fun deleteFixedExpense(expense: FixedExpense) {
        viewModelScope.launch {
            repository.deleteFixedExpense(expense)
        }
    }
}
