package com.biometric.app.ui

import android.animation.ObjectAnimator
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.core.view.isEmpty
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivityBusinessHealthBinding
import com.biometric.app.ui.viewmodel.*
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.MotionManager
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class BusinessHealthActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityBusinessHealthBinding
    private val viewModel: BusinessHealthViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter

    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityBusinessHealthBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Business Health")
        
        if (isGlobal) shopId = ""

        setupToolbar(shopName)
        setupUI()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(name: String) {
        setupDualHeader(binding.toolbar, name, "Business Health")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadHealthScore(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.totalScore == 0 && state.snapshot.totalSales == 0.0 && state.metrics.isEmpty()
                        
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.HEALTH, lifecycleScope, immediate = true)
                            if (isDataZero) {
                                binding.contentLayout.visibility = View.GONE
                            } else {
                                // Keep old data visible (dimmed by loader) while refreshing
                                binding.contentLayout.visibility = View.VISIBLE
                            }
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                        
                        updateScoreUI(state)
                        updateMetricsBreakdown(state.metrics)
                        updateFinancialMetrics(state.snapshot)
                        updateTrends(state.trends)
                        updateDayBasedInsights(state.bestDay, state.slowestDay, state.dayInsight)
                        updateRiskImpacts(state.riskImpacts)
                        updateSuggestions(state.suggestions)
                        updateProjection(state.predictionScore)
                    }
                }
            }
        }
    }

    private fun updateScoreUI(state: BusinessHealthState) {
        val animation = ObjectAnimator.ofInt(binding.scoreProgress, "progress", binding.scoreProgress.progress, state.totalScore)
        animation.duration = 1000
        animation.interpolator = DecelerateInterpolator()
        animation.start()

        binding.tvScore.text = state.totalScore.toString()
        
        val statusEmoji = when {
            state.totalScore >= 85 -> "🟢"
            state.totalScore >= 70 -> "🟡"
            state.totalScore >= 50 -> "🟠"
            else -> "🔴"
        }
        binding.tvHealthStatus.text = getString(R.string.health_status_format, statusEmoji, state.status)
        
        val statusColor = when(state.status) {
            "EXCELLENT" -> R.color.green
            "GOOD" -> R.color.green_700
            "WARNING" -> R.color.amber
            else -> R.color.red
        }
        binding.tvHealthStatus.setTextColor(ContextCompat.getColor(this, statusColor))

        // Task: Adaptive Motion - UI reacting dynamically to Profit/Loss (Health status)
        val isPositive = state.totalScore >= 70
        MotionManager.startPulse(binding.scoreProgress, isPositive)
        MotionManager.startPulse(binding.tvHealthStatus, isPositive)

        val trendIcon = if (state.trendPoints >= 0) "📈" else "📉"
        val trendText = if (state.trendPoints >= 0) "+${state.trendPoints}" else state.trendPoints.toString()
        binding.tvTrend.text = getString(R.string.health_trend_format, trendIcon, trendText)
        binding.tvTrend.setTextColor(ContextCompat.getColor(this, if (state.trendPoints >= 0) R.color.green else R.color.red))
    }

    private fun updateMetricsBreakdown(metrics: List<HealthMetric>) {
        binding.llMetricsBreakdown.removeAllViews()
        metrics.forEach { metric ->
            val view = layoutInflater.inflate(R.layout.item_health_metric, binding.llMetricsBreakdown, false)
            view.findViewById<TextView>(R.id.tvMetricLabel).text = metric.label
            view.findViewById<TextView>(R.id.tvMetricDescription).text = metric.description
            view.findViewById<TextView>(R.id.tvMetricValue).text = metric.value
            view.findViewById<TextView>(R.id.tvBaselineValue).text = metric.baselineValue
            view.findViewById<TextView>(R.id.tvMetricScore).text = String.format(Locale.getDefault(), "%d/%d", metric.score, metric.maxScore)
            view.findViewById<TextView>(R.id.tvMetricIcon).text = metric.icon

            val statusColor = when(metric.status) {
                "Excellent" -> R.color.green
                "Good" -> R.color.green_700
                "Warning" -> R.color.amber
                else -> R.color.red
            }
            view.findViewById<View>(R.id.statusIndicator).backgroundTintList =
                android.content.res.ColorStateList.valueOf(ContextCompat.getColor(this, statusColor))
            binding.llMetricsBreakdown.addView(view)
        }
    }

    private fun updateFinancialMetrics(snapshot: FinancialSnapshot) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        
        // Totals
        binding.layoutSales.apply {
            tvMetricIcon.text = "🏪"
            tvMetricLabel.text = "Total Sales"
            tvMetricValue.text = currencyFormat.format(snapshot.totalSales)
        }
        
        binding.layoutProfit.apply {
            tvMetricIcon.text = "💎"
            tvMetricLabel.text = "Net Profit"
            tvMetricValue.text = currencyFormat.format(snapshot.netProfit)
            tvMetricValue.setTextColor(ContextCompat.getColor(this@BusinessHealthActivity, if (snapshot.netProfit >= 0) R.color.green else R.color.red))
        }
        
        binding.layoutExpenses.apply {
            tvMetricIcon.text = "📉"
            tvMetricLabel.text = "Total Expenses"
            tvMetricValue.text = currencyFormat.format(snapshot.totalExpenses)
        }
        
        binding.layoutSalary.apply {
            tvMetricIcon.text = "👨‍🍳"
            tvMetricLabel.text = "Total Salary"
            tvMetricValue.text = currencyFormat.format(snapshot.totalSalary)
        }

        // Ratios
        binding.layoutMarginRatio.apply {
            tvRatioIcon.text = "💹"
            tvRatioLabel.text = "Profit Margin"
            tvRatioValue.text = String.format(Locale.getDefault(), "%.1f%%", snapshot.profitMargin)
        }
        
        binding.layoutExpRatio.apply {
            tvRatioIcon.text = "📊"
            tvRatioLabel.text = "Expense Ratio"
            tvRatioValue.text = String.format(Locale.getDefault(), "%.1f%%", snapshot.expenseRatio)
        }
        
        binding.layoutSalRatio.apply {
            tvRatioIcon.text = "🤝"
            tvRatioLabel.text = "Salary Ratio"
            tvRatioValue.text = String.format(Locale.getDefault(), "%.1f%%", snapshot.salaryRatio)
        }
    }

    private fun updateTrends(trends: List<TrendPoint>) {
        binding.llTrends.removeAllViews()
        
        trends.forEach { trend ->
            val view = layoutInflater.inflate(R.layout.item_health_trend_row, binding.llTrends, false)
            view.findViewById<TextView>(R.id.tvTrendLabel).text = "${trend.icon} ${trend.label}"
            view.findViewById<TextView>(R.id.tvTrendValues).text = String.format(
                Locale.getDefault(), 
                "%s → %s", 
                formatLargeCurrency(trend.previous), 
                formatLargeCurrency(trend.current),
            )
            
            val tvGrowth = view.findViewById<TextView>(R.id.tvTrendGrowth)
            tvGrowth.text = String.format(Locale.getDefault(), "%s%.1f%%", if (trend.growth >= 0) "+" else "", trend.growth)
            
            // Expense growth is bad, Sales/Profit growth is good
            val isPositiveMetric = trend.label != "Expenses"
            val isGrowthGood = (isPositiveMetric && trend.growth >= 0) || (!isPositiveMetric && trend.growth <= 0)
            
            tvGrowth.setTextColor(ContextCompat.getColor(this, if (isGrowthGood) R.color.green else R.color.red))
            
            binding.llTrends.addView(view)
        }
    }

    private fun formatLargeCurrency(value: Double): String {
        return if (value >= 100000) String.format(Locale.getDefault(), "%.1fL", value / 100000)
        else if (value >= 1000) String.format(Locale.getDefault(), "₹%.1fK", value / 1000)
        else String.format(Locale.getDefault(), "₹%.0f", value)
    }

    private fun updateDayBasedInsights(best: String, slowest: String, insight: String) {
        binding.tvBestDay.text = best
        binding.tvSlowestDay.text = slowest
        binding.tvDayInsight.text = insight
    }

    private fun updateRiskImpacts(impacts: List<String>) {
        if (impacts.isNotEmpty() && binding.llRiskImpacts.isEmpty()) {
            HapticUtil.vibrateRisk(binding.root)
        }
        binding.llRiskImpacts.removeAllViews()
        impacts.forEach { impact ->
            val view = layoutInflater.inflate(R.layout.item_health_insight, binding.llRiskImpacts, false)
            val card = view as com.google.android.material.card.MaterialCardView
            val tvIcon = view.findViewById<TextView>(R.id.tvIcon)
            val tvMessage = view.findViewById<TextView>(R.id.tvMessage)
            
            card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.alert_bg))
            tvIcon.text = "⚠️"
            tvIcon.background = null // Remove circle background to show card color
            tvMessage.text = impact
            tvMessage.setTextColor(ContextCompat.getColor(this, R.color.alert_text))
            
            binding.llRiskImpacts.addView(view)
        }
    }

    private fun updateSuggestions(suggestions: List<String>) {
        binding.llSuggestions.removeAllViews()
        suggestions.forEach { suggestion ->
            val view = layoutInflater.inflate(R.layout.item_health_insight, binding.llSuggestions, false)
            val card = view as com.google.android.material.card.MaterialCardView
            val tvIcon = view.findViewById<TextView>(R.id.tvIcon)
            val tvMessage = view.findViewById<TextView>(R.id.tvMessage)
            
            card.setCardBackgroundColor(ContextCompat.getColor(this, R.color.insight_blue_bg))
            tvIcon.text = "💡"
            tvIcon.background = null
            tvMessage.text = suggestion
            tvMessage.setTextColor(ContextCompat.getColor(this, R.color.insight_blue_text))
            
            binding.llSuggestions.addView(view)
        }
    }

    private fun updateProjection(score: Int) {
        binding.tvPredictionScore.text = String.format(Locale.getDefault(), "%d / 100 📈", score)
    }
}
