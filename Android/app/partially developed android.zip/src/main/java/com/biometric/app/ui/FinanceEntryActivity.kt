package com.biometric.app.ui

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.databinding.ActivityFinanceEntryBinding
import com.biometric.app.ui.viewmodel.FinanceEntryViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import com.biometric.app.util.HapticUtil
import com.biometric.app.utils.PremiumUI
import com.biometric.app.utils.Toaster
import com.biometric.app.util.MotionManager
import com.biometric.app.util.KeyboardUtil
import kotlin.time.Duration.Companion.milliseconds
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class FinanceEntryActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityFinanceEntryBinding
    private val mainViewModel: MainViewModel by viewModels()
    private val viewModel: FinanceEntryViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    
    private var selectedDate: Calendar = Calendar.getInstance()
    private var selectedEntryForEdit: Cashbook? = null
    private lateinit var speechRecognizer: SpeechRecognizer
    private lateinit var recentEntriesAdapter: RecentEntriesAdapter
    private var currentShopId: String = ""
    private lateinit var biometricManager: BiometricAuthManager

    private val requestPermissionLauncher = registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
        if (isGranted) {
            startVoiceRecognition()
        } else {
            Toast.makeText(this, "Permission denied to record audio", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityFinanceEntryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }

        biometricManager = BiometricAuthManager(
            context = this,
            activity = this,
            onAuthSuccess = { 
                selectedEntryForEdit?.let { 
                    viewModel.deleteFinancialEntry(it)
                    MotionManager.playDeleteDissolve(binding.animFeedback)
                    HapticUtil.vibrateDeletion(binding.root)
                    HapticUtil.vibrateSuccess(binding.root)
                    Toast.makeText(this, "Entry deleted successfully", Toast.LENGTH_SHORT).show()
                    Toast.makeText(this, "Entry deleted successfully", Toast.LENGTH_SHORT).show()
                    clearForm()
                }
            },
            onAuthError = { 
                HapticUtil.vibrateError(binding.root)
                Toast.makeText(this, "Authentication failed: $it", Toast.LENGTH_SHORT).show() 
            }
        )

        observeViewModel()
        setupUI()
        setupSpeechRecognizer()

        setupMotionFeedback(
            binding.btnCashIn, 
            binding.btnCashOut, 
            binding.btnUpdate, 
            binding.btnDelete, 
            binding.btnClear, 
            binding.fabVoiceInput
        )

        intent.getStringExtra("DEFAULT_TYPE")?.let { type ->
            if (type == "IN") {
                binding.actCategory.setText("DAILY SALES (CASH)", false)
            } else if (type == "OUT") {
                binding.actCategory.setText("PURCHASE", false)
                binding.llInventoryFields.visibility = View.VISIBLE
            }
        }
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                sharedViewModel.setSelectedShop(selectedShop)
            }
            .show()
    }

    private fun setupUI() {
        val units = arrayOf("Litre", "Kg", "Piece", "Gram", "Bundle")
        val unitAdapter = ArrayAdapter(this, android.R.layout.simple_dropdown_item_1line, units)
        binding.actUnit.setAdapter(unitAdapter)
        binding.actUnit.setOnItemClickListener { _, _, _, _ ->
            // AUTO-FOCUS: After selecting unit, go to Amount
            KeyboardUtil.showKeyboard(binding.etAmount)
        }

        binding.actCategory.setOnClickListener {
            showCategoryGridPicker()
        }

        binding.actCustomCategory.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    val category = s.toString().uppercase()
                    if (category.contains("PURCHASE") || category.contains("EXPENSE")) {
                        binding.llInventoryFields.visibility = View.VISIBLE
                    } else {
                        binding.llInventoryFields.visibility = View.GONE
                    }
                }
                override fun afterTextChanged(s: Editable?) {
                    if (binding.actCustomCategory.isFocused && !s.isNullOrEmpty()) {
                        handleCustomCategoryEntry(s.toString())
                    }
                }
            }
        )

        binding.etAmount.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (binding.etAmount.isFocused && (s?.length ?: 0) >= 1) {
                        calculateAutoQty()
                    }
                }
            }
        )

        binding.etQuantity.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    // Removed automatic focus jump from Qty
                }
            }
        )

        binding.actUnit.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (binding.actUnit.isFocused && !s.isNullOrEmpty()) {
                        handleUnitEntry()
                    }
                }
            }
        )

        binding.etDescription.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
                override fun afterTextChanged(s: Editable?) {
                    if (binding.etDescription.isFocused) {
                        val text = s.toString()
                        handleDescriptionEntry(text)
                    }
                }
            }
        )

        binding.etDescription.setOnItemClickListener { _, _, _, _ ->
            // After selecting an item from the description list, move focus to Amount
            binding.etAmount.requestFocus()
            KeyboardUtil.showKeyboard(binding.etAmount)
        }

        recentEntriesAdapter = RecentEntriesAdapter(::onEntryClick, ::onEntryLongClick)
        binding.rvRecentEntries.layoutManager = LinearLayoutManager(this)
        binding.rvRecentEntries.adapter = recentEntriesAdapter

        updateDateButton()

        binding.btnPickDate.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, 
                "Day", 
                selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                updateDateButton()
            }
        }

        binding.btnPrevDate.setOnClickListener {
            selectedDate.add(Calendar.DAY_OF_MONTH, -1)
            updateDateButton()
        }

        binding.btnNextDate.setOnClickListener {
            selectedDate.add(Calendar.DAY_OF_MONTH, 1)
            updateDateButton()
        }

        binding.btnCashIn.setOnClickListener {
            val category = binding.actCategory.text.toString()
            HapticUtil.vibrateClick(it)
            recordFinance(currentShopId, "IN", category)
        }

        binding.btnCashOut.setOnClickListener {
            val category = binding.actCategory.text.toString()
            HapticUtil.vibrateClick(it)
            recordFinance(currentShopId, "OUT", category)
        }

        binding.btnUpdate.setOnClickListener { 
            selectedEntryForEdit?.let { entry ->
                val amount = binding.etAmount.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
                val qty = binding.etQuantity.text.toString().replace(',', '.').toDoubleOrNull()
                val unit = binding.actUnit.text.toString()
                val desc = binding.etDescription.text.toString()
                val category = binding.actCategory.text.toString()
                val type = entry.transactionType 
                viewModel.updateFinancialEntry(entry, amount, type, category, desc, selectedDate.timeInMillis, qty, unit)
                clearForm()
            }
        }

        binding.btnDelete.setOnClickListener {
            selectedEntryForEdit?.let { onEntryLongClick(it) }
        }

        binding.btnClear.setOnClickListener { clearForm() }

        binding.fabVoiceInput.setOnClickListener {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startVoiceRecognition()
            } else {
                requestPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun showCategoryGridPicker() {
        val categories = arrayOf(
            "💰 DAILY SALES (CASH)", 
            "📱 DAILY SALES (QR)", 
            "🛒 PURCHASE", 
            "📈 EXPENSE", 
            "👨‍🍳 SALARY", 
            "➕ OTHER"
        )
        
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_category_grid, null)
        val chipGroup = dialogView.findViewById<com.google.android.material.chip.ChipGroup>(R.id.cgCategoryGrid)
        
        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle("Select Category 🏷️")
            .setView(dialogView)
            .show()

        categories.forEach { cat ->
            val chip = com.google.android.material.chip.Chip(this).apply {
                text = cat
                isClickable = true
                isFocusable = true
                setOnClickListener {
                    if (cat.contains("OTHER")) {
                        binding.tilCustomCategory.visibility = View.VISIBLE
                        binding.actCustomCategory.setText("")
                        // ATOMIC AUTO-FOCUS: Open keyboard for Custom Category Name
                        // Increased delay to ensure dialog dismissal is complete and focus is requested
                        binding.actCustomCategory.postDelayed({
                            KeyboardUtil.showKeyboard(binding.actCustomCategory)
                        }, 250L)
                        binding.actCategory.setText("OTHER", false)
                    } else {
                        binding.tilCustomCategory.visibility = View.GONE
                        val clean = if (cat.length > 2) cat.substring(3).trim() else cat
                        binding.actCategory.setText(clean, false)
                        
                        if ((clean == "PURCHASE") || (clean == "EXPENSE")) {
                            binding.llInventoryFields.visibility = View.VISIBLE
                        } else {
                            binding.llInventoryFields.visibility = View.GONE
                        }
                    }
                    dialog.dismiss()
                    
                    if (!cat.contains("OTHER")) {
                        // ATOMIC AUTO-FOCUS: Move to description immediately after category selection
                        // Use a slightly longer delay and clear focus first to ensure keyboard pops up reliably
                        binding.etDescription.postDelayed({
                            binding.root.requestFocus()
                            KeyboardUtil.showKeyboard(binding.etDescription)
                        }, 100L)
                    }
                }
            }
            chipGroup.addView(chip)
        }
    }

    private fun showMonthListSelection() {
        val months = arrayOf("January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December")
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Month 📅")
            .setItems(months) { _, monthIndex ->
                selectedDate.set(Calendar.MONTH, monthIndex)
                binding.btnPickDate.performClick()
            }
            .show()
    }

    private var customCatActionJob: kotlinx.coroutines.Job? = null
    private fun handleCustomCategoryEntry(text: String) {
        customCatActionJob?.cancel()
        customCatActionJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(1500.milliseconds)
            KeyboardUtil.showKeyboard(binding.etDescription)
        }
    }

    private var descriptionActionJob: kotlinx.coroutines.Job? = null

    private fun handleDescriptionEntry(text: String) {
        descriptionActionJob?.cancel()
        if (text.trim().isEmpty()) return

        descriptionActionJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(1500.milliseconds) // Requirement: 1.5s based auto-focus movement
            
            val cleanType = binding.actCategory.text.toString().uppercase()
            val isInventory = cleanType.contains("PURCHASE") || cleanType.contains("EXPENSE")
            val itemName = text.uppercase().trim()

            if (isInventory) {
                viewModel.getPriceHistory(currentShopId, itemName).firstOrNull()?.let { historyList ->
                    val latestHistory = historyList.maxByOrNull { it.date }
                    if (latestHistory != null && latestHistory.price > 0) {
                        // AUTO-RECOGNITION: Populate unit and move to Amount
                        binding.actUnit.setText(latestHistory.unit ?: "", false)
                        
                        val amount = binding.etAmount.text.toString().replace(',', '.').toDoubleOrNull()
                        if (amount != null) {
                            val calculatedQty = amount / latestHistory.price
                            binding.etQuantity.setText(if (calculatedQty < 1.0) "1" else calculatedQty.toInt().toString())
                        }
                        
                        KeyboardUtil.showKeyboard(binding.etAmount)
                    } else {
                        // NEW ITEM: Move to Quantity
                        KeyboardUtil.showKeyboard(binding.etQuantity)
                    }
                } ?: run {
                    KeyboardUtil.showKeyboard(binding.etQuantity)
                }
            } else {
                // NORMAL ENTRY: Move to Amount
                KeyboardUtil.showKeyboard(binding.etAmount)
            }
        }
    }

    // No auto-focus jump from Qty anymore as requested

    private var unitActionJob: kotlinx.coroutines.Job? = null
    private fun handleUnitEntry() {
        unitActionJob?.cancel()
        unitActionJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(1500.milliseconds)
            binding.etAmount.requestFocus()
        }
    }

    private var autoQtyJob: kotlinx.coroutines.Job? = null

    private fun calculateAutoQty() {
        val amountStr = binding.etAmount.text.toString()
        val amount = amountStr.replace(',', '.').toDoubleOrNull() ?: return
        val itemName = binding.etDescription.text.toString().uppercase().trim()
        if (itemName.isEmpty()) return

        autoQtyJob?.cancel()
        autoQtyJob = lifecycleScope.launch {
            kotlinx.coroutines.delay(300.milliseconds) // Shorter delay for amount calculation
            viewModel.getPriceHistory(currentShopId, itemName)
                .firstOrNull()?.let { historyList ->
                    val latestHistory = historyList.maxByOrNull { it.date }
                    latestHistory?.let { history ->
                        if (history.price > 0) {
                            val calculatedQty = amount / history.price
                            val currentQtyText = binding.etQuantity.text.toString()
                            val currentQty = currentQtyText.replace(',', '.').toDoubleOrNull() ?: 0.0
                            
                            if (!binding.etQuantity.isFocused || (currentQty == 0.0)) {
                                val finalQty = if (calculatedQty < 1.0) 1 else calculatedQty.toInt()
                                binding.etQuantity.setText(finalQty.toString())
                                binding.actUnit.setText(history.unit ?: "", false)
                                
                                // Do NOT auto-focus or open dropdowns here to keep UX stable
                            }
                        }
                    }
                }
        }
    }

    private fun onEntryClick(entry: Cashbook) {
        selectedEntryForEdit = entry
        binding.etAmount.setText(entry.amount.toString())
        
        binding.actCategory.setText(entry.category, false)
        binding.tilCustomCategory.visibility = View.GONE
        
        binding.etDescription.setText(entry.description)
        
        val qtyText = entry.quantity?.let { 
            if (it == it.toLong().toDouble()) it.toLong().toString() else it.toString() 
        } ?: ""
        binding.etQuantity.setText(qtyText)

        binding.actUnit.setText(entry.unit ?: "", false)
        
        if ((entry.category == "PURCHASE") || (entry.category == "EXPENSE")) {
            binding.llInventoryFields.visibility = View.VISIBLE
        } else {
            binding.llInventoryFields.visibility = View.GONE
        }

        binding.llActionButtons.visibility = View.GONE
        binding.llEditButtons.visibility = View.VISIBLE
    }

    private fun onEntryLongClick(entry: Cashbook) {
        selectedEntryForEdit = entry
        MaterialAlertDialogBuilder(this)
            .setTitle("Confirm Deletion")
            .setMessage("For security, biometric authentication is required to delete this financial record.")
            .setPositiveButton("Verify & Delete") { _, _ ->
                if (biometricManager.canAuthenticate()) {
                    biometricManager.authenticate()
                } else {
                    viewModel.deleteFinancialEntry(entry)
                    MotionManager.playDeleteDissolve(binding.animFeedback)
                    HapticUtil.vibrateDeletion(binding.root)
                    Toast.makeText(this, "Entry deleted (No Biometrics Found)", Toast.LENGTH_SHORT).show()
                    clearForm()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearForm() {
        selectedEntryForEdit = null
        binding.etAmount.text?.clear()
        binding.etDescription.text?.clear()
        binding.etQuantity.text?.clear()
        binding.actUnit.text.clear()
        binding.actCategory.text.clear()
        binding.actCustomCategory.text.clear()
        
        // ZERO-FOCUS: Clear focus from all fields to prevent keyboard re-opening
        binding.etAmount.clearFocus()
        binding.etDescription.clearFocus()
        binding.etQuantity.clearFocus()
        binding.actUnit.clearFocus()
        binding.actCategory.clearFocus()
        binding.actCustomCategory.clearFocus()
        
        // Ensure focus is completely removed from the form
        binding.root.requestFocus()
        
        binding.tilCustomCategory.visibility = View.GONE
        binding.llInventoryFields.visibility = View.GONE
        binding.llActionButtons.visibility = View.VISIBLE
        binding.llEditButtons.visibility = View.GONE
    }

    private fun updateDateButton() {
        val format = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        binding.btnPickDate.text = format.format(selectedDate.time)
        viewModel.setDate(selectedDate.timeInMillis)
    }

    private fun setupSpeechRecognizer() {
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(error: Int) {}
            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                if (!matches.isNullOrEmpty()) {
                    processVoiceCommand(matches[0])
                }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
    }

    private fun startVoiceRecognition() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, "Speak now...")
        speechRecognizer.startListening(intent)
    }

    private fun processVoiceCommand(command: String) {
        val parts = command.split(" ")
        var amount: Double? = null
        var category: String? = null

        for (part in parts) {
            val num = part.toDoubleOrNull()
            if (num != null) {
                amount = num
                break
            }
        }

        if (command.contains("purchase", ignoreCase = true)) category = "PURCHASE"
        if (command.contains("salary", ignoreCase = true)) category = "SALARY"
        if (command.contains("advance", ignoreCase = true)) category = "ADVANCE"

        binding.etDescription.setText(command)

        amount?.let { binding.etAmount.setText(it.toString()) }
        category?.let { binding.actCategory.setText(it, false) }
    }

    private fun recordFinance(shopId: String, type: String, catFromDropdown: String) {
        val customCat = binding.actCustomCategory.text.toString().trim()
        val category = if (customCat.isNotEmpty()) customCat.uppercase() else catFromDropdown.uppercase()
        
        val amount = binding.etAmount.text.toString().replace(',', '.').toDoubleOrNull() ?: 0.0
        val desc = binding.etDescription.text.toString()
        val qty = binding.etQuantity.text.toString().replace(',', '.').toDoubleOrNull()
        val unit = binding.actUnit.text.toString()

        if ((category == "OTHER") && desc.isBlank()) {
            HapticUtil.vibrateError(binding.root)
            binding.tilDescription.error = "Description is required for OTHER"
            return
        } else {
            binding.tilDescription.error = null
        }

        if ((category == "PURCHASE" || category == "EXPENSE") && (qty == null || qty <= 0)) {
            HapticUtil.vibrateError(binding.root)
            binding.tilQuantity.error = "Qty required for $category"
            return
        } else {
            binding.tilQuantity.error = null
        }

        if (amount > 0 && category.isNotEmpty()) {
            if (selectedEntryForEdit == null) {
                viewModel.addFinancialEntry(shopId, amount, type, category, desc, selectedDate.timeInMillis, qty, unit)
                MotionManager.playCreateBlast(binding.animFeedback)
                Toaster.show(this, "$category Recorded: ₹$amount")
            } else {
                viewModel.updateFinancialEntry(selectedEntryForEdit!!, amount, type, category, desc, selectedDate.timeInMillis, qty, unit)
                MotionManager.playUpdateMorph(binding.animFeedback)
                Toaster.show(this, "$category Updated: ₹$amount")
            }
            KeyboardUtil.hideKeyboard(this)
            clearForm()
        } else {
            HapticUtil.vibrateError(binding.root)
            Toast.makeText(this, "Please enter a valid amount and category", Toast.LENGTH_SHORT).show()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            currentShopId = it.shopId
                            updateToolbarTitle(it.name)
                            viewModel.setShopId(it.shopId)
                        }
                    }
                }
                launch {
                    viewModel.recentPurchaseDescriptions.collect { descs ->
                        val itemMasterNames = viewModel.allItems.value.map { it.name.uppercase().trim() }
                        val combinedDescs = (descs + itemMasterNames).asSequence().distinct().sorted().toList()
                        val descAdapter = ArrayAdapter(this@FinanceEntryActivity, android.R.layout.simple_dropdown_item_1line, combinedDescs)
                        binding.etDescription.setAdapter(descAdapter)
                    }
                }
                launch {
                    viewModel.isEntriesLoading.collect { isLoading ->
                        // Strict Anti-Flicker Logic
                        val isDataZero = viewModel.recentEntries.value.isEmpty()
                        if (isLoading && isDataZero) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.CASHBOOK, lifecycleScope)
                            binding.scrollView.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.scrollView.visibility = View.VISIBLE
                        }
                    }
                }
                launch {
                    viewModel.recentEntries.collect { entries ->
                        recentEntriesAdapter.submitList(entries)
                    }
                }
                launch {
                    viewModel.events.collect { event ->
                        when (event) {
                            is FinanceEntryViewModel.FinanceEvent.Success -> {
                                HapticUtil.vibrateSuccess(binding.root)
                            }
                            is FinanceEntryViewModel.FinanceEvent.Risk -> {
                                HapticUtil.vibrateRisk(binding.root)
                                Toast.makeText(this@FinanceEntryActivity, "⚠️ ${event.message}", Toast.LENGTH_LONG).show()
                            }
                            is FinanceEntryViewModel.FinanceEvent.Error -> {
                                HapticUtil.vibrateError(binding.root)
                                Toast.makeText(this@FinanceEntryActivity, "❌ ${event.message}", Toast.LENGTH_SHORT).show()
                            }
                        }
                    }
                }
            }
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.selectedEntry.collect { entry ->
                    if (entry != null && selectedEntryForEdit == null) {
                        onEntryClick(entry)
                    }
                }
            }
        }
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Cash Book Ledger")
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("📊", "Reports") {
                val intent = Intent(this@FinanceEntryActivity, ReportsActivity::class.java).apply {
                    putExtra("SHOP_ID", currentShopId)
                }
                startActivity(intent)
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("📊", "Reports") {
                val intent = Intent(this@FinanceEntryActivity, ReportsActivity::class.java).apply {
                    putExtra("SHOP_ID", currentShopId)
                }
                startActivity(intent)
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    override fun onDestroy() {
        super.onDestroy()
        speechRecognizer.destroy()
    }

    inner class RecentEntriesAdapter(
        private val onItemClick: (Cashbook) -> Unit,
        private val onLongClick: (Cashbook) -> Unit
    ) : androidx.recyclerview.widget.ListAdapter<Cashbook, RecentEntriesAdapter.ViewHolder>(CashbookDiffCallback()) {

        inner class ViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
            val tvDate: TextView = itemView.findViewById(R.id.tvDate)
            val tvEmoji: TextView = itemView.findViewById(R.id.tvEmoji)
            val tvParticulars: TextView = itemView.findViewById(R.id.tvParticulars)
            val tvDebit: TextView = itemView.findViewById(R.id.tvDebit)
            val tvCredit: TextView = itemView.findViewById(R.id.tvCredit)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val view = LayoutInflater.from(parent.context).inflate(R.layout.item_finance_row, parent, false)
            return ViewHolder(view)
        }
        
        private fun getEmojiForEntry(category: String, description: String?): String {
            return FinancialCategory.getEmoji(category, description)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = getItem(position)
            val dateFormat = SimpleDateFormat("dd/MM/yy", Locale.getDefault())
            holder.tvDate.text = dateFormat.format(Date(item.transactionDate))
            holder.tvEmoji.text = getEmojiForEntry(item.category, item.description)
            
            val category = item.category
            val categoryShort = when {
                category.contains("CASH") -> "CASH"
                category.contains("QR") -> "QR"
                category.contains("PURCHASE") -> "PUR"
                category.contains("EXPENSE") -> "EXP"
                category.contains("SALARY") -> "SAL"
                category.contains("ADVANCE") -> "ADV"
                category.contains("EB/GAS") -> "GAS"
                category.contains("RENT") -> "RENT"
                category.contains("MAINTENANCE") -> "MAIN"
                else -> if (category.length > 5) category.take(4).uppercase() else category
            }

            val description = item.description
            val particulars = if (description.isNullOrEmpty() || description.equals(category, ignoreCase = true)) {
                category
            } else {
                "$categoryShort: $description"
            }
            holder.tvParticulars.text = particulars

            if (item.transactionType == "IN") {
                holder.tvCredit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvCredit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.green))
                holder.tvDebit.text = ""
            } else {
                holder.tvDebit.text = String.format(Locale.getDefault(), "₹%.2f", item.amount)
                holder.tvDebit.setTextColor(ContextCompat.getColor(holder.itemView.context, R.color.red))
                holder.tvCredit.text = ""
            }
            holder.itemView.setOnClickListener { onItemClick(item) }
            holder.itemView.setOnLongClickListener { onLongClick(item); true }
        }
    }

    class CashbookDiffCallback : androidx.recyclerview.widget.DiffUtil.ItemCallback<Cashbook>() {
        override fun areItemsTheSame(oldItem: Cashbook, newItem: Cashbook) = oldItem.entryId == newItem.entryId
        override fun areContentsTheSame(oldItem: Cashbook, newItem: Cashbook) = oldItem == newItem
    }
}
