package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable
import java.util.UUID

@Keep
data class EmployeeHistory(
    @get:PropertyName("historyId") @set:PropertyName("historyId")
    var historyId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("employeeId") @set:PropertyName("employeeId")
    var employeeId: String = "",
    
    @get:PropertyName("version") @set:PropertyName("version")
    var version: Int = 0,

    @get:PropertyName("type") @set:PropertyName("type")
    var type: String = "SALARY", // SALARY, ALLOWANCE, or SHIFT
    
    @get:PropertyName("salaryType") @set:PropertyName("salaryType")
    var salaryType: String = "",
    
    @get:PropertyName("oldValue") @set:PropertyName("oldValue")
    var oldValue: Double = 0.0,

    @get:PropertyName("newValue") @set:PropertyName("newValue")
    var newValue: Double = 0.0,
    
    @get:PropertyName("shiftStart") @set:PropertyName("shiftStart")
    var shiftStart: String = "",
    
    @get:PropertyName("shiftEnd") @set:PropertyName("shiftEnd")
    var shiftEnd: String = "",
    
    @get:PropertyName("breakHours") @set:PropertyName("breakHours")
    var breakHours: Double = 0.0,

    @get:PropertyName("shift2Start") @set:PropertyName("shift2Start")
    var shift2Start: String? = null,

    @get:PropertyName("shift2End") @set:PropertyName("shift2End")
    var shift2End: String? = null,

    @get:PropertyName("weekendShiftStart") @set:PropertyName("weekendShiftStart")
    var weekendShiftStart: String? = null,
    
    @get:PropertyName("weekendShiftEnd") @set:PropertyName("weekendShiftEnd")
    var weekendShiftEnd: String? = null,
    
    @get:PropertyName("weekendBreakHours") @set:PropertyName("weekendBreakHours")
    var weekendBreakHours: Double? = null,

    @get:PropertyName("weekendShift2Start") @set:PropertyName("weekendShift2Start")
    var weekendShift2Start: String? = null,

    @get:PropertyName("weekendShift2End") @set:PropertyName("weekendShift2End")
    var weekendShift2End: String? = null,

    @get:PropertyName("isBonusEligible") @set:PropertyName("isBonusEligible")
    var isBonusEligible: Boolean = true,

    @get:PropertyName("isPaidLeaveEligible") @set:PropertyName("isPaidLeaveEligible")
    var isPaidLeaveEligible: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekdays") @set:PropertyName("paidLeaveOnWeekdays")
    var paidLeaveOnWeekdays: Boolean = true,

    @get:PropertyName("paidLeaveOnWeekends") @set:PropertyName("paidLeaveOnWeekends")
    var paidLeaveOnWeekends: Boolean = false,

    @get:PropertyName("rulesOverrideJson") @set:PropertyName("rulesOverrideJson")
    var rulesOverrideJson: String? = null,
    
    @get:PropertyName("changeDate") @set:PropertyName("changeDate")
    var changeDate: Long = System.currentTimeMillis(),

    @get:PropertyName("effectiveDate") @set:PropertyName("effectiveDate")
    var effectiveDate: Long = System.currentTimeMillis(),

    @get:PropertyName("endDate") @set:PropertyName("endDate")
    var endDate: Long? = null,
    
    @get:PropertyName("changeReason") @set:PropertyName("changeReason")
    var changeReason: String? = null,

    @get:PropertyName("salaryRate") @set:PropertyName("salaryRate")
    var salaryRate: Double = 0.0
) : Serializable
