package com.biometric.app.ui

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class LauncherActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPreferences = getSharedPreferences("user_prefs", MODE_PRIVATE)
        val isLoggedIn = sharedPreferences.getBoolean("is_logged_in", false)

        val authPrefs = getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
        val isLocked = authPrefs.getBoolean("is_locked", true) // Default to locked on cold start
        val lastActive = authPrefs.getLong("last_active_time", 0L)
        val timeout = 5 * 60 * 1000L // 5 Minutes
        val isExpired = (lastActive != 0L) && (System.currentTimeMillis() - lastActive > timeout)

        if (isLoggedIn && !isLocked && !isExpired) {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                overrideActivityTransition(Activity.OVERRIDE_TRANSITION_OPEN, 0, 0)
            } else {
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        } else {
            // Force directly to Login screen to prevent dashboard flicker
            val intent = Intent(this, LoginActivity::class.java)
            startActivity(intent)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                overrideActivityTransition(Activity.OVERRIDE_TRANSITION_OPEN, 0, 0)
            } else {
                @Suppress("DEPRECATION")
                overridePendingTransition(0, 0)
            }
        }
        finish()
    }
}
