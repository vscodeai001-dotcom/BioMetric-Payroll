package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class AuditLog(
    @get:PropertyName("logId") @set:PropertyName("logId")
    var logId: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("action") @set:PropertyName("action")
    var action: String = "", // ADD, UPDATE, DELETE, RESTORE, VIEW, LOGIN_FAIL
    
    @get:PropertyName("module") @set:PropertyName("module")
    var module: String = "", // POS, Cashbook, Expense, Salary, Attendance, Investment, Stock, Reports, Security
    
    @get:PropertyName("oldValue") @set:PropertyName("oldValue")
    var oldValue: String? = null,
    
    @get:PropertyName("newValue") @set:PropertyName("newValue")
    var newValue: String? = null,
    
    @get:PropertyName("userDisplayName") @set:PropertyName("userDisplayName")
    var userDisplayName: String = "",
    
    @get:PropertyName("userId") @set:PropertyName("userId")
    var userId: String = "",
    
    @get:PropertyName("timestamp") @set:PropertyName("timestamp")
    var timestamp: Long = System.currentTimeMillis()
)
