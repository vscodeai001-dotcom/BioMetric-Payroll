package com.biometric.app.domain

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FeatureManager @Inject constructor() {

    // Define features
    enum class Feature(val displayName: String, val emoji: String) {
        DASHBOARD("Dashboard", "📊"),
        POS("POS", "🛒"),
        STAFF("Staff Management", "👥"),
        INVENTORY("Inventory", "📦"),
        REPORTS("Reports", "📈"),
        FINANCE("Finance Entry", "💳"),
        DAILY_ANALYTICS("Daily Analytics", "🧮"),
        SALES_PATTERN("Sales Pattern", "🎯"),
        RISK_ALERTS("Risk Alerts", "🏥"),
        AUDIT_TRAIL("Audit Trail", "📋"),
        RECYCLE_BIN("Recycle Bin", "🗑️"),
        SMART_STOCK("Smart Stock", "📦"),
        STOCK_AUDIT("Stock Audit", "🔍"),
        AI_PREDICTIONS("AI Predictions", "🧠"),
        FIXED_EXPENSES("Fixed Expenses", "🧾"),
        INVESTMENTS("Investments", "💰")
    }

    private val _enabledFeatures = MutableStateFlow<Set<Feature>>(Feature.entries.toSet())
    val enabledFeatures: StateFlow<Set<Feature>> = _enabledFeatures.asStateFlow()

    fun setFeatures(features: Set<Feature>) {
        _enabledFeatures.value = features
    }

    fun isFeatureEnabled(feature: Feature): Boolean {
        return _enabledFeatures.value.contains(feature)
    }

    // Helper to get all features for Admin UI
    fun getAllFeatures(): List<Feature> = Feature.entries
}
