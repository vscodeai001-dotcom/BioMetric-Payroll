package com.biometric.app.ui

import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.DayData
import com.biometric.app.databinding.ActivityDayOfWeekLedgerBinding
import com.biometric.app.databinding.ItemPatternLedgerRowBinding
import com.biometric.app.ui.viewmodel.ReportsViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class DayOfWeekLedgerActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityDayOfWeekLedgerBinding
    private val viewModel: ReportsViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel

    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var selectedCalendar: Calendar = Calendar.getInstance()
    private var shopId: String? = null
    private var currentFilter = "Monthly"
    private var selectedDayOfWeek: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityDayOfWeekLedgerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopId = intent.getStringExtra("SHOP_ID") ?: sharedViewModel.selectedShop.value?.shopId
        
        setupToolbar()
        setupFilters()
        setupRecyclerView()
        observeViewModel()

        // Default selection based on TODAY
        val today = Calendar.getInstance().get(Calendar.DAY_OF_WEEK)
        selectedDayOfWeek = today
        val chipId = when(today) {
            Calendar.MONDAY -> R.id.chipMon
            Calendar.TUESDAY -> R.id.chipTue
            Calendar.WEDNESDAY -> R.id.chipWed
            Calendar.THURSDAY -> R.id.chipThu
            Calendar.FRIDAY -> R.id.chipFri
            Calendar.SATURDAY -> R.id.chipSat
            Calendar.SUNDAY -> R.id.chipSun
            else -> null
        }
        chipId?.let { binding.cgDayOfWeek.check(it) }
        
        refreshData()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        
        updateProfileHeader()
    }

    private fun updateProfileHeader() {
        val shopName = sharedViewModel.selectedShop.value?.name ?: "Shop"
        setupDualHeader(binding.toolbar, shopName, "Day Pattern Ledger")
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateProfileHeader()
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        if (item.itemId == android.R.id.home) {
            finish()
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupFilters() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }
        
        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(this, currentFilter, selectedCalendar) { newDate ->
                selectedCalendar.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }

        // Day of Week Selector
        binding.cgDayOfWeek.setOnCheckedStateChangeListener { _, checkedIds ->
            selectedDayOfWeek = when(checkedIds.firstOrNull()) {
                R.id.chipMon -> Calendar.MONDAY
                R.id.chipTue -> Calendar.TUESDAY
                R.id.chipWed -> Calendar.WEDNESDAY
                R.id.chipThu -> Calendar.THURSDAY
                R.id.chipFri -> Calendar.FRIDAY
                R.id.chipSat -> Calendar.SATURDAY
                R.id.chipSun -> Calendar.SUNDAY
                else -> null // User unselected the chip
            }
            // Trigger UI update with existing data using unified filtering
            applyFiltersAndNotify(viewModel.reportData.value.dayWiseReport)
        }
    }

    private fun setupRecyclerView() {
        binding.rvLedgerList.layoutManager = LinearLayoutManager(this)
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedCalendar, amount)
        refreshData()
    }

    private fun refreshData() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedCalendar.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedCalendar.timeInMillis)
        
        val range = DateRangeUtil.getRangeForPeriod(currentFilter, selectedCalendar.timeInMillis)
        viewModel.loadReportsForPeriod(shopId, range.first, range.second, includeBonus = true)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            updateProfileHeader()
                            refreshData()
                        }
                    }
                }
                launch {
                    viewModel.reportData.collectLatest { state ->
                        if (viewModel.isLoading.value) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                            applyFiltersAndNotify(state.dayWiseReport)
                        }
                    }
                }
            }
        }
    }

    private fun applyFiltersAndNotify(report: List<DayData>) {
        val todayMidnight = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
        }.timeInMillis

        val filteredList = report.filter { day ->
            // 1. Filter by selected Day of Week (if any)
            val matchesDay = if (selectedDayOfWeek != null) {
                day.calendar.get(Calendar.DAY_OF_WEEK) == selectedDayOfWeek
            } else true
            
            // 2. Filter out Current and Future days with 0 sales
            val isTodayOrFuture = day.calendar.timeInMillis >= todayMidnight
            val hasNoSales = day.totalIn < 0.01
            
            matchesDay && !(isTodayOrFuture && hasNoSales)
        }
        updateUI(filteredList)
    }

    private fun updateUI(list: List<DayData>) {
        val adapter = LedgerAdapter(list)
        binding.rvLedgerList.adapter = adapter
        
        if (list.isNotEmpty()) {
            val totalSales = list.sumOf { it.totalIn }
            val totalOut = list.sumOf { it.totalOut + it.salaryEarned + it.fixedExpense }
            val totalProfit = totalSales - totalOut
            
            val avgSales = totalSales / list.size
            val avgOut = totalOut / list.size
            
            binding.tvTotalSales.text = String.format(Locale.getDefault(), "₹ %.2f", totalSales)
            binding.tvTotalOutflow.text = String.format(Locale.getDefault(), "₹ %.2f", totalOut)
            binding.tvTotalNetProfit.text = String.format(Locale.getDefault(), "₹ %.2f", totalProfit)
            binding.tvTotalNetProfit.setTextColor(ContextCompat.getColor(this, if (totalProfit >= 0) R.color.green else R.color.red))
            
            binding.tvAvgSales.text = String.format(Locale.getDefault(), "₹ %.2f", avgSales)
            binding.tvAvgOutflow.text = String.format(Locale.getDefault(), "₹ %.2f", avgOut)
            
            val headerLabel = if (selectedDayOfWeek != null) {
                getString(R.string.label_average_pattern, getDayName(selectedDayOfWeek!!).uppercase())
            } else {
                "AVERAGE PERIOD PATTERN"
            }
            binding.tvAvgHeader.text = headerLabel
            
            val highestDay = list.maxByOrNull { it.totalIn }
            // REQUIREMENT: Lowest amt shows only > 0. If any day sales 0, no need to show as 0 -> shows next least.
            val lowestDay = list.filter { it.totalIn > 0.01 }.minByOrNull { it.totalIn }
            
            val sdf = SimpleDateFormat("dd MMM", Locale.getDefault())
            binding.tvHighestDay.text = highestDay?.let { "${sdf.format(it.calendar.time)} (₹%.2f)".format(it.totalIn) } ?: "--"
            binding.tvLowestDay.text = lowestDay?.let { "${sdf.format(it.calendar.time)} (₹%.2f)".format(it.totalIn) } ?: "--"
        } else {
            binding.tvTotalSales.text = "₹ 0.00"
            binding.tvTotalOutflow.text = "₹ 0.00"
            binding.tvTotalNetProfit.text = "₹ 0.00"
            binding.tvAvgSales.text = "₹ 0.00"
            binding.tvAvgOutflow.text = "₹ 0.00"
            binding.tvHighestDay.text = "--"
            binding.tvLowestDay.text = "--"
        }
    }

    private fun getDayName(day: Int) = when(day) {
        Calendar.MONDAY -> "Monday"
        Calendar.TUESDAY -> "Tuesday"
        Calendar.WEDNESDAY -> "Wednesday"
        Calendar.THURSDAY -> "Thursday"
        Calendar.FRIDAY -> "Friday"
        Calendar.SATURDAY -> "Saturday"
        else -> "Sunday"
    }

    inner class LedgerAdapter(private val items: List<DayData>) : RecyclerView.Adapter<LedgerAdapter.ViewHolder>() {
        inner class ViewHolder(val binding: ItemPatternLedgerRowBinding) : RecyclerView.ViewHolder(binding.root)
        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val b = ItemPatternLedgerRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(b)
        }
        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val data = items[position]
            val outflow = data.totalOut + data.salaryEarned + data.fixedExpense
            val profit = data.totalIn - outflow

            holder.binding.tvDate.text = SimpleDateFormat("dd MMM", Locale.getDefault()).format(data.calendar.time)
            holder.binding.tvCash.text = "%.2f".format(data.cashIn)
            holder.binding.tvQr.text = "%.2f".format(data.qrIn)
            holder.binding.tvTotal.text = "%.2f".format(data.totalIn)
            holder.binding.tvOut.text = "%.2f".format(outflow)
            holder.binding.tvProfit.text = "%.2f".format(profit)
            holder.binding.tvProfit.setTextColor(ContextCompat.getColor(this@DayOfWeekLedgerActivity, if (profit >= 0) R.color.green else R.color.red))
        }
        override fun getItemCount() = items.size
    }
}
