package com.biometric.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.FixedExpense
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import javax.inject.Inject

data class ExpenseCategoryItem(
    val category: String,
    val amount: Double,
    val percentage: Double = 0.0
)

data class ExpenseAnalysisState(
    val categories: List<ExpenseCategoryItem> = emptyList(),
    val totalExpense: Double = 0.0,
    val insights: List<String> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class ExpenseAnalysisViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(ExpenseAnalysisState())
    val state: StateFlow<ExpenseAnalysisState> = _state.asStateFlow()

    fun loadAnalysis(shopId: String, period: String, date: Long) {
        viewModelScope.launch(Dispatchers.Default) {
            val (start, end) = getTimestampsForPeriod(period, date)
            val cacheKey = "expense_analysis_${shopId}_${period}_${start}_${end}"
            
            // OPTIMISTIC UI: Try to load from cache first
            val cached = repository.getListCache<ExpenseAnalysisState>(cacheKey).firstOrNull()
            
            // UNIFORM LOADING: Only set loading true if no cache available
            _state.update { (cached ?: it).copy(isLoading = cached == null) }

            // 1. Get Cashbook Outflow (excluding Salary/Advance)
            val cashbookEntries = repository.getCashbookEntriesForPeriod(shopId, start, end).first()
            val filteredCashbook = cashbookEntries.filter { 
                it.transactionType == "OUT" && 
                !(it.category.contains("SALARY", ignoreCase = true) || (it.description?.contains("SALARY", ignoreCase = true) == true)) &&
                it.category != "ADVANCE"
            }
            
            val cashbookGroups = filteredCashbook.groupBy { it.category }
                .mapValues { it.value.sumOf { entry -> entry.amount } }

            // 2. Get Prorated Fixed Expenses
            val fixedExpenses = repository.getFixedExpensesForShop(shopId).first()
            val fixedBreakdown = calculateFixedBreakdown(fixedExpenses, start, end)

            // 3. Get Staff Salary
            val totalSalary = repository.calculateProjectedSalary(shopId, start, end)

            // Combine all
            val combinedMap = mutableMapOf<String, Double>()
            
            cashbookGroups.forEach { (cat, amt) ->
                combinedMap[cat] = (combinedMap[cat] ?: 0.0) + amt
            }
            
            fixedBreakdown.forEach { (name, amt) ->
                combinedMap[name] = (combinedMap[name] ?: 0.0) + amt
            }
            
            if (totalSalary > 0) {
                combinedMap["Staff Salary"] = totalSalary
            }

            val total = combinedMap.values.sum()
            val items = combinedMap.map { (cat, amt) ->
                ExpenseCategoryItem(cat, amt, if (total > 0) (amt / total) * 100 else 0.0)
            }.sortedByDescending { it.amount }

            val insights = generateInsights(items, total)

            val finalState = _state.value.copy(
                categories = items,
                totalExpense = total,
                insights = insights,
                isLoading = false
            )
            repository.saveListCache(cacheKey, listOf(finalState))
            _state.value = finalState
        }
    }

    private fun calculateFixedBreakdown(expenses: List<FixedExpense>, start: Long, end: Long): Map<String, Double> {
        val breakdown = mutableMapOf<String, Double>()
        if (start > end) return breakdown

        val expensesByShopAndName = expenses.groupBy { it.name }
        val tempCal = Calendar.getInstance()

        var currentDay = start
        while (currentDay <= end) {
            tempCal.timeInMillis = currentDay
            val daysInMonth = tempCal.getActualMaximum(Calendar.DAY_OF_MONTH)

            expensesByShopAndName.forEach { (name, expenseVersions) ->
                val activeExpense = expenseVersions
                    .filter { !it.isArchived && it.effectiveFrom <= currentDay }
                    .maxByOrNull { it.effectiveFrom }

                activeExpense?.let { expense ->
                    if (daysInMonth > 0) {
                        val dailyRate = expense.monthlyAmount / daysInMonth
                        breakdown[name] = (breakdown[name] ?: 0.0) + dailyRate
                    }
                }
            }
            tempCal.add(Calendar.DAY_OF_YEAR, 1)
            currentDay = tempCal.timeInMillis
        }
        return breakdown
    }

    private fun generateInsights(items: List<ExpenseCategoryItem>, total: Double): List<String> {
        val insights = mutableListOf<String>()
        if (items.isEmpty()) return listOf("No expense data recorded for this period.")

        val highest = items.first()
        insights.add("⚠ Highest Expense Category: \"${highest.category}\" accounts for ${highest.percentage.toInt()}% of total expenses.")

        if (highest.category.contains("Ingredients", ignoreCase = true) || highest.category.contains("Purchase", ignoreCase = true)) {
            insights.add("💡 Cost Reduction Suggestion: Consider optimizing inventory and bulk purchases for ${highest.category.lowercase()}.")
        } else if (highest.category == "Staff Salary") {
            insights.add("💡 Tip: Monitor staff productivity vs sales to ensure salary efficiency.")
        }

        if (total > 0) {
            insights.add("📊 Total spending for this period is ${String.format(Locale.getDefault(), "₹%.2f", total)}.")
        }

        return insights
    }

    private fun getTimestampsForPeriod(period: String, date: Long): Pair<Long, Long> {
        return DateRangeUtil.getRangeForPeriod(period, date)
    }
}
