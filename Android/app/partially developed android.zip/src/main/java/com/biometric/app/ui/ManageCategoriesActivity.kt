package com.biometric.app.ui

import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.ExpenseCategory
import com.biometric.app.databinding.ActivityManageListBinding
import com.biometric.app.databinding.DialogAddCategoryBinding
import com.biometric.app.databinding.ItemSettingsListRowBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.MotionManager
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import kotlin.time.Duration.Companion.milliseconds

@AndroidEntryPoint
class ManageCategoriesActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityManageListBinding
    private val viewModel: MainViewModel by viewModels()
    private lateinit var adapter: CategoryListAdapter
    private var currentShopId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityManageListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        currentShopId = intent.getStringExtra("SHOP_ID")
        viewModel.setManagementShopId(currentShopId)

        setupToolbar()
        setupRecyclerView()
        setupListeners()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        setupDualHeader(binding.toolbar, "Master Data ⚙️", "Manage Categories")
    }

    private fun setupRecyclerView() {
        adapter = CategoryListAdapter(
            onEdit = { showAddCategoryDialog(it) },
            onDelete = { confirmDelete(it) }
        )
        binding.rvList.layoutManager = LinearLayoutManager(this)
        binding.rvList.adapter = adapter
    }

    private fun setupListeners() {
        binding.fabAdd.setOnClickListener {
            showAddCategoryDialog()
        }

        binding.etSearch.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                adapter.filter(s.toString())
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        setupMotionFeedback(binding.fabAdd)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.expenseCategories.collectLatest { categories ->
                    adapter.submitFullList(categories)
                }
            }
        }
    }

    private fun showAddCategoryDialog(existing: ExpenseCategory? = null) {
        val dialogBinding = DialogAddCategoryBinding.inflate(layoutInflater)
        
        existing?.let {
            dialogBinding.etCategoryName.setText(it.name)
            dialogBinding.etEmoji.setText(it.emoji)
            dialogBinding.cbIsFixed.isChecked = it.isFixed
        }

        // ATOMIC AUTO-FOCUS
        var autoFocusJob: kotlinx.coroutines.Job? = null
        dialogBinding.etCategoryName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (dialogBinding.etCategoryName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        delay(1500.milliseconds)
                        dialogBinding.etEmoji.requestFocus()
                    }
                }
            }
        })

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) "Add Category" else "Edit Category")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val name = dialogBinding.etCategoryName.text.toString().trim()
                val emoji = dialogBinding.etEmoji.text.toString().trim().ifEmpty { "💰" }
                val isFixed = dialogBinding.cbIsFixed.isChecked

                if (name.isNotEmpty()) {
                    val cat = existing?.copy(name = name, emoji = emoji, isFixed = isFixed)
                        ?: ExpenseCategory(name = name, emoji = emoji, isFixed = isFixed, shopId = currentShopId)
                    
                    viewModel.addExpenseCategory(cat)
                    MotionManager.playUpdateMorph(binding.animFeedback)
                    HapticUtil.vibrateSuccess(binding.root)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun confirmDelete(cat: ExpenseCategory) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Category?")
            .setMessage(getString(R.string.msg_delete_category_confirm, cat.name))
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteExpenseCategory(cat)
                MotionManager.playDeleteDissolve(binding.animFeedback)
                HapticUtil.vibrateSuccess(binding.root)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    inner class CategoryListAdapter(
        private val onEdit: (ExpenseCategory) -> Unit,
        private val onDelete: (ExpenseCategory) -> Unit
    ) : RecyclerView.Adapter<CategoryListAdapter.ViewHolder>() {

        private var fullList: List<ExpenseCategory> = emptyList()
        private var filteredList: List<ExpenseCategory> = emptyList()

        fun submitFullList(list: List<ExpenseCategory>) {
            fullList = list
            filter(binding.etSearch.text.toString())
        }

        fun filter(query: String) {
            filteredList = if (query.isEmpty()) {
                fullList
            } else {
                fullList.filter { it.name.contains(query, ignoreCase = true) }
            }
            notifyDataSetChanged()
        }

        inner class ViewHolder(val binding: ItemSettingsListRowBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val b = ItemSettingsListRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(b)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = filteredList[position]
            holder.binding.tvItemIcon.text = item.emoji
            holder.binding.tvItemName.text = item.name
            holder.binding.tvItemSubtitle.text = if (item.isFixed) getString(R.string.label_fixed_expense_type) else getString(R.string.label_variable_expense_type)
            
            holder.binding.btnEdit.setOnClickListener { onEdit(item) }
            holder.binding.btnDelete.setOnClickListener { onDelete(item) }
            
            MotionManager.applyTouchScale(holder.binding.root)
        }

        override fun getItemCount() = filteredList.size
    }
}
