package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class ExpenseCategory(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = UUID.randomUUID().toString(),

    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String? = null, // null for global, otherwise specific shop
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("emoji") @set:PropertyName("emoji")
    var emoji: String = "💰",
    
    @get:PropertyName("isFixed") @set:PropertyName("isFixed")
    var isFixed: Boolean = false,
    
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true
)
