package com.biometric.app.data.dao

// Removed. Using Firebase Realtime Database.
