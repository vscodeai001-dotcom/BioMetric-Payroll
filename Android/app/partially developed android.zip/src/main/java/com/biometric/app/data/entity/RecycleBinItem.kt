package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class RecycleBinItem(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = UUID.randomUUID().toString(),
    
    @get:PropertyName("recordId") @set:PropertyName("recordId")
    var recordId: String = "",

    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String? = null,
    
    @get:PropertyName("module") @set:PropertyName("module")
    var module: String = "", // CASHBOOK, STAFF, ATTENDANCE, etc.
    
    @get:PropertyName("actionType") @set:PropertyName("actionType")
    var actionType: String = "DELETED", // DELETED, UPDATED
    
    @get:PropertyName("snapshotJson") @set:PropertyName("snapshotJson")
    var snapshotJson: String = "",
    
    @get:PropertyName("previousValueJson") @set:PropertyName("previousValueJson")
    var previousValueJson: String? = null,
    
    @get:PropertyName("timestamp") @set:PropertyName("timestamp")
    var timestamp: Long = System.currentTimeMillis(),
    
    @get:PropertyName("userId") @set:PropertyName("userId")
    var userId: String = "",
    
    @get:PropertyName("userName") @set:PropertyName("userName")
    var userName: String = "",
    
    @get:PropertyName("itemName") @set:PropertyName("itemName")
    var itemName: String = "" // Display name like "Staff: John" or "Cash: ₹500"
)
