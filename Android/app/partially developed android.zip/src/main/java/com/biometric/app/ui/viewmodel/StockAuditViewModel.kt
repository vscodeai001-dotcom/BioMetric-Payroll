package com.biometric.app.ui.viewmodel

import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.InventoryItem
import com.biometric.app.data.entity.StockAudit
import com.biometric.app.data.entity.StockAuditItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * UI State for the Stock Audit screen.
 *
 * @property items List of items being audited.
 * @property totalVarianceValue The cumulative financial value of all variances found.
 * @property isLoading Flag for showing a progress indicator.
 * @property isSubmitted Flag indicating if the audit has been successfully pushed to the repository.
 */
data class StockAuditState(
    val items: List<StockAuditItemUI> = emptyList(),
    val totalVarianceValue: Double = 0.0,
    val isLoading: Boolean = false,
    val isSubmitted: Boolean = false,
)

/**
 * UI representation of an inventory item during an audit.
 *
 * @property item The original inventory item from the database.
 * @property physicalQty The actual quantity counted manually in the shop.
 * @property variance The difference between physical quantity and system quantity.
 */
data class StockAuditItemUI(
    val item: InventoryItem,
    var physicalQty: Double = 0.0,
    var variance: Double = 0.0
)

/**
 * ViewModel for managing the Stock Audit process.
 * Handles loading inventory items, tracking physical counts, and submitting the audit results.
 */
@HiltViewModel
class StockAuditViewModel @Inject constructor(
    private val repository: MainRepository
) : ViewModel() {

    private val _state = MutableStateFlow(StockAuditState())
    val state: StateFlow<StockAuditState> = _state.asStateFlow()

    private var shopId: String = ""

    fun setShopId(id: String) {
        if (shopId == id) return
        shopId = id
        loadInventory()
    }

    private fun loadInventory() {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            repository.getShopInventory(shopId).collectLatest { inventory ->
                val uiItems = inventory.map { StockAuditItemUI(it, it.totalQuantity, 0.0) }
                _state.update { it.copy(items = uiItems, isLoading = false) }
            }
        }
    }

    fun updatePhysicalQty(itemName: String, qty: Double) {
        val currentItems = _state.value.items.toMutableList()
        val index = currentItems.indexOfFirst { it.item.name == itemName }
        if (index != -1) {
            val uiItem = currentItems[index]
            val variance = qty - uiItem.item.totalQuantity
            currentItems[index] = uiItem.copy(physicalQty = qty, variance = variance)
            
            val totalVariance = currentItems.sumOf { it.variance * (it.item.totalCost / it.item.totalQuantity.coerceAtLeast(1.0)) }
            
            _state.update { it.copy(items = currentItems, totalVarianceValue = totalVariance) }
        }
    }

    fun submitAudit(userName: String, userId: String) {
        viewModelScope.launch {
            _state.update { it.copy(isLoading = true) }
            try {
                val auditItems = _state.value.items.map { ui ->
                    StockAuditItem(
                        itemName = ui.item.name,
                        systemQty = ui.item.totalQuantity,
                        physicalQty = ui.physicalQty,
                        variance = ui.variance,
                        unitType = ui.item.unitType
                    )
                }

                val audit = StockAudit(
                    shopId = shopId,
                    items = auditItems,
                    totalVariance = _state.value.totalVarianceValue,
                    userId = userId,
                    userName = userName
                )

                repository.pushStockAudit(audit)
                
                // Optional: Adjust inventory based on audit? 
                // Business rule check needed. For now just log.
                
                _state.update { it.copy(isLoading = false, isSubmitted = true) }
            } catch (e: Exception) {
                Log.e("StockAuditVM", "Error submitting audit", e)
                _state.update { it.copy(isLoading = false) }
            }
        }
    }
}
