package com.biometric.app.data

import androidx.room.Database
import androidx.room.RoomDatabase
import com.biometric.app.data.dao.LocationDao
import com.biometric.app.data.entity.LocationTrack

@Database(entities = [LocationTrack::class], version = 1, exportSchema = false)
abstract class AppDatabase : RoomDatabase() {
    abstract fun locationDao(): LocationDao
}
