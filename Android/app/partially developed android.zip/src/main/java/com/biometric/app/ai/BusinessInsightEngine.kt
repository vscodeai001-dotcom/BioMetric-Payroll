package com.biometric.app.ai

import com.biometric.app.data.RawMetrics
import com.biometric.app.data.entity.Employee
import com.biometric.app.data.entity.InventoryItem
import java.util.*
import kotlin.math.abs

object BusinessInsightEngine {

    fun analyze(intent: AiIntent, bundle: BusinessDataBundle): List<BusinessInsight> {
        val insights = mutableListOf<BusinessInsight>()
        val m = bundle.metrics
        val pm = bundle.previousMetrics

        // 0. Time Comparison Analysis
        if (intent == AiIntent.TIME_COMPARISON && pm != null) {
            val salesDiff = m.sales - pm.sales
            val profitDiff = m.profit - pm.profit
            
            insights.add(
                BusinessInsight(
                    title = "Time Comparison",
                    description = String.format(
                        Locale.getDefault(), 
                        "Comparing %s vs %s: Sales are %s by ₹%.0f, and Profit is %s by ₹%.0f.",
                        bundle.periodLabel, bundle.previousPeriodLabel,
                        if (salesDiff >= 0) "UP" else "DOWN", abs(salesDiff),
                        if (profitDiff >= 0) "UP" else "DOWN", abs(profitDiff)
                    ),
                    impact = if (profitDiff >= 0) ImpactLevel.POSITIVE else ImpactLevel.NEGATIVE,
                    trend = if (profitDiff >= 0) TrendDirection.UP else TrendDirection.DOWN,
                    reason = "Direct comparative analysis between the two requested periods."
                )
            )
        }

        // 1. Profit & Loss Analysis
        if ((pm != null) && (pm.profit != 0.0)) {
            val diff = m.profit - pm.profit
            val diffPercent = (diff / abs(pm.profit)) * 100
            
            if (diffPercent > 5) {
                insights.add(
                    BusinessInsight(
                        title = "Profit Growth",
                        description = String.format(Locale.getDefault(), "Your profit increased by %.1f%% compared to %s.", diffPercent, bundle.previousPeriodLabel),
                        impact = ImpactLevel.POSITIVE,
                        trend = TrendDirection.UP,
                        reason = if (m.sales > pm.sales) "Higher sales volume" else "Reduced operational costs",
                    )
                )
            } else if (diffPercent < -5) {
                val reason = when {
                    m.expense > pm.expense -> String.format(Locale.getDefault(), "Increase in variable expenses (up ₹%.0f)", m.expense - pm.expense)
                    m.salary > pm.salary -> "Higher staff salary payouts"
                    m.sales < pm.sales -> String.format(Locale.getDefault(), "Dip in sales revenue (down ₹%.0f)", pm.sales - m.sales)
                    else -> "Increased overheads"
                }
                insights.add(
                    BusinessInsight(
                        title = "Profit Decline",
                        description = String.format(Locale.getDefault(), "Profit dropped by %.1f%% from %s.", abs(diffPercent), bundle.previousPeriodLabel),
                        impact = ImpactLevel.NEGATIVE,
                        trend = TrendDirection.DOWN,
                        reason = reason,
                        recommendation = "Review the $reason and consider cost-cutting measures.",
                    )
                )
            }
        }

        // 2. Sales Analysis
        if ((m.sales > 0) && (pm != null) && (pm.sales > 0)) {
            val salesDiff = ((m.sales - pm.sales) / pm.sales) * 100
            if (salesDiff < -10) {
                insights.add(
                    BusinessInsight(
                        title = "Sales Alert",
                        description = String.format(Locale.getDefault(), "Revenue is down by %.1f%% this period.", abs(salesDiff)),
                        impact = ImpactLevel.NEGATIVE,
                        trend = TrendDirection.DOWN,
                        recommendation = "Run a promotion on your top selling items to boost traffic.",
                    )
                )
            }
        }

        // 3. Operational Efficiency
        if (m.sales > 0) {
            val totalCost = m.expense + m.salary + m.fixed
            val expenseRatio = (totalCost / m.sales) * 100
            if (expenseRatio > 55) {
                insights.add(
                    BusinessInsight(
                        title = "High Operational Costs",
                        description = String.format(Locale.getDefault(), "Expenses are consuming %.1f%% of your revenue.", expenseRatio),
                        impact = ImpactLevel.HIGH,
                        trend = TrendDirection.STABLE,
                        recommendation = "Check for wastage in groceries or optimize staff shifts.",
                    )
                )
            }
        }

        // 4. Staff & Attendance Insights
        val employeesRaw = bundle.extraContext["employees"]
        val attendanceRaw = bundle.extraContext["attendance"]
        
        if (employeesRaw is List<*> && attendanceRaw is List<*> && (intent == AiIntent.ATTENDANCE_QUERY || intent == AiIntent.GENERAL)) {
            val employees = employeesRaw.filterIsInstance<Employee>()
            val attendance = attendanceRaw.filterIsInstance<com.biometric.app.data.entity.Attendance>()

            val attendanceByEmp = attendance.groupBy { it.employeeId }
            
            // Find most absent (least present records)
            val staffAttendanceStats = employees.map { emp ->
                val presentDays = attendanceByEmp[emp.employeeId]?.distinctBy { 
                    val cal = Calendar.getInstance().apply { timeInMillis = it.checkInTime }
                    "${cal[Calendar.YEAR]}_${cal[Calendar.DAY_OF_YEAR]}"
                }?.size ?: 0
                emp.name to presentDays
            }
            
            val totalDaysInRange = if (bundle.cashbookEntries.isNotEmpty()) {
                val maxDate = bundle.cashbookEntries.maxOf { it.transactionDate }
                val minDate = bundle.cashbookEntries.minOf { it.transactionDate }
                ((maxDate - minDate) / 86400000L + 1).toInt().coerceAtLeast(1)
            } else {
                val cal = Calendar.getInstance()
                cal.getActualMaximum(Calendar.DAY_OF_MONTH) // Fallback to month length
            }
            
            // Simplified: Just report staff with 0 attendance or low attendance
            val absentStaff = staffAttendanceStats.filter { it.second == 0 }
            val irregularStaff = staffAttendanceStats.filter { it.second > 0 && (it.second < (totalDaysInRange * 0.7)) }

            if (absentStaff.isNotEmpty()) {
                insights.add(
                    BusinessInsight(
                        title = "Staff Absence",
                        description = String.format(Locale.getDefault(), "%d staff members had ZERO attendance during %s.", absentStaff.size, bundle.periodLabel),
                        impact = ImpactLevel.NEGATIVE,
                        trend = TrendDirection.DOWN,
                        reason = "Totally absent: ${absentStaff.joinToString { it.first }}",
                        recommendation = "Check if these employees have left the job or if their attendance wasn't marked."
                    )
                )
            }
            
            if (irregularStaff.isNotEmpty()) {
                val mostIrregular = irregularStaff.minBy { it.second }
                insights.add(
                    BusinessInsight(
                        title = "Irregular Attendance",
                        description = String.format(Locale.getDefault(), "%s has the lowest attendance with only %d days present in %s.", mostIrregular.first, mostIrregular.second, bundle.periodLabel),
                        impact = ImpactLevel.NEGATIVE,
                        trend = TrendDirection.DOWN,
                        recommendation = "Speak with ${mostIrregular.first} regarding their frequent absences."
                    )
                )
            }
            
            if (absentStaff.isEmpty() && irregularStaff.isEmpty() && employees.isNotEmpty()) {
                insights.add(
                    BusinessInsight(
                        title = "Perfect Attendance",
                        description = "All staff members are regular with their attendance! 🌟",
                        impact = ImpactLevel.POSITIVE,
                        trend = TrendDirection.STABLE
                    )
                )
            }
        }
        
        // 5. Salary Liability Insight
        val salaryLiability = bundle.extraContext["salary_liability"] as? Double
        if (salaryLiability != null && (intent == AiIntent.SALARY_QUERY || intent == AiIntent.GENERAL)) {
            insights.add(BusinessInsight(
                title = "Salary Liability",
                description = String.format(Locale.getDefault(), "Total estimated salary for this period is ₹%.0f.", salaryLiability),
                impact = ImpactLevel.NEUTRAL,
                trend = TrendDirection.STABLE,
                recommendation = "Ensure you have enough cash flow to cover staff payments."
            ))
        }

        // 6. Inventory Analysis
        val inventoryRaw = bundle.extraContext["inventory"]
        if (inventoryRaw is List<*> && (intent == AiIntent.STOCK_QUERY || intent == AiIntent.GENERAL)) {
            val inventory = inventoryRaw.filterIsInstance<InventoryItem>()
            val lowStockItems = inventory.filter { it.totalQuantity < 5 }
            if (lowStockItems.isNotEmpty()) {
                val names = lowStockItems.asSequence().take(3).joinToString { it.name }
                insights.add(
                    BusinessInsight(
                        title = "Stock Alert",
                        description = "$names and ${lowStockItems.size - lowStockItems.asSequence().take(3).toList().size} others are running low.",
                        impact = ImpactLevel.NEGATIVE,
                        trend = TrendDirection.DOWN,
                        recommendation = "Replenish these items immediately to avoid stockouts.",
                    )
                )
            }
        }

        return insights
    }

    fun calculateHealthScore(m: RawMetrics): Int {
        if (m.sales <= 0) return 0
        val profitMargin = (m.profit / m.sales) * 100
        val expenseRatio = ((m.expense + m.salary + m.fixed) / m.sales) * 100
        
        var score = 60 // Base
        score += (profitMargin * 0.8).toInt()
        score -= (expenseRatio * 0.5).toInt()
        
        return score.coerceIn(0, 100)
    }
}
