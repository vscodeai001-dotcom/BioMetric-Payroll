package com.biometric.app.ui

import android.app.DatePickerDialog
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.github.mikephil.charting.formatter.PercentFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivitySpendAnalysisBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.ui.viewmodel.*
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class SpendAnalysisActivity : MotionBaseActivity() {

    private lateinit var binding: ActivitySpendAnalysisBinding
    private val viewModel: SpendAnalysisViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter
    
    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivitySpendAnalysisBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fix Task bar overlap
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Spend Analysis")
        
        if (isGlobal) shopId = ""

        setupToolbar(shopName)
        setupUI()
        setupCharts()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Spend Analysis")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadAnalysis(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun setupCharts() {
        ChartStyleManager.applyChartStyle(binding.pieChartAllSpends, this)
        binding.pieChartAllSpends.apply {
            setUsePercentValues(true)
            dragDecelerationFrictionCoef = 0.95f
            isDrawHoleEnabled = true
            holeRadius = 58f
            transparentCircleRadius = 61f
            setDrawCenterText(true)
            centerText = "Spend Share"
            rotationAngle = 0f
            isRotationEnabled = true
            isHighlightPerTapEnabled = true
            setEntryLabelTextSize(10f)
        }

        ChartStyleManager.applyChartStyle(binding.lineChartTrend, this)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.items.isEmpty() && state.allExpenseCategories.isEmpty()
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.SPEND_ANALYSIS, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }

                        if (!state.isLoading) {
                            updateSummaryUI(state)
                            updatePieChart(state.allExpenseCategories)
                            updateTrendChart(state.trendData)
                            updateItemTable(state.items)
                            updateSupplierList(state.suppliers)
                            updateInsights(state.insights)
                        }
                    }
                }
            }
        }
    }

    private fun updateSummaryUI(state: SpendAnalysisState) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        binding.tvTotalSpending.text = currencyFormat.format(state.totalBusinessSpending)
        binding.tvSummaryPurchase.text = formatLargeCurrency(state.totalPurchase)
        binding.tvSummarySalary.text = formatLargeCurrency(state.totalSalary)
        binding.tvSummaryFixed.text = formatLargeCurrency(state.totalFixed)

        binding.tvTotalPurchase.text = currencyFormat.format(state.totalPurchase)
        binding.tvAvgDailyPurchase.text = currencyFormat.format(state.avgDailyPurchase)
        binding.tvPurchaseRatio.text = String.format(Locale.getDefault(), "%.1f%%", state.purchaseToSalesRatio)
        
        val trendIcon = if (state.trendPercentage >= 0) "📈" else "📉"
        binding.tvPurchaseTrend.text = String.format(Locale.getDefault(), "%s %.1f%%", trendIcon, kotlin.math.abs(state.trendPercentage))
        binding.tvPurchaseTrend.setTextColor(ContextCompat.getColor(this, if (state.trendPercentage <= 0) R.color.green else R.color.red))
    }

    private fun formatLargeCurrency(value: Double): String {
        return if (value >= 100000) String.format(Locale.getDefault(), "₹%.1fL", value / 100000)
        else if (value >= 1000) String.format(Locale.getDefault(), "₹%.1fK", value / 1000)
        else String.format(Locale.getDefault(), "₹%.0f", value)
    }

    private fun updatePieChart(categories: List<SpendCategory>) {
        if (categories.isEmpty()) {
            binding.pieChartAllSpends.clear()
            binding.pieChartAllSpends.invalidate()
            return
        }

        val entries = categories.map { PieEntry(it.amount.toFloat(), it.icon + " " + it.category) }
        val dataSet = PieDataSet(entries, "").apply {
            colors = listOf(
                Color.parseColor("#4F46E5"), Color.parseColor("#10B981"),
                Color.parseColor("#F59E0B"), Color.parseColor("#EF4444"),
                Color.parseColor("#8B5CF6"), Color.parseColor("#EC4899"),
                Color.parseColor("#06B6D4")
            )
            sliceSpace = 3f
            selectionShift = 5f
        }

        val data = PieData(dataSet).apply {
            setValueFormatter(PercentFormatter(binding.pieChartAllSpends))
            setValueTextSize(11f)
            setValueTextColor(Color.WHITE)
        }

        binding.pieChartAllSpends.data = data
        binding.pieChartAllSpends.animateY(1400, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)
        binding.pieChartAllSpends.invalidate()
    }

    private fun updateTrendChart(trendPoints: List<SpendTrendPoint>) {
        if (trendPoints.isEmpty()) {
            binding.lineChartTrend.clear()
            binding.lineChartTrend.invalidate()
            return
        }

        val entries = trendPoints.mapIndexed { index, point -> Entry(index.toFloat(), point.amount.toFloat()) }
        val dataSet = LineDataSet(entries, "Daily Outflow").apply {
            color = Color.parseColor("#4F46E5")
            setDrawCircles(true)
            setCircleColor(Color.parseColor("#4F46E5"))
            lineWidth = 2f
            setDrawFilled(true)
            fillColor = Color.parseColor("#4F46E5")
            fillAlpha = 30
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        binding.lineChartTrend.xAxis.valueFormatter = IndexAxisValueFormatter(trendPoints.map { it.label })
        binding.lineChartTrend.data = LineData(dataSet)
        binding.lineChartTrend.animateX(1500)
        binding.lineChartTrend.invalidate()
    }

    private fun updateItemTable(items: List<SpendItem>) {
        val childCount = binding.tableItemDetails.childCount
        if (childCount > 2) {
            binding.tableItemDetails.removeViews(2, childCount - 2)
        }

        items.forEach { item ->
            val row = TableRow(this).apply {
                setPadding(0, 12, 0, 12)
            }

            val tvName = TextView(this).apply {
                text = String.format(Locale.getDefault(), "%s %s", item.trendIcon, item.name)
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.2f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            }

            val tvQty = TextView(this).apply {
                text = String.format(Locale.getDefault(), "%.0f", item.qty)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 0.8f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            }

            val tvSpend = TextView(this).apply {
                text = formatLargeCurrency(item.totalSpend)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setPadding(4, 0, 4, 0)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTypeface(null, Typeface.BOLD)
            }

            val tvAvg = TextView(this).apply {
                text = String.format(Locale.getDefault(), "₹%.0f", item.avgPrice)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(ContextCompat.getColor(this@SpendAnalysisActivity, R.color.text_secondary))
            }

            row.addView(tvName)
            row.addView(tvQty)
            row.addView(tvSpend)
            row.addView(tvAvg)
            binding.tableItemDetails.addView(row)
        }
    }

    private fun updateSupplierList(suppliers: List<SupplierSpend>) {
        binding.llSupplierList.removeAllViews()
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))

        suppliers.forEach { s ->
            val view = layoutInflater.inflate(R.layout.item_health_metric, binding.llSupplierList, false)
            view.findViewById<TextView>(R.id.tvMetricLabel).text = s.name
            view.findViewById<TextView>(R.id.tvMetricValue).text = String.format(Locale.getDefault(), "%.1f%% Share", s.share)
            view.findViewById<TextView>(R.id.tvMetricScore).text = currencyFormat.format(s.amount)
            
            val color = if (s.share > 50) R.color.red else R.color.green
            view.findViewById<View>(R.id.statusIndicator).setBackgroundColor(ContextCompat.getColor(this, color))
            
            binding.llSupplierList.addView(view)
        }
    }

    private fun updateInsights(insights: List<String>) {
        binding.llInsights.removeAllViews()
        insights.forEach { text ->
            val textView = TextView(this).apply {
                this.text = text
                setPadding(0, 12, 0, 12)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(ContextCompat.getColor(this@SpendAnalysisActivity, R.color.text_primary))
            }
            binding.llInsights.addView(textView)
        }
    }
}
