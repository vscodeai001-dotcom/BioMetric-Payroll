package com.biometric.app.util

import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.pdf.PdfDocument
import android.net.Uri
import android.util.Log
import androidx.core.content.FileProvider
import com.biometric.app.data.OrderWithItems
import com.biometric.app.data.entity.Shop
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*

class BillExportManager(private val context: Context) {

    fun generateBillPdf(shop: Shop, orderWithItems: OrderWithItems): File? {
        val pdfDocument = PdfDocument()
        val pageInfo = PdfDocument.PageInfo.Builder(300, 600, 1).create()
        val page = pdfDocument.startPage(pageInfo)
        val canvas: Canvas = page.canvas
        val paint = Paint()
        val titlePaint = Paint().apply {
            textSize = 14f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        val textPaint = Paint().apply {
            textSize = 10f
        }
        val boldPaint = Paint().apply {
            textSize = 10f
            isFakeBoldText = true
        }

        var y = 40f
        canvas.drawText(shop.name, 150f, y, titlePaint)
        y += 20f
        if (shop.location.isNotEmpty()) {
            canvas.drawText(shop.location, 150f, y, textPaint.apply { textAlign = Paint.Align.CENTER })
            y += 20f
        }
        canvas.drawLine(20f, y, 280f, y, paint)
        y += 20f

        textPaint.textAlign = Paint.Align.LEFT
        val sdf = SimpleDateFormat("dd/MM/yy HH:mm", Locale.getDefault())
        canvas.drawText("Bill: ${orderWithItems.order.orderId.takeLast(6)}", 20f, y, textPaint)
        y += 15f
        canvas.drawText("Date: ${sdf.format(Date(orderWithItems.order.closedAt ?: System.currentTimeMillis()))}", 20f, y, textPaint)
        y += 15f
        canvas.drawText("Type: ${orderWithItems.order.serviceType}", 20f, y, textPaint)
        y += 20f

        canvas.drawLine(20f, y, 280f, y, paint)
        y += 20f
        canvas.drawText("Item", 20f, y, boldPaint)
        canvas.drawText("Qty", 180f, y, boldPaint)
        canvas.drawText("Price", 230f, y, boldPaint)
        y += 15f

        orderWithItems.items.forEach { item ->
            canvas.drawText(item.itemName, 20f, y, textPaint)
            canvas.drawText(item.quantity.toInt().toString(), 180f, y, textPaint)
            canvas.drawText(String.format(Locale.getDefault(), "%.2f", item.subTotal), 230f, y, textPaint)
            y += 15f
        }

        canvas.drawLine(20f, y, 280f, y, paint)
        y += 25f
        canvas.drawText("TOTAL AMOUNT:", 120f, y, boldPaint)
        canvas.drawText(String.format(Locale.getDefault(), "Rs. %.2f", orderWithItems.order.totalAmount), 220f, y, boldPaint)
        
        y += 40f
        canvas.drawText("Thank you! Visit again.", 150f, y, textPaint.apply { textAlign = Paint.Align.CENTER })

        pdfDocument.finishPage(page)

        val file = File(context.cacheDir, "Bill_${orderWithItems.order.orderId.takeLast(6)}.pdf")
        return try {
            pdfDocument.writeTo(FileOutputStream(file))
            pdfDocument.close()
            file
        } catch (e: Exception) {
            Log.e("BillExportManager", "Error generating PDF", e)
            pdfDocument.close()
            null
        }
    }

    fun shareBillOnWhatsApp(file: File, phoneNumber: String = "") {
        val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        
        if (phoneNumber.isNotEmpty()) {
            val formattedPhone = if (phoneNumber.startsWith("+")) phoneNumber.removePrefix("+") else phoneNumber
            intent.setPackage("com.whatsapp")
            intent.putExtra("jid", "$formattedPhone@s.whatsapp.net")
        }

        val chooser = Intent.createChooser(intent, "Share Bill")
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
