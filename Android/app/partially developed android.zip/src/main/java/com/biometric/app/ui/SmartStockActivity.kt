package com.biometric.app.ui

import android.os.Bundle
import android.view.View
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.R
import com.biometric.app.databinding.ActivitySmartStockBinding
import com.biometric.app.ui.adapter.SmartStockAdapter
import com.biometric.app.ui.viewmodel.SmartStockViewModel
import com.biometric.app.util.PremiumLoader
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.util.*

@AndroidEntryPoint
class SmartStockActivity : MotionBaseActivity() {

    private lateinit var binding: ActivitySmartStockBinding
    private val viewModel: SmartStockViewModel by viewModels()
    
    private val urgentAdapter = SmartStockAdapter()
    private val plannedAdapter = SmartStockAdapter()
    private val allAdapter = SmartStockAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySmartStockBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupUI()
        observeViewModel()
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.rvUrgent.layoutManager = LinearLayoutManager(this)
        binding.rvUrgent.adapter = urgentAdapter

        binding.rvPlanned.layoutManager = LinearLayoutManager(this)
        binding.rvPlanned.adapter = plannedAdapter

        binding.rvAll.layoutManager = LinearLayoutManager(this)
        binding.rvAll.adapter = allAdapter
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                viewModel.state.collectLatest { state ->
                    // UNIFORM LOADING: Use Smart Delay Loader
                    val isDataZero = state.reminders.isEmpty()
                    if (state.isLoading) {
                        PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.SMART_STOCK, lifecycleScope, immediate = true)
                        if (isDataZero) binding.contentLayout.visibility = View.GONE
                    } else {
                        PremiumLoader.hide(binding.brewingLoader)
                        binding.contentLayout.visibility = View.VISIBLE
                    }
                    
                    binding.tvTomorrowLabel.text = getString(R.string.tomorrow_prediction) + " (${state.tomorrowLabel.uppercase()})"
                    binding.tvPatternSummary.text = state.patternSummary

                    val urgent = state.reminders.filter { it.urgency == "URGENT" }
                    val medium = state.reminders.filter { it.urgency == "MEDIUM" }
                    val safe = state.reminders.filter { it.urgency == "SAFE" }
                    
                    urgentAdapter.submitList(urgent)
                    plannedAdapter.submitList(medium)
                    allAdapter.submitList(safe)

                    binding.tvUrgentHeader.visibility = if (urgent.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvUrgent.visibility = if (urgent.isNotEmpty()) View.VISIBLE else View.GONE
                    
                    binding.tvMediumHeader.visibility = if (medium.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvPlanned.visibility = if (medium.isNotEmpty()) View.VISIBLE else View.GONE
                    
                    binding.tvSafeHeader.visibility = if (safe.isNotEmpty()) View.VISIBLE else View.GONE
                    binding.rvAll.visibility = if (safe.isNotEmpty()) View.VISIBLE else View.GONE

                    binding.tvUrgentCount.text = getString(R.string.urgent_items_format, urgent.size)
                    
                    val avgConfidence = if (state.reminders.isNotEmpty()) state.reminders.map { it.confidence }.average().toInt() else 0
                    binding.tvConfidence.text = getString(R.string.ai_confidence_format, avgConfidence)
                }
            }
        }
    }
}
