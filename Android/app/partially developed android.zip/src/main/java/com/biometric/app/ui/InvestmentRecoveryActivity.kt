package com.biometric.app.ui

import android.animation.ObjectAnimator
import android.app.DatePickerDialog
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
import com.github.mikephil.charting.formatter.ValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.Investment
import com.biometric.app.databinding.ActivityInvestmentRecoveryBinding
import com.biometric.app.databinding.DialogAddInvestmentBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.ui.adapter.InvestmentAdapter
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.ui.viewmodel.InvestmentRecoveryViewModel
import com.biometric.app.ui.viewmodel.InvestmentFilterType
import com.biometric.app.util.PickerHelper
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.util.PremiumLoader
import com.biometric.app.util.KeyboardUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.util.*
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds

@AndroidEntryPoint
class InvestmentRecoveryActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityInvestmentRecoveryBinding
    private val viewModel: InvestmentRecoveryViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: com.biometric.app.ui.viewmodel.SharedViewModel
    private lateinit var investmentAdapter: InvestmentAdapter
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var isChartExpanded = false
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityInvestmentRecoveryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        if (isGlobal) {
            viewModel.setGlobalMode(true)
        }

        setupUI()
        setupChart()
        observeViewModel()

        setupMotionFeedback(binding.btnAddInvestment)
    }

    private fun setupUI() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.toolbar.setOnClickListener { showShopSelectionDialog() }
        
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else (sharedViewModel.selectedShop.value?.name ?: "Shop"))
        updateToolbarTitle(shopName)

        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            val type = when (selected) {
                "Daily" -> InvestmentFilterType.DAY
                "Weekly" -> InvestmentFilterType.WEEKLY
                "Monthly" -> InvestmentFilterType.MONTHLY
                "Quarterly" -> InvestmentFilterType.QUARTERLY
                "Half Yearly" -> InvestmentFilterType.HALF_YEARLY
                "Annually" -> InvestmentFilterType.YEARLY
                "Custom" -> {
                    showDateRangePicker()
                    null
                }
                else -> InvestmentFilterType.MONTHLY
            }
            type?.let { viewModel.updateFilter(it) }
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            val periodStr = when (viewModel.filterState.value.filterType) {
                InvestmentFilterType.DAY -> "Daily"
                InvestmentFilterType.WEEKLY -> "Weekly"
                InvestmentFilterType.MONTHLY -> "Monthly"
                InvestmentFilterType.QUARTERLY -> "Quarterly"
                InvestmentFilterType.HALF_YEARLY -> "Half Yearly"
                InvestmentFilterType.YEARLY -> "Annually"
                else -> "Monthly"
            }
            PickerHelper.showSmartPicker(
                this, periodStr, Calendar.getInstance().apply { timeInMillis = viewModel.filterState.value.startDate }
            ) { newDate ->
                viewModel.updateFilter(viewModel.filterState.value.filterType, newDate.timeInMillis)
            }
        }

        investmentAdapter = InvestmentAdapter(
            onDeleteClick = { investment ->
                MaterialAlertDialogBuilder(this)
                    .setTitle(R.string.delete_asset_title)
                    .setMessage(R.string.delete_asset_msg)
                    .setPositiveButton(android.R.string.ok) { _, _ -> viewModel.deleteInvestment(investment) }
                    .setNegativeButton(android.R.string.cancel, null)
                    .show()
            }
        ) { investment ->
            showInvestmentDialog(investment)
        }

        binding.rvInvestments.layoutManager = LinearLayoutManager(this)
        binding.rvInvestments.adapter = investmentAdapter

        binding.btnAddInvestment.setOnClickListener { showInvestmentDialog(null) }

        val years = arrayOf("1", "2", "3", "4", "5", "10")
        val spinnerAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, years)
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        binding.spinnerTargetYears.adapter = spinnerAdapter
        binding.spinnerTargetYears.setSelection(1)

        binding.spinnerTargetYears.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                updateCustomTarget()
            }
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) {}
        }

        binding.btnToggleExpand.setOnClickListener {
            isChartExpanded = !isChartExpanded
            binding.btnToggleExpand.text = if (isChartExpanded) "Mini View ↙️" else "Expand ↗️"
            binding.tvChartTitle.text = if (isChartExpanded) "AI Recovery Projection" else getString(R.string.profit_growth_trend)
            viewModel.summary.value.let { summary ->
                updateChart(summary.monthlyProfits, summary.cumulativeProfits, summary.projectedProfits, summary.totalInvestment)
            }
        }
        
        binding.btnResetFilter.setOnClickListener { viewModel.resetToDefault() }
    }

    private fun updateToolbarTitle(shopName: String) {
        val line1 = if (shopName.contains("Investment", ignoreCase = true)) "Capital Network" else shopName
        setupDualHeader(binding.toolbar, line1, "Investment Recovery")
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) {
            Toast.makeText(this, "Loading shops...", Toast.LENGTH_SHORT).show()
            return
        }

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                isGlobal = false
                viewModel.onShopSelected(shops[which])
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupChart() {
        ChartStyleManager.applyChartStyle(binding.profitChart, this)
        binding.profitChart.apply {
            extraTopOffset = 30f
            animateX(1000)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.selectedShop.collect { shop ->
                        if (!isGlobal) {
                            shop?.let { updateToolbarTitle(it.name) }
                        }
                    }
                }
                launch {
                    viewModel.investments.collectLatest { list ->
                        investmentAdapter.submitList(list)
                    }
                }
                launch {
                    viewModel.summary.collectLatest { summary ->
                        updateSummary(summary)
                        updateChart(summary.monthlyProfits, summary.cumulativeProfits, summary.projectedProfits, summary.totalInvestment)
                    }
                }
                launch {
                    viewModel.isLoading.collect { loading ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        if (loading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.INVESTMENT, lifecycleScope)
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                        }
                    }
                }
                launch {
                    viewModel.filterState.collectLatest { filter ->
                        updateFilterUI(filter)
                    }
                }
            }
        }
    }

    private fun updateFilterUI(filter: com.biometric.app.ui.viewmodel.InvestmentFilterState) {
        val periodStr = when (filter.filterType) {
            com.biometric.app.ui.viewmodel.InvestmentFilterType.DAY -> "Daily"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.WEEKLY -> "Weekly"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.MONTHLY -> "Monthly"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.QUARTERLY -> "Quarterly"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.HALF_YEARLY -> "Half Yearly"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.YEARLY -> "Annually"
            com.biometric.app.ui.viewmodel.InvestmentFilterType.CUSTOM -> "Custom"
        }
        filterAdapter.setSelected(periodStr, filter.startDate)
        
        if (filter.isDefaultMode) {
            binding.layoutFilterIcons.tvDateLabel.text = "All Time"
            binding.btnResetFilter.visibility = View.GONE
        } else {
            val sdf = java.text.SimpleDateFormat("dd MMM yy", Locale.getDefault())
            binding.layoutFilterIcons.tvDateLabel.text = getString(R.string.range_format, sdf.format(Date(filter.startDate)), sdf.format(Date(filter.endDate)))
            binding.btnResetFilter.visibility = View.VISIBLE
        }
    }

    private fun adjustDate(amount: Int) {
        // Not supported
    }

    private fun showFilterTypeDialog() {
        // No longer used, handled by HorizontalFilterAdapter
    }

    private fun showDateRangePicker() {
        val constraints = com.google.android.material.datepicker.CalendarConstraints.Builder()
            .setEnd(System.currentTimeMillis())
            .build()

        val picker = com.google.android.material.datepicker.MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText(R.string.select_date_range)
            .setCalendarConstraints(constraints)
            .build()

        picker.addOnPositiveButtonClickListener { range ->
            val start = range.first ?: 0L
            val end = range.second ?: System.currentTimeMillis()
            viewModel.updateFilter(viewModel.filterState.value.filterType, start, end)
        }

        picker.show(supportFragmentManager, "date_range_picker")
    }

    private fun updateSummary(summary: com.biometric.app.ui.viewmodel.RecoverySummary) {
        val totalInv = summary.totalInvestment
        val totalProfit = summary.totalProfitEarned
        val remaining = maxOf(0.0, totalInv - totalProfit)
        val roi = if (totalInv > 0) (totalProfit / totalInv) * 100 else 0.0
        val progress = if (totalInv > 0) ((totalProfit / totalInv) * 100).toInt() else 0

        val locale = Locale.forLanguageTag("en-IN")
        val currencyFormat = NumberFormat.getCurrencyInstance(locale)
        binding.tvTotalInvestment.text = currencyFormat.format(totalInv)
        binding.tvTotalProfit.text = currencyFormat.format(totalProfit)
        binding.tvRemainingCapital.text = currencyFormat.format(remaining)
        binding.tvROI.text = getString(R.string.roi_label, roi)
        
        val anim = ObjectAnimator.ofInt(binding.recoveryProgressIndicator, "progress", binding.recoveryProgressIndicator.progress, minOf(100, progress))
        anim.duration = 800
        anim.interpolator = DecelerateInterpolator()
        anim.start()
        binding.tvProgressPercent.text = getString(R.string.progress_percent_label, progress)

        updateCustomTarget()
        
        // RECOVERY TIME CALCULATION
        if (summary.averageMonthlyProfit > 0) {
            val months = (remaining / summary.averageMonthlyProfit).toInt()
            val years = months / 12
            val remMonths = months % 12

            binding.tvRecoveryTime.text = if (years > 0) {
                getString(R.string.recovery_time_full, months, years, remMonths)
            } else {
                getString(R.string.recovery_time_months, months)
            }

            if (months > 48) {
                binding.tvInsights.text = getString(R.string.insight_slow, years, remMonths)
                binding.tvInsights.setBackgroundResource(R.drawable.insight_bg_warn)
                binding.tvInsights.setTextColor(ContextCompat.getColor(this, R.color.red))
            } else {
                binding.tvInsights.text = getString(R.string.insight_healthy, months)
                binding.tvInsights.setBackgroundResource(R.drawable.insight_bg)
                binding.tvInsights.setTextColor(ContextCompat.getColor(this, R.color.green))
            }

            // Add AI Break-even Projection
            summary.breakEvenMonth?.let { month ->
                val prediction = "\n\n🚀 AI Predicts Break-even by $month"
                binding.tvInsights.append(prediction)
            }
        } else {
            binding.tvRecoveryTime.text = "N/A"
            binding.tvInsights.text = if (totalInv > 0) "Profit trend insufficient to project time. Keep recording sales!" else "Add your investments to see recovery analysis."
            binding.tvInsights.setBackgroundResource(R.drawable.insight_bg)
            binding.tvInsights.setTextColor(ContextCompat.getColor(this, R.color.text_secondary))
        }
    }

    private fun updateChart(
        monthlyProfits: Map<String, Double>,
        cumulativeProfits: Map<String, Double>,
        projections: Map<String, Double>,
        targetInvestment: Double
    ) {
        if (!isChartExpanded) {
            // MINI VIEW: Shows only actual profitable months (non-cumulative)
            updateMiniChart(monthlyProfits)
        } else {
            // EXPANDED VIEW: Shows full cumulative view with AI projections
            updateExpandedChart(cumulativeProfits, projections, targetInvestment)
        }
    }

    private fun updateMiniChart(monthlyProfits: Map<String, Double>) {
        if (monthlyProfits.isEmpty()) {
            binding.profitChart.clear()
            return
        }

        val entries = mutableListOf<Entry>()
        val labels = monthlyProfits.keys.toList()
        
        monthlyProfits.values.forEachIndexed { i, p ->
            entries.add(Entry(i.toFloat(), p.toFloat()))
        }

        val primaryColor = ContextCompat.getColor(this, R.color.green)
        val dataSet = LineDataSet(entries, "Monthly Profit").apply {
            color = primaryColor
            setCircleColor(primaryColor)
            lineWidth = 3f
            circleRadius = 5f
            setDrawCircleHole(true)
            circleHoleColor = ContextCompat.getColor(this@InvestmentRecoveryActivity, R.color.colorSurface)
            valueTextSize = 10f
            valueTextColor = ContextCompat.getColor(this@InvestmentRecoveryActivity, R.color.text_primary)
            setDrawFilled(true)
            fillColor = primaryColor
            fillAlpha = 35
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawValues(true)
            valueFormatter = object : ValueFormatter() {
                override fun getFormattedValue(v: Float) = String.format(Locale.getDefault(), "₹%.0f", v)
            }
        }

        binding.profitChart.apply {
            xAxis.apply {
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float): String {
                        val i = v.toInt()
                        return if ((i >= 0) && (i < labels.size)) labels[i] else ""
                    }
                }
                labelCount = if (labels.size > 5) 5 else labels.size
            }
            data = LineData(dataSet)
            description.text = "Actual Monthly Performance"
            invalidate()
        }
    }

    private fun updateExpandedChart(actuals: Map<String, Double>, projections: Map<String, Double>, targetInvestment: Double) {
        if (actuals.isEmpty() && projections.isEmpty()) {
            binding.profitChart.clear()
            return
        }

        val entries = mutableListOf<Entry>()
        val projEntries = mutableListOf<Entry>()
        val targetEntries = mutableListOf<Entry>()

        val actualLabels = actuals.keys.toList()
        val projLabels = projections.keys.toList()
        val allLabels = actualLabels + projLabels

        actuals.values.forEachIndexed { i, p ->
            entries.add(Entry(i.toFloat(), p.toFloat()))
        }

        // Connect actual to projection
        if (entries.isNotEmpty() && projections.isNotEmpty()) {
            projEntries.add(entries.last())
        }

        val lastActualIdx = actualLabels.size
        projections.values.forEachIndexed { i, p ->
            projEntries.add(Entry((lastActualIdx + i).toFloat(), p.toFloat()))
        }

        // Target Investment Line
        if (targetInvestment > 0) {
            allLabels.indices.forEach { i ->
                targetEntries.add(Entry(i.toFloat(), targetInvestment.toFloat()))
            }
        }

        val actualColor = ContextCompat.getColor(this, R.color.green)
        val projColor = ContextCompat.getColor(this, R.color.blue)
        val targetColor = ContextCompat.getColor(this, R.color.red)

        val actualDataSet = LineDataSet(entries, "Recovered").apply {
            color = actualColor
            setCircleColor(actualColor)
            lineWidth = 3f
            circleRadius = 4f
            setDrawCircleHole(true)
            valueTextSize = 0f
            setDrawFilled(true)
            fillColor = actualColor
            fillAlpha = 30
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        val projDataSet = LineDataSet(projEntries, "Projected").apply {
            color = projColor
            setCircleColor(projColor)
            lineWidth = 2f
            circleRadius = 3f
            enableDashedLine(10f, 10f, 0f)
            valueTextSize = 0f
            setDrawCircles(true)
            mode = LineDataSet.Mode.LINEAR
        }

        val targetDataSet = LineDataSet(targetEntries, "Investment Target").apply {
            color = targetColor
            lineWidth = 2f
            setDrawCircles(false)
            enableDashedLine(20f, 10f, 0f)
            setDrawValues(false)
        }

        binding.profitChart.apply {
            xAxis.apply {
                valueFormatter = object : ValueFormatter() {
                    override fun getFormattedValue(v: Float): String {
                        val i = v.toInt()
                        return if ((i >= 0) && (i < allLabels.size)) allLabels[i] else ""
                    }
                }
                labelCount = if (allLabels.size > 5) 5 else allLabels.size
            }
            data = LineData(actualDataSet, projDataSet, targetDataSet)
            description.text = "Recovery vs Investment"
            invalidate()
        }
    }

    private fun updateCustomTarget() {
        val summary = viewModel.summary.value
        val totalInv = summary.totalInvestment
        val totalProfit = summary.totalProfitEarned
        val remaining = maxOf(0.0, totalInv - totalProfit)
        val yearsStr = (binding.spinnerTargetYears.selectedItem?.toString() ?: "2")
        val months = yearsStr.toInt() * 12
        val req = if (months > 0) (remaining / months) else 0.0
        val locale = Locale.forLanguageTag("en-IN")
        val currencyFormat = NumberFormat.getCurrencyInstance(locale)
        binding.tvRequiredProfit.text = getString(R.string.required_profit_label, currencyFormat.format(req))
    }

    private fun showInvestmentDialog(existing: Investment?) {
        val dialogBinding = DialogAddInvestmentBinding.inflate(LayoutInflater.from(this))
        val categories = arrayOf("Capital", "Deposit", "Equipment", "Furniture", "Renovation", "Interior", "Machinery", "Miscellaneous")
        val categoryAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, categories)
        dialogBinding.spinnerCategory.adapter = categoryAdapter

        var selDate = existing?.date ?: System.currentTimeMillis()
        val sdf = java.text.SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        dialogBinding.btnDate.text = sdf.format(Date(selDate))

        if (existing != null) {
            dialogBinding.etItemName.setText(existing.itemName)
            dialogBinding.etAmount.setText(existing.amount.toString())
            val catIndex = categories.indexOf(existing.category)
            if (catIndex >= 0) dialogBinding.spinnerCategory.setSelection(catIndex)
        }

        // ATOMIC AUTO-FOCUS: Move from name to amount after typing
        var autoFocusJob: kotlinx.coroutines.Job? = null
        dialogBinding.etItemName.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) {
                if (dialogBinding.etItemName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        kotlinx.coroutines.delay(1500.milliseconds)
                        KeyboardUtil.showKeyboard(dialogBinding.etAmount)
                    }
                }
            }
        })

        dialogBinding.btnDate.setOnClickListener {
            val cal = Calendar.getInstance()
            cal.timeInMillis = selDate
            DatePickerDialog(
                this,
                { _, y, m, d ->
                    cal[y, m] = d
                    selDate = cal.timeInMillis
                    dialogBinding.btnDate.text = sdf.format(Date(selDate))
                },
                cal[Calendar.YEAR],
                cal[Calendar.MONTH],
                cal[Calendar.DAY_OF_MONTH],
            ).show()
        }

        MaterialAlertDialogBuilder(this)
            .setTitle(if (existing == null) R.string.add_new_asset else R.string.edit_asset_title)
            .setView(dialogBinding.root)
            .setPositiveButton(android.R.string.ok) { _, _ ->
                val name = dialogBinding.etItemName.text.toString()
                val amount = dialogBinding.etAmount.text.toString().toDoubleOrNull() ?: 0.0
                if (name.isNotEmpty() && (amount > 0)) {
                    if (existing == null) {
                        viewModel.addInvestment(name, amount, selDate, dialogBinding.spinnerCategory.selectedItem.toString())
                    } else {
                        viewModel.updateInvestment(existing.copy(itemName = name, amount = amount, date = selDate, category = dialogBinding.spinnerCategory.selectedItem.toString()))
                    }
                    KeyboardUtil.hideKeyboard(this)
                    dialogBinding.etItemName.clearFocus()
                    dialogBinding.etAmount.clearFocus()
                }
            }
            .setNegativeButton(android.R.string.cancel, null)
            .show()
    }
}
