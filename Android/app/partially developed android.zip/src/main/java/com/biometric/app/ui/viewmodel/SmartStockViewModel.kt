package com.biometric.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.SmartStockReminder
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.data.entity.InventoryItem
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

data class SmartStockState(
    val reminders: List<SmartStockReminder> = emptyList(),
    val isLoading: Boolean = true,
    val tomorrowLabel: String = "",
    val patternSummary: String = "",
)

@HiltViewModel
class SmartStockViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel
) : ViewModel() {

    private val _state = MutableStateFlow(SmartStockState())
    val state: StateFlow<SmartStockState> = _state.asStateFlow()

    private val rawMaterialKeywords = listOf(
        "MILK", "TEA", "SUGAR", "EGG", "OIL", "COFFEE", "GINGER", "LEMON", "MASALA", "GAS", 
        "CURD", "BISCUIT", "BREAD", "BUTTER", "CREAM", "HONEY", "SALT", "POWDER"
    )

    private val exclusions = listOf(
        "POLICE", "POOJA", "GOD", "FLOWER", "CUP", "EXTRA", "GIFT", "REPAIR", "CLEANING", 
        "MAINTENANCE", "DONATION", "STATIONERY", "ELECTRICITY", "RENT", "TAX"
    )

    init {
        viewModelScope.launch {
            sharedViewModel.selectedShop.collect { shop ->
                shop?.let { loadIntegratedPredictions(it.shopId) }
            }
        }
    }

    private fun loadIntegratedPredictions(shopId: String) {
        val now = System.currentTimeMillis()
        val hundredTwentyDaysAgo = now - (120L * 24 * 60 * 60 * 1000)
        val cacheKey = "smart_stock_$shopId"

        viewModelScope.launch {
            // OPTIMISTIC UI: Try to load from cache
            val cached = repository.getListCache<SmartStockState>(cacheKey).firstOrNull()
            _state.update { (cached ?: it).copy(isLoading = cached == null) }

            combine(
                repository.getInventoryItems(shopId),
                repository.getCashbookEntriesForPeriod(shopId, hundredTwentyDaysAgo, now)
            ) { inventory, cashbook ->
                val newState = processIntegratedPredictions(inventory, cashbook)
                repository.saveListCache(cacheKey, listOf(newState))
                newState
            }.flowOn(Dispatchers.Default)
                .collect { newState ->
                    _state.value = newState
                }
        }
    }

    private fun isRawMaterial(name: String): Boolean {
        val upperName = name.uppercase()
        val isExcluded = exclusions.any { upperName.contains(it) }
        if (isExcluded) return false
        
        return rawMaterialKeywords.any { upperName.contains(it) }
    }

    private fun processIntegratedPredictions(inventory: List<InventoryItem>, cashbook: List<Cashbook>): SmartStockState {
        val tomorrow = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 1) }
        val tomorrowDayName = tomorrow.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG, Locale.getDefault())
        val isTomorrowWeekend = (tomorrow[Calendar.DAY_OF_WEEK] == Calendar.SATURDAY) || 
                               (tomorrow[Calendar.DAY_OF_WEEK] == Calendar.SUNDAY)
        
        val now = System.currentTimeMillis()
        val fourMonthsAgo = now - (120L * 24 * 60 * 60 * 1000)

        // Optimization: Pre-filter and pre-sort cashbook once
        val outEntries = cashbook.filter { it.transactionType == "OUT" }
            .sortedBy { it.transactionDate }

        val reminders = inventory.filter { isRawMaterial(it.name) }.mapNotNull { item ->
            // Optimization: Filter pre-sorted entries for this specific item
            val purchases = outEntries.filter {
                (it.description?.contains(item.name, ignoreCase = true) == true ||
                 it.category.contains(item.name, ignoreCase = true))
            }

            if (purchases.size < 2) return@mapNotNull null

            // 1. Gap Analysis
            val gaps = mutableListOf<Long>()
            for (i in 1 until purchases.size) {
                val gap = purchases[i].transactionDate - purchases[i - 1].transactionDate
                if (gap > TimeUnit.HOURS.toMillis(12)) gaps.add(gap)
            }
            if (gaps.isEmpty()) return@mapNotNull null
            
            val avgGapMillis = gaps.average().toLong()
            val avgGapDays = (avgGapMillis / (24L * 60 * 60 * 1000)).toInt().coerceAtLeast(1)

            // 2. Usage Analysis
            val relevantPurchases = purchases.filter { it.transactionDate >= fourMonthsAgo && it.quantity != null }
            
            var weekdayTotal = 0.0
            var weekdayCount = 0
            var weekendTotal = 0.0
            var weekendCount = 0
            
            val tempCal = Calendar.getInstance()
            relevantPurchases.forEach { p ->
                tempCal.timeInMillis = p.transactionDate
                val isWeekend = tempCal.get(Calendar.DAY_OF_WEEK) == Calendar.SATURDAY || 
                               tempCal.get(Calendar.DAY_OF_WEEK) == Calendar.SUNDAY
                if (isWeekend) {
                    weekendTotal += (p.quantity ?: 0.0)
                    weekendCount++
                } else {
                    weekdayTotal += (p.quantity ?: 0.0)
                    weekdayCount++
                }
            }
            
            val weekdayAvg = if (weekdayCount > 0) weekdayTotal / weekdayCount else 0.0
            val weekendAvg = if (weekendCount > 0) weekendTotal / weekendCount else 0.0
            
            val predictedTomorrow = if (isTomorrowWeekend) weekendAvg else weekdayAvg
            val suggestedWeekly = (weekdayAvg * 5) + (weekendAvg * 2)

            val lastPurchase = purchases.last().transactionDate
            val daysPassed = ((now - lastPurchase) / (24L * 60 * 60 * 1000)).toInt()

            // 3. Urgency Logic
            val urgency = when {
                daysPassed >= avgGapDays || (item.totalQuantity <= (predictedTomorrow * 1.1) && predictedTomorrow > 0) -> "URGENT"
                daysPassed >= avgGapDays - 1 || (item.totalQuantity <= (predictedTomorrow * 1.5) && predictedTomorrow > 0) -> "MEDIUM"
                else -> "SAFE"
            }

            val patternInsight = when {
                predictedTomorrow <= 0 -> "Based on your purchase gap of $avgGapDays days."
                isTomorrowWeekend && weekendAvg > weekdayAvg -> {
                    val spike = (((weekendAvg / weekdayAvg.coerceAtLeast(0.1)) - 1) * 100).toInt()
                    "Tomorrow is $tomorrowDayName (busy), you need $spike% more ${item.name} than weekdays."
                }
                !isTomorrowWeekend && weekdayAvg > weekendAvg && weekendAvg > 0 -> "Tomorrow is $tomorrowDayName, stable weekday demand expected."
                else -> "Regular demand pattern for $tomorrowDayName."
            }

            SmartStockReminder(
                itemName = item.name,
                currentStock = item.totalQuantity,
                unit = item.unitType,
                suggestedDaily = if (predictedTomorrow > 0) predictedTomorrow else 0.0,
                suggestedWeekly = if (suggestedWeekly > 0) suggestedWeekly else 0.0,
                patternInsight = patternInsight,
                urgency = urgency,
                confidence = if (purchases.size > 12) 98 else if (purchases.size > 6) 88 else 70,
                lastPurchaseDate = lastPurchase,
                avgGapDays = avgGapDays
            )
        }.sortedByDescending { 
            when(it.urgency) {
                "URGENT" -> 3
                "MEDIUM" -> 2
                else -> 1
            }
        }

        return SmartStockState(
            reminders = reminders,
            isLoading = false,
            tomorrowLabel = tomorrowDayName ?: "Tomorrow",
            patternSummary = "AI optimized using last 120 days of ${tomorrowDayName ?: "daily"} patterns."
        )
    }
}
