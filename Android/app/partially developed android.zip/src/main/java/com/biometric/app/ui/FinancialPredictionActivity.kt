package com.biometric.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.LinearLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.setMargins
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.ForecastInsight
import com.biometric.app.databinding.ActivityFinancialPredictionBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.PredictionMetricRow
import com.biometric.app.ui.viewmodel.PredictionViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class FinancialPredictionActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityFinancialPredictionBinding
    private val viewModel: PredictionViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter
    
    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var isGlobal: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityFinancialPredictionBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Shop")
        
        if (isGlobal) shopId = ""

        setupToolbar(shopName)
        setupUI()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        // Force initial data load for the current default filter.
        // This ensures the loader starts immediately even if the shop-selection observer is delayed.
        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Financial Forecast")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🚀", "Future Prediction") {
                val intent = Intent(this, FuturePredictionActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", supportActionBar?.title?.toString()?.split("\n")?.firstOrNull())
                }
                startActivity(intent)
            },
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🚀", "Future Prediction") {
                val intent = Intent(this, FuturePredictionActivity::class.java).apply {
                    putExtra("SHOP_ID", shopId)
                    putExtra("SHOP_NAME", supportActionBar?.title?.toString()?.split("\n")?.firstOrNull())
                }
                startActivity(intent)
            },
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        viewModel.loadPredictions(shopId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.metrics.isEmpty()

                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.FORECAST, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            // 1. UPDATE DATA WHILE CONTENT IS STILL GONE (or just before showing)
                            if (state.metrics.isNotEmpty()) {
                                // Range Labels
                                binding.tvPrevRangeLabel.text = String.format(Locale.getDefault(), "Previous: %s", state.prevRange?.dateString ?: "")
                                binding.tvCurrentRangeLabel.text = String.format(Locale.getDefault(), "Current: %s", state.currentRange?.dateString ?: "")
                                binding.tvExpectedRangeLabel.text = String.format(Locale.getDefault(), "Expected: %s", state.expectedRange?.dateString ?: "")

                                // Main Card
                                val profitRow = state.metrics.find { it.title == "Profit" }
                                profitRow?.let { updateProfitCard(it, it.growthPercent) }

                                // Detailed Table
                                updateDetailedTable(state.metrics)

                                // Insights
                                updateInsightsList(state.insights)

                                // Month-End Forecast
                                updateForecastUI(state.forecast)
                            }
                            
                            // 2. NOW SHOW CONTENT ATOMICALLY
                            if (binding.contentLayout.visibility != View.VISIBLE || binding.contentLayout.alpha < 1f) {
                                binding.contentLayout.visibility = View.VISIBLE
                                binding.contentLayout.alpha = 1f
                                // Small delay ensures content is rendered before removing overlay
                                binding.root.postDelayed({
                                    PremiumLoader.hide(binding.brewingLoader)
                                }, 50)
                            } else {
                                PremiumLoader.hide(binding.brewingLoader)
                            }
                        }
                    }
                }
            }
        }
    }

    private fun updateForecastUI(forecast: ForecastInsight) {
        if (forecast.isVisible) {
            binding.cardMonthEndForecast.visibility = View.VISIBLE
            binding.tvForecastRemaining.text = "${forecast.remainingDays} days remaining in month"
            
            // Remaining Days Predictions
            binding.tvForecastSales.text = formatCurrency(forecast.remainingSales)
            binding.tvForecastCashOut.text = formatCurrency(forecast.remainingCashOut)
            binding.tvForecastSalary.text = formatCurrency(forecast.remainingSalary)
            binding.tvForecastFixed.text = formatCurrency(forecast.remainingFixed)
            binding.tvForecastProfit.text = formatCurrency(forecast.remainingProfit)

            // Historical Averages
            binding.tvAvgSales.text = formatCurrency(forecast.avgSales)
            binding.tvAvgExpense.text = formatCurrency(forecast.avgExpense)
            binding.tvAvgProfit.text = formatCurrency(forecast.avgProfit)

            // Final Calculation
            binding.tvUpToDateProfit.text = formatCurrency(forecast.upToDateProfit)
            binding.tvRemainingProfitSmall.text = formatCurrency(forecast.remainingProfit)
            binding.tvFinalEstimatedProfit.text = formatCurrency(forecast.finalEstimatedProfit)
            
        } else {
            binding.cardMonthEndForecast.visibility = View.GONE
        }
    }

    private fun formatCurrency(value: Double): String {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        currencyFormat.maximumFractionDigits = 0
        return currencyFormat.format(value)
    }

    private fun updateProfitCard(profit: PredictionMetricRow, growth: Double) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        binding.tvPredictedProfit.text = currencyFormat.format(profit.expectedValue)
        
        val growthIcon = when {
            growth > 10.0 -> "🚀"
            growth > 0.0 -> "📈"
            growth < -10.0 -> "🆘"
            growth < 0.0 -> "📉"
            else -> "➖"
        }
        
        binding.tvProfitGrowth.text = String.format(Locale.getDefault(), "%s %.1f%% growth (vs prev period)", growthIcon, growth)
        
        val color = when {
            growth > 0 -> ContextCompat.getColor(this, R.color.green)
            growth < 0 -> ContextCompat.getColor(this, R.color.red)
            else -> ContextCompat.getColor(this, R.color.text_secondary)
        }
        binding.tvProfitGrowth.setTextColor(color)
    }

    private fun updateDetailedTable(metrics: List<PredictionMetricRow>) {
        // Remove old rows except header
        val childCount = binding.tableForecast.childCount
        if (childCount > 2) {
            binding.tableForecast.removeViews(2, childCount - 2)
        }

        val metricIcons = mapOf(
            "Sales" to "💰",
            "Cash Outflow" to "💸",
            "Expense" to "📉",
            "Salary" to "👔",
            "Fixed Expense" to "🏠",
            "Profit" to "💎"
        )

        metrics.forEach { metric ->
            val row = TableRow(this).apply {
                this.setPadding(0, 16, 0, 16)
            }

            val icon = metricIcons[metric.title] ?: "🔹"
            val tvTitle = TextView(this).apply {
                text = "$icon ${metric.title}"
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(ContextCompat.getColor(this@FinancialPredictionActivity, R.color.text_primary))
                setTypeface(null, Typeface.BOLD)
            }

            val tvPrev = TextView(this).apply {
                text = formatCompact(metric.previousValue)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
            }

            val tvCurrent = TextView(this).apply {
                text = formatCompact(metric.currentValue)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 12f)
                setTypeface(null, Typeface.BOLD)
            }

            val tvExpected = TextView(this).apply {
                text = formatCompact(metric.expectedValue)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setTextColor(ContextCompat.getColor(this@FinancialPredictionActivity, R.color.colorPrimary))
                setTypeface(null, Typeface.BOLD)
            }

            row.addView(tvTitle)
            row.addView(tvPrev)
            row.addView(tvCurrent)
            row.addView(tvExpected)
            binding.tableForecast.addView(row)
        }
    }

    private fun formatCompact(value: Double): String {
        val absV = kotlin.math.abs(value)
        val sign = if (value < 0) "-" else ""
        return when {
            absV >= 100000 -> String.format(Locale.getDefault(), "%s₹%.1fL", sign, absV / 100000)
            absV >= 1000 -> String.format(Locale.getDefault(), "%s₹%.1fK", sign, absV / 1000)
            else -> String.format(Locale.getDefault(), "%s₹%.0f", sign, absV)
        }
    }

    private fun updateInsightsList(insights: List<String>) {
        binding.llInsights.removeAllViews()
        val emojis = listOf("🚀", "💡", "⚠️", "📊", "✅", "🔍")
        insights.forEachIndexed { index, text ->
            val emoji = emojis[index % emojis.size]
            val card = com.google.android.material.card.MaterialCardView(this).apply {
                val params = LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT
                )
                params.setMargins(0, 0, 0, 16)
                layoutParams = params
                radius = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, 12f, resources.displayMetrics)
                setCardBackgroundColor(ContextCompat.getColor(this@FinancialPredictionActivity, R.color.colorSurfaceVariant))
                cardElevation = 0f
            }

            val layout = LinearLayout(this).apply {
                this.orientation = LinearLayout.HORIZONTAL
                this.setPadding(16, 16, 16, 16)
                this.gravity = android.view.Gravity.CENTER_VERTICAL
            }

            val tvEmoji = TextView(this).apply {
                this.text = emoji
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 20f)
                setPadding(0, 0, 16, 0)
            }

            val textView = TextView(this).apply {
                this.text = text
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(ContextCompat.getColor(this@FinancialPredictionActivity, R.color.text_primary))
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
            }

            layout.addView(tvEmoji)
            layout.addView(textView)
            card.addView(layout)
            binding.llInsights.addView(card)
        }
    }
}