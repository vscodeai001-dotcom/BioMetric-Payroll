package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName

@Keep
data class WorkShift(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = "",
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("startTime") @set:PropertyName("startTime")
    var startTime: String = "09:00",
    
    @get:PropertyName("endTime") @set:PropertyName("endTime")
    var endTime: String = "18:00",
    
    @get:PropertyName("graceMinutes") @set:PropertyName("graceMinutes")
    var graceMinutes: Int = 15,
    
    @get:PropertyName("trackingMode") @set:PropertyName("trackingMode")
    var trackingMode: String = "SHIFT", // SHIFT, 24/7, CUSTOM
    
    @get:PropertyName("isActive") @set:PropertyName("isActive")
    var isActive: Boolean = true
)
