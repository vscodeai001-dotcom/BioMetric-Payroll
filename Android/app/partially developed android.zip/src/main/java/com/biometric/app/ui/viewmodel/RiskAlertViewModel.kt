package com.biometric.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.RawMetrics
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

enum class RiskPriority { LOW, MEDIUM, HIGH }

data class RiskAlert(
    val category: String, // Sales, Expense, Salary, Profit, Day-Based, Cash Flow
    val priority: RiskPriority,
    val title: String,
    val changeText: String, // e.g., "-18%" or "+₹8,000"
    val reason: String?,
    val impact: String?,
    val suggestion: String,
    val affectedDays: String? = null,
)

data class RiskTrendData(
    val label: String,
    val riskScore: Int
)

data class RiskSummary(
    val total: Int = 0,
    val high: Int = 0,
    val medium: Int = 0,
    val low: Int = 0
)

data class RiskAlertState(
    val alerts: List<RiskAlert> = emptyList(),
    val summary: RiskSummary = RiskSummary(),
    val trendData: List<RiskTrendData> = emptyList(),
    val isLoading: Boolean = true
)

@HiltViewModel
class RiskAlertViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<RiskAlertState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        val (start, end) = getTimestampsForPeriod(period, date)
        val cacheKey = "risk_alerts_$shopId" + "_${period}_$start" + "_$end"
        
        // Previous period for primary comparison
        val (prevStart, prevEnd) = if (period == "Up To Date") {
            val pStart = Calendar.getInstance().apply { 
                timeInMillis = start
                add(Calendar.MONTH, -1)
            }.timeInMillis
            val pEnd = Calendar.getInstance().apply { 
                timeInMillis = end
                add(Calendar.MONTH, -1)
            }.timeInMillis
            pStart to pEnd
        } else {
            getPreviousPeriodTimestamps(period, start)
        }

        // Generate trend ranges (last 6 periods)
        val trendRanges = mutableListOf<Pair<Long, Long>>()
        val trendLabels = mutableListOf<String>()
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        val sdf = when (period) {
            "Day" -> SimpleDateFormat("dd MMM", Locale.getDefault())
            "Week" -> SimpleDateFormat("'W'w", Locale.getDefault())
            "Month", "Up To Date" -> SimpleDateFormat("MMM", Locale.getDefault())
            else -> SimpleDateFormat("MMM yy", Locale.getDefault())
        }

        for (i in 5 downTo 0) {
            val trendCal = cal.clone() as Calendar
            when (period) {
                "Day" -> trendCal.add(Calendar.DAY_OF_YEAR, -i)
                "Week" -> trendCal.add(Calendar.WEEK_OF_YEAR, -i)
                "Month", "Up To Date" -> trendCal.add(Calendar.MONTH, -i)
                "Quarter" -> trendCal.add(Calendar.MONTH, -i * 3)
                "Half Yearly" -> trendCal.add(Calendar.MONTH, -i * 6)
                "Annually" -> trendCal.add(Calendar.YEAR, -i)
            }
            
            // OPTIMIZATION: If we are in "Up To Date" mode, we want current month to be partial, 
            // but previous months to be FULL for a better "typical spending" baseline.
            val range = if (period == "Up To Date" && i > 0) {
                DateRangeUtil.getRangeForPeriod("Monthly", trendCal.timeInMillis)
            } else {
                getTimestampsForPeriod(period, trendCal.timeInMillis)
            }
            
            trendRanges.add(range)
            trendLabels.add(sdf.format(trendCal.time))
        }

        val trendFlows = trendRanges.map { (s, e) -> repository.getShopMetricsFlow(shopId, s, e) }

        combine(
            repository.getShopMetricsFlow(shopId, start, end),
            repository.getShopMetricsFlow(shopId, prevStart, prevEnd),
            repository.getCashbookEntriesForPeriod(shopId, 0, end),
            repository.getFixedExpensesForShop(shopId),
            combine(trendFlows) { it.toList() }
        ) { args: Array<Any?> ->
            val currentMetrics = args[0] as RawMetrics
            val prevMetrics = args[1] as RawMetrics
            @Suppress("UNCHECKED_CAST") val allCashbook = args[2] as List<Cashbook>
            @Suppress("UNCHECKED_CAST") val trendMetricsList = args[4] as List<com.biometric.app.data.RawMetrics>

            val alerts = mutableListOf<RiskAlert>()

            // 1. Sales Risk
            if (prevMetrics.sales > 0) {
                val change = (currentMetrics.sales - prevMetrics.sales) / prevMetrics.sales
                if (change <= -0.10) {
                    alerts.add(RiskAlert(
                        category = "Sales",
                        priority = if (change <= -0.25) RiskPriority.HIGH else RiskPriority.MEDIUM,
                        title = "Revenue is Down",
                        changeText = "${(change * 100).toInt()}% vs last period",
                        reason = "Sales dropped from ₹${kotlin.math.round(prevMetrics.sales).toInt()} to ₹${kotlin.math.round(currentMetrics.sales).toInt()}",
                        impact = "Reduced cash flow affects your ability to cover upcoming expenses.",
                        suggestion = "Run a limited-time promotion or check if any high-selling items are out of stock."
                    ))
                }
            }

            // 2. Expense Risk
            if (prevMetrics.expense > 0) {
                val increase = (currentMetrics.expense - prevMetrics.expense) / prevMetrics.expense
                if (increase >= 0.15) {
                    val majorCategory = allCashbook.asSequence()
                        .filter { (it.transactionDate in start..end) && (it.transactionType == "OUT") }
                        .groupBy { it.category }
                        .mapValues { it.value.sumOf { e -> e.amount } }
                        .maxByOrNull { it.value }

                    alerts.add(RiskAlert(
                        category = "Expense",
                        priority = if (increase >= 0.30) RiskPriority.HIGH else RiskPriority.MEDIUM,
                        title = "Higher Spending Detected",
                        changeText = "+${(increase * 100).toInt()}% increase",
                        reason = "Increased spending on ${majorCategory?.key ?: "various items"} (+₹${kotlin.math.round(currentMetrics.expense - prevMetrics.expense).toInt()})",
                        impact = "Your profit margin is being squeezed by rising operational costs.",
                        suggestion = "Review ${majorCategory?.key?.lowercase() ?: "recent expenses"} and look for ways to reduce waste or negotiate better prices."
                    ))
                }
            }

            // 3. Salary Risk
            if (currentMetrics.sales > 0) {
                val salRatio = currentMetrics.salary / currentMetrics.sales
                if (salRatio >= 0.30) {
                    alerts.add(RiskAlert(
                        category = "Staff",
                        priority = if (salRatio >= 0.45) RiskPriority.HIGH else RiskPriority.MEDIUM,
                        title = "High Staff Cost Ratio",
                        changeText = "${(salRatio * 100).toInt()}% of revenue",
                        reason = "Staff costs (₹${kotlin.math.round(currentMetrics.salary).toInt()}) are high relative to your sales (₹${kotlin.math.round(currentMetrics.sales).toInt()})",
                        impact = "Labor costs are consuming too much of your daily earnings.",
                        suggestion = "Adjust staff schedules to match busy hours or avoid unnecessary overtime."
                    ))
                }
            }

            // 4. Profit Risk
            if (currentMetrics.profit < 0) {
                alerts.add(RiskAlert(
                    category = "Profit",
                    priority = RiskPriority.HIGH,
                    title = "Business at a Loss",
                    changeText = "-₹${kotlin.math.round(kotlin.math.abs(currentMetrics.profit)).toInt()}",
                    reason = "Total expenses (₹${kotlin.math.round(currentMetrics.expense + currentMetrics.salary + currentMetrics.fixed).toInt()}) exceeded your sales (₹${kotlin.math.round(currentMetrics.sales).toInt()})",
                    impact = "Continuing at a loss will deplete your capital quickly.",
                    suggestion = "Urgent: Cut non-essential spending and focus on increasing daily sales immediately."
                ))
            }

            // 5. Cash Flow Risk
            if (currentMetrics.expense + currentMetrics.salary > currentMetrics.sales) {
                alerts.add(RiskAlert(
                    category = "Cash Flow",
                    priority = RiskPriority.MEDIUM,
                    title = "Negative Cash Flow",
                    changeText = "Outflow > Inflow",
                    reason = "Daily operational payments (₹${kotlin.math.round(currentMetrics.expense + currentMetrics.salary).toInt()}) are exceeding direct sales income",
                    impact = "You might face a liquidity crunch for upcoming inventory purchases.",
                    suggestion = "Maintain a minimum cash reserve and defer non-essential purchases until sales improve."
                ))
            }

            // 6. ANOMALY DETECTION: Unusual Expense Spikes
            val periodLabel = when (period.lowercase().replace(" ", "")) {
                "day", "daily" -> "Today's"
                "uptodate" -> "Up-to-date"
                "weekly", "week" -> "Weekly"
                "monthly", "month" -> {
                    val sdfMonth = SimpleDateFormat("MMMM", Locale.getDefault())
                    "${sdfMonth.format(Date(date))} month"
                }
                "quarterly", "quarter" -> "Quarterly"
                "halfyearly", "halfyear" -> "Half-yearly"
                "annually", "annual" -> "Annual"
                else -> period
            }

            val currentExpense = currentMetrics.expense
            // BASELINE: We use the most recent 3 non-zero periods for a more relevant average
            val recentPastPeriods = trendMetricsList.dropLast(1)
                .filter { it.expense > 0 }
                .takeLast(3)
            
            val typicalFullPeriodExpense = if (recentPastPeriods.isNotEmpty()) recentPastPeriods.asSequence().map { it.expense }.average() else 0.0
            
            // PRO-RATA LOGIC: If current period is partial (Up To Date), scale the typical average to match days elapsed
            val avgExpense = if (period == "Up To Date") {
                val daysInCurrent = ((end - start) / 86400000.0) + 1.0
                val daysInFullMonth = 30.0 // Standard approximation
                (typicalFullPeriodExpense / daysInFullMonth) * daysInCurrent
            } else {
                typicalFullPeriodExpense
            }
            
            // Anomaly logic: 30% increase vs scaled average is a warning
            if (currentExpense > (avgExpense * 1.3) && avgExpense > 1000) {
                val percentIncrease = ((currentExpense - avgExpense) / avgExpense * 100).toInt()
                
                // Detailed Breakdown for Anomaly
                val topCategories = allCashbook.asSequence()
                    .filter { (it.transactionDate in start..end) && (it.transactionType == "OUT") }
                    .groupBy { it.category }
                    .mapValues { it.value.sumOf { e -> e.amount } }
                    .toList()
                    .sortedByDescending { it.second }
                    .take(3)
                    .joinToString(", ") { "${it.first} (₹${it.second.toInt()})" }

                alerts.add(RiskAlert(
                    category = "Anomaly",
                    priority = if (percentIncrease > 80 || (currentExpense - avgExpense) > 10000) RiskPriority.HIGH else RiskPriority.MEDIUM,
                    title = "Unusual High Expense",
                    changeText = "+$percentIncrease% Anomaly",
                    reason = "$periodLabel expense (₹${kotlin.math.round(currentExpense).toInt()}) has significantly exceeded the expected baseline of ₹${kotlin.math.round(avgExpense).toInt()}.",
                    impact = "Major spending identified in: $topCategories. Sudden spikes can indicate waste or irregular bulk purchases.",
                    suggestion = "Review the latest entries in $topCategories and verify if these were planned business costs."
                ))
            }

            val summary = RiskSummary(
                total = alerts.size,
                high = alerts.count { it.priority == RiskPriority.HIGH },
                medium = alerts.count { it.priority == RiskPriority.MEDIUM },
                low = alerts.count { it.priority == RiskPriority.LOW }
            )

            val trendData = trendMetricsList.mapIndexed { index, m ->
                RiskTrendData(trendLabels[index], calculateRiskScoreRepo(m))
            }

            val result = RiskAlertState(
                alerts = alerts,
                summary = summary,
                trendData = trendData,
                isLoading = false
            )
            repository.saveListCache(cacheKey, listOf(result))
            result
        }.onStart {
            // UNIFORM LOADING: Only show loading if we don't have cached data
            val cached = repository.getListCache<RiskAlertState>(cacheKey).firstOrNull()
            if (cached != null) {
                emit(cached.copy(isLoading = false))
            } else {
                emit(RiskAlertState(isLoading = true))
            }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), RiskAlertState())

    fun loadRisks(shopId: String, period: String, date: Long) {
        _params.value = Triple(shopId, period, date)
    }

    private fun calculateRiskScoreRepo(m: RawMetrics): Int {
        if (m.sales == 0.0) return if (m.expense > 0 || m.salary > 0) 80 else 0
        var score = 0
        if (m.profit < 0) score += 50
        val expRatio = (m.expense + m.salary + m.fixed) / m.sales
        if (expRatio > 0.8) score += 30
        if (expRatio > 1.0) score += 20
        return score.coerceIn(0, 100)
    }

    private fun getTimestampsForPeriod(period: String, date: Long): Pair<Long, Long> {
        return DateRangeUtil.getRangeForPeriod(period, date)
    }

    private fun getPreviousPeriodTimestamps(period: String, currentStart: Long): Pair<Long, Long> {
        val start = Calendar.getInstance().apply { timeInMillis = currentStart }
        val end = Calendar.getInstance().apply { timeInMillis = currentStart }
        
        when (period) {
            "Day" -> { start.add(Calendar.DAY_OF_YEAR, -1); end.add(Calendar.DAY_OF_YEAR, -1) }
            "Up To Date" -> {
                start.add(Calendar.MONTH, -1)
                start[Calendar.DAY_OF_MONTH] = 1
            }
            "Month" -> {
                start.add(Calendar.MONTH, -1); start.set(Calendar.DAY_OF_MONTH, 1)
                end.add(Calendar.MONTH, -1); end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
            }
            "Week" -> { start.add(Calendar.WEEK_OF_YEAR, -1); end.add(Calendar.WEEK_OF_YEAR, -1) }
            "Quarter" -> { start.add(Calendar.MONTH, -3); end.add(Calendar.MONTH, -3) }
            "Half Yearly" -> { start.add(Calendar.MONTH, -6); end.add(Calendar.MONTH, -6) }
            "Annually" -> { start.add(Calendar.YEAR, -1); end.add(Calendar.YEAR, -1) }
        }
        start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
        end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
        return start.timeInMillis to end.timeInMillis
    }
}
