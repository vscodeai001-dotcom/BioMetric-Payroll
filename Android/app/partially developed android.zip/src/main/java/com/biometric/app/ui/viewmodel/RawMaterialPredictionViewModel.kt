package com.biometric.app.ui.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Cashbook
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.*
import java.util.concurrent.TimeUnit
import javax.inject.Inject

data class RawMaterialPredictionItem(
    val itemName: String,
    val emoji: String,
    val lastPurchaseDate: Long,
    val avgGapDays: Int,
    val daysPassed: Int,
    val priority: RawMaterialPriority,
    val unit: String
)

enum class RawMaterialPriority {
    URGENT, MEDIUM, SAFE
}

data class RawMaterialPredictionState(
    val urgentItems: List<RawMaterialPredictionItem> = emptyList(),
    val mediumItems: List<RawMaterialPredictionItem> = emptyList(),
    val safeItems: List<RawMaterialPredictionItem> = emptyList(),
    val isLoading: Boolean = true,
    val filterDays: Int = 30
)

@HiltViewModel
class RawMaterialPredictionViewModel @Inject constructor(
    private val repository: MainRepository,
    private val sharedViewModel: SharedViewModel
) : ViewModel() {

    private val _state = MutableStateFlow(RawMaterialPredictionState())
    val state: StateFlow<RawMaterialPredictionState> = _state.asStateFlow()

    private val rawMaterialKeywords = listOf(
        "MILK", "TEA", "SUGAR", "EGG", "OIL", "COFFEE", "GINGER", "LEMON", "MASALA", "GAS", 
        "CURD", "BISCUIT", "BREAD", "BUTTER", "CREAM", "HONEY", "SALT", "POWDER"
    )

    private val exclusions = listOf(
        "POLICE", "POOJA", "GOD", "FLOWER", "CUP", "EXTRA", "GIFT", "REPAIR", "CLEANING", 
        "MAINTENANCE", "DONATION", "STATIONERY", "ELECTRICITY", "RENT", "TAX"
    )

    init {
        viewModelScope.launch {
            sharedViewModel.selectedShop.collect { shop ->
                shop?.let { loadPredictions(it.shopId) }
            }
        }
    }

    fun setFilterRange(days: Int) {
        _state.update { it.copy(filterDays = days) }
        viewModelScope.launch {
            sharedViewModel.selectedShop.value?.let { loadPredictions(it.shopId) }
        }
    }

    private fun loadPredictions(shopId: String) {
        val now = System.currentTimeMillis()
        val cacheKey = "raw_material_pred_${shopId}_${_state.value.filterDays}"

        viewModelScope.launch {
            // OPTIMISTIC UI: Try to load from cache
            val cached = repository.getListCache<RawMaterialPredictionState>(cacheKey).firstOrNull()
            _state.update { (cached ?: it).copy(isLoading = cached == null) }

            repository.getCashbookEntriesForPeriod(shopId, 0, now)
                .map { entries ->
                    val newState = processEntries(entries, _state.value.filterDays)
                    repository.saveListCache(cacheKey, listOf(newState))
                    newState
                }
                .flowOn(Dispatchers.Default)
                .collect { items ->
                    _state.update {
                        it.copy(
                            urgentItems = items.filter { item -> item.priority == RawMaterialPriority.URGENT },
                            mediumItems = items.filter { item -> item.priority == RawMaterialPriority.MEDIUM },
                            safeItems = items.filter { item -> item.priority == RawMaterialPriority.SAFE },
                            isLoading = false
                        )
                    }
                }
        }
    }

    private fun processEntries(entries: List<Cashbook>, filterDays: Int): List<RawMaterialPredictionItem> {
        val now = System.currentTimeMillis()
        val filterMillis = filterDays * 24L * 60 * 60 * 1000
        val cutoffTime = now - filterMillis

        val purchases = entries.filter { 
            it.transactionType == "OUT" &&
            !it.category.contains("SALARY", true) &&
            !it.category.contains("ADVANCE", true)
        }

        val itemsGrouped = purchases.groupBy { 
            it.description?.uppercase()?.trim() ?: it.category.uppercase().trim()
        }

        val predictionItems = mutableListOf<RawMaterialPredictionItem>()

        itemsGrouped.forEach { (name, history) ->
            if (isRawMaterial(name)) {
                val sortedHistory = history.sortedBy { it.transactionDate }
                
                // Only consider items purchased within the filter range
                if (sortedHistory.last().transactionDate < cutoffTime) return@forEach

                if (sortedHistory.size < 2) return@forEach 

                val gaps = mutableListOf<Long>()
                for (i in 1 until sortedHistory.size) {
                    val gap = sortedHistory[i].transactionDate - sortedHistory[i - 1].transactionDate
                    if (gap > TimeUnit.HOURS.toMillis(12)) { 
                        gaps.add(gap)
                    }
                }

                if (gaps.isEmpty()) return@forEach

                val avgGapMillis = gaps.average().toLong()
                val avgGapDays = (avgGapMillis / (24L * 60 * 60 * 1000)).toInt().coerceAtLeast(1)

                val lastPurchase = sortedHistory.last().transactionDate
                val daysPassed = ((now - lastPurchase) / (24L * 60 * 60 * 1000)).toInt()

                val priority = when {
                    daysPassed >= avgGapDays -> RawMaterialPriority.URGENT
                    daysPassed == avgGapDays - 1 -> RawMaterialPriority.MEDIUM
                    else -> RawMaterialPriority.SAFE
                }

                predictionItems.add(
                    RawMaterialPredictionItem(
                        itemName = name.lowercase().replaceFirstChar { it.uppercase() },
                        emoji = getEmojiForItem(name),
                        lastPurchaseDate = lastPurchase,
                        avgGapDays = avgGapDays,
                        daysPassed = daysPassed,
                        priority = priority,
                        unit = sortedHistory.last().unit ?: "Piece"
                    )
                )
            }
        }

        return predictionItems.sortedByDescending { it.daysPassed.toDouble() / it.avgGapDays }
    }

    private fun isRawMaterial(name: String): Boolean {
        val isExcluded = exclusions.any { name.contains(it, true) }
        if (isExcluded) return false
        
        return rawMaterialKeywords.any { name.contains(it, true) }
    }

    private fun getEmojiForItem(name: String): String {
        return when {
            name.contains("MILK") -> "🥛"
            name.contains("TEA") -> "🍃"
            name.contains("SUGAR") -> "🍚"
            name.contains("EGG") -> "🥚"
            name.contains("OIL") -> "🛢️"
            name.contains("COFFEE") -> "☕"
            name.contains("GINGER") -> "🫚"
            name.contains("LEMON") -> "🍋"
            name.contains("MASALA") -> "🌶️"
            name.contains("GAS") -> "🔥"
            name.contains("CURD") -> "🥣"
            name.contains("BISCUIT") -> "🍪"
            name.contains("BREAD") -> "🍞"
            name.contains("BUTTER") -> "🧈"
            else -> "📦"
        }
    }
}
