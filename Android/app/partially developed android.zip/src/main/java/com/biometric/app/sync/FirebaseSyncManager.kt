package com.biometric.app.sync

import android.util.Log
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.database.*
import com.biometric.app.data.entity.*
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.tasks.await
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import javax.inject.Singleton

@Singleton
class FirebaseSyncManager @Inject constructor() {

    val syncScope = CoroutineScope(Dispatchers.IO + SupervisorJob())

    private val auth = FirebaseAuth.getInstance()
    private val database = FirebaseDatabase.getInstance().apply {
        setPersistenceEnabled(true)
        setPersistenceCacheSizeBytes(100 * 1024 * 1024) 
    }.reference

    fun getGlobalRef() = database

    val lastSyncTime = MutableStateFlow(System.currentTimeMillis())

    // Sync Status Flow
    val syncStatus: Flow<Boolean> = callbackFlow {
        val connectedRef = FirebaseDatabase.getInstance().getReference(".info/connected")
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val connected = snapshot.getValue(Boolean::class.java) ?: false
                trySend(connected)
            }
            override fun onCancelled(error: DatabaseError) {
                trySend(element = false)
            }
        }
        connectedRef.addValueEventListener(listener)
        awaitClose { connectedRef.removeEventListener(listener) }
    }

    fun getOwnerRef(): DatabaseReference? {
        val uid = auth.currentUser?.uid ?: return null
        return database.child("owners").child(uid)
    }

    private var hasInitializedSync = false

    fun startSync() {
        if (hasInitializedSync) return
        val ref = getOwnerRef() ?: return
        
        ref.child("shops").keepSynced(true)
        ref.child("employees").keepSynced(true)
        ref.child("fixed_expenses").keepSynced(true)
        ref.child("inventory").keepSynced(true)
        ref.child("summaries").keepSynced(true)
        ref.child("monthly_snapshots").keepSynced(true)
        ref.child("attendance_punches").keepSynced(true)
        
        hasInitializedSync = true
    }

    // Generic Flow for any table
    inline fun <reified T : Any> getDataFlow(table: String): Flow<List<T>> = callbackFlow {
        val ref = getOwnerRef()?.child(table) ?: run {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastSyncTime.value = System.currentTimeMillis()
                
                syncScope.launch(Dispatchers.Default) {
                    val list = mutableListOf<T>()
                    for (childSnapshot in snapshot.children) {
                        try {
                            if (childSnapshot.hasChildren()) {
                                childSnapshot.getValue(T::class.java)?.let { list.add(it) }
                            } else {
                                Log.w("FirebaseSyncManager", "Skipping primitive value in table '$table': ${childSnapshot.value}")
                            }
                        } catch (e: Exception) {
                            Log.e("FirebaseSyncManager", "Failed to convert to ${T::class.java.name} in table '$table'", e)
                        }
                    }
                    trySend(list)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseSyncManager", "Query cancelled for table '$table': ${error.message}")
                trySend(emptyList())
                this@callbackFlow.close()
            }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    inline fun <reified T : Any> getQueryFlow(query: Query): Flow<List<T>> = callbackFlow {
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastSyncTime.value = System.currentTimeMillis()
                
                syncScope.launch(Dispatchers.Default) {
                    val list = mutableListOf<T>()
                    for (childSnapshot in snapshot.children) {
                        try {
                            childSnapshot.getValue(T::class.java)?.let { list.add(it) }
                        } catch (e: Exception) {
                            Log.e("FirebaseSyncManager", "Query conversion failed", e)
                        }
                    }
                    trySend(list)
                }
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseSyncManager", "Query cancelled: ${error.message}")
                trySend(emptyList())
                this@callbackFlow.close()
            }
        }
        query.addValueEventListener(listener)
        awaitClose { query.removeEventListener(listener) }
    }

    // Single item flow from global root
    inline fun <reified T : Any> getGlobalItemFlow(path: String): Flow<T?> = callbackFlow {
        val ref = getGlobalRef().child(path)
        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastSyncTime.value = System.currentTimeMillis()
                trySend(snapshot.getValue(T::class.java))
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseSyncManager", "Global query cancelled: ${error.message}")
                trySend(null)
                this@callbackFlow.close()
            }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    // Single item flow relative to owner root
    inline fun <reified T : Any> getItemFlow(table: String, itemId: String): Flow<T?> = callbackFlow {
        val ref = getOwnerRef()?.child(table)?.child(itemId) ?: run {
            trySend(null)
            return@callbackFlow
        }

        val listener = object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                lastSyncTime.value = System.currentTimeMillis()
                trySend(snapshot.getValue(T::class.java))
            }
            override fun onCancelled(error: DatabaseError) {
                Log.e("FirebaseSyncManager", "Item query cancelled: ${error.message}")
                trySend(null)
                this@callbackFlow.close()
            }
        }
        ref.addValueEventListener(listener)
        awaitClose { ref.removeEventListener(listener) }
    }

    /**
     * Efficiently fetches data within a specific time window.
     * Use this for large tables like Orders, Cashbook, and Attendance.
     */
    inline fun <reified T : Any> getTimeWindowedFlow(
        table: String,
        orderBy: String,
        startTime: Long,
        endTime: Long,
    ): Flow<List<T>> {
        val ref = getOwnerRef()?.child(table) ?: return flowOf(emptyList())
        val query = ref.orderByChild(orderBy).startAt(startTime.toDouble()).endAt(endTime.toDouble())
        return getQueryFlow(query)
    }

    /**
     * CONFLICT RESOLUTION (Last Write Wins based on lastModified timestamp)
     */
    private fun <T : Any> pushWithConflictResolution(
        table: String,
        itemId: String,
        item: T,
        lastModified: Long
    ) {
        val ref = getOwnerRef()?.child(table)?.child(itemId) ?: return
        
        ref.runTransaction(
            object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                val existing = currentData.getValue(Map::class.java)
                val existingLastModified = (existing?.get("lastModified") as? Long) ?: 0L
                
                return if (lastModified >= existingLastModified) {
                    currentData.value = item
                    Transaction.success(currentData)
                } else {
                    Transaction.abort()
                }
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (!committed && (error == null)) {
                    Log.d("Sync", "Conflict detected for $itemId in $table. Local update rejected as server data is newer.")
                }
            }
        })
    }

    // Write Methods
    suspend fun pushShop(shop: Shop) = getOwnerRef()?.child("shops")?.child(shop.shopId)?.setValue(shop)?.await()
    suspend fun pushItem(item: Item) = getOwnerRef()?.child("items")?.child(item.itemId)?.setValue(item)?.await()
    suspend fun pushPrice(price: ShopItemPrice) = getOwnerRef()?.child("prices")?.child("${price.shopId}_${price.itemId}")?.setValue(price)?.await()
    
    suspend fun pushOrder(order: Order) {
        val ref = getOwnerRef()
        ref?.child("orders")?.child(order.orderId)?.setValue(order)?.await()
        
        // Update Aggregated Summary
        order.closedAt?.let { timestamp ->
            val sdf = SimpleDateFormat("yyyy_MM", Locale.getDefault())
            val monthKey = sdf.format(Date(timestamp))
            val summaryRef = ref?.child("summaries")?.child(order.shopId)?.child(monthKey)
            
            summaryRef?.runTransaction(object : Transaction.Handler {
                override fun doTransaction(currentData: MutableData): Transaction.Result {
                    val summary = currentData.getValue(MonthSummary::class.java) ?: MonthSummary()
                    summary.totalSales += order.totalAmount
                    when (order.paymentMethod) {
                        "ONLINE", "QR" -> summary.qrSales += order.totalAmount
                        "CASH" -> summary.cashSales += order.totalAmount
                        "SPLIT" -> {
                            summary.cashSales += order.cashAmount
                            summary.qrSales += order.onlineAmount
                        }
                    }
                    currentData.value = summary
                    return Transaction.success(currentData)
                }
                override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {}
            })
        }
    }

    suspend fun pushOrderItem(item: OrderItem) = getOwnerRef()?.child("order_items")?.child(item.orderItemId)?.setValue(item)?.await()
    
    fun pushCashbookEntry(entry: Cashbook) {
        entry.lastModified = System.currentTimeMillis()
        getOwnerRef()?.child("cashbook")?.child(entry.entryId)?.setValue(entry)
    }

    suspend fun pushEmployee(emp: Employee) = getOwnerRef()?.child("employees")?.child(emp.employeeId)?.setValue(emp)?.await()
    suspend fun pushAttendance(att: Attendance) {
        val id = att.attendanceId.ifBlank { return }
        getOwnerRef()?.child("attendance")?.child(id)?.setValue(att)?.await()
    }

    suspend fun pushAttendancePunch(punch: AttendancePunch) {
        val id = punch.punchId.ifBlank { return }
        getOwnerRef()?.child("attendance_punches")?.child(id)?.setValue(punch)?.await()
    }
    suspend fun pushStockMovement(sm: StockMovement) = getOwnerRef()?.child("stock_movements")?.child(sm.movementId)?.setValue(sm)?.await()
    suspend fun pushAdvance(adv: AdvancePayment) = getOwnerRef()?.child("advance_payments")?.child(adv.advanceId)?.setValue(adv)?.await()
    fun pushSalaryPayment(p: SalaryPayment) {
        val ref = getOwnerRef() ?: return
        
        ref.child("salary_payments").child(p.paymentId).runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                currentData.value = p
                return Transaction.success(currentData)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (!committed) Log.e("Sync", "Individual salary payment update failed: ${error?.message}")
            }
        })
        
        val ts = p.paymentDate
        val monthKey = SimpleDateFormat("yyyy_MM", Locale.getDefault()).format(Date(ts))
        val summaryRef = ref.child("summaries").child(p.shopId).child(monthKey)
        
        summaryRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val summary = currentData.getValue(MonthSummary::class.java) ?: MonthSummary(shopId = p.shopId, monthKey = monthKey)
                summary.totalExpenses += p.netPaid
                currentData.value = summary
                return Transaction.success(currentData)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (!committed) Log.e("Sync", "Salary payment summary update failed: ${error?.message}")
            }
        })
    }
    suspend fun pushSupplier(s: Supplier) = getOwnerRef()?.child("suppliers")?.child(s.supplierId)?.setValue(s)?.await()
    suspend fun pushPurchase(p: Purchase) = getOwnerRef()?.child("purchases")?.child(p.purchaseId)?.setValue(p)?.await()
    suspend fun pushHistory(hist: EmployeeHistory) = getOwnerRef()?.child("employee_history")?.child(hist.historyId)?.setValue(hist)?.await()

    fun pushHistoryAtomic(hist: EmployeeHistory) {
        val ref = getOwnerRef()?.child("employee_history") ?: return
        val countersRef = getOwnerRef()?.child("history_counters")?.child(hist.employeeId) ?: return

        countersRef.runTransaction(object : Transaction.Handler {
            override fun doTransaction(currentData: MutableData): Transaction.Result {
                val currentVersion = currentData.getValue(Int::class.java) ?: 0
                val nextVersion = currentVersion + 1
                currentData.value = nextVersion
                
                hist.version = nextVersion
                ref.child(hist.historyId).setValue(hist)
                
                return Transaction.success(currentData)
            }
            override fun onComplete(error: DatabaseError?, committed: Boolean, snapshot: DataSnapshot?) {
                if (!committed) {
                    Log.e("FirebaseSyncManager", "Atomic history push failed: ${error?.message}")
                }
            }
        })
    }
    suspend fun pushClosedDay(day: ShopClosedDay) = getOwnerRef()?.child("shop_closed_days")?.child(day.id)?.setValue(day)?.await()
    suspend fun pushReminder(reminder: Reminder) = getOwnerRef()?.child("reminders")?.child(reminder.reminderId)?.setValue(reminder)?.await()
    suspend fun pushStockPattern(pattern: StockPattern) = getOwnerRef()?.child("stock_patterns")?.child("${pattern.shopId}_${pattern.itemId}")?.setValue(pattern)?.await()
    suspend fun pushShopTable(table: ShopTable) = getOwnerRef()?.child("shop_tables")?.child("${table.shopId}_${table.tableId}")?.setValue(table)?.await()
    suspend fun pushProfile(profile: UserProfile) {
        getOwnerRef()?.child("user_profiles")?.child(profile.uid)?.setValue(profile)?.await()
        
        // SYNC TO FIRESTORE for Security Rules
        try {
            FirebaseFirestore.getInstance()
                .collection("userProfiles")
                .document(profile.uid)
                .set(profile)
                .await()
        } catch (e: Exception) {
            Log.e("FirebaseSyncManager", "Firestore profile sync failed", e)
        }
    }
    
    suspend fun pushFixedExpense(expense: FixedExpense) {
        if (expense.id.isBlank()) return
        getOwnerRef()?.child("fixed_expenses")?.child(expense.id)?.setValue(expense)?.await()
    }
    
    suspend fun pushInvestment(investment: Investment) = getOwnerRef()?.child("investments")?.child(investment.investmentId)?.setValue(investment)?.await()
    
    suspend fun pushStockAudit(audit: StockAudit) = getOwnerRef()?.child("stock_audits")?.child(audit.auditId)?.setValue(audit)?.await()

    suspend fun pushRecycleBin(item: RecycleBinItem) = getOwnerRef()?.child("recycle_bin")?.child(item.id)?.setValue(item)?.await()

    suspend fun pushExpenseCategory(cat: ExpenseCategory) = getOwnerRef()?.child("expense_categories")?.child(cat.id)?.setValue(cat)?.await()

    suspend fun pushDescriptionMaster(item: DescriptionMaster) = getOwnerRef()?.child("description_master")?.child(item.id)?.setValue(item)?.await()

    // Audit Trail
    suspend fun pushAuditLog(log: AuditLog) = getOwnerRef()?.child("audit_logs")?.child(log.logId)?.setValue(log)?.await()

    // Inventory & Price History
    suspend fun pushInventoryItem(item: InventoryItem) {
        val key = item.name.uppercase().trim()
        if (key.isBlank()) return
        getOwnerRef()?.child("inventory")?.child(key)?.setValue(item)?.await()
    }
    
    suspend fun pushPriceHistory(history: PriceHistory) {
        val key = history.referenceEntryId.ifBlank { history.historyId }
        if (key.isBlank()) return
        getOwnerRef()?.child("price_history")?.child(key)?.setValue(history)?.await()
    }

    suspend fun pushPriceHistoryBulk(histories: List<PriceHistory>) {
        val ref = getOwnerRef()?.child("price_history") ?: return
        val updates = mutableMapOf<String, Any?>()
        histories.forEach { history ->
            val key = history.referenceEntryId.ifBlank { history.historyId }
            if (key.isNotBlank()) {
                updates[key] = history
            }
        }
        if (updates.isNotEmpty()) {
            ref.updateChildren(updates).await()
        }
    }

    suspend fun pushInventoryBulk(items: List<InventoryItem>) {
        val ref = getOwnerRef()?.child("inventory") ?: return
        val updates = mutableMapOf<String, Any?>()
        items.forEach { item ->
            val key = item.name.uppercase().trim()
            if (key.isNotBlank()) {
                updates[key] = item
            }
        }
        if (updates.isNotEmpty()) {
            ref.updateChildren(updates).await()
        }
    }

    suspend fun updateMonthSummaryDirect(shopId: String, monthKey: String, summary: MonthSummary) {
        getOwnerRef()?.child("summaries")?.child(shopId)?.child(monthKey)?.setValue(summary)?.await()
    }

    suspend fun bulkRestore(updates: Map<String, Any?>) {
        val ref = getOwnerRef() ?: return
        updates.entries.chunked(300).forEach { chunk ->
            val chunkMap = chunk.associateBy({ it.key }) { it.value }
            ref.updateChildren(chunkMap).await()
        }
    }

    suspend fun clearSnapshotsAndSummaries() {
        val ref = getOwnerRef() ?: return
        ref.child("monthly_snapshots").removeValue().await()
        ref.child("summaries").removeValue().await()
    }

    suspend fun clearTable(table: String) {
        getOwnerRef()?.child(table)?.removeValue()?.await()
    }

    // Delete Methods
    suspend fun deleteShop(shopId: String) = getOwnerRef()?.child("shops")?.child(shopId)?.removeValue()?.await()
    suspend fun deleteItem(itemId: String) = getOwnerRef()?.child("items")?.child(itemId)?.removeValue()?.await()
    suspend fun deleteOrder(orderId: String) = getOwnerRef()?.child("orders")?.child(orderId)?.removeValue()?.await()
    suspend fun deleteOrderItem(orderItemId: String) = getOwnerRef()?.child("order_items")?.child(orderItemId)?.removeValue()?.await()
    suspend fun deleteCashbookEntry(entryId: String) = getOwnerRef()?.child("cashbook")?.child(entryId)?.removeValue()?.await()
    suspend fun deleteEmployee(employeeId: String) = getOwnerRef()?.child("employees")?.child(employeeId)?.removeValue()?.await()
    suspend fun deleteAttendance(attendanceId: String) = getOwnerRef()?.child("attendance")?.child(attendanceId)?.removeValue()?.await()
    suspend fun deleteAttendancePunch(punchId: String) = getOwnerRef()?.child("attendance_punches")?.child(punchId)?.removeValue()?.await()
    suspend fun deleteAdvance(advanceId: String) = getOwnerRef()?.child("advance_payments")?.child(advanceId)?.removeValue()?.await()
    suspend fun deleteClosedDay(dayId: String) = getOwnerRef()?.child("shop_closed_days")?.child(dayId)?.removeValue()?.await()
    suspend fun deleteReminder(reminderId: String) = getOwnerRef()?.child("reminders")?.child(reminderId)?.removeValue()?.await()
    suspend fun deleteHistory(historyId: String) = getOwnerRef()?.child("employee_history")?.child(historyId)?.removeValue()?.await()
    suspend fun deleteFixedExpense(expenseId: String) {
        if (expenseId.isBlank()) return
        getOwnerRef()?.child("fixed_expenses")?.child(expenseId)?.removeValue()?.await()
    }
    suspend fun deleteInvestment(investmentId: String) = getOwnerRef()?.child("investments")?.child(investmentId)?.removeValue()?.await()
    
    suspend fun deleteRecycleBinItem(id: String) = getOwnerRef()?.child("recycle_bin")?.child(id)?.removeValue()?.await()

    suspend fun deleteInventoryItem(itemName: String) {
        val key = itemName.uppercase().trim()
        if (key.isBlank()) return
        getOwnerRef()?.child("inventory")?.child(key)?.removeValue()?.await()
    }
    
    suspend fun deletePriceHistoryByReference(referenceId: String) {
        if (referenceId.isBlank()) return
        getOwnerRef()?.child("price_history")?.child(referenceId)?.removeValue()?.await()
    }

    fun deleteCashbookEntryByReference(referenceId: String) {
        if (referenceId.isBlank()) return
        getOwnerRef()?.child("cashbook")?.orderByChild("referenceId")?.equalTo(referenceId)?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { it.ref.removeValue() }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }

    suspend fun pushMonthlySnapshot(snapshot: MonthlySnapshot) {
        val ref = getOwnerRef()?.child(snapshot.snapshotId)
        ref?.setValue(snapshot)?.await()
    }

    suspend fun pushSalarySnapshot(snapshot: SalarySnapshot) {
        val ref = getOwnerRef()?.child(snapshot.snapshotId)
        ref?.setValue(snapshot)?.await()
    }

    fun deleteOrderItemsByOrderId(orderId: String) {
        if (orderId.isBlank()) return
        getOwnerRef()?.child("order_items")?.orderByChild("orderId")?.equalTo(orderId)?.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                snapshot.children.forEach { it.ref.removeValue() }
            }
            override fun onCancelled(error: DatabaseError) {}
        })
    }
}

@IgnoreExtraProperties
data class MonthSummary(
    var shopId: String = "",
    var monthKey: String = "",
    var totalSales: Double = 0.0,
    var cashSales: Double = 0.0,
    var qrSales: Double = 0.0,
    var totalExpenses: Double = 0.0
)
