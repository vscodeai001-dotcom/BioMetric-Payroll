package com.biometric.app.ui.viewmodel

import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Employee
import com.biometric.app.data.entity.Shop
import com.biometric.app.data.entity.ShopMenuItem
import com.biometric.app.data.entity.UserProfile
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.*
import java.util.Calendar
import javax.inject.Inject
import javax.inject.Singleton

@OptIn(ExperimentalCoroutinesApi::class)
@Singleton
class SharedViewModel @Inject constructor(
    private val repository: MainRepository
) {
    private val scope = CoroutineScope(Dispatchers.Main + SupervisorJob())

    val userProfile: StateFlow<UserProfile?> = repository.getProfileFlow()
        .stateIn(scope, SharingStarted.Eagerly, null)

    val currentEmployee: StateFlow<Employee?> = userProfile.filterNotNull()
        .flatMapLatest { profile ->
            if (profile.isStaff()) repository.getEmployee(profile.uid)
            else flowOf(null)
        }.stateIn(scope, SharingStarted.Eagerly, null)

    val allShops: StateFlow<List<Shop>> = repository.getAllShops()
        .stateIn(scope, SharingStarted.Eagerly, emptyList())

    private val _shopData = MutableStateFlow<Map<String, ShopWithProfit>>(emptyMap())
    val shopData: StateFlow<Map<String, ShopWithProfit>> = _shopData.asStateFlow()

    private val _selectedShop = MutableStateFlow<Shop?>(null)
    val selectedShop: StateFlow<Shop?> = _selectedShop.asStateFlow()

    private val _isWarmingUp = MutableStateFlow(false)
    val isWarmingUp = _isWarmingUp.asStateFlow()

    fun warmUpDashboard() {
        if (_isWarmingUp.value) return
        _isWarmingUp.value = true
        
        // Eagerly load cached data from repository into memory
        scope.launch(Dispatchers.IO) {
            val cachedShops = repository.getCachedShops()
            val cachedMetrics = repository.getCachedGlobalMetrics()
            
            if (cachedShops.isNotEmpty()) {
                cachedShops.forEach { updateShopData(it.shop.shopId, it) }
            }
            
            // Warm up global metrics into repository memory
            cachedMetrics?.let { 
                // Repository cache is already on disk, this IO call ensures it's ready for sync reading
            }

            _isWarmingUp.value = false
        }
    }

    // --- INSTANT DATA CACHE (Shared across all Activities) ---
    
    val currentShopMenu: StateFlow<List<ShopMenuItem>> = _selectedShop.filterNotNull()
        .flatMapLatest { repository.getShopMenu(it.shopId) }
        .stateIn(scope, SharingStarted.WhileSubscribed(60000), emptyList())

    val currentShopEmployees: StateFlow<List<Employee>> = _selectedShop.filterNotNull()
        .flatMapLatest { repository.getShopEmployees(it.shopId) }
        .stateIn(scope, SharingStarted.WhileSubscribed(60000), emptyList())

    private val _refreshRequested = MutableSharedFlow<Unit>(replay = 0)
    val refreshRequested = _refreshRequested.asSharedFlow()

    /**
     * Triggers a SILENT background refresh of the main dashboard.
     * Use this after any CRUD operation (Finance, POS, Attendance).
     */
    fun triggerDashboardRefresh() {
        _refreshRequested.tryEmit(Unit)
    }

    fun updateShopData(shopId: String, data: ShopWithProfit) {
        val current = _shopData.value.toMutableMap()
        current[shopId] = data
        _shopData.value = current
    }

    fun setSelectedShop(shop: Shop) {
        _selectedShop.value = shop
        // PROACTIVE PREFETCHING: Warm up critical screens when shop is selected
        warmUpShopData(shop.shopId)
    }

    private fun warmUpShopData(shopId: String) {
        scope.launch(Dispatchers.IO) {
            // Eagerly collect and cache menu and employees in background
            currentShopMenu.first()
            currentShopEmployees.first()
            
            // Warm up current month metrics
            val cal = Calendar.getInstance()
            val start = cal.apply { set(Calendar.DAY_OF_MONTH, 1) }.timeInMillis
            val end = System.currentTimeMillis()
            repository.getShopMetricsFlow(shopId, start, end).first()
        }
    }

    fun clearShopData() {
        _shopData.value = emptyMap()
    }
}
