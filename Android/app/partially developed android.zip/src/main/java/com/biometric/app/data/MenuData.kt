package com.biometric.app.data

import com.biometric.app.data.entity.Item

object MenuData {
    val initialItems = listOf(
        // TEA & HOT DRINKS
        Item("tea_dum", "☕ Dum Tea", "Tea", globalPrice = 15.0),
        Item("tea_nattu", "☕ Nattu Sakkarai Tea", "Tea", globalPrice = 20.0),
        Item("tea_ginger", "🫚 Ginger Tea", "Tea", globalPrice = 18.0),
        Item("tea_masala", "🌿 Masala Tea", "Tea", globalPrice = 18.0),
        Item("tea_lemon", "🍋 Lemon Tea", "Tea", globalPrice = 18.0),
        Item("tea_ginger_lemon", "🍋 Ginger Lemon Tea", "Tea", globalPrice = 22.0),
        Item("coffee_std", "☕ Coffee", "Coffee", globalPrice = 22.0),
        Item("coffee_sukku", "☕ Sukku Coffee", "Coffee", globalPrice = 28.0),
        Item("tea_kullad", "🍯 Kullad Tea", "Tea", globalPrice = 22.0),
        Item("tea_kashmiri", "🌸 Kashmiri Chai", "Tea", globalPrice = 22.0),
        Item("tea_green", "🍵 Green Tea", "Tea", globalPrice = 28.0),
        Item("drink_boost", "⚡ Boost", "Health Drink", globalPrice = 28.0),
        Item("drink_horlicks", "🥛 Horlicks", "Health Drink", globalPrice = 28.0),

        // MILK & SPECIAL DRINKS
        Item("milk_badam", "🥛 Badam Milk", "Milk Drink", globalPrice = 22.0),
        Item("milk_rose", "🌹 Rose Milk", "Flavoured Milk", globalPrice = 45.0),
        Item("milk_chilled_badam", "🧊 Chilled Badam Milk", "Flavoured Milk", globalPrice = 45.0),

        // MAGGIE
        Item("maggie_veg", "🍳 Veg Maggie", "Maggie", globalPrice = 55.0),
        Item("maggie_egg", "🍳 Egg Maggie", "Maggie", globalPrice = 65.0),

        // FRESH JUICES
        Item("juice_lemon", "🍋 Lemon Juice", "Fresh Juice", globalPrice = 25.0),
        Item("juice_watermelon", "🍉 Watermelon Juice", "Fresh Juice", globalPrice = 30.0),
        Item("juice_muskmelon", "🍈 Muskmelon Juice", "Fresh Juice", globalPrice = 40.0),
        Item("juice_sathukudi", "🍊 Sathukudi Juice", "Fresh Juice", globalPrice = 50.0),
        Item("juice_apple", "🍎 Apple Juice", "Fresh Juice", globalPrice = 50.0),
        Item("juice_pomegranate", "🎈 Pomegranate Juice", "Fresh Juice", globalPrice = 60.0),
        Item("juice_red_banana", "🍌 Red Banana Juice", "Fresh Juice", globalPrice = 60.0),
        Item("juice_fig", "🫐 Fig Juice", "Fresh Juice", globalPrice = 60.0),
        Item("juice_mixed", "🍹 Mixed Juice", "Fresh Juice", globalPrice = 90.0),
        Item("juice_orange", "🍊 Orange Juice", "Fresh Juice", globalPrice = 80.0),

        // MILK SHAKES
        Item("shake_vanilla", "🍦 Vanilla Shake", "Milkshake", globalPrice = 50.0),
        Item("shake_strawberry", "🍓 Strawberry Shake", "Milkshake", globalPrice = 50.0),
        Item("shake_chocolate", "🍫 Chocolate Shake", "Milkshake", globalPrice = 50.0),
        Item("shake_mango", "🥭 Mango Milkshake", "Milkshake", globalPrice = 50.0),
        Item("shake_butterscotch", "🧈 Butterscotch Shake", "Milkshake", globalPrice = 55.0),
        Item("shake_dairy_milk", "🥛 Dairy Milk Shake", "Milkshake", globalPrice = 55.0),
        Item("shake_5star", "⭐ 5 Star Milkshake", "Milkshake", globalPrice = 55.0),
        Item("shake_oreo", "🍪 Oreo Milkshake", "Milkshake", globalPrice = 60.0),
        Item("shake_pista", "🥜 Pista Milkshake", "Milkshake", globalPrice = 60.0),
        Item("shake_blackcurrant", "🍇 Blackcurrant Shake", "Milkshake", globalPrice = 60.0),
        Item("shake_kitkat", "🍫 KitKat Milkshake", "Milkshake", globalPrice = 70.0),
        Item("shake_red_banana", "🍌 Red Banana Shake", "Milkshake", globalPrice = 70.0),
        Item("shake_dates", "🌴 Dates Milkshake", "Milkshake", globalPrice = 70.0),

        // COOLERS
        Item("cooler_nannari", "🍋 Nannari Sarbath", "Cooler", globalPrice = 30.0),
        Item("cooler_pal", "🥛 Pal Sarbath", "Cooler", globalPrice = 40.0),
        Item("cooler_lemon_mint", "🍃 Lemon Mint Cooler", "Cooler", globalPrice = 35.0),
        Item("cooler_matka_lassi", "🥛 Matka Lassi", "Cooler", globalPrice = 45.0),
        Item("cooler_cold_coffee", "🧊 Cold Coffee", "Cooler", globalPrice = 50.0),
        Item("cooler_fizz_mojito", "🍹 Fizz Mojito", "Cooler", globalPrice = 55.0),

        // ICE CREAMS
        Item("ice_vanilla", "🍦 Vannila Ice Cream", "Ice Cream", globalPrice = 40.0),
        Item("ice_chocolate", "🍫 Chocolate Ice Cream", "Ice Cream", globalPrice = 40.0),
        Item("ice_fruit_falooda", "🍓 Fruit Falooda", "Ice Cream", globalPrice = 80.0),
        Item("ice_royal_falooda", "👑 Royal Falooda", "Ice Cream", globalPrice = 120.0),

        // FALOODA
        Item("falooda_std", "🍧 Falooda", "Falooda", globalPrice = 80.0),

        // FRIES
        Item("snack_fries", "🍟 French Fries", "Fries", globalPrice = 50.0),
        Item("snack_smiley", "😊 Smiley", "Fries", globalPrice = 50.0),
        Item("snack_nuggets_veg", "🍗 Veg Nuggets", "Fries", globalPrice = 60.0),

        // BREAD ITEMS
        Item("bread_omelet", "🍳 Bread Omelet", "Bread Item", globalPrice = 55.0),
        Item("bread_cheese_omelet", "🧀 Cheese Bread Omelet", "Bread Item", globalPrice = 65.0),

        // SANDWICHES
        Item("sandwich_veg", "🥪 Veg Sandwich", "Sandwich", globalPrice = 40.0),
        Item("sandwich_cheese", "🧀 Cheese Sandwich", "Sandwich", globalPrice = 60.0),
        Item("sandwich_paneer", "🥪 Paneer Sandwich", "Sandwich", globalPrice = 70.0),

        // FRIED CHICKEN
        Item("chicken_lollipop", "🍗 Chicken Lollipop (2 pcs)", "Fried Chicken", globalPrice = 60.0),
        Item("chicken_popcorn", "🍿 Chicken Popcorn (100 g)", "Fried Chicken", globalPrice = 80.0),
        Item("chicken_finger", "🍗 Chicken Finger (4 pcs)", "Fried Chicken", globalPrice = 80.0),
        Item("chicken_nuggets", "🍗 Chicken Nuggets (6 pcs)", "Fried Chicken", globalPrice = 80.0),
        Item("chicken_burger", "🍔 Chicken Burger", "Burger", globalPrice = 100.0),

        // SNACKS
        Item("snack_masala_vadai", "🍘 Masala Vadai", "Snack", globalPrice = 10.0),
        Item("snack_medhu_vadai", "🍘 Medhu Vadai", "Snack", globalPrice = 10.0),
        Item("snack_vazhaikkai_bajji", "🍘 Vazhaikkai Bajji", "Snack", globalPrice = 10.0),
        Item("snack_chilli_bajji", "🍘 Chilli Bajji", "Snack", globalPrice = 5.0),
        Item("snack_onion_bajji", "🍘 Onion Bajji", "Snack", globalPrice = 5.0),
        Item("snack_potato_bajji", "🍘 Potato Bajji", "Snack", globalPrice = 5.0),
        Item("snack_masala_bonda", "🍘 Masala Bonda", "Snack", globalPrice = 10.0),
        Item("snack_sundal", "🍘 Sundal", "Snack", globalPrice = 10.0),
        Item("snack_mini_samosa", "🍘 Mini Samosa", "Snack", globalPrice = 10.0),
        Item("snack_samosa", "🍘 Samosa", "Snack", globalPrice = 10.0)
    )
}
