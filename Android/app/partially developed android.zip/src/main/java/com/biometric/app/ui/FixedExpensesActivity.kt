package com.biometric.app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder

import com.biometric.app.data.entity.FixedExpense
import com.biometric.app.databinding.ActivityFixedExpensesBinding
import com.biometric.app.databinding.DialogAddFixedExpenseBinding
import com.biometric.app.ui.adapter.FixedExpenseAdapter
import com.biometric.app.ui.viewmodel.FixedExpensesViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject
import kotlin.time.Duration.Companion.milliseconds
import com.biometric.app.util.KeyboardUtil

@AndroidEntryPoint
class FixedExpensesActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityFixedExpensesBinding

    private val viewModel: FixedExpensesViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    
    private lateinit var adapter: FixedExpenseAdapter
    private var currentShopId: String? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFixedExpensesBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Using standard Toolbar setup
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        updateToolbarTitle("Shop")

        setupRecyclerView()
        observeViewModel()

        intent.getStringExtra("SHOP_ID")?.let {
            viewModel.loadFixedExpenses(it)
        }

        binding.fabAddExpense.setOnClickListener {
            showAddEditDialog(null)
        }
    }

    private fun setupRecyclerView() {
        adapter = FixedExpenseAdapter(
            onEdit = { expense -> showAddEditDialog(expense) },
            onDelete = { expense -> showDeleteConfirmation(expense) }
        )
        binding.rvFixedExpenses.adapter = adapter
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            currentShopId = it.shopId
                            updateToolbarTitle(it.name)
                            viewModel.loadFixedExpenses(it.shopId)
                        }
                    }
                }
                launch {
                    viewModel.fixedExpenses.collectLatest { expenses ->
                        adapter.submitList(expenses)
                    }
                }
            }
        }
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Fixed Expenses")
    }



    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showAddEditDialog(expenseToEdit: FixedExpense?) {
        val sId = currentShopId ?: return
        val dialogBinding = DialogAddFixedExpenseBinding.inflate(LayoutInflater.from(this))

        val selectedDate = Calendar.getInstance()
        expenseToEdit?.let { selectedDate.timeInMillis = it.effectiveFrom }

        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        dialogBinding.btnEffectiveDate.text = sdf.format(selectedDate.time)

        dialogBinding.btnEffectiveDate.setOnClickListener {
            DatePickerDialog(
                this,
                { _, year, month, day ->
                    selectedDate[year, month] = day
                    dialogBinding.btnEffectiveDate.text = sdf.format(selectedDate.time)
                },
                selectedDate[Calendar.YEAR],
                selectedDate[Calendar.MONTH],
                selectedDate[Calendar.DAY_OF_MONTH]
            ).show()
        }

        expenseToEdit?.let {
            dialogBinding.etExpenseName.setText(it.name)
            dialogBinding.etExpenseAmount.setText(it.monthlyAmount.toString())
        }

        // ATOMIC AUTO-FOCUS
        var autoFocusJob: kotlinx.coroutines.Job? = null
        dialogBinding.etExpenseName.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (dialogBinding.etExpenseName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        kotlinx.coroutines.delay(1500.milliseconds)
                        KeyboardUtil.showKeyboard(dialogBinding.etExpenseAmount)
                    }
                }
            }
        })

        MaterialAlertDialogBuilder(this)
            .setTitle(if (expenseToEdit == null) "Add Fixed Expense" else "Edit Fixed Expense")
            .setView(dialogBinding.root)
            .setPositiveButton("Save") { _, _ ->
                val name = dialogBinding.etExpenseName.text.toString().trim()
                val amount = dialogBinding.etExpenseAmount.text.toString().toDoubleOrNull() ?: 0.0

                if (name.isNotEmpty() && amount > 0) {
                    if (expenseToEdit != null) {
                        val archivedExpense = expenseToEdit.copy(isArchived = true)
                        viewModel.addFixedExpense(archivedExpense)
                        
                        val newExpense = FixedExpense(
                            id = UUID.randomUUID().toString(),
                            shopId = sId,
                            name = name,
                            monthlyAmount = amount,
                            effectiveFrom = selectedDate.timeInMillis,
                            isArchived = false
                        )
                        viewModel.addFixedExpense(newExpense)
                    } else {
                        val newExpense = FixedExpense(
                            id = UUID.randomUUID().toString(),
                            shopId = sId,
                            name = name,
                            monthlyAmount = amount,
                            effectiveFrom = selectedDate.timeInMillis,
                            isArchived = false
                        )
                        viewModel.addFixedExpense(newExpense)
                    }
                    KeyboardUtil.hideKeyboard(this)
                    dialogBinding.etExpenseName.clearFocus()
                    dialogBinding.etExpenseAmount.clearFocus()
                    Toast.makeText(this, "Expense saved", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteConfirmation(expense: FixedExpense) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Delete Expense")
            .setMessage(String.format("Are you sure you want to delete '%s'? This will completely remove the entry.", expense.name))
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteFixedExpense(expense)
                Toast.makeText(this, "Expense deleted", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}