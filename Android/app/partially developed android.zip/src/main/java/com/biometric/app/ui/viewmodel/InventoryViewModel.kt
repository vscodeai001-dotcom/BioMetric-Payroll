package com.biometric.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.core.content.edit
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.MainRepository
import com.biometric.app.data.SmartStockReminder
import com.biometric.app.data.entity.InventoryItem
import com.biometric.app.data.entity.PriceHistory
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PredictionEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.*
import javax.inject.Inject

data class InventoryDisplayItem(
    val name: String,
    val unitType: String,
    val totalQuantity: Double,
    val totalCost: Double,
    val avgPrice: Double,
    val lastPrice: Double,
    val priceChangePercentage: Double = 0.0,
    val alerts: List<String> = emptyList(),
)

data class InventoryState(
    val items: List<InventoryDisplayItem> = emptyList(),
    val totalStockValue: Double = 0.0,
    val totalItemCount: Int = 0,
    val isLoading: Boolean = true,
    val alerts: List<String> = emptyList(),
    val suggestions: List<String> = emptyList(),
    val stockPredictions: List<SmartStockReminder> = emptyList(),
    val periodLabel: String = "Up To Date",
    val selectedDate: Long = System.currentTimeMillis()
)

@HiltViewModel
@OptIn(kotlinx.coroutines.FlowPreview::class)
class InventoryViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _shopId = MutableStateFlow<String?>(null)
    private val _period = MutableStateFlow("Up-To-Date")
    private val _referenceDate = MutableStateFlow(System.currentTimeMillis())
    
    private val _state = MutableStateFlow(InventoryState())
    val state: StateFlow<InventoryState> = _state.asStateFlow()

    private var isBackfilling = false

    init {
        // ROCKET SPEED: Load cached inventory immediately
        viewModelScope.launch {
            val cached = repository.getListCache<InventoryDisplayItem>("inventory_display")
            if (cached.isNotEmpty()) {
                _state.update { it.copy(items = cached, isLoading = false) }
            }
        }

        viewModelScope.launch {
            combine(
                _shopId.filterNotNull(),
                _period,
                _referenceDate,
                repository.firebaseSync.getDataFlow<PriceHistory>("price_history")
            ) { sId, period, refDate, history ->
                val filtered = history.filter { it.shopId == sId }
                DataBundle(sId, period, refDate, filtered)
            }.collectLatest { bundle ->
                loadInventoryDataReactive(bundle.period, bundle.referenceDate, bundle.history)
            }
        }
        
        viewModelScope.launch {
            combine(_shopId.filterNotNull(), _period, _referenceDate) { sId, period, refDate ->
                val (start, _) = DateRangeUtil.getRangeForPeriod(period, refDate)
                sId to start
            }.distinctUntilChanged().collect { (sId, start) ->
                checkAndTriggerBackfill(sId, start)
            }
        }
    }

    private data class DataBundle(val shopId: String, val period: String, val referenceDate: Long, val history: List<PriceHistory>)

    private suspend fun checkAndTriggerBackfill(shopId: String, viewingPeriodStart: Long? = null) {
        if (isBackfilling) return
        withContext(Dispatchers.IO) {
            try {
                val lastCheck = getApplication<Application>().getSharedPreferences("stock_prefs", 0)
                    .getLong("last_backfill_$shopId", 0L)
                
                // Allow re-checking every hour
                if (System.currentTimeMillis() - lastCheck < 3600000 && viewingPeriodStart == null) return@withContext

                // HISTORICAL GAP FIX: The previous 30-day window was too small to catch missed entries
                // in older months. We now check back 120 days (4 months) to ensure safety.
                val lookbackLimit = viewingPeriodStart ?: (System.currentTimeMillis() - (120L * 24 * 60 * 60 * 1000))
                
                val cashbookEntries = repository.getCashbookEntriesForPeriod(shopId, lookbackLimit, Long.MAX_VALUE).first()
                val currentHistory = repository.firebaseSync.getDataFlow<PriceHistory>("price_history").first()
                val historyEntryIds = currentHistory.filter { it.shopId == shopId }.map { it.referenceEntryId }.toSet()
                
                val missing = cashbookEntries.any { 
                    (it.transactionType == "OUT") && 
                    !FinancialCategory.isSalary(it.category, it.description) && 
                    !FinancialCategory.isAdvance(it.category) &&
                    it.entryId !in historyEntryIds
                }

                if (missing) {
                    // Trigger backfill for the detected missing range
                    runInventoryBackfill(shopId, lookbackLimit)
                }
                
                getApplication<Application>().getSharedPreferences("stock_prefs", 0).edit {
                    putLong("last_backfill_$shopId", System.currentTimeMillis())
                }
            } catch (_: Exception) {}
        }
    }

    fun setShopId(shopId: String) {
        _shopId.value = shopId
    }

    fun setPeriod(period: String) {
        _period.value = period
    }

    fun setReferenceDate(date: Long) {
        _referenceDate.value = date
    }

    private fun loadInventoryDataReactive(period: String, refDate: Long, allHistory: List<PriceHistory>) {
        viewModelScope.launch(Dispatchers.Default) {
            // UNIFORM LOADING: Only set loading true if no items available
            _state.update { it.copy(isLoading = it.items.isEmpty(), periodLabel = period, selectedDate = refDate) }
            
            try {
                // UNIFORM FILTER FIX: "Up To Date" now correctly means "1st of the month until selected date"
                // matches the behavior of all other screens in the application.
                val (start, end) = DateRangeUtil.getRangeForPeriod(period, refDate)
                val grouped = allHistory.filter { it.date in start..end }.groupBy { it.itemName.uppercase().trim() }
                
                // BATCH OPTIMIZATION: Index allHistory by item name for faster lookup in comparison
                val historyByItem = allHistory.groupBy { it.itemName.uppercase().trim() }
                
                val globalAlerts = mutableListOf<String>()
                
                // Previous month range
                val prevMonthStart = Calendar.getInstance().apply { 
                    timeInMillis = start
                    add(Calendar.MONTH, -1)
                }.timeInMillis
                val prevMonthEnd = start - 1
                
                val displayItems = grouped.map { (name, history) ->
                    val totalQty = history.sumOf { it.quantity }
                    val totalCost = history.sumOf { it.price * it.quantity }
                    val avgPrice = if (totalQty > 0) totalCost / totalQty else 0.0
                    
                    val sortedHistory = history.sortedBy { it.date }
                    val lastPrice = sortedHistory.lastOrNull()?.price ?: 0.0
                    
                    // Optimized previous month comparison using the index
                    val prevMonthHistory = historyByItem[name]?.filter { it.date in prevMonthStart..prevMonthEnd } ?: emptyList()
                    val prevAvgPrice = if (prevMonthHistory.isNotEmpty()) {
                        prevMonthHistory.sumOf { it.price * it.quantity } / prevMonthHistory.sumOf { it.quantity }
                    } else avgPrice
                    
                    val priceChange = if (prevAvgPrice > 0) ((avgPrice - prevAvgPrice) / prevAvgPrice) * 100 else 0.0
                    
                    val itemAlerts = mutableListOf<String>()
                    if (priceChange > 10) {
                        val alert = String.format(Locale.getDefault(), "%s cost increased %.0f%% vs last month", name, priceChange)
                        itemAlerts.add(alert)
                        globalAlerts.add(String.format(Locale.getDefault(), "⚠ High Cost Alert: %s", alert))
                    }
                    
                    if (history.any { it.quantity <= 0 }) {
                        itemAlerts.add("Missing Quantity in entries")
                        globalAlerts.add(String.format(Locale.getDefault(), "⚠ Missing Qty Alert: %s entries missing quantity", name))
                    }
                    
                    InventoryDisplayItem(
                        name = name,
                        unitType = history.firstOrNull { !it.unit.isNullOrBlank() }?.unit ?: "Unit", 
                        totalQuantity = totalQty,
                        totalCost = totalCost,
                        avgPrice = avgPrice,
                        lastPrice = lastPrice,
                        priceChangePercentage = priceChange,
                        alerts = itemAlerts
                    )
                }.sortedByDescending { it.totalCost }

                val suggestions = generateSuggestions(displayItems)
                
                // Predictive Stock Ordering
                val predictions = grouped.map { (name, history) ->
                    val currentStockItem = displayItems.find { it.name == name }
                    val pred = PredictionEngine.predictStockNeed(history, currentStockItem?.totalQuantity ?: 0.0)
                    val lastPurchased = history.maxOf { it.date }
                    val daysSinceLast = (System.currentTimeMillis() - lastPurchased) / 86400000L
                    
                    SmartStockReminder(
                        itemName = name,
                        currentStock = currentStockItem?.totalQuantity ?: 0.0,
                        unit = history.firstOrNull { !it.unit.isNullOrBlank() }?.unit ?: "Unit",
                        suggestedDaily = pred.suggestedDaily,
                        suggestedWeekly = pred.suggestedWeekly,
                        patternInsight = pred.insight,
                        urgency = if (daysSinceLast >= pred.avgGapDays || (pred.daysUntilEmpty ?: 10) <= 2) "URGENT" else "PLANNED",
                        confidence = pred.confidence,
                        lastPurchaseDate = lastPurchased,
                        avgGapDays = pred.avgGapDays
                    )
                }.filter { it.confidence > 40 }.sortedByDescending { it.urgency == "URGENT" }

                _state.update { 
                    it.copy(
                        items = displayItems,
                        totalStockValue = displayItems.sumOf { item -> item.totalCost },
                        totalItemCount = displayItems.size,
                        isLoading = false,
                        alerts = globalAlerts,
                        suggestions = suggestions,
                        stockPredictions = predictions
                    )
                }
                
                // Persist cache for rocket speed next open
                repository.saveListCache("inventory_display", displayItems)
            } catch (e: Exception) {
                Log.e("InventoryViewModel", "Error loading inventory", e)
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    private fun generateSuggestions(items: List<InventoryDisplayItem>): List<String> {
        val suggestions = mutableListOf<String>()
        if (items.isEmpty()) return listOf("💡 Add purchase entries in Cash Screen to track stock automatically.")
        
        items.take(3).forEach { item ->
            if (item.priceChangePercentage > 10) {
                suggestions.add(String.format(Locale.getDefault(), "💡 %s cost is up %.0f%%. Check alternative suppliers.", item.name, item.priceChangePercentage))
            }
        }
        
        suggestions.add("💡 Avoid overstocking on low-demand weekdays.")
        suggestions.add("💡 Reduce purchase on low-demand days to optimize cash flow.")
        
        return suggestions
    }

    fun getPriceHistory(shopId: String, itemName: String): Flow<List<PriceHistory>> {
        return repository.getPriceHistory(shopId, itemName)
    }


    fun runInventoryBackfill(shopId: String, since: Long = 0L) {
        if (isBackfilling) return
        viewModelScope.launch(Dispatchers.IO) {
            isBackfilling = true
            _state.update { it.copy(isLoading = true) }
            try {
                val entries = repository.getCashbookEntriesForPeriod(shopId, since, Long.MAX_VALUE).first()
                // Filter for any OUT entry that is not a salary/advance
                val purchases = entries.filter { 
                    it.transactionType == "OUT" && 
                    FinancialCategory.isSalary(it.category, it.description).not() && 
                    !FinancialCategory.isAdvance(it.category)
                }
                
                val historyList = mutableListOf<PriceHistory>()
                purchases.forEach { entry ->
                    val cleanName = entry.description?.uppercase()?.trim() ?: entry.category.uppercase().trim()
                    if (cleanName.isNotBlank() && cleanName != "UNKNOWN") {
                        val qty = entry.quantity ?: 1.0
                        val price = if (qty > 0) entry.amount / qty else entry.amount
                        historyList.add(
                            PriceHistory(
                                shopId = shopId,
                                itemName = cleanName,
                                price = price,
                                quantity = qty,
                                unit = entry.unit,
                                date = entry.transactionDate,
                                referenceEntryId = entry.entryId
                            )
                        )
                    }
                }
                
                if (historyList.isNotEmpty()) {
                    repository.firebaseSync.pushPriceHistoryBulk(historyList)
                }
                
                val itemNames = purchases.mapNotNull { 
                    it.description?.uppercase()?.trim() ?: it.category.uppercase().trim() 
                }.distinct().filter { it.isNotBlank() }
                
                val inventoryItemsToPush = mutableListOf<InventoryItem>()
                itemNames.forEach { name ->
                    val historyForItem = historyList.filter { it.itemName == name }
                    if (historyForItem.isNotEmpty()) {
                        val totalQty = historyForItem.sumOf { it.quantity }
                        val totalCost = historyForItem.sumOf { it.price * it.quantity }
                        val sorted = historyForItem.sortedBy { it.date }
                        val last = sorted.last()
                        
                        inventoryItemsToPush.add(InventoryItem(
                            shopId = shopId,
                            name = name,
                            unitType = last.unit ?: "Piece",
                            totalQuantity = totalQty,
                            totalCost = totalCost,
                            lastPrice = last.price,
                            lastUpdate = System.currentTimeMillis()
                        ))
                    }
                }

                if (inventoryItemsToPush.isNotEmpty()) {
                    repository.firebaseSync.pushInventoryBulk(inventoryItemsToPush)
                }
            } catch (e: Exception) {
                Log.e("InventoryViewModel", "Backfill failed", e)
            } finally {
                isBackfilling = false
                _state.update { it.copy(isLoading = false) }
            }
        }
    }

    fun renameItemGlobally(oldName: String, newName: String) {
        val sId = _shopId.value ?: return
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val cleanOld = oldName.trim().uppercase()
                val cleanNew = newName.trim().uppercase()

                // 1. Update all Cashbook entries (Global for this shop)
                val allEntries = repository.getCashbookEntriesForPeriod(sId, 0, Long.MAX_VALUE).first()
                val entriesToUpdate = allEntries.filter { it.description?.trim()?.uppercase() == cleanOld }
                
                entriesToUpdate.forEach { entry ->
                    repository.insertCashbookEntry(entry.copy(description = cleanNew))
                }

                // 2. Update all Price History
                val history = repository.getPriceHistory(sId, cleanOld).first()
                history.forEach { h ->
                    repository.firebaseSync.pushPriceHistory(h.copy(itemName = cleanNew))
                }

                // 3. Rebuild new inventory item
                rebuildInventoryItem(sId, cleanNew)

                // 4. Delete old inventory item if it's different
                if (cleanOld != cleanNew) {
                    repository.firebaseSync.deleteInventoryItem(cleanOld)
                }

            } catch (e: Exception) {
                Log.e("InventoryVM", "Global rename failed", e)
            }
        }
    }

    private suspend fun rebuildInventoryItem(shopId: String, name: String, defaultUnit: String = "Piece") {
        val history = repository.getPriceHistory(shopId, name).first()
        if (history.isEmpty()) return

        val totalQty = history.sumOf { it.quantity }
        val totalCost = history.sumOf { it.price * it.quantity }
        val sortedHistory = history.sortedBy { it.date }
        val lastPrice = sortedHistory.last().price
        val lastUnit = sortedHistory.last().unit ?: defaultUnit
        
        val item = InventoryItem(
            shopId = shopId,
            name = name,
            unitType = lastUnit,
            totalQuantity = totalQty,
            totalCost = totalCost,
            lastPrice = lastPrice,
            lastUpdate = System.currentTimeMillis()
        )
        repository.firebaseSync.pushInventoryItem(item)
    }
}
