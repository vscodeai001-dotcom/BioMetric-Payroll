package com.biometric.app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.chip.Chip
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.OrderWithItems
import com.biometric.app.databinding.ActivityPosReportBinding
import com.biometric.app.databinding.ItemPosBillDetailBinding
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.ReportsViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class PosReportActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityPosReportBinding
    private val mainViewModel: MainViewModel by viewModels()
    private val viewModel: ReportsViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel

    private var shopId: String? = null
    private var selectedCalendar: Calendar = Calendar.getInstance()

    enum class ReportPeriod { DAY, WEEK, MONTH, QUARTER, HALF_YEAR, ANNUAL }
    private var currentPeriod = ReportPeriod.MONTH

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPosReportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        shopId = intent.getStringExtra("SHOP_ID")
        val shopName = intent.getStringExtra("SHOP_NAME") ?: "POS Reports"

        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener { showShopSelectionDialog() }
        updateToolbarTitle(shopName)

        setupUI()
        observeViewModel()

        // Ensure default selection state
        updateChipUI(binding.chipMonth)
        onPeriodChanged(ReportPeriod.MONTH)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Bill List")
    }

    private fun setupUI() {
        binding.rvBillDetails.layoutManager = LinearLayoutManager(this)

        val periodChips = listOf(
            binding.chipDay to ReportPeriod.DAY,
            binding.chipWeek to ReportPeriod.WEEK,
            binding.chipMonth to ReportPeriod.MONTH,
            binding.chipQuarter to ReportPeriod.QUARTER,
            binding.chipHalfYear to ReportPeriod.HALF_YEAR,
            binding.chipYear to ReportPeriod.ANNUAL
        )

        periodChips.forEach { (chip, period) ->
            chip.setOnClickListener {
                // Clear other selections in UI
                periodChips.forEach { it.first.isChecked = false }
                chip.isChecked = true
                onPeriodChanged(period)
            }
        }

        binding.btnPreviousDate.setOnClickListener { adjustDate(-1) }
        binding.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.tvSelectedDate.setOnClickListener { showDatePicker() }

        binding.llTopSellingHeader.setOnClickListener {
            toggleVisibility(binding.tvTopSellingItems, binding.ivTopSellingArrow)
        }

        binding.llLowSellingHeader.setOnClickListener {
            toggleVisibility(binding.tvLowSellingItems, binding.ivLowSellingArrow)
        }
    }

    private fun updateChipUI(selectedChip: Chip) {
        val chips = listOf(
            binding.chipDay, binding.chipWeek, binding.chipMonth,
            binding.chipQuarter, binding.chipHalfYear, binding.chipYear
        )
        chips.forEach { it.isChecked = false }
        selectedChip.isChecked = true
    }

    private fun showDatePicker() {
        PickerHelper.showSmartPicker(this, "Day", selectedCalendar) { selectedCal ->
            selectedCalendar.timeInMillis = selectedCal.timeInMillis
            onPeriodChanged(currentPeriod) // Re-normalize and refresh
        }
    }

    private fun onPeriodChanged(period: ReportPeriod) {
        currentPeriod = period

        // Normalize selectedCalendar to the start of the selected period
        when (period) {
            ReportPeriod.DAY -> {
                // Stay on selected day
            }
            ReportPeriod.WEEK -> {
                selectedCalendar.set(Calendar.DAY_OF_WEEK, selectedCalendar.firstDayOfWeek)
            }
            ReportPeriod.MONTH -> {
                selectedCalendar.set(Calendar.DAY_OF_MONTH, 1)
            }
            ReportPeriod.QUARTER -> {
                val quarter = selectedCalendar.get(Calendar.MONTH) / 3
                selectedCalendar.set(Calendar.MONTH, quarter * 3)
                selectedCalendar.set(Calendar.DAY_OF_MONTH, 1)
            }
            ReportPeriod.HALF_YEAR -> {
                val half = if (selectedCalendar.get(Calendar.MONTH) < 6) 0 else 6
                selectedCalendar.set(Calendar.MONTH, half)
                selectedCalendar.set(Calendar.DAY_OF_MONTH, 1)
            }
            ReportPeriod.ANNUAL -> {
                selectedCalendar.set(Calendar.MONTH, 0)
                selectedCalendar.set(Calendar.DAY_OF_MONTH, 1)
            }
        }

        updateFilterText()
        refreshData()
    }

    private fun adjustDate(amount: Int) {
        when (currentPeriod) {
            ReportPeriod.DAY -> selectedCalendar.add(Calendar.DAY_OF_YEAR, amount)
            ReportPeriod.WEEK -> selectedCalendar.add(Calendar.WEEK_OF_YEAR, amount)
            ReportPeriod.MONTH -> selectedCalendar.add(Calendar.MONTH, amount)
            ReportPeriod.QUARTER -> selectedCalendar.add(Calendar.MONTH, amount * 3)
            ReportPeriod.HALF_YEAR -> selectedCalendar.add(Calendar.MONTH, amount * 6)
            ReportPeriod.ANNUAL -> selectedCalendar.add(Calendar.YEAR, amount)
        }
        updateFilterText()
        refreshData()
    }

    private fun toggleVisibility(view: View, arrow: View) {
        val isVisible = view.visibility == View.VISIBLE
        view.visibility = if (isVisible) View.GONE else View.VISIBLE
        arrow.rotation = if (isVisible) 270f else 90f
    }

    private fun updateFilterText() {
        val sdfMonth = SimpleDateFormat("MMMM yyyy", Locale.getDefault())
        val sdfDay = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        val year = selectedCalendar.get(Calendar.YEAR)

        val displayText = when (currentPeriod) {
            ReportPeriod.DAY -> sdfDay.format(selectedCalendar.time)
            ReportPeriod.WEEK -> {
                val weekStart = selectedCalendar.clone() as Calendar
                weekStart.set(Calendar.DAY_OF_WEEK, weekStart.firstDayOfWeek)
                val weekEnd = weekStart.clone() as Calendar
                weekEnd.add(Calendar.DAY_OF_WEEK, 6)
                "${sdfDay.format(weekStart.time)} - ${sdfDay.format(weekEnd.time)}"
            }
            ReportPeriod.MONTH -> sdfMonth.format(selectedCalendar.time)
            ReportPeriod.QUARTER -> {
                val quarter = (selectedCalendar.get(Calendar.MONTH) / 3) + 1
                "Quarter $quarter, $year"
            }
            ReportPeriod.HALF_YEAR -> {
                val half = (selectedCalendar.get(Calendar.MONTH) / 6) + 1
                "Half Year $half, $year"
            }
            ReportPeriod.ANNUAL -> "Year $year"
        }

        binding.tvSelectedDate.text = displayText
        binding.tvCurrentFilter.text = String.format(Locale.getDefault(), "Viewing: %s", displayText)
    }

    private fun refreshData() {
        val start = selectedCalendar.clone() as Calendar
        val end = selectedCalendar.clone() as Calendar

        when (currentPeriod) {
            ReportPeriod.DAY -> {
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.WEEK -> {
                start.set(Calendar.DAY_OF_WEEK, start.firstDayOfWeek)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.timeInMillis = start.timeInMillis
                end.add(Calendar.DAY_OF_WEEK, 6)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.MONTH -> {
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.QUARTER -> {
                val quarter = start.get(Calendar.MONTH) / 3
                start.set(Calendar.MONTH, quarter * 3)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, (quarter * 3) + 2)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.HALF_YEAR -> {
                val half = if (start.get(Calendar.MONTH) < 6) 0 else 6
                start.set(Calendar.MONTH, half)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, half + 5)
                end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
            ReportPeriod.ANNUAL -> {
                start.set(Calendar.MONTH, 0)
                start.set(Calendar.DAY_OF_MONTH, 1)
                start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
                end.set(Calendar.MONTH, 11)
                end.set(Calendar.DAY_OF_MONTH, 31)
                end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)
            }
        }

        shopId?.let {
            viewModel.loadPosReports(it, start.timeInMillis, end.timeInMillis)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            updateToolbarTitle(it.name)
                            refreshData()
                        }
                    }
                }

                launch {
                    viewModel.isLoading.collectLatest { loading ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        if (loading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.POS, lifecycleScope)
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                    }
                }

                launch {
                    viewModel.posBillReports.collect { billList ->
                        binding.rvBillDetails.adapter = BillDetailsAdapter(billList,
                            onEdit = { showEditBillDialog(it) },
                            onDelete = { showDeleteBillDialog(it) }
                        )
                    }
                }

                launch {
                    viewModel.posReportSummary.collect { summary ->
                        summary?.let {
                            binding.tvTotalSales.text = String.format(Locale.getDefault(), "₹ %.2f", it.totalSales)
                            binding.tvCashSales.text = String.format(Locale.getDefault(), "₹ %.2f", it.cashSales)
                            binding.tvQrSales.text = String.format(Locale.getDefault(), "₹ %.2f", it.qrSales)
                        }
                    }
                }

                launch {
                    viewModel.topSellingItems.collect { items ->
                        binding.tvTopSellingItems.text = items.joinToString("\n") { "- ${it.first}: ${it.second}" }
                    }
                }

                launch {
                    viewModel.lowSellingItems.collect { items ->
                        binding.tvLowSellingItems.text = items.joinToString("\n") { "- ${it.first}: ${it.second}" }
                    }
                }
            }
        }
    }

    private fun showShopSelectionDialog() {
        lifecycleScope.launch {
            // Use mainViewModel to get shops
            mainViewModel.allShops.collectLatest { shops ->
                if (shops.isEmpty()) return@collectLatest

                val shopNames = shops.map { it.name }.toTypedArray()
                MaterialAlertDialogBuilder(this@PosReportActivity)
                    .setTitle("Switch Shop")
                    .setItems(shopNames) { _, which ->
                        val selectedShop = shops[which]
                        sharedViewModel.setSelectedShop(selectedShop)
                    }
                    .show()
            }
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return when (item.itemId) {
            android.R.id.home -> {
                finish()
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun showEditBillDialog(orderWithItems: OrderWithItems) {
        val dialogView = LayoutInflater.from(this).inflate(R.layout.dialog_edit_bill_amount, null)
        val tvInfo = dialogView.findViewById<TextView>(R.id.tvBillInfo)
        val etAmount = dialogView.findViewById<EditText>(R.id.etPayableAmount)

        tvInfo.text = String.format(Locale.getDefault(), "Bill #%s - Current Total: ₹ %.2f",
            orderWithItems.order.orderId.takeLast(6), orderWithItems.order.payableAmount)
        etAmount.setText(String.format(Locale.getDefault(), "%.2f", orderWithItems.order.payableAmount))

        AlertDialog.Builder(this)
            .setTitle("Quick Edit Bill Amount")
            .setView(dialogView)
            .setPositiveButton("Update Amount") { _, _ ->
                val newAmount = etAmount.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                val updatedOrder = orderWithItems.order.copy(
                    totalAmount = newAmount,
                    payableAmount = newAmount,
                    lastModified = System.currentTimeMillis()
                )
                viewModel.updateOrderAndItems(updatedOrder, orderWithItems.items)
                Toast.makeText(this, "Bill updated", Toast.LENGTH_SHORT).show()
                refreshData()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showDeleteBillDialog(orderWithItems: OrderWithItems) {
        AlertDialog.Builder(this)
            .setTitle("Delete Bill?")
            .setMessage(String.format(Locale.getDefault(), "Are you sure you want to delete Bill #%s?", orderWithItems.order.orderId.takeLast(6)))
            .setPositiveButton("Delete") { _, _ ->
                viewModel.deleteOrder(orderWithItems.order)
                Toast.makeText(this, "Bill deleted", Toast.LENGTH_SHORT).show()
                refreshData()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    inner class BillDetailsAdapter(
        private val items: List<OrderWithItems>,
        private val onEdit: (OrderWithItems) -> Unit,
        private val onDelete: (OrderWithItems) -> Unit
    ) : RecyclerView.Adapter<BillDetailsAdapter.ViewHolder>() {

        inner class ViewHolder(val binding: ItemPosBillDetailBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder =
            ViewHolder(ItemPosBillDetailBinding.inflate(LayoutInflater.from(parent.context), parent, false))

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = items[position]
            val timeFormat = SimpleDateFormat("hh:mm a", Locale.getDefault())
            val closedAt = item.order.closedAt
            val timeStr = if (closedAt != null) timeFormat.format(Date(closedAt)) else "N/A"

            holder.binding.tvBillHeader.text = String.format(Locale.getDefault(), "Bill #%s - %s", item.order.orderId.takeLast(6), timeStr)

            val methodText = when(item.order.paymentMethod) {
                "SPLIT" -> String.format(Locale.getDefault(), "SPLIT (C:₹%.2f, Q:₹%.2f)", item.order.cashAmount, item.order.onlineAmount)
                "ONLINE" -> "QR/ONLINE"
                else -> item.order.paymentMethod ?: "N/A"
            }
            holder.binding.tvPaymentMethod.text = methodText

            val serviceText = if (item.order.serviceType == "TABLE") {
                String.format(Locale.getDefault(), "Table %s", item.order.tableId ?: "N/A")
            } else {
                item.order.serviceType
            }
            holder.binding.tvServiceType.text = serviceText
            
            val itemsSummary = item.items.joinToString(", ") { String.format(Locale.getDefault(), "%s x %d", it.itemName, it.quantity.toInt()) }
            holder.binding.tvItemsSummary.text = itemsSummary
            holder.binding.tvBillTotal.text = String.format(Locale.getDefault(), "Total: ₹ %.2f", item.order.payableAmount)

            holder.itemView.setOnClickListener {
                val fullDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                val closedTime = item.order.closedAt?.let { fullDateFormat.format(Date(it)) } ?: "N/A"
                val createdTime = fullDateFormat.format(Date(item.order.createdAt))
                
                MaterialAlertDialogBuilder(holder.itemView.context)
                    .setTitle("Bill Details 📋")
                    .setMessage("Bill ID: #${item.order.orderId.takeLast(6)}\n" +
                            "Logical Close Time: $closedTime\n" +
                            "**Actual Recorded Time: $createdTime**\n\n" +
                            "Total Amount: ₹${item.order.totalAmount}\n" +
                            "Items: ${item.items.joinToString { it.itemName }}")
                    .setPositiveButton("Edit Amount") { _, _ -> onEdit(item) }
                    .setNeutralButton("Delete") { _, _ -> onDelete(item) }
                    .setNegativeButton("Close", null)
                    .show()
            }
            holder.itemView.setOnLongClickListener {
                onDelete(item)
                true
            }
        }
        override fun getItemCount() = items.size
    }
}
