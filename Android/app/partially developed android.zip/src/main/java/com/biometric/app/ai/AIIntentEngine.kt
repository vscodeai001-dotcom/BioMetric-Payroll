package com.biometric.app.ai

object AIIntentEngine {

    fun detectIntent(query: String): AiIntent {
        val q = query.lowercase()
        return when {
            q.contains("sales") || q.contains("income") || q.contains("revenue") || q.contains("collection") -> {
                if (q.contains("trend") || q.contains("chart") || q.contains("graph")) AiIntent.TREND_ANALYSIS
                else if (q.contains("top") || q.contains("best")) AiIntent.TOP_PERFORMER
                else if (q.contains("low") || q.contains("worst")) AiIntent.LOW_PERFORMER
                else AiIntent.SALES_SUMMARY
            }
            q.contains("profit") || q.contains("earning") || q.contains("make") || q.contains("made") || q.contains("net") -> {
                if (q.contains("why") || q.contains("dropped") || q.contains("decrease") || q.contains("increase") || q.contains("low")) AiIntent.PROFIT_ANALYSIS
                else if (q.contains("prediction") || q.contains("forecast") || q.contains("future")) AiIntent.PREDICTION_QUERY
                else AiIntent.PROFIT_SUMMARY
            }
            q.contains("spend") || q.contains("expense") || q.contains("purchase") || q.contains("bought") || q.contains("cost") || q.contains("spending") -> AiIntent.PURCHASE_ANALYSIS
            q.contains("absent") || q.contains("present") || q.contains("attendance") || q.contains("staff") || q.contains("leave") || q.contains("worker") -> {
                if (q.contains("salary") || q.contains("pay") || q.contains("total") || q.contains("liability") || q.contains("spent") || q.contains("amt")) AiIntent.SALARY_QUERY
                else AiIntent.ATTENDANCE_QUERY
            }
            q.contains("salary") || q.contains("pay") -> AiIntent.SALARY_QUERY
            q.contains("stock") || q.contains("inventory") || q.contains("buy next") || q.contains("purchase next") || q.contains("what should i buy") -> AiIntent.STOCK_QUERY
            q.contains("investment") || q.contains("recover") || q.contains("capital") || q.contains("roi") -> AiIntent.INVESTMENT_QUERY
            q.contains("health") || q.contains("how is my business") || q.contains("business doing") || q.contains("status") -> AiIntent.HEALTH_QUERY
            q.contains("goal") || q.contains("target") -> AiIntent.GOAL_QUERY
            q.contains("compare") || q.contains("vs") -> {
                if (q.contains("shop") || q.contains("branch")) AiIntent.SHOP_COMPARISON
                else AiIntent.TIME_COMPARISON
            }
            q.contains("help") || q.contains("what can you do") -> AiIntent.HELP
            else -> AiIntent.GENERAL
        }
    }

    fun extractEntities(query: String): List<String> {
        val stopWords = setOf("how", "much", "did", "i", "on", "for", "the", "of", "is", "was", "show", "me", "find", "get", "what", "total", "any", "at", "were", "my", "tell", "please", "yesterday", "today", "last", "week", "month", "days", "ago", "profit", "sales", "expense", "amt", "amount")
        val entities = mutableListOf<String>()
        val words = query.lowercase().split(" ")
        for (word in words) {
            val clean = word.trim().removeSuffix("s")
            if (clean.length > 2 && clean !in stopWords && clean.toDoubleOrNull() == null) {
                entities.add(clean)
            }
        }
        return entities
    }
}
