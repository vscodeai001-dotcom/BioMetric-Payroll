package com.biometric.app.data.entity

import android.os.Build
import androidx.annotation.Keep
import com.google.firebase.database.PropertyName

enum class UserRole {
    SUPER_ADMIN, ADMIN, STAFF
}

@Keep
data class UserProfile(
    @get:PropertyName("uid") @set:PropertyName("uid")
    var uid: String = "",

    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",

    @get:PropertyName("email") @set:PropertyName("email")
    var email: String = "",

    @get:PropertyName("phone") @set:PropertyName("phone")
    var phone: String = "",

    @get:PropertyName("employeeId") @set:PropertyName("employeeId")
    var employeeId: String = "",

    @get:PropertyName("password") @set:PropertyName("password")
    var password: String = "",

    @get:PropertyName("role") @set:PropertyName("role")
    var role: String = UserRole.STAFF.name,

    @get:PropertyName("joinDate") @set:PropertyName("joinDate")
    var joinDate: Long = System.currentTimeMillis(),

    @get:PropertyName("deviceId") @set:PropertyName("deviceId")
    var deviceId: String? = null,

    @get:PropertyName("deviceModel") @set:PropertyName("deviceModel")
    var deviceModel: String? = null,

    @get:PropertyName("androidVersion") @set:PropertyName("androidVersion")
    var androidVersion: Int = Build.VERSION.SDK_INT,

    @get:PropertyName("registeredAt") @set:PropertyName("registeredAt")
    var registeredAt: Long? = null,

    @get:PropertyName("isPremium") @set:PropertyName("isPremium")
    var isPremium: Boolean = false,

    @get:PropertyName("subscriptionExpiry") @set:PropertyName("subscriptionExpiry")
    var subscriptionExpiry: Long? = null,

    @get:PropertyName("lastCheckTimestamp") @set:PropertyName("lastCheckTimestamp")
    var lastCheckTimestamp: Long = System.currentTimeMillis(),

    @get:PropertyName("enabledFeatures") @set:PropertyName("enabledFeatures")
    var enabledFeatures: List<String>? = null,

    @get:PropertyName("brandingName") @set:PropertyName("brandingName")
    var brandingName: String? = null,

    @get:PropertyName("brandingLogoUrl") @set:PropertyName("brandingLogoUrl")
    var brandingLogoUrl: String? = null,

    @get:PropertyName("dataLastModified") @set:PropertyName("dataLastModified")
    var dataLastModified: Long = System.currentTimeMillis()
) {
    fun isSuperAdmin() = role == UserRole.SUPER_ADMIN.name
    fun isAdmin() = role == UserRole.ADMIN.name
    fun isStaff() = role == UserRole.STAFF.name
    
    fun isOwner() = isSuperAdmin()

    companion object {
        const val ROLE_OWNER = "SUPER_ADMIN"
    }
}
