package com.biometric.app.ai

import com.biometric.app.data.MainRepository
import kotlinx.coroutines.flow.first
import java.util.*

class BusinessContextBuilder(private val repository: MainRepository) {

    suspend fun build(shopId: String?, start: Long, end: Long, periodLabel: String): BusinessDataBundle {
        val currentShopId = shopId ?: ""
        
        // 1. Metrics
        val metrics = repository.getShopMetricsFlow(currentShopId, start, end).first()
        
        // 2. Previous Period Metrics
        val prevRange = getPreviousPeriod(start, end)
        val previousMetrics = if (currentShopId.isNotEmpty()) {
            repository.getShopMetricsFlow(currentShopId, prevRange.first, prevRange.second).first()
        } else null
        
        // 3. Cashbook & Orders
        val entries = repository.getCashbookEntriesForPeriod(shopId, start, end).first()
        val orders = if (currentShopId.isNotEmpty()) {
            repository.getOrdersWithItemsForPeriod(currentShopId, start, end).first()
        } else emptyList()
        
        // 4. Top Items & Expenses
        val topItems = orders.asSequence().flatMap { it.items }
            .groupBy { it.itemName }
            .mapValues { it.value.sumOf { i -> i.quantity } }
            .toList()
            .sortedByDescending { it.second }
            .take(5)

        val topExpenses = entries.asSequence().filter { it.transactionType == "OUT" }
            .groupBy { it.category }
            .mapValues { it.value.sumOf { e -> e.amount } }
            .toList()
            .sortedByDescending { it.second }
            .take(5)

        // 5. Extra Context (Investments, Staff, Stock)
        val extraContext = mutableMapOf<String, Any>()
        if (currentShopId.isNotEmpty()) {
            extraContext["investments"] = repository.getInvestments(currentShopId).first()
            extraContext["inventory"] = repository.getInventoryItems(currentShopId).first()
            val employees = repository.getShopEmployees(currentShopId).first()
            extraContext["employees"] = employees
            
            // Fetch attendance for all employees in this period
            val allAttendance = mutableListOf<com.biometric.app.data.entity.Attendance>()
            employees.forEach { emp ->
                val records = repository.getAttendanceFlow(emp.employeeId, start, end).first()
                allAttendance.addAll(records)
            }
            extraContext["attendance"] = allAttendance
            
            // Fetch total salary liability
            extraContext["salary_liability"] = repository.calculateProjectedSalary(currentShopId, start, end)
        }

        return BusinessDataBundle(
            metrics = metrics,
            previousMetrics = previousMetrics,
            cashbookEntries = entries,
            orders = orders,
            topItems = topItems,
            topExpenses = topExpenses,
            periodLabel = periodLabel,
            previousPeriodLabel = getPeriodLabel(prevRange.first, prevRange.second),
            extraContext = extraContext,
        )
    }

    private fun getPreviousPeriod(start: Long, end: Long): Pair<Long, Long> {
        val diff = end - start
        val cal = Calendar.getInstance().apply { timeInMillis = start }
        
        return if ((diff > 25 * 24 * 60 * 60 * 1000L)) { // Month-ish
            cal.add(Calendar.MONTH, -1)
            val pStart = cal.timeInMillis
            cal[Calendar.DAY_OF_MONTH] = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
            pStart to cal.timeInMillis
        } else if ((diff > 6 * 24 * 60 * 60 * 1000L)) { // Week-ish
            cal.add(Calendar.WEEK_OF_YEAR, -1)
            val pStart = cal.timeInMillis
            cal.add(Calendar.DAY_OF_YEAR, 6)
            pStart to cal.timeInMillis
        } else {
            val pStart = start - diff - 86400000L
            pStart to (start - 86400000L)
        }
    }

    private fun getPeriodLabel(start: Long, end: Long): String {
        val diff = end - start
        return if (diff > 25 * 24 * 60 * 60 * 1000L) "Last Month"
        else if (diff > 6 * 24 * 60 * 60 * 1000L) "Last Week"
        else "Previous Period"
    }
}
