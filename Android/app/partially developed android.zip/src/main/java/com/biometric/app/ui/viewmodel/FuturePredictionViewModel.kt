package com.biometric.app.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.MainRepository
import com.biometric.app.data.RawMetrics
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.FinanceEngine
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class PeriodPrediction(
    val label: String,
    val dateRange: String,
    val sales: Double,
    val salary: Double,
    val fixed: Double,
    val expense: Double,
    val profit: Double,
    val isLive: Boolean,
    val isPartial: Boolean = false
)

data class FuturePredictionState(
    val title: String = "",
    val predictions: List<PeriodPrediction> = emptyList(),
    val totalEstimatedProfit: Double = 0.0,
    val isLoading: Boolean = true
)

@HiltViewModel
class FuturePredictionViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _params = MutableStateFlow<Triple<String, String, Long>?>(null)

    @OptIn(ExperimentalCoroutinesApi::class)
    val state: StateFlow<FuturePredictionState> = _params.filterNotNull().flatMapLatest { (shopId, period, date) ->
        val cacheKey = "future_prediction_${shopId}_${period}_$date"
        val cached = repository.getListCache<FuturePredictionState>(cacheKey).firstOrNull()
        
        flow {
            if (cached != null) {
                emit(cached.copy(isLoading = false))
            } else {
                emit(FuturePredictionState(isLoading = true))
            }
            
            val now = System.currentTimeMillis()
            val calendar = Calendar.getInstance().apply { timeInMillis = date }
            val year = calendar.get(Calendar.YEAR)
            val isUptoDate = period.lowercase() == "up to date"
            
            val itemPeriod = when {
                period.lowercase().contains("annual") || isUptoDate -> "Monthly"
                period.lowercase().contains("quarter") -> "Quarter"
                period.lowercase().contains("half") -> "Half Yearly"
                else -> period
            }

            val periods = generatePeriods(period, date)
            
            // Lookback for the very first period in the list to ensure continuity
            val startOfList = periods.first().second.first
            val pre1Range = getPreviousPeriod(itemPeriod, startOfList, -1)
            val pre2Range = getPreviousPeriod(itemPeriod, startOfList, -2)
            val pre3Range = getPreviousPeriod(itemPeriod, startOfList, -3)

            val lookbackFlows = listOf(
                repository.getShopMetricsFlow(shopId, pre1Range.first, pre1Range.second),
                repository.getShopMetricsFlow(shopId, pre2Range.first, pre2Range.second),
                repository.getShopMetricsFlow(shopId, pre3Range.first, pre3Range.second)
            )

            val periodFlows = periods.map { (label, range) ->
                repository.getShopMetricsFlow(shopId, range.first, range.second).map { metrics ->
                    Triple(label, range, metrics)
                }
            }

            combine(combine(lookbackFlows) { it.toList() }, combine(periodFlows) { it.toList() }) { lookbacks, mainData ->
                val p3 = lookbacks[2]; val p2 = lookbacks[1]; val p1 = lookbacks[0]
                
                val resultList = mutableListOf<PeriodPrediction>()
                var currentP3 = p3; var currentP2 = p2; var currentP1 = p1

                mainData.forEach { (label, range, metrics) ->
                    val (start, end) = range
                    val isFuture = start > now
                    val isCurrent = now in start..end
                    val isPast = end < now

                    val prediction: PeriodPrediction = when {
                        isPast -> {
                            PeriodPrediction(label, formatDateRange(start, end), metrics.sales, metrics.salary, metrics.fixed, metrics.expense, metrics.profit, isLive = true)
                        }
                        isCurrent -> {
                            if (isUptoDate) {
                                // Up To Date: Just live so far, no prediction added
                                val liveMetrics = repository.getShopMetricsFlow(shopId, start, now).first()
                                PeriodPrediction(label, formatDateRange(start, now), liveMetrics.sales, liveMetrics.salary, liveMetrics.fixed, liveMetrics.expense, liveMetrics.profit, isLive = true, isPartial = true)
                            } else {
                                // Hybrid: Live so far + Rolling average for rest
                                val liveMetrics = repository.getShopMetricsFlow(shopId, start, now).first()
                                val totalDays = ((end - start) / 86400000.0).coerceAtLeast(1.0)
                                val passedDays = ((now - start) / 86400000.0).coerceAtLeast(0.0)
                                val remainingRatio = ((totalDays - passedDays) / totalDays).coerceIn(0.0, 1.0)

                                val rolling = FinanceEngine.calculateRollingPast(currentP1, currentP2, currentP3)
                                PeriodPrediction(
                                    label, formatDateRange(start, end),
                                    liveMetrics.sales + (rolling.sales * remainingRatio),
                                    liveMetrics.salary + (rolling.salary * remainingRatio),
                                    liveMetrics.fixed + (rolling.fixed * remainingRatio),
                                    liveMetrics.expense + (rolling.expense * remainingRatio),
                                    liveMetrics.profit + (rolling.profit * remainingRatio),
                                    isLive = true, isPartial = true
                                )
                            }
                        }
                        else -> {
                            // Future
                            if (isUptoDate) null
                            else {
                                val rolling = FinanceEngine.calculateRollingPast(currentP1, currentP2, currentP3)
                                PeriodPrediction(label, formatDateRange(start, end), rolling.sales, rolling.salary, rolling.fixed, rolling.expense, rolling.profit, isLive = false)
                            }
                        }
                    } ?: return@forEach

                    resultList.add(prediction)
                    
                    // Update rolling pointers for NEXT iteration
                    val fullMetrics = RawMetrics(prediction.sales, prediction.salary, prediction.expense, prediction.fixed, prediction.profit)
                    currentP3 = currentP2; currentP2 = currentP1; currentP1 = fullMetrics
                }

                val totalLabel = when(period.lowercase()) {
                    "annual", "annually" -> "Estimated Annual Report ($year)"
                    "quarterly", "quarter" -> "Annual Projection (Quarter-wise)"
                    "up to date" -> "Year-to-Date Actuals ($year)"
                    else -> "Projection Timeline"
                }

                val result = FuturePredictionState(
                    title = totalLabel,
                    predictions = resultList,
                    totalEstimatedProfit = resultList.sumOf { it.profit },
                    isLoading = false
                )
                repository.saveListCache(cacheKey, listOf(result))
                result
            }.collect { emit(it) }
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), FuturePredictionState())

    fun load(shopId: String, period: String, date: Long) {
        _params.value = Triple(shopId, period, date)
    }

    private fun generatePeriods(period: String, baseDate: Long): List<Pair<String, Pair<Long, Long>>> {
        val list = mutableListOf<Pair<String, Pair<Long, Long>>>()
        val cal = Calendar.getInstance().apply { timeInMillis = baseDate }
        val year = cal.get(Calendar.YEAR)
        
        when (period.lowercase()) {
            "quarterly", "quarter" -> {
                for (q in 0..3) {
                    val qCal = Calendar.getInstance().apply { set(year, q * 3, 1) }
                    val range = DateRangeUtil.getRangeForPeriod("Quarterly", qCal.timeInMillis)
                    list.add("Quarter ${q + 1} (Q${q + 1})" to range)
                }
            }
            "half-yearly", "half yearly", "half year" -> {
                for (h in 0..1) {
                    val hCal = Calendar.getInstance().apply { set(year, h * 6, 1) }
                    val range = DateRangeUtil.getRangeForPeriod("Half Yearly", hCal.timeInMillis)
                    list.add("Half Year ${h + 1} (H${h + 1})" to range)
                }
            }
            "annual", "annually", "up to date" -> {
                for (m in 0..11) {
                    val mCal = Calendar.getInstance().apply { set(year, m, 1) }
                    val range = DateRangeUtil.getRangeForPeriod("Monthly", mCal.timeInMillis)
                    val monthName = SimpleDateFormat("MMMM", Locale.getDefault()).format(mCal.time)
                    list.add(monthName to range)
                }
            }
            "daily", "day" -> {
                // Show Prev, Selected, Next
                for (i in -1..1) {
                    val dCal = Calendar.getInstance().apply { timeInMillis = baseDate; add(Calendar.DAY_OF_YEAR, i) }
                    val range = DateRangeUtil.getRangeForPeriod("Daily", dCal.timeInMillis)
                    val label = when(i) {
                        -1 -> "Yesterday"
                        0 -> "Today"
                        1 -> "Tomorrow"
                        else -> SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(dCal.time)
                    }
                    list.add(label to range)
                }
            }
            "weekly", "week" -> {
                for (i in -1..1) {
                    val wCal = Calendar.getInstance().apply { timeInMillis = baseDate; add(Calendar.WEEK_OF_YEAR, i) }
                    val range = DateRangeUtil.getRangeForPeriod("Weekly", wCal.timeInMillis)
                    val label = when(i) {
                        -1 -> "Last Week"
                        0 -> "This Week"
                        1 -> "Next Week"
                        else -> "Week ${i}"
                    }
                    list.add(label to range)
                }
            }
            "monthly", "month" -> {
                for (i in -1..1) {
                    val mCal = Calendar.getInstance().apply { timeInMillis = baseDate; add(Calendar.MONTH, i) }
                    val range = DateRangeUtil.getRangeForPeriod("Monthly", mCal.timeInMillis)
                    val label = when(i) {
                        -1 -> "Last Month"
                        0 -> "This Month"
                        1 -> "Next Month"
                        else -> SimpleDateFormat("MMMM", Locale.getDefault()).format(mCal.time)
                    }
                    list.add(label to range)
                }
            }
        }
        return list
    }

    private fun getPreviousPeriod(period: String, fromDate: Long, offset: Int): Pair<Long, Long> {
        val cal = Calendar.getInstance().apply { timeInMillis = fromDate }
        DateRangeUtil.shiftPeriod(period, cal, offset)
        return DateRangeUtil.getRangeForPeriod(period, cal.timeInMillis)
    }

    private fun getRangeForPeriodInternal(period: String, date: Long): Pair<Long, Long> {
        return DateRangeUtil.getRangeForPeriod(period, date)
    }

    private fun formatDateRange(start: Long, end: Long): String {
        val sdf = SimpleDateFormat("MMM dd", Locale.getDefault())
        val sdfYear = SimpleDateFormat("yyyy", Locale.getDefault())
        return "${sdf.format(Date(start))} - ${sdf.format(Date(end))}, ${sdfYear.format(Date(end))}"
    }
}
