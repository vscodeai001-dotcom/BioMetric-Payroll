package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class Attendance(
    @get:PropertyName("attendanceId") @set:PropertyName("attendanceId")
    var attendanceId: String = "",
    
    @get:PropertyName("employeeId") @set:PropertyName("employeeId")
    var employeeId: String = "",
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("checkInTime") @set:PropertyName("checkInTime")
    var checkInTime: Long = 0,
    
    @get:PropertyName("checkOutTime") @set:PropertyName("checkOutTime")
    var checkOutTime: Long? = null,
    
    @get:PropertyName("type") @set:PropertyName("type")
    var type: String = "WORK", // WORK, GAP
    
    @get:PropertyName("hoursWorked") @set:PropertyName("hoursWorked")
    var hoursWorked: Double = 0.0,
    
    @get:PropertyName("shiftStart") @set:PropertyName("shiftStart")
    var shiftStart: String = "10:00",
    
    @get:PropertyName("shiftEnd") @set:PropertyName("shiftEnd")
    var shiftEnd: String = "22:00",

    @get:PropertyName("shift2Start") @set:PropertyName("shift2Start")
    var shift2Start: String? = null,

    @get:PropertyName("shift2End") @set:PropertyName("shift2End")
    var shift2End: String? = null,
    
    @get:PropertyName("breakHours") @set:PropertyName("breakHours")
    var breakHours: Double = 0.0,
    
    @get:PropertyName("salaryType") @set:PropertyName("salaryType")
    var salaryType: String = "MONTHLY_FIXED",
    
    @get:PropertyName("salaryRate") @set:PropertyName("salaryRate")
    var salaryRate: Double = 0.0,
    
    @get:PropertyName("note") @set:PropertyName("note")
    var note: String? = null,

    @get:PropertyName("synced") @set:PropertyName("synced")
    var synced: Boolean = false,

    @get:PropertyName("lateDeduction") @set:PropertyName("lateDeduction")
    var lateDeduction: Double = 0.0,

    @get:PropertyName("otHours") @set:PropertyName("otHours")
    var otHours: Double = 0.0,

    @get:PropertyName("createdAt") @set:PropertyName("createdAt")
    var createdAt: Long = System.currentTimeMillis()
) : Serializable
