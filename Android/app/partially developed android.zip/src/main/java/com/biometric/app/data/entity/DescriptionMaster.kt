package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.util.UUID

@Keep
data class DescriptionMaster(
    @get:PropertyName("id") @set:PropertyName("id")
    var id: String = UUID.randomUUID().toString(),

    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String? = null,
    
    @get:PropertyName("name") @set:PropertyName("name")
    var name: String = "",
    
    @get:PropertyName("category") @set:PropertyName("category")
    var category: String? = null,
    
    @get:PropertyName("lastUsed") @set:PropertyName("lastUsed")
    var lastUsed: Long = System.currentTimeMillis()
)
