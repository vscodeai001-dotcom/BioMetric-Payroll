package com.biometric.app.ui

import android.app.DatePickerDialog
import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.DialogFragment
import androidx.fragment.app.viewModels
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.data.entity.FixedExpense
import com.biometric.app.databinding.DialogFixedExpensesBinding
import com.biometric.app.databinding.DialogAddFixedExpenseBinding
import com.biometric.app.ui.adapter.FixedExpenseAdapter
import com.biometric.app.ui.viewmodel.FixedExpensesViewModel
import com.biometric.app.util.HapticUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import kotlin.time.Duration.Companion.milliseconds
import com.biometric.app.util.KeyboardUtil

@AndroidEntryPoint
class FixedExpensesDialogFragment : DialogFragment() {

    private val viewModel: FixedExpensesViewModel by viewModels()
    private lateinit var binding: DialogFixedExpensesBinding
    private lateinit var adapter: FixedExpenseAdapter
    private lateinit var shopId: String

    companion object {
        private const val ARG_SHOP_ID = "shop_id"

        fun newInstance(shopId: String): FixedExpensesDialogFragment {
            val args = Bundle().apply {
                putString(ARG_SHOP_ID, shopId)
            }
            return FixedExpensesDialogFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        shopId = arguments?.getString(ARG_SHOP_ID) ?: return
        viewModel.loadFixedExpenses(shopId)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        binding = DialogFixedExpensesBinding.inflate(layoutInflater)

        setupRecyclerView()
        observeViewModel()

        binding.btnAddExpense.setOnClickListener {
            showAddExpenseDialog(null)
        }

        return AlertDialog.Builder(requireContext())
            .setTitle("Fixed Monthly Expenses 💵")
            .setView(binding.root)
            .setPositiveButton("Close", null)
            .create()
    }

    private fun setupRecyclerView() {
        adapter = FixedExpenseAdapter(
            onEdit = { expense ->
                showAddExpenseDialog(expense)
            },
            onDelete = { expense ->
                showDeleteConfirmationDialog(expense)
            }
        )
        binding.rvFixedExpenses.adapter = adapter
        binding.rvFixedExpenses.layoutManager = LinearLayoutManager(context)
    }

    private fun showDeleteConfirmationDialog(expense: FixedExpense) {
        AlertDialog.Builder(requireContext())
            .setTitle("Delete Expense")
            .setMessage("Are you sure you want to delete this expense? This will archive the record.")
            .setPositiveButton("Delete") { _, _ ->
                val archivedExpense = expense.copy(isArchived = true)
                viewModel.addFixedExpense(archivedExpense)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            viewModel.fixedExpenses.collectLatest {
                adapter.submitList(it.filter { !it.isArchived })
            }
        }
    }

    private fun showAddExpenseDialog(expenseToEdit: FixedExpense? = null) {
        val dialogBinding = DialogAddFixedExpenseBinding.inflate(LayoutInflater.from(requireContext()))

        val selectedDate = Calendar.getInstance()
        expenseToEdit?.let { selectedDate.timeInMillis = it.effectiveFrom }

        val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
        dialogBinding.btnEffectiveDate.text = sdf.format(selectedDate.time)

        dialogBinding.btnEffectiveDate.setOnClickListener {
            DatePickerDialog(
                requireContext(),
                { _, year, month, day ->
                    selectedDate.set(year, month, day)
                    dialogBinding.btnEffectiveDate.text = sdf.format(selectedDate.time)
                },
                selectedDate.get(Calendar.YEAR),
                selectedDate.get(Calendar.MONTH),
                selectedDate.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        expenseToEdit?.let {
            dialogBinding.etExpenseName.setText(it.name)
            dialogBinding.etExpenseAmount.setText(it.monthlyAmount.toString())
        }

        // ATOMIC AUTO-FOCUS
        var autoFocusJob: kotlinx.coroutines.Job? = null
        dialogBinding.etExpenseName.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (dialogBinding.etExpenseName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        kotlinx.coroutines.delay(1500.milliseconds)
                        KeyboardUtil.showKeyboard(dialogBinding.etExpenseAmount)
                    }
                }
            }
        })

        AlertDialog.Builder(requireContext())
            .setTitle(if (expenseToEdit == null) "Add Fixed Expense 📝" else "Edit Fixed Expense 📝")
            .setView(dialogBinding.root)
            .setPositiveButton(if (expenseToEdit == null) "Add" else "Update") { _, _ ->
                val name = dialogBinding.etExpenseName.text.toString().trim()
                val amount = dialogBinding.etExpenseAmount.text.toString().toDoubleOrNull() ?: 0.0

                if (name.isNotEmpty() && amount > 0) {
                    HapticUtil.vibrateSuccess(dialogBinding.root)
                    if (expenseToEdit != null) {
                        // Archive the old expense
                        val archivedExpense = expenseToEdit.copy(isArchived = true)
                        viewModel.addFixedExpense(archivedExpense)
                        // Add the new version
                        val newExpense = FixedExpense(
                            id = UUID.randomUUID().toString(),
                            shopId = shopId,
                            name = name,
                            monthlyAmount = amount,
                            effectiveFrom = selectedDate.timeInMillis
                        )
                        viewModel.addFixedExpense(newExpense)
                    } else {
                        val newExpense = FixedExpense(
                            id = UUID.randomUUID().toString(),
                            shopId = shopId,
                            name = name,
                            monthlyAmount = amount,
                            effectiveFrom = selectedDate.timeInMillis
                        )
                        viewModel.addFixedExpense(newExpense)
                    }
                    KeyboardUtil.hideKeyboard(requireActivity())
                    dialogBinding.etExpenseName.clearFocus()
                    dialogBinding.etExpenseAmount.clearFocus()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}
