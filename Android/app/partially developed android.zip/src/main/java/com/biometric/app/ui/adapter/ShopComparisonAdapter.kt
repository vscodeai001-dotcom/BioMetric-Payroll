package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.R
import com.biometric.app.databinding.ItemShopComparisonCardBinding
import com.biometric.app.ui.viewmodel.ShopComparisonMetrics
import java.text.NumberFormat
import java.util.*

class ShopComparisonAdapter : ListAdapter<ShopComparisonMetrics, ShopComparisonAdapter.ViewHolder>(DiffCallback()) {

    private var topShopId: String? = null
    private var worstShopId: String? = null

    class ViewHolder(val binding: ItemShopComparisonCardBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemShopComparisonCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val metrics = getItem(position)
        val context = holder.itemView.context
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))

        val shopLocation = metrics.shop.name.split(",").lastOrNull()?.trim() ?: metrics.shop.name
        holder.binding.tvShopName.text = shopLocation
        holder.binding.tvSales.text = currencyFormat.format(metrics.totalSales)
        holder.binding.tvExpenses.text = currencyFormat.format(metrics.otherOutflow)
        holder.binding.tvProfit.text = currencyFormat.format(metrics.netProfit)
        
        // Restore Salary and Fixed Expenses binding
        holder.binding.tvSalary.text = currencyFormat.format(metrics.staffSalary)
        holder.binding.tvFixed.text = currencyFormat.format(metrics.fixedExpenses)
        
        // Daywise logic
        holder.binding.tvAvgSales.text = currencyFormat.format(metrics.avgSales)
        holder.binding.tvAvgExp.text = currencyFormat.format(metrics.avgExp)
        holder.binding.tvAvgDailyProfit.text = currencyFormat.format(metrics.avgDailyProfit)
        holder.binding.tvBestDay.text = metrics.bestDay
        holder.binding.tvSlowestDay.text = metrics.slowestDay
        holder.binding.tvPLDays.text = String.format(Locale.getDefault(), "%d / %d", metrics.profitableDays, metrics.lossDays)

        // Growth Badge
        val growth = metrics.growthPercentage
        holder.binding.tvGrowthBadge.text = String.format(Locale.getDefault(), "%s %.1f%%", if (growth >= 0) "📈 +" else "📉", growth)
        holder.binding.tvGrowthBadge.setTextColor(ContextCompat.getColor(context, if (growth >= 0) R.color.green else R.color.red))
        holder.binding.tvGrowthBadge.setBackgroundResource(if (growth >= 0) R.drawable.insight_bg else R.drawable.insight_bg_warn)

        // Highlights
        when (metrics.shop.shopId) {
            topShopId -> {
                holder.binding.tvPerformanceLabel.visibility = View.VISIBLE
                holder.binding.tvPerformanceLabel.text = "🏆 Top Performing Shop"
                holder.binding.tvPerformanceLabel.setTextColor(ContextCompat.getColor(context, R.color.amber))
            }
            worstShopId -> {
                holder.binding.tvPerformanceLabel.visibility = View.VISIBLE
                holder.binding.tvPerformanceLabel.text = "⚠️ Lowest Profit Shop"
                holder.binding.tvPerformanceLabel.setTextColor(ContextCompat.getColor(context, R.color.red))
            }
            else -> {
                holder.binding.tvPerformanceLabel.visibility = View.GONE
            }
        }
    }

    fun updateHighlights(topId: String?, worstId: String?) {
        val oldTop = topShopId
        val oldWorst = worstShopId
        topShopId = topId
        worstShopId = worstId

        // Notify only the items that changed
        currentList.forEachIndexed { index, metrics ->
            val id = metrics.shop.shopId
            if (id == topId || id == worstId || id == oldTop || id == oldWorst) {
                notifyItemChanged(index)
            }
        }
    }

    class DiffCallback : DiffUtil.ItemCallback<ShopComparisonMetrics>() {
        override fun areItemsTheSame(oldItem: ShopComparisonMetrics, newItem: ShopComparisonMetrics) = oldItem.shop.shopId == newItem.shop.shopId
        override fun areContentsTheSame(oldItem: ShopComparisonMetrics, newItem: ShopComparisonMetrics) = oldItem == newItem
    }
}
