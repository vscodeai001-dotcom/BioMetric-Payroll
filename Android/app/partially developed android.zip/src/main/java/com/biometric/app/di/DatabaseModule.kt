package com.biometric.app.di

import androidx.room.Room
import com.biometric.app.data.AppDatabase
import com.biometric.app.data.MainRepository
import com.biometric.app.data.dao.LocationDao
import com.biometric.app.sync.FirebaseSyncManager
import android.content.Context
import com.biometric.app.data.DataSafetyManager
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): AppDatabase {
        return Room.databaseBuilder(
            context,
            AppDatabase::class.java,
            "biometric_payroll.db"
        ).build()
    }

    @Provides
    fun provideLocationDao(database: AppDatabase): LocationDao {
        return database.locationDao()
    }

    @Provides
    @Singleton
    fun provideMainRepository(
        @ApplicationContext context: Context,
        firebaseSync: FirebaseSyncManager,
        dataSafety: DataSafetyManager
    ): MainRepository {
        return MainRepository(context, firebaseSync, dataSafety)
    }
}
