package com.biometric.app.util

import com.biometric.app.data.RawMetrics

/**
 * Unified Financial Engine for Biometric Payroll.
 * Handles Accurate Past calculations and AI-driven Predictions (50/30/20).
 */
object FinanceEngine {

    /**
     * 1. ACCURATE PAST (P):
     * Returns the actual value of the immediate previous period (P1).
     */
    fun calculateAccuratePast(p1: RawMetrics, p2: RawMetrics, p3: RawMetrics): RawMetrics {
        return p1
    }

    /**
     * 2. ROLLING PAST (RP - 50/30/20):
     * Returns the weighted average of the past 3 periods.
     * Formula: P1*0.5 + P2*0.3 + P3*0.2
     */
    fun calculateRollingPast(p1: RawMetrics, p2: RawMetrics, p3: RawMetrics): RawMetrics {
        return RawMetrics(
            sales = (p1.sales * 0.5) + (p2.sales * 0.3) + (p3.sales * 0.2),
            salary = (p1.salary * 0.5) + (p2.salary * 0.3) + (p3.salary * 0.2),
            expense = (p1.expense * 0.5) + (p2.expense * 0.3) + (p3.expense * 0.2),
            fixed = (p1.fixed * 0.5) + (p2.fixed * 0.3) + (p3.fixed * 0.2),
            profit = (p1.profit * 0.5) + (p2.profit * 0.3) + (p3.profit * 0.2),
        )
    }

    /**
     * 3. PREDICTION (E):
     * Returns the Weighted Rolling Prediction for the NEXT period.
     * Logic: P1*0.5 + P2*0.3 + P3*0.2
     */
    fun calculatePrediction(
        p1: RawMetrics, 
        p2: RawMetrics, 
        p3: RawMetrics
    ): RawMetrics {
        return calculateRollingPast(p1, p2, p3)
    }
    
    fun getFullForecast(
        current: RawMetrics,
        p1: RawMetrics,
        p2: RawMetrics,
        p3: RawMetrics
    ): ForecastResult {
        // P (Past) is the actual value of the immediate previous period (P1) matching the current date range.
        val p = calculateAccuratePast(p1, p2, p3)
        
        // RP (Rolling Past) is the weighted average of the past 3 periods.
        val rp = calculateRollingPast(p1, p2, p3)
        
        // E (Expected) is the projection based on the matching date range of the past 3 periods (50/30/20).
        // This ensures 'E' updates dynamically when arrows move (e.g., 1st-9th comparison).
        val e = calculatePrediction(p1, p2, p3)
        
        val growthTrend = if (p.sales > 0) ((current.sales - p.sales) / p.sales) * 100.0 else 0.0
        
        return ForecastResult(p, rp, e, growthTrend)
    }

    data class ForecastResult(
        val past: RawMetrics,
        val rolling: RawMetrics,
        val expected: RawMetrics,
        val growthTrend: Double
    )
}
