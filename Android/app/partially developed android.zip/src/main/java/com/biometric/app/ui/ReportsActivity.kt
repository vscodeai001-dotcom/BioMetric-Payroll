package com.biometric.app.ui

import android.app.DatePickerDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.*
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.github.mikephil.charting.formatter.PercentFormatter
import com.biometric.app.databinding.ActivityReportsBinding
import com.biometric.app.ui.viewmodel.*
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.PremiumLoader
import com.biometric.app.util.PickerHelper
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
@OptIn(kotlinx.coroutines.ExperimentalCoroutinesApi::class)
class ReportsActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityReportsBinding
    private val reportsViewModel: ReportsViewModel by viewModels()
    private val staffViewModel: StaffViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var repository: MainRepository
    
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var selectedDate: Calendar = Calendar.getInstance()
    private var shopId: String? = null
    private var currentFilter = "Up To Date"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityReportsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Fix Task bar overlap
        ViewCompat.setOnApplyWindowInsetsListener(binding.root) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom)
            insets
        }

        shopId = intent.getStringExtra("SHOP_ID") ?: return finish()
        val shopName = intent.getStringExtra("SHOP_NAME")
        
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            val shops = mainViewModel.allShops.value
            if (shops.isNotEmpty()) {
                val names = shops.map { it.name }.toTypedArray()
                MaterialAlertDialogBuilder(this)
                    .setTitle("Switch Shop")
                    .setItems(names) { _, which ->
                        sharedViewModel.setSelectedShop(shops[which])
                    }.show()
            }
        }
        
        updateToolbarTitle(shopName ?: "Reports")

        shopId?.let { staffViewModel.setShop(it) }
        binding.contentLayout.visibility = View.VISIBLE
        setupUI()
        observeViewModel()
    }

    private fun updateToolbarTitle(name: String) {
        setupDualHeader(binding.toolbar, name, "Reports Dashboard")
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshReport()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshReport()
            }
        }

        binding.btnManageFixedExpenses.setOnClickListener {
            val intent = Intent(this, FixedExpensesActivity::class.java)
            intent.putExtra("SHOP_ID", shopId)
            startActivity(intent)
        }

        binding.btnDayWiseReport.setOnClickListener {
            val intent = Intent(this, DayWiseReportActivity::class.java)
            intent.putExtra("SHOP_ID", shopId)
            startActivity(intent)
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshReport()
    }

    private fun refreshReport() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)

        lifecycleScope.launch {
            val start = selectedDate.clone() as Calendar
            val end = selectedDate.clone() as Calendar

            when (currentFilter) {
                "Daily" -> { }
                "Up To Date" -> {
                start[Calendar.DAY_OF_MONTH] = 1
                }
                "Weekly" -> {
                    start.set(Calendar.DAY_OF_WEEK, start.firstDayOfWeek)
                    end.set(Calendar.DAY_OF_WEEK, start.firstDayOfWeek + 6)
                }
                "Monthly" -> {
                start[Calendar.DAY_OF_MONTH] = 1
                    end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                }
                "Quarterly" -> {
                val quarter = (start[Calendar.MONTH] / 3)
                    start.set(Calendar.MONTH, quarter * 3)
                start[Calendar.DAY_OF_MONTH] = 1
                    end.set(Calendar.MONTH, (quarter * 3) + 2)
                    end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                }
                "Half Yearly" -> {
                    val half = if (start[Calendar.MONTH] < 6) 0 else 6
                    start.set(Calendar.MONTH, half)
                    start.set(Calendar.DAY_OF_MONTH, 1)
                    end.set(Calendar.MONTH, half + 5)
                    end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
                }
                "Annually" -> {
                    start.set(Calendar.DAY_OF_YEAR, 1)
                    end.set(Calendar.YEAR, start.get(Calendar.YEAR))
                    end.set(Calendar.MONTH, 11)
                    end.set(Calendar.DAY_OF_MONTH, 31)
                }
            }

            start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0); start.set(Calendar.MILLISECOND, 0)
            end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59); end.set(Calendar.MILLISECOND, 999)

            shopId?.let { reportsViewModel.loadReportsForPeriod(it, start.timeInMillis, end.timeInMillis) }
        }
    }

    private var currentProfit: Double = 0.0

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            shopId = it.shopId
                            updateToolbarTitle(it.name)
                            refreshReport()
                        }
                    }
                }
                launch {
                    staffViewModel.employeeStats.collectLatest {
                        refreshReport()
                    }
                }

                launch {
                    reportsViewModel.isLoading.collectLatest { loading ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = currentProfit == 0.0 && reportsViewModel.reportData.value.cashbookEntries.isEmpty()

                        if (loading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.REPORTS, lifecycleScope, immediate = true)
                            if (isDataZero) binding.scrollView.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.scrollView.visibility = View.VISIBLE
                        }
                    }
                }
                launch {
                    combine(
                        reportsViewModel.cashFlow,
                        reportsViewModel.totalSalary,
                        reportsViewModel.totalFixedExpenses,
                    ) { summary, salary, expenses ->
                        Triple(summary, salary, expenses)
                    }.collect { (summary, salary, expenses) ->
                        updateSummary(summary?.totalIn ?: 0.0, summary?.totalOut ?: 0.0, salary, expenses)
                    }
                }
                launch {
                    reportsViewModel.expenseAnalysis.collectLatest { analysis ->
                        analysis?.let { updateExpenseChart(it) }
                    }
                }
            }
        }
    }

    private fun updateExpenseChart(analysis: ExpenseAnalysis) {
        val entries = mutableListOf<PieEntry>()
        if (analysis.fixedExpenses > 0) entries.add(PieEntry(analysis.fixedExpenses.toFloat(), "Fixed"))
        if (analysis.salaryExpenses > 0) entries.add(PieEntry(analysis.salaryExpenses.toFloat(), "Salary"))
        if (analysis.variableExpenses > 0) entries.add(PieEntry(analysis.variableExpenses.toFloat(), "Variable"))

        if (entries.isEmpty()) {
            binding.cardExpenseAnalysis.visibility = android.view.View.GONE
            return
        }
        binding.cardExpenseAnalysis.visibility = android.view.View.VISIBLE

        val dataSet = PieDataSet(entries, "").apply {
            val colors = mutableListOf<Int>()
            colors.add(ContextCompat.getColor(this@ReportsActivity, R.color.blue))
            colors.add(ContextCompat.getColor(this@ReportsActivity, R.color.amber))
            colors.add(ContextCompat.getColor(this@ReportsActivity, R.color.red))
            setColors(colors)
            valueTextSize = 12f
            valueTextColor = android.graphics.Color.WHITE
            valueFormatter = PercentFormatter(binding.pieChartExpenses)
        }

        binding.pieChartExpenses.apply {
            data = PieData(dataSet)
            setUsePercentValues(true)
            description.isEnabled = false
            legend.isEnabled = true
            isDrawHoleEnabled = true
            setHoleColor(android.graphics.Color.TRANSPARENT)
            centerText = "Expenses"
            setCenterTextColor(ContextCompat.getColor(this@ReportsActivity, R.color.text_primary))
            animateY(1000)
            invalidate()
        }
    }

    private fun updateSummary(totalIn: Double, totalOut: Double, salary: Double, fixedExpenses: Double) {
        val profit = totalIn - totalOut - salary - fixedExpenses
        currentProfit = profit
        binding.tvTotalCashIn.text = String.format(Locale.getDefault(), "₹ %.2f", totalIn)
        binding.tvTotalCashOut.text = String.format(Locale.getDefault(), "₹ %.2f", totalOut)
        binding.tvTotalSalary.text = String.format(Locale.getDefault(), "₹ %.2f", salary)
        binding.tvFixedExpenses.text = String.format(Locale.getDefault(), "₹ %.2f", fixedExpenses)
        binding.tvFinalProfit.text = String.format(Locale.getDefault(), "₹ %.2f", profit)

        if (profit >= 0) {
            binding.tvFinalProfit.setTextColor(0xFFFFFFFF.toInt())
            binding.tvSummaryTitle.text = getString(R.string.net_profit_format, currentFilter.uppercase())
        } else {
            binding.tvFinalProfit.setTextColor(0xFFFCA5A5.toInt())
            binding.tvSummaryTitle.text = getString(R.string.net_loss_format, currentFilter.uppercase())
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, emptyList())) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}
