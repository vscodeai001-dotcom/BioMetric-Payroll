package com.biometric.app.ui.viewmodel

import com.biometric.app.data.entity.Shop

data class MetricData(
    val current: Double = 0.0,
    val rolling: Double = 0.0,
    val past: Double = 0.0,
    val expected: Double = 0.0
)

data class ShopWithProfit(
    val shop: Shop,
    val profit: MetricData = MetricData(),
    val sales: MetricData = MetricData(),
    val salary: MetricData = MetricData(),
    val expense: MetricData = MetricData(),
    val fixed: MetricData = MetricData()
) {
    // Legacy support for older code if needed
    val currentProfit: Double get() = profit.current
    val totalSales: Double get() = sales.current
    val totalSalary: Double get() = salary.current
    val totalExpense: Double get() = expense.current
    val fixedExpense: Double get() = fixed.current
}