package com.biometric.app.di

import com.biometric.app.ai.GeminiService
import com.biometric.app.ai.enterprise.EnterpriseNlrManager
import com.biometric.app.ai.enterprise.NativeIntelligenceEngine
import com.biometric.app.ai.enterprise.SqlExecutor
import com.biometric.app.ai.enterprise.SqlGenerator
import com.biometric.app.api.ApiService
import com.biometric.app.data.MainRepository
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import javax.inject.Singleton

@Module
@InstallIn(SingletonComponent::class)
object ApiModule {

    private const val GEMINI_API_KEY = "AIzaSyBptaB9GQdDhsWZ0u6dxnellgNJPhTK95Q"

    @Provides
    @Singleton
    fun provideApiService(): ApiService {
        return Retrofit.Builder()
            .baseUrl("https://your-api-endpoint.com/api/") // Placeholder
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    @Provides
    @Singleton
    fun provideGeminiService(): GeminiService {
        return GeminiService(GEMINI_API_KEY)
    }

    @Provides
    @Singleton
    fun provideSqlGenerator(): SqlGenerator {
        return SqlGenerator(GEMINI_API_KEY)
    }

    @Provides
    @Singleton
    fun provideSqlExecutor(): SqlExecutor {
        return SqlExecutor()
    }

    @Provides
    @Singleton
    fun provideEnterpriseNlrManager(
        repository: MainRepository,
        generator: SqlGenerator,
        executor: SqlExecutor
    ): EnterpriseNlrManager {
        return EnterpriseNlrManager(repository, generator, executor, NativeIntelligenceEngine(repository))
    }
}
