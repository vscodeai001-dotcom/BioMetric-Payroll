package com.biometric.app.ui

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import com.biometric.app.data.entity.UserRole
import android.os.Bundle
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.core.content.edit
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.work.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.common.api.ApiException
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.firebase.auth.FirebaseAuth
import com.razorpay.Checkout
import com.razorpay.PaymentResultListener
import com.biometric.app.R
import com.biometric.app.backup.BackupWorker
import com.biometric.app.backup.GoogleDriveManager
import com.biometric.app.data.MenuData
import com.biometric.app.data.entity.SalaryRules
import com.biometric.app.data.entity.Shop
import com.biometric.app.data.entity.UserProfile
import com.biometric.app.databinding.ActivityMainBinding
import com.biometric.app.databinding.DialogAddShopBinding
import com.bumptech.glide.Glide
import com.biometric.app.domain.BrandingManager
import com.biometric.app.domain.DataMigrationUseCase
import com.biometric.app.domain.FeatureManager
import com.biometric.app.sync.FirebaseSyncManager
import com.biometric.app.util.PremiumLoader
import com.biometric.app.ui.adapter.ShopAdapter
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.util.PickerHelper
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.viewmodel.ShopWithProfit
import com.biometric.app.util.DateRangeUtil
import android.view.ViewGroup
import androidx.recyclerview.widget.GridLayoutManager
import com.biometric.app.databinding.DialogCorrectionRequestBinding
import com.biometric.app.util.MotionManager
import com.biometric.app.utils.PremiumUI
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.delay
import com.biometric.app.domain.location.TrackingService
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.time.Duration.Companion.seconds
import java.io.File
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.TimeUnit
import kotlin.time.Duration.Companion.milliseconds
import javax.inject.Inject
import com.biometric.app.domain.GoogleDriveBackupUseCase as ManualBackupUseCase

@AndroidEntryPoint
@OptIn(ExperimentalCoroutinesApi::class)
class MainActivity : MotionBaseActivity(), PaymentResultListener {

    private var _binding: ActivityMainBinding? = null
    private val binding get() = _binding!!

    private val viewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var firebaseSyncManager: FirebaseSyncManager
    @Inject lateinit var migrationUseCase: DataMigrationUseCase
    @Inject lateinit var backupUseCase: ManualBackupUseCase
    @Inject lateinit var featureManager: FeatureManager

    @Inject lateinit var brandingManager: BrandingManager

    private lateinit var adapter: ShopAdapter
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var selectedDate: Calendar = Calendar.getInstance()


    private val driveManager by lazy { GoogleDriveManager(this) }

    private var isGlobalProfitVisible = false
    private var globalProfitValue: Double = 0.0
    private var hideGlobalProfitJob: kotlinx.coroutines.Job? = null
    private var tvLastSynced: android.widget.TextView? = null
    private var isPrivacyModeEnabled = true

    @Suppress("DEPRECATION")
    private val driveSignInLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val task = GoogleSignIn.getSignedInAccountFromIntent(result.data)
        try {
            task.getResult(ApiException::class.java)
            MaterialAlertDialogBuilder(this)
                .setTitle("Backup Configured ✅")
                .setMessage("Google Drive has been linked successfully. Your data will be backed up automatically every 24 hours.")
                .setPositiveButton("Awesome", null)
                .show()
            scheduleDailyBackup()
            checkForAutoRestore()
        } catch (e: ApiException) {
            val errorMsg = when (e.statusCode) {
                10 -> "Developer Error (10): Please ensure your SHA-1 fingerprint is registered in the Google Cloud Console."
                7 -> "Network Error: Please check your internet connection."
                else -> "Failed to link Google Drive: ${e.message}"
            }
            Toast.makeText(this, errorMsg, Toast.LENGTH_LONG).show()
        }
    }

    private val jsonPickerLauncher = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        uri?.let {
            try {
                contentResolver.openInputStream(it)?.bufferedReader()?.use { reader ->
                    val json = reader.readText()
                    lifecycleScope.launch {
                        val progressDialog = MaterialAlertDialogBuilder(this@MainActivity)
                            .setTitle("Restoring Data ⏳")
                            .setMessage("Importing manual backup... This may take a moment.")
                            .setCancelable(false)
                            .show()

                        val result = backupUseCase.restoreFromJson(json)
                        progressDialog.dismiss()
                        handleRestoreResult(result)
                    }
                }
            } catch (e: Exception) {
                Toast.makeText(this, "Error reading file: ${e.message}", Toast.LENGTH_SHORT).show()
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return

        val currentUser = FirebaseAuth.getInstance().currentUser
        if (currentUser == null) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        _binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // PERFORMANCE: If data is already ready (from warm-up), skip the loader entirely
        if (viewModel.isLoading.value) {
            PremiumLoader.show(binding.loadingLayout, PremiumLoader.ScreenType.GENERIC, lifecycleScope, immediate = true)
        } else {
            binding.loadingLayout.root.visibility = View.GONE
            binding.contentLayout.visibility = View.VISIBLE
            binding.contentLayout.alpha = 1f
        }

        setSupportActionBar(binding.toolbar)
        supportActionBar?.title = null
        val headers = setupDualHeader(binding.toolbar, "Workforce Hub 🏢", "Organization Dashboard")
        headers.btnShop?.visibility = View.GONE
        tvLastSynced = headers.status
        tvLastSynced?.visibility = View.VISIBLE

        setupListeners()
        setupSwipeRefresh()
        observeViewModel()

        setupMotionFeedback(
            binding.btnStaffPunch, binding.btnStaffCorrection,
            binding.btnManageStaff, binding.btnAttendanceLogs,
            binding.btnPayrollHub, binding.btnReportsHub,
            binding.btnLiveMap, binding.btnGeofenceManager,
            binding.btnShiftManager, binding.btnRouteReplay
        )

        binding.sectionAdminHub.alpha = 0f
        binding.sectionAdminHub.translationY = 50f
        binding.sectionAdminHub.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(800)
            .setInterpolator(android.view.animation.OvershootInterpolator())
            .start()

        viewModel.startRealtimeSync()
        applyRolePermissions()

        Checkout.preload(applicationContext)

        val sharedPrefs = getSharedPreferences("defaults", MODE_PRIVATE)
        // Skip teashop default items sync if not needed
        // viewModel.syncDefaultItems(MenuData.initialItems)

        if (!sharedPrefs.getBoolean("summaries_migrated", false)) {
            lifecycleScope.launch {
                try {
                    migrationUseCase.migrateToSummaries()
                    sharedPrefs.edit { putBoolean("summaries_migrated", true) }
                    Toast.makeText(this@MainActivity, "Data optimized for better performance.", Toast.LENGTH_SHORT).show()
                } catch (_: Exception) {
                    // Silently fail
                }
            }
        }

        if (driveManager.isUserSignedIn()) {
            scheduleDailyBackup()
            checkForAutoRestore()
        } else {
            // Check if we should prompt for cloud link to restore data
            checkIfCloudLinkNeeded()
        }
    }

    private fun checkIfCloudLinkNeeded() {
        val prefs = getSharedPreferences("backup_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("auto_restore_checked", false)) return

        lifecycleScope.launch {
            // Wait for shops to load (using value since it's a StateFlow)
            val shops = viewModel.allShops.value
            if (shops.isEmpty()) {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("Restore previous data?")
                    .setMessage("You have no shops registered. Would you like to link Google Drive to check for existing backups from your previous devices?")
                    .setPositiveButton("Link Drive") { _, _ ->
                        driveSignInLauncher.launch(driveManager.getSignInIntent())
                    }
                    .setNegativeButton("Start Fresh") { _, _ ->
                        prefs.edit { putBoolean("auto_restore_checked", true) }
                    }
                    .setCancelable(false)
                    .show()
            }
        }
    }

    private fun checkForAutoRestore() {
        val prefs = getSharedPreferences("backup_prefs", MODE_PRIVATE)
        if (prefs.getBoolean("auto_restore_checked", false)) return

        lifecycleScope.launch {
            try {
                val latestFile = driveManager.getLatestBackupFile()
                if (latestFile != null) {
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle("Restore last backup?")
                        .setMessage("We found a backup from ${latestFile.name} on your Google Drive. Would you like to restore your previous shop data?")
                        .setPositiveButton("Yes") { _, _ ->
                            performAutoRestore(latestFile.id)
                        }
                        .setNegativeButton("Skip") { _, _ ->
                            prefs.edit { putBoolean("auto_restore_checked", true) }
                        }
                        .setCancelable(false)
                        .show()
                } else {
                    val localFile = File(filesDir, "TeaShop_Latest_AutoBackup.json")
                    if (localFile.exists()) {
                        MaterialAlertDialogBuilder(this@MainActivity)
                            .setTitle("Restore last backup?")
                            .setMessage("We found a local backup. Would you like to restore your previous data?")
                            .setPositiveButton("Yes") { _, _ ->
                                lifecycleScope.launch {
                                    val result = backupUseCase.restoreFromJson(localFile.readText())
                                    if (result.isSuccess) {
                                        prefs.edit { putBoolean("auto_restore_checked", true) }
                                        viewModel.triggerRefresh()
                                        Toast.makeText(this@MainActivity, "Local restore successful", Toast.LENGTH_SHORT).show()
                                    }
                                }
                            }
                            .setNegativeButton("Skip") { _, _ ->
                                prefs.edit { putBoolean("auto_restore_checked", true) }
                            }
                            .show()
                    } else {
                        prefs.edit { putBoolean("auto_restore_checked", true) }
                    }
                }
            } catch (_: Exception) {
                // Ignore
            }
        }
    }

    private fun showBackupRestoreDialog() {
        val options = mutableListOf<RichMenuItem>()
        
        if (!driveManager.isUserSignedIn()) {
            options.add(RichMenuItem("🌐", "Link Google Drive", "Enable auto-backups & cloud sync", "LINK_DRIVE"))
            options.add(RichMenuItem("📥", "Restore Manual JSON", "Recover data from a file you saved", "RESTORE_LOCAL"))
        } else {
            options.add(RichMenuItem("🛡️", "Cloud Backup Settings", "Manage account & sync health", "STATUS"))
            options.add(RichMenuItem("⚡", "Fast Cloud Restore", "Fast recovery from your Google Drive", "RESTORE_CLOUD"))
            options.add(RichMenuItem("🔄", "Restore from Auto-Backup", "Recover from recent local cache", "RESTORE_AUTO"))
            options.add(RichMenuItem("📂", "Select Backup File", "Import from a specific backup file", "RESTORE_MANUAL"))
        }

        val adapter = object : android.widget.ArrayAdapter<RichMenuItem>(this, 0, options) {
            override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
                val itemBinding = if (convertView == null) {
                    com.biometric.app.databinding.ItemRichMenuBinding.inflate(LayoutInflater.from(context), parent, false)
                } else {
                    com.biometric.app.databinding.ItemRichMenuBinding.bind(convertView)
                }
                val item = getItem(position)!!
                itemBinding.tvMenuIcon.text = item.icon
                itemBinding.tvMenuTitle.text = item.title
                itemBinding.tvMenuSubtitle.text = item.subtitle
                return itemBinding.root
            }
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Backup & Restore 🏰")
            .setAdapter(adapter) { _, which ->
                when (options[which].action) {
                    "LINK_DRIVE" -> driveSignInLauncher.launch(driveManager.getSignInIntent())
                    "STATUS" -> showCloudStatusDialog()
                    "RESTORE_CLOUD" -> lifecycleScope.launch { driveManager.getLatestBackupFile()?.let { performAutoRestore(it.id) } }
                    "RESTORE_AUTO" -> {
                        val localFile = File(filesDir, "TeaShop_Latest_AutoBackup.json")
                        if (localFile.exists()) restoreFromFile(localFile)
                        else Toast.makeText(this, "No local auto-backup found", Toast.LENGTH_SHORT).show()
                    }
                    "RESTORE_MANUAL", "RESTORE_LOCAL" -> jsonPickerLauncher.launch("application/json")
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private data class RichMenuItem(val icon: String, val title: String, val subtitle: String, val action: String)

    private fun showCloudStatusDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Backup Status ✅")
            .setMessage("Your Daily Cloud Backup is ACTIVE.\n\nData is safely exported to your Google Drive every 24 hours. This allows you to recover your business data if you lose your phone.")
            .setPositiveButton("Close", null)
            .setNeutralButton("Switch Account") { _, _ -> driveSignInLauncher.launch(driveManager.getSignInIntent()) }
            .show()
    }

    private fun restoreFromFile(file: File) {
        lifecycleScope.launch {
            val progressDialog = MaterialAlertDialogBuilder(this@MainActivity)
                .setTitle("Restoring Data")
                .setMessage("Processing backup file... Please wait.")
                .setCancelable(false)
                .show()
            val result = backupUseCase.restoreFromJson(file.readText())
            progressDialog.dismiss()
            handleRestoreResult(result)
        }
    }

    private fun handleRestoreResult(result: Result<String>) {
        if (result.isSuccess) {
            MaterialAlertDialogBuilder(this)
                .setTitle("Restore Successful! ✨")
                .setMessage(result.getOrNull() ?: "Your data has been recovered and synchronized.")
                .setPositiveButton("Awesome", null)
                .show()
            sharedViewModel.clearShopData()
            viewModel.triggerRefresh()
            getSharedPreferences("backup_prefs", MODE_PRIVATE).edit { putBoolean("auto_restore_checked", true) }
        } else {
            MaterialAlertDialogBuilder(this)
                .setTitle("Restore Failed ❌")
                .setMessage("Error: ${result.exceptionOrNull()?.message}\n\nPlease ensure you are using a valid TeaShop backup file.")
                .setPositiveButton("OK", null)
                .show()
        }
    }

    private fun performAutoRestore(fileId: String) {
        lifecycleScope.launch {
            val tempFile = File(cacheDir, "temp_restore.json")
            val success = driveManager.downloadFile(fileId, tempFile)

            if (success) {
                val json = tempFile.readText()
                val result = backupUseCase.restoreFromJson(json)
                if (result.isSuccess) {
                    getSharedPreferences("backup_prefs", MODE_PRIVATE).edit {
                        putBoolean("auto_restore_checked", true)
                    }
                    MaterialAlertDialogBuilder(this@MainActivity)
                        .setTitle("Restore Complete")
                        .setMessage("Your data has been restored successfully.")
                        .setPositiveButton("OK") { _, _ -> viewModel.triggerRefresh() }
                        .show()
                } else {
                    Toast.makeText(this@MainActivity, "Restore failed: ${result.exceptionOrNull()?.message}", Toast.LENGTH_LONG).show()
                }
            } else {
                Toast.makeText(this@MainActivity, "Failed to download backup file.", Toast.LENGTH_SHORT).show()
            }
            tempFile.delete()
        }
    }

    private fun scheduleDailyBackup() {
        val backupRequest = PeriodicWorkRequestBuilder<BackupWorker>(24, TimeUnit.HOURS)
            .setConstraints(Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build())
            .addTag("daily_backup")
            .build()

        WorkManager.getInstance(this).enqueueUniquePeriodicWork(
            "daily_backup",
            ExistingPeriodicWorkPolicy.KEEP,
            backupRequest,
        )
    }

    override fun onResume() {
        super.onResume()
        loadPrivacySettings()
        
        // Optimize: Silent refresh on resume to prevent UI stutter/lag.
        // The ViewModel will already trigger a recalculation if the filter period changes.
        if (viewModel.currentPeriod.value != "Up To Date") {
            viewModel.setFilter("Up To Date", System.currentTimeMillis())
        }
        viewModel.triggerRefresh()
    }

    override fun onPause() {
        super.onPause()
    }

    private fun loadPrivacySettings() {
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        isPrivacyModeEnabled = prefs.getBoolean("mask_profits", true)
        
        if (!isPrivacyModeEnabled) {
            isGlobalProfitVisible = true
            binding.btnGlobalProfitPrivacy.visibility = View.GONE
        } else {
            // If just enabled privacy mode, hide it again
            // But if it was already visible from a previous click, we don't necessarily want to hide it immediately?
            // Actually, the user wants it dynamic. If they turn ON masking, we should hide it.
            // If they turn OFF masking, we should show it.
            if (!isGlobalProfitVisible) {
                binding.btnGlobalProfitPrivacy.visibility = View.VISIBLE
                binding.btnGlobalProfitPrivacy.alpha = 0.5f
            }
        }
        
        if (::adapter.isInitialized) {
            adapter.setPrivacyMode(isPrivacyModeEnabled)
        }
        updateGlobalProfitUI()
    }

    private fun setupRecyclerView() {
        adapter = ShopAdapter(
            featureManager = featureManager,
            onShopClick = { shop ->
                sharedViewModel.setSelectedShop(shop)
                val intent = Intent(this, ShopDashboardActivity::class.java).apply {
                    putExtra("SHOP_ID", shop.shopId)
                    putExtra("SHOP_NAME", shop.name)
                    putExtra("TABLE_COUNT", shop.tableCount)
                }
                startActivity(intent)
            },
            onEditClick = { shop ->
                showAddShopDialog(shop)
            },
            onDeleteClick = { shop ->
                showDeleteShopDialog(shop)
            },
            onSalesClick = { shop ->
                sharedViewModel.setSelectedShop(shop)
                val intent = Intent(this, FinanceEntryActivity::class.java).apply {
                    putExtra("SHOP_ID", shop.shopId)
                    putExtra("SHOP_NAME", shop.name)
                    putExtra("DEFAULT_TYPE", "IN")
                }
                startActivity(intent)
            },
            onSalaryClick = { shop ->
                sharedViewModel.setSelectedShop(shop)
                val intent = Intent(this, StaffActivity::class.java).apply {
                    putExtra("SHOP_ID", shop.shopId)
                    putExtra("SHOP_NAME", shop.name)
                }
                startActivity(intent)
            },
            onPurchasesClick = { shop ->
                sharedViewModel.setSelectedShop(shop)
                val intent = Intent(this, InventoryActivity::class.java).apply {
                    putExtra("SHOP_ID", shop.shopId)
                    putExtra("SHOP_NAME", shop.name)
                }
                startActivity(intent)
            },
        ) { shop ->
            sharedViewModel.setSelectedShop(shop)
            val intent = Intent(this, FixedExpensesActivity::class.java).apply {
                putExtra("SHOP_ID", shop.shopId)
                putExtra("SHOP_NAME", shop.name)
            }
            startActivity(intent)
        }

        binding.rvShops.layoutManager = LinearLayoutManager(this)
        binding.rvShops.adapter = adapter
    }

    private fun showDeleteShopDialog(shop: Shop) {
        val securityInput = android.widget.EditText(this).apply {
            hint = "Type 'DELETE' to confirm"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS
            gravity = android.view.Gravity.CENTER
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("🚨 Delete Shop?")
            .setMessage("Are you absolutely sure you want to delete '${shop.name}'?\n\nThis action CANNOT be undone. All sales, expenses, and staff records for this shop will be permanently erased.")
            .setView(securityInput)
            .setPositiveButton("PERMANENTLY DELETE") { _, _ ->
                val input = securityInput.text.toString().trim()
                if (input == "DELETE") {
                    viewModel.deleteShop(shop)
                    PremiumUI.showSuccess(this, "Shop Erased", "${shop.name} has been removed.")
                } else {
                    Toast.makeText(this, "Incorrect confirmation text. Deletion cancelled.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun setupSwipeRefresh() {
        binding.swipeRefresh.setOnRefreshListener {
            viewModel.triggerRefresh()
        }

        binding.swipeRefresh.setColorSchemeColors(
            ContextCompat.getColor(this, R.color.colorPrimary),
            ContextCompat.getColor(this, R.color.green_700)
        )
    }

    private fun setupListeners() {
        binding.btnStaffPunch.setOnClickListener {
            val intent = Intent(this, PunchActivity::class.java)
            startActivity(intent)
        }

        binding.btnStaffCorrection.setOnClickListener {
            showCorrectionDialog()
        }

        binding.btnManageStaff.setOnClickListener {
            val intent = Intent(this, StaffActivity::class.java)
            // If we have a selected shop, pass it, otherwise the activity should handle all staff
            sharedViewModel.selectedShop.value?.let { shop ->
                intent.putExtra("SHOP_ID", shop.shopId)
                intent.putExtra("SHOP_NAME", shop.name)
            }
            startActivity(intent)
        }

        binding.btnAttendanceLogs.setOnClickListener {
            val intent = Intent(this, StaffAttendanceActivity::class.java)
            sharedViewModel.selectedShop.value?.let { shop ->
                intent.putExtra("SHOP_ID", shop.shopId)
                intent.putExtra("SHOP_NAME", shop.name)
            }
            startActivity(intent)
        }

        binding.btnPayrollHub.setOnClickListener {
            val intent = Intent(this, PayrollManagementActivity::class.java)
            startActivity(intent)
        }

        binding.btnReportsHub.setOnClickListener {
            val intent = Intent(this, DetailedReportActivity::class.java).apply {
                putExtra("IS_GLOBAL", true)
            }
            startActivity(intent)
        }

        binding.btnLiveMap.setOnClickListener {
            startActivity(Intent(this, TrackingMapActivity::class.java))
        }

        binding.btnGeofenceManager.setOnClickListener {
            startActivity(Intent(this, GeofenceManagerActivity::class.java))
        }

        binding.btnShiftManager.setOnClickListener {
            startActivity(Intent(this, ShiftManagerActivity::class.java))
        }

        binding.btnRouteReplay.setOnClickListener {
            startActivity(Intent(this, RouteReplayActivity::class.java))
        }

        binding.btnDeviceDashboard.setOnClickListener {
            startActivity(Intent(this, DeviceDashboardActivity::class.java))
        }

        binding.btnPayrollManagement.setOnClickListener {
            startActivity(Intent(this, PayrollManagementActivity::class.java))
        }

        filterAdapter = HorizontalFilterAdapter(showCustom = true) { selected: String ->
            if (selected == "Custom") {
                showDateRangePicker()
            } else {
                viewModel.setFilter(selected, selectedDate.timeInMillis)
            }
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = GridLayoutManager(this, 8)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            val period = viewModel.currentPeriod.value
            if (period.equals("Custom", ignoreCase = true)) {
                showDateRangePicker()
            } else {
                PickerHelper.showSmartPicker(
                    this, 
                    period, 
                    selectedDate
                ) { newDate ->
                    viewModel.setFilter(period, newDate.timeInMillis)
                }
            }
        }
    }

    private fun updateGlobalProfitUI() {
        if (!isPrivacyModeEnabled || isGlobalProfitVisible) {
            val currentText = binding.tvGlobalTotal.text.toString().replace("₹", "").trim().toDoubleOrNull() ?: 0.0
            MotionManager.animateValue(binding.tvGlobalTotal, currentText, globalProfitValue, "₹ ")
            binding.btnGlobalProfitPrivacy.alpha = 1.0f
            if (!isPrivacyModeEnabled) {
                binding.btnGlobalProfitPrivacy.visibility = View.GONE
            } else {
                binding.btnGlobalProfitPrivacy.visibility = View.VISIBLE
            }
        } else {
            binding.tvGlobalTotal.text = getString(R.string.privacy_mask)
            binding.btnGlobalProfitPrivacy.alpha = 0.5f
            binding.btnGlobalProfitPrivacy.visibility = View.VISIBLE
        }
    }


    private fun adjustDate(amount: Int) {
        val currentPeriod = viewModel.currentPeriod.value
        if (currentPeriod == "Custom") return
        DateRangeUtil.adjustDate(currentPeriod, selectedDate, amount)
        viewModel.setFilter(currentPeriod, selectedDate.timeInMillis)
    }

    private fun showDateRangePicker() {
        val picker = com.google.android.material.datepicker.MaterialDatePicker.Builder.dateRangePicker()
            .setTitleText("Select Custom Range")
            .build()
        
        picker.addOnPositiveButtonClickListener { range ->
            val start = range.first ?: System.currentTimeMillis()
            val end = range.second ?: System.currentTimeMillis()
            viewModel.setFilter("Custom", start, end)
        }
        picker.show(supportFragmentManager, "date_range_picker")
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                // Workforce stats update
                launch {
                    combine(sharedViewModel.currentShopEmployees, sharedViewModel.allShops) { employees, shops ->
                        employees.size
                    }.collectLatest { count ->
                        binding.tvTotalStaffCount.text = "$count Active Staff Members"
                    }
                }
                
                // Tracking Status Update
                launch {
                    while (true) {
                        val isRunning = isServiceRunning(TrackingService::class.java)
                        binding.tvTrackingStatus.text = if (isRunning) "Tracking: ACTIVE ●" else "Tracking: OFF ○"
                        binding.tvTrackingStatus.setTextColor(ContextCompat.getColor(this@MainActivity, if (isRunning) R.color.green_light else R.color.red))
                        delay(5.seconds)
                    }
                }
                
                launch {
                    sharedViewModel.userProfile.collectLatest { profile ->
                        profile?.let {
                            // Update FeatureManager with user-level permissions
                            if (it.enabledFeatures != null) {
                                val enabledEnums = FeatureManager.Feature.entries.asSequence().filter { f -> f.name in it.enabledFeatures!! }.toSet()
                                featureManager.setFeatures(enabledEnums)
                            }
                            
                            // Update BrandingManager
                            brandingManager.updateBranding(
                                BrandingManager.BrandingConfig(
                                    appName = it.brandingName ?: "TeaShop POS",
                                    logoUrl = it.brandingLogoUrl
                                )
                            )
                            
                            // Apply branding to UI
                            supportActionBar?.title = brandingManager.brandingConfig.value.appName
                            
                            it.brandingLogoUrl?.let { url ->
                                binding.ivAppLogo.visibility = View.VISIBLE
                                Glide.with(this@MainActivity).load(url).into(binding.ivAppLogo)
                            } ?: run {
                                binding.ivAppLogo.visibility = View.GONE
                            }

                            val isStaff = it.isStaff()
                            val shops = viewModel.allShops.value
                            val hasShops = shops.isNotEmpty() || viewModel.hasCachedShops.value

                            if (isStaff) {
                                binding.sectionStaff.visibility = View.VISIBLE
                                binding.btnAddShop.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.STAFF)) View.VISIBLE else View.GONE
                                binding.cardGlobalInsights.visibility = View.GONE
                                binding.btnComparison.visibility = View.GONE
                                binding.layoutFilterIcons.root.visibility = View.GONE
                                binding.sectionAdmin.visibility = View.GONE
                                binding.sectionTracking.visibility = View.VISIBLE
                                
                                // Specific Staff UI updates
                                lifecycleScope.launch {
                                    sharedViewModel.currentEmployee.collectLatest { emp ->
                                        emp?.let { e ->
                                            binding.tvStaffShift.text = "Shift: ${e.shiftStart} - ${e.shiftEnd}"
                                            supportActionBar?.title = "Welcome, ${e.name}"
                                        }
                                    }
                                }
                            } else {
                                // SuperAdmin/Owner full access
                                binding.btnAddShop.visibility = View.VISIBLE
                                binding.cardGlobalInsights.visibility = if (hasShops) View.VISIBLE else View.GONE
                                binding.btnComparison.visibility = if (hasShops) View.VISIBLE else View.GONE
                                binding.layoutFilterIcons.root.visibility = if (hasShops) View.VISIBLE else View.GONE
                            }
                        }
                    }
                }
                launch {
                    viewModel.isSubscribed.collectLatest { subscribed ->
                        if (!subscribed) showSubscriptionLock()
                    }
                }
                launch {
                    combine(
                        viewModel.isLoading,
                        viewModel.shopsWithProfit,
                        viewModel.globalProfit
                    ) { loading, _, _ ->
                        loading
                    }.collectLatest { loading ->
                        val isSwipeActive = binding.swipeRefresh.isRefreshing && binding.contentLayout.isVisible
                        
                        // ABSOLUTE LOADING LOGIC: We only show the loader if we have NO data to display.
                        // If we have cached/previous shops, we show them while calculating in background.
                        val allShops = viewModel.allShops.value
                        val shopsWithProfitValue = viewModel.shopsWithProfit.value
                        
                        val shouldShowLoader = loading && shopsWithProfitValue.isEmpty()

                        if (shouldShowLoader && !isSwipeActive) {
                            PremiumLoader.show(binding.loadingLayout, PremiumLoader.ScreenType.GENERIC, lifecycleScope, immediate = true)
                            binding.contentLayout.visibility = View.GONE
                        } else {
                            // ATOMIC CONTENT SHOW:
                            if ((binding.contentLayout.visibility != View.VISIBLE) || (binding.contentLayout.alpha < 1f)) {
                                binding.contentLayout.visibility = View.VISIBLE
                                binding.contentLayout.alpha = 1f
                                if (!loading) {
                                    animateContentEntry(binding.contentLayout)
                                    binding.swipeRefresh.isRefreshing = false
                                }
                                PremiumLoader.hide(binding.loadingLayout)
                            } else {
                                if (loading) {
                                    // If loading but we have data, show a non-obstructive overlay if it takes long
                                    PremiumLoader.show(binding.loadingLayout, PremiumLoader.ScreenType.GENERIC, lifecycleScope)
                                } else {
                                    PremiumLoader.hide(binding.loadingLayout)
                                    binding.swipeRefresh.isRefreshing = false
                                }
                            }
                        }

                        val hasCachedShops = viewModel.hasCachedShops.value
                        if (!loading || allShops.isNotEmpty() || hasCachedShops) {
                            if (allShops.isEmpty() && !hasCachedShops) {
                                binding.rvShops.visibility = View.GONE
                                binding.layoutEmptyShops.visibility = View.VISIBLE
                            } else {
                                binding.rvShops.visibility = View.VISIBLE
                                binding.layoutEmptyShops.visibility = View.GONE
                                adapter.submitList(shopsWithProfitValue)
                            }
                        }
                    }
                }
                launch {
                    viewModel.shopsWithProfit.collect { shopsWithProfit: List<ShopWithProfit> ->
                        val allShops = viewModel.allShops.value
                        if (!viewModel.isLoading.value) {
                            if (allShops.isEmpty()) {
                                binding.rvShops.visibility = View.GONE
                                binding.layoutEmptyShops.visibility = View.VISIBLE
                            } else {
                                binding.rvShops.visibility = View.VISIBLE
                                binding.layoutEmptyShops.visibility = View.GONE
                                adapter.submitList(shopsWithProfit)
                            }
                        } else {
                            if (allShops.isNotEmpty()) {
                                adapter.submitList(shopsWithProfit)
                            }
                        }
                    }
                }
                launch {
                    viewModel.globalProfit.collect { total ->
                        globalProfitValue = total
                        updateGlobalProfitUI()
                    }
                }
                launch {
                    combine(
                        viewModel.globalPastProfit,
                        viewModel.globalPredictedProfit
                    ) { past, expected ->
                        past to expected
                    }.collect { (past, expected) ->
                        binding.tvGlobalPast.text = String.format(Locale.getDefault(), "Past: ₹%.0f", past)
                        binding.tvGlobalPredicted.text = String.format(Locale.getDefault(), "Exp: ₹%.0f", expected)
                    }
                }
                launch {
                    viewModel.currentPeriod.collectLatest { period ->
                        updateFilterButtonText(period, viewModel.currentDate.value, viewModel.customEndDate.value)
                    }
                }
                launch {
                    viewModel.currentDate.collectLatest { timestamp ->
                        updateFilterButtonText(viewModel.currentPeriod.value, timestamp, viewModel.customEndDate.value)
                    }
                }
                launch {
                    viewModel.customEndDate.collectLatest { endDate ->
                        updateFilterButtonText(viewModel.currentPeriod.value, viewModel.currentDate.value, endDate)
                    }
                }
                launch {
                    firebaseSyncManager.syncStatus.collectLatest { connected ->
                        tvLastSynced?.setTextColor(
                            ContextCompat.getColor(this@MainActivity, if (connected) R.color.green else R.color.red)
                        )
                    }
                }
                launch {
                    firebaseSyncManager.lastSyncTime.collectLatest { timestamp ->
                        val now = System.currentTimeMillis()
                        val diff = now - timestamp
                        val text = when {
                            diff < 10000 -> "Syncing..."
                            diff < 60000 -> "Synced just now"
                            diff < 3600000 -> "Synced ${diff / 60000}m ago"
                            else -> {
                                val sdf = SimpleDateFormat("hh:mm a", Locale.getDefault())
                                "Last synced: ${sdf.format(Date(timestamp))}"
                            }
                        }
                        tvLastSynced?.text = getString(R.string.sync_bullet_format, text)
                    }
                }
            }
        }
    }

    private fun updateFilterButtonText(period: String, timestamp: Long, endDate: Long?) {
        selectedDate.timeInMillis = timestamp
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(period, timestamp, endDate)
        filterAdapter.setSelected(period, timestamp)
        
        // Dynamic Requirement: Hide navigation arrows in Custom mode to save space and prevent confusion
        // Use INVISIBLE to maintain perfect centering of the date label.
        val isCustom = period.equals("Custom", ignoreCase = true)
        binding.layoutFilterIcons.btnPrevDate.visibility = if (isCustom) View.INVISIBLE else View.VISIBLE
        binding.layoutFilterIcons.btnNextDate.visibility = if (isCustom) View.INVISIBLE else View.VISIBLE
    }

    private fun showSubscriptionLock() {
        MaterialAlertDialogBuilder(this)
            .setTitle("Trial Expired ⏳")
            .setMessage("Your 7-day free trial has ended. Please subscribe to continue managing your shops.")
            .setCancelable(false)
            .setPositiveButton("Subscribe Now") { _, _ ->
                startPayment()
            }
            .setNegativeButton("Logout") { _, _ ->
                logout()
            }
            .show()
    }

    private fun startPayment() {
        val checkout = Checkout()
        checkout.setKeyID("rzp_test_RSU1rXBX2q7CSJ")

        try {
            val options = JSONObject()
            options.put("name", "Tea Shop ERP Premium")
            options.put("description", "Lifetime Premium Subscription")
            options.put("image", "https://s3.amazonaws.com/rzp-mobile/images/rzp.png")
            options.put("theme.color", "#4F46E5")
            options.put("currency", "INR")
            options.put("amount", "99900")

            val user = FirebaseAuth.getInstance().currentUser
            val retryObj = JSONObject()
            retryObj.put("enabled", true)
            retryObj.put("max_count", 4)
            options.put("retry", retryObj)

            options.put("prefill.contact", user?.phoneNumber ?: "")

            checkout.open(this, options)
        } catch (e: Exception) {
            Toast.makeText(this, "Error in payment: " + e.message, Toast.LENGTH_LONG).show()
            e.printStackTrace()
        }
    }

    override fun onPaymentSuccess(razorpayPaymentId: String?) {
        Toast.makeText(this, "Payment Successful! Unlocking Premium...", Toast.LENGTH_LONG).show()
        lifecycleScope.launch {
            val user = FirebaseAuth.getInstance().currentUser
            if (user != null) {
                val profile = UserProfile(
                    uid = user.uid,
                    phone = user.phoneNumber ?: "",
                    joinDate = System.currentTimeMillis(),
                    isPremium = true
                )
                viewModel.upgradeToPremium(profile)
            }
        }
    }

    override fun onPaymentError(code: Int, response: String?) {
        Toast.makeText(this, "Payment Failed: $response", Toast.LENGTH_LONG).show()
    }

    private fun logout() {
        FirebaseAuth.getInstance().signOut()
        val authPrefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        authPrefs.edit {
            putBoolean("is_locked", false)
            putBoolean("has_logged_in_before", true)
        }
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }

    private fun showAddShopDialog(existingShop: Shop? = null) {
        val dialogBinding = DialogAddShopBinding.inflate(LayoutInflater.from(this))
        var currentRules = existingShop?.salaryRules ?: SalaryRules()

        existingShop?.let {
            dialogBinding.etShopName.setText(it.name)
            dialogBinding.etLocation.setText(it.location)
            dialogBinding.etTableCount.setText(it.tableCount.toString())
        }

        // ATOMIC AUTO-FOCUS
        var autoFocusJob: kotlinx.coroutines.Job? = null
        dialogBinding.etShopName.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (dialogBinding.etShopName.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        kotlinx.coroutines.delay(1.5.seconds)
                        dialogBinding.etLocation.requestFocus()
                    }
                }
            }
        })

        dialogBinding.etLocation.addTextChangedListener(object : android.text.TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: android.text.Editable?) {
                if (dialogBinding.etLocation.isFocused && !s.isNullOrBlank()) {
                    autoFocusJob?.cancel()
                    autoFocusJob = lifecycleScope.launch {
                        kotlinx.coroutines.delay(1500.milliseconds)
                        dialogBinding.etTableCount.requestFocus()
                    }
                }
            }
        })

        dialogBinding.btnConfigureRules.setOnClickListener {
            showSalaryRulesDialog(currentRules) { updatedRules ->
                currentRules = updatedRules
                Toast.makeText(this, "Rules applied locally. Save shop to confirm.", Toast.LENGTH_SHORT).show()
            }
        }

        AlertDialog.Builder(this)
            .setTitle(if (existingShop == null) "Add New Shop" else "Edit Shop")
            .setView(dialogBinding.root)
            .setPositiveButton(if (existingShop == null) "Create" else "Update") { _, _ ->
                val name = dialogBinding.etShopName.text.toString()
                val location = dialogBinding.etLocation.text.toString()
                val tableCountStr = dialogBinding.etTableCount.text.toString()
                val tableCount = tableCountStr.toIntOrNull() ?: 0

                if (name.isNotEmpty()) {
                    if (existingShop == null) {
                        val newShop = Shop(
                            shopId = UUID.randomUUID().toString(),
                            name = name,
                            location = location,
                            openingDate = System.currentTimeMillis(),
                            openingCashBalance = 0.0,
                            tableCount = tableCount,
                            salaryRules = currentRules
                        )
                        viewModel.addShop(newShop)
                        PremiumUI.showSuccess(this, "Shop Registered", "${newShop.name} is now active!")
                    } else {
                        val updatedShop = existingShop.copy(
                            name = name, 
                            location = location, 
                            tableCount = tableCount,
                            salaryRules = currentRules
                        )
                        viewModel.addShop(updatedShop)
                        PremiumUI.showSuccess(this, "Shop Updated", "${updatedShop.name} updated successfully.")
                    }
                }
            }
            .setNeutralButton(if (existingShop != null) "Delete" else null) { _, _ ->
                existingShop?.let {
                    viewModel.deleteShop(it)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showSalaryRulesDialog(rules: SalaryRules, onRulesUpdated: (SalaryRules) -> Unit) {
        val rulesBinding = com.biometric.app.databinding.DialogSalaryRulesBinding.inflate(LayoutInflater.from(this))
        
        rulesBinding.etNewJoineeCutoff.setText(rules.newJoineeCutoffDay.toString())
        rulesBinding.etMaxAbsencesPaidLeave.setText(rules.maxAbsencesForPaidLeave.toString())
        rulesBinding.etMaxAbsencesBonus.setText(rules.maxAbsencesForBonus.toString())
        rulesBinding.etMaxShortfallBonus.setText(rules.maxShortfallMinutesForBonus.toString())
        rulesBinding.etPaidLeavePool.setText(rules.paidLeaveDaysPool.toString())

        rulesBinding.etDefaultShiftStart.setText(rules.defaultShiftStart)
        rulesBinding.etDefaultShiftEnd.setText(rules.defaultShiftEnd)
        rulesBinding.etDefaultBreakHours.setText(rules.defaultBreakHours.toString())
        rulesBinding.etDefaultOtMultiplier.setText(rules.defaultOtMultiplier.toString())
        
        rulesBinding.cbDefaultBonusEligible.isChecked = rules.isBonusEligibleDefault
        rulesBinding.cbDefaultPaidLeaveEligible.isChecked = rules.isPaidLeaveEligibleDefault
        rulesBinding.cbDefaultPaidLeaveWeekdays.isChecked = rules.paidLeaveOnWeekdaysDefault
        rulesBinding.cbDefaultPaidLeaveWeekends.isChecked = rules.paidLeaveOnWeekendsDefault

        MaterialAlertDialogBuilder(this)
            .setTitle("Salary Rules & Defaults")
            .setView(rulesBinding.root)
            .setPositiveButton("Apply") { _, _ ->
                val updatedRules = SalaryRules(
                    newJoineeCutoffDay = rulesBinding.etNewJoineeCutoff.text.toString().toIntOrNull() ?: 5,
                    maxAbsencesForPaidLeave = rulesBinding.etMaxAbsencesPaidLeave.text.toString().toIntOrNull() ?: 3,
                    maxAbsencesForBonus = rulesBinding.etMaxAbsencesBonus.text.toString().toIntOrNull() ?: 0,
                    maxShortfallMinutesForBonus = rulesBinding.etMaxShortfallBonus.text.toString().toIntOrNull() ?: 6,
                    paidLeaveDaysPool = rulesBinding.etPaidLeavePool.text.toString().toIntOrNull() ?: 1,
                    defaultShiftStart = rulesBinding.etDefaultShiftStart.text.toString().ifEmpty { "10:00" },
                    defaultShiftEnd = rulesBinding.etDefaultShiftEnd.text.toString().ifEmpty { "22:00" },
                    defaultBreakHours = rulesBinding.etDefaultBreakHours.text.toString().toDoubleOrNull() ?: 0.0,
                    defaultOtMultiplier = rulesBinding.etDefaultOtMultiplier.text.toString().toDoubleOrNull() ?: 1.0,
                    isBonusEligibleDefault = rulesBinding.cbDefaultBonusEligible.isChecked,
                    isPaidLeaveEligibleDefault = rulesBinding.cbDefaultPaidLeaveEligible.isChecked,
                    paidLeaveOnWeekdaysDefault = rulesBinding.cbDefaultPaidLeaveWeekdays.isChecked,
                    paidLeaveOnWeekendsDefault = rulesBinding.cbDefaultPaidLeaveWeekends.isChecked
                )
                onRulesUpdated(updatedRules)
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        // MainActivity keeps the Cloud icon visible in More Actions
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, showShopSwitcher = false, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🧠", "AI Assistant") {
                startActivity(Intent(this, AiChatActivity::class.java))
            },
            GlobalSwitcherDelegate.ActionItem("☁️", "Backup") {
                showBackupRestoreDialog()
            },
            GlobalSwitcherDelegate.ActionItem("⚙️", "Settings") {
                val intent = Intent(this, SettingsActivity::class.java)
                startActivity(intent)
            },
            GlobalSwitcherDelegate.ActionItem("🚪", "Logout") {
                logout()
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun applyRolePermissions() {
        val sharedPrefs = getSharedPreferences("auth_prefs", Context.MODE_PRIVATE)
        val roleStr = sharedPrefs.getString("user_role", UserRole.STAFF.name) ?: UserRole.STAFF.name
        val role = try { UserRole.valueOf(roleStr) } catch (e: Exception) { UserRole.STAFF }

        when (role) {
            UserRole.STAFF -> {
                binding.sectionStaff.visibility = View.VISIBLE
                binding.sectionAdminHub.visibility = View.GONE
                binding.cardGlobalInsights.visibility = View.GONE
                binding.btnAddShop.visibility = View.GONE
                binding.tvActiveShopsTitle.visibility = View.GONE
                binding.rvShops.visibility = View.GONE
                binding.sectionDataManagement.visibility = View.GONE
                binding.sectionTracking.visibility = View.GONE
            }
            UserRole.ADMIN -> {
                binding.sectionStaff.visibility = View.GONE
                binding.sectionAdminHub.visibility = View.VISIBLE
                binding.cardGlobalInsights.visibility = View.GONE
                binding.btnAddShop.visibility = View.VISIBLE // ALLOW ADMIN TO REGISTER WORKPLACE
                binding.tvActiveShopsTitle.visibility = View.VISIBLE
                binding.rvShops.visibility = View.VISIBLE
                binding.sectionDataManagement.visibility = View.GONE
                binding.sectionTracking.visibility = View.VISIBLE
                binding.sectionAdmin.visibility = View.VISIBLE
                binding.btnDeviceDashboard.visibility = View.GONE
            }
            UserRole.SUPER_ADMIN -> {
                binding.sectionStaff.visibility = View.GONE
                binding.sectionAdminHub.visibility = View.VISIBLE
                binding.cardGlobalInsights.visibility = View.GONE
                binding.btnAddShop.visibility = View.VISIBLE // Keep this if they need to add departments/sites
                binding.tvActiveShopsTitle.visibility = View.VISIBLE
                binding.rvShops.visibility = View.VISIBLE
                binding.sectionDataManagement.visibility = View.VISIBLE
                binding.sectionTracking.visibility = View.VISIBLE
                binding.sectionAdmin.visibility = View.VISIBLE
                binding.btnDeviceDashboard.visibility = View.VISIBLE
            }
        }
    }

    private fun stopLoadingAnimation() {
        // Removed - managed by PremiumLoader
    }

    private fun showCorrectionDialog() {
        val dialogBinding = DialogCorrectionRequestBinding.inflate(LayoutInflater.from(this))
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Request Correction")
            .setView(dialogBinding.root)
            .setPositiveButton("Submit Request") { _, _ ->
                val reason = dialogBinding.etReason.text.toString()
                if (reason.isNotEmpty()) {
                    Toast.makeText(this, "Correction Request Submitted! 📝", Toast.LENGTH_LONG).show()
                    // Save to Firestore 'attendanceCorrections'
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    @Suppress("DEPRECATION")
    private fun isServiceRunning(serviceClass: Class<*>): Boolean {
        val manager = getSystemService(ACTIVITY_SERVICE) as ActivityManager
        for (service in manager.getRunningServices(Int.MAX_VALUE)) {
            if (serviceClass.name == service.service.className) {
                return true
            }
        }
        return false
    }

    override fun onDestroy() {
        super.onDestroy()
        GlobalSwitcherDelegate.dismissPopup()
        stopLoadingAnimation()
        _binding = null
    }
}
