package com.biometric.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.edit

abstract class SecurityBaseActivity : AppCompatActivity() {

    companion object {
        private var isProcessVerified = false
        
        fun markAsVerified() {
            isProcessVerified = true
        }
    }

    protected open fun isSecurityBypass(): Boolean = false

    private var isLockingInProgress = false
    private val logoutHandler = Handler(Looper.getMainLooper())
    private val logoutRunnable = Runnable {
        lockApp()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        if (isSecurityBypass()) {
            return
        }

        // Check session in onCreate to prevent layout inflation flicker in subclasses
        if (checkSession()) return
    }

    override fun onUserInteraction() {
        super.onUserInteraction()
        if (!isSecurityBypass()) {
            resetSessionTimer()
        }
    }

    override fun onResume() {
        super.onResume()
        if (isSecurityBypass()) {
            return
        }
        
        if (checkSession()) {
            return // App is locked, stop further processing in this activity
        }
        resetSessionTimer()
    }

    override fun onPause() {
        super.onPause()
        stopSessionTimer()
    }

    private fun resetSessionTimer() {
        stopSessionTimer()
        // 5 Minutes timeout
        logoutHandler.postDelayed(logoutRunnable, 5 * 60 * 1000L)
        
        val sharedPrefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        sharedPrefs.edit {
            putLong("last_active_time", System.currentTimeMillis())
        }
    }

    private fun stopSessionTimer() {
        logoutHandler.removeCallbacks(logoutRunnable)
    }

    private fun checkSession(): Boolean {
        val sharedPrefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        val isLocked = sharedPrefs.getBoolean("is_locked", false)
        val lastActive = sharedPrefs.getLong("last_active_time", 0L)
        
        // Cold Start / Process Start Detection: Force lock on every new process start
        if (!isProcessVerified) {
            lockApp()
            return true
        }

        // Only lock if explicitly marked as locked OR if more than 5 minutes have passed since last activity
        val shouldLock = isLocked || (lastActive != 0L && System.currentTimeMillis() - lastActive > 5 * 60 * 1000L)
        
        if (shouldLock) {
            lockApp()
            return true
        }
        return false
    }

    private fun lockApp() {
        if (isLockingInProgress || isFinishing || isDestroyed) return
        isLockingInProgress = true

        val sharedPrefs = getSharedPreferences("auth_prefs", MODE_PRIVATE)
        sharedPrefs.edit(commit = true) {
            putBoolean("is_locked", true)
        }
        
        val intent = Intent(this, LoginActivity::class.java)
        intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
        startActivity(intent)
        finish()
    }
}
