package com.biometric.app.ui

import android.app.DatePickerDialog
import android.os.Bundle
import android.util.TypedValue
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.TableLayout
import android.widget.TableRow
import android.widget.TextView
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.github.mikephil.charting.data.BarData
import com.github.mikephil.charting.data.BarDataSet
import com.github.mikephil.charting.data.BarEntry
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.databinding.ActivitySalesPatternBinding
import com.biometric.app.util.ChartStyleManager
import com.biometric.app.ui.viewmodel.DayPattern
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SalesPatternViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class SalesPatternActivity : MotionBaseActivity() {

    private lateinit var binding: ActivitySalesPatternBinding
    private val viewModel: SalesPatternViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var filterAdapter: HorizontalFilterAdapter

    private var selectedDate = Calendar.getInstance()
    private var currentFilter = "Up To Date"
    private var shopId: String = ""
    private var shopName: String = ""
    private var isGlobal: Boolean = false
    private var lastDataTimestamp: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivitySalesPatternBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID") ?: ""
        val shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Sales")

        if (isGlobal) {
            shopId = ""
        }

        setupToolbar(shopName)
        setupUI()
        setupChart()
        observeViewModel()

        setupMotionFeedback(binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate)

        refreshData()
    }

    private fun setupToolbar(name: String) {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(name)
    }

    private fun updateToolbarTitle(name: String) {
        val line1 = if (isGlobal) "Global Insights 🌏" else name
        setupDualHeader(binding.toolbar, line1, "Sales Pattern")
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                shopId = selectedShop.shopId
                sharedViewModel.setSelectedShop(selectedShop)
                updateToolbarTitle(selectedShop.name)
                refreshData()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            currentFilter = selected
            refreshData()
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, currentFilter, selectedDate
            ) { newDate ->
                selectedDate.timeInMillis = newDate.timeInMillis
                refreshData()
            }
        }
    }

    private fun setupChart() {
        ChartStyleManager.applyChartStyle(binding.barChart, this)
        binding.barChart.apply {
            setDrawBarShadow(false)
            isHighlightFullBarEnabled = false
            xAxis.labelCount = 7
            axisLeft.spaceTop = 20f
            
            legend.apply {
                isEnabled = true
                verticalAlignment = com.github.mikephil.charting.components.Legend.LegendVerticalAlignment.TOP
                horizontalAlignment = com.github.mikephil.charting.components.Legend.LegendHorizontalAlignment.RIGHT
                orientation = com.github.mikephil.charting.components.Legend.LegendOrientation.HORIZONTAL
                setDrawInside(true)
                yOffset = 0f
                xOffset = 10f
                textSize = 10f
            }

            animateY(1000)
        }
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(currentFilter, selectedDate, amount)
        refreshData()
    }

    private fun refreshData() {
        updateFilterText()
        val sId = if (isGlobal) "" else shopId
        viewModel.loadAnalysis(sId, currentFilter, selectedDate.timeInMillis)
    }

    private fun updateFilterText() {
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(currentFilter, selectedDate.timeInMillis)
        filterAdapter.setSelected(currentFilter, selectedDate.timeInMillis)
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                shopName = it.name
                                updateToolbarTitle(it.name)
                                refreshData()
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.patterns.isEmpty()
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.SALES_PATTERN, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                        
                        if (!state.isLoading && state.patterns.isNotEmpty()) {
                            // PERFORMANCE FIX: Prevent double loading and double animation
                            val currentDataHash = state.patterns.hashCode().toLong() + state.totalSales.toLong()
                            if (lastDataTimestamp == currentDataHash) return@collectLatest
                            lastDataTimestamp = currentDataHash

                            val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
                            binding.tvCurrentAvg.text = currencyFormat.format(state.currentAvg)
                            binding.tvPreviousAvg.text = currencyFormat.format(state.previousAvg)
                            
                            val trendIcon = if (state.avgChangePercent >= 0) "📈" else "📉"
                            binding.tvAvgChange.text = String.format(Locale.getDefault(), "%s %.1f%%", trendIcon, state.avgChangePercent)
                            binding.tvAvgChange.setTextColor(if (state.avgChangePercent >= 0) ContextCompat.getColor(this@SalesPatternActivity, R.color.green) else ContextCompat.getColor(this@SalesPatternActivity, R.color.red))

                            binding.tvVeryHighDays.text = state.veryHighDays.joinToString(", ") { it.dayName }
                            binding.tvHighDays.text = state.highDays.joinToString(", ") { it.dayName }
                            binding.tvAverageDays.text = state.averageDays.joinToString(", ") { it.dayName }
                            binding.tvBelowAverageDays.text = state.belowAverageDays.joinToString(", ") { it.dayName }
                            binding.tvLowDays.text = state.lowDays.joinToString(", ") { it.dayName }

                            binding.tvTotalSales.text = String.format(Locale.getDefault(), "Total Sales: %s", currencyFormat.format(state.totalSales))
                            val trendType = if (state.totalChangeAmount >= 0) "Increase" else "Decrease"
                            binding.tvTrendStatus.text = String.format(Locale.getDefault(), "Trend: %s by %s compared to last period", trendType, currencyFormat.format(kotlin.math.abs(state.totalChangeAmount)))

                            binding.tvTableTitle.text = state.periodLabel
                            updateTable(state.patterns)
                            updateInsights(state.insights)
                            updateChart(state.patterns)
                        }
                    }
                }
            }
        }
    }

    private fun updateChart(patterns: List<DayPattern>) {
        if (patterns.isEmpty()) return

        val avgEntries = mutableListOf<BarEntry>()
        val maxEntries = mutableListOf<BarEntry>()
        val minEntries = mutableListOf<BarEntry>()

        patterns.forEachIndexed { index, pattern ->
            avgEntries.add(BarEntry(index.toFloat(), pattern.averageSales.toFloat()))
            maxEntries.add(BarEntry(index.toFloat(), pattern.maxSalesValue.toFloat()))
            minEntries.add(BarEntry(index.toFloat(), pattern.minSalesValue.toFloat()))
        }

        val avgDataSet = BarDataSet(avgEntries, "Average").apply {
            color = ContextCompat.getColor(this@SalesPatternActivity, R.color.blue)
            valueTextColor = ContextCompat.getColor(this@SalesPatternActivity, R.color.text_primary)
            valueTextSize = 8f
            setDrawValues(false)
        }

        val maxDataSet = BarDataSet(maxEntries, "Highest").apply {
            color = ContextCompat.getColor(this@SalesPatternActivity, R.color.green)
            valueTextColor = ContextCompat.getColor(this@SalesPatternActivity, R.color.text_primary)
            valueTextSize = 8f
            setDrawValues(false)
        }

        val minDataSet = BarDataSet(minEntries, "Lowest").apply {
            color = ContextCompat.getColor(this@SalesPatternActivity, R.color.red)
            valueTextColor = ContextCompat.getColor(this@SalesPatternActivity, R.color.text_primary)
            valueTextSize = 8f
            setDrawValues(false)
        }

        val barData = BarData(avgDataSet, maxDataSet, minDataSet)
        val groupSpace = 0.25f
        val barSpace = 0.05f
        val barWidth = 0.20f
        // (0.20 + 0.05) * 3 + 0.25 = 1.00

        barData.barWidth = barWidth

        binding.barChart.apply {
            data = barData
            xAxis.axisMinimum = 0f
            xAxis.axisMaximum = patterns.size.toFloat()
            groupBars(0f, groupSpace, barSpace)
            xAxis.valueFormatter = IndexAxisValueFormatter(patterns.map { it.dayName.take(3) })
            xAxis.setCenterAxisLabels(true)
            xAxis.granularity = 1f
            xAxis.isGranularityEnabled = true
            
            // Adjust axis left for max values
            val absoluteMax = patterns.maxOfOrNull { it.maxSalesValue }?.toFloat() ?: 100f
            axisLeft.axisMaximum = absoluteMax * 1.15f
            
            animateY(1400, com.github.mikephil.charting.animation.Easing.EaseInOutQuad)
            invalidate()
        }
    }

    private fun updateTable(patterns: List<DayPattern>) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))

        val childCount = binding.tablePattern.childCount
        if (childCount > 2) {
            binding.tablePattern.removeViews(2, childCount - 2)
        }

        patterns.forEach { pattern ->
            val row = TableRow(this).apply {
                setPadding(0, 12, 0, 4)
            }

            val tvDay = TextView(this).apply {
                text = pattern.dayName
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.2f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val tvAvg = TextView(this).apply {
                text = currencyFormat.format(pattern.averageSales)
                gravity = android.view.Gravity.END
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTypeface(null, android.graphics.Typeface.BOLD)
            }

            val tvIndicator = TextView(this).apply {
                text = String.format(Locale.getDefault(), "%s %s", getIndicatorEmoji(pattern.indicator), pattern.indicator)
                gravity = android.view.Gravity.END
                setTextColor(getIndicatorColor(pattern.indicator))
                layoutParams = TableRow.LayoutParams(0, TableRow.LayoutParams.WRAP_CONTENT, 1.2f)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            }

            row.addView(tvDay)
            row.addView(tvAvg)
            row.addView(tvIndicator)
            binding.tablePattern.addView(row)

            // Detail row for Max/Min
            val detailRow = TableRow(this).apply {
                setPadding(0, 0, 0, 12)
            }
            val tvDetails = TextView(this).apply {
                val maxStr = "🔥 Highest: ${currencyFormat.format(pattern.maxSalesValue)} (${pattern.maxSalesDate})"
                val minStr = "📉 Lowest: ${currencyFormat.format(pattern.minSalesValue)} (${pattern.minSalesDate})"
                text = getString(R.string.sales_pattern_details, maxStr, minStr)
                layoutParams = TableRow.LayoutParams(TableRow.LayoutParams.MATCH_PARENT, TableRow.LayoutParams.WRAP_CONTENT).apply {
                    span = 3
                }
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
                setTextColor(ContextCompat.getColor(this@SalesPatternActivity, R.color.text_secondary))
                setLineSpacing(0f, 1.1f)
            }
            detailRow.addView(tvDetails)
            binding.tablePattern.addView(detailRow)

            // Separator
            val separator = View(this).apply {
                layoutParams = TableLayout.LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, 1)
                setBackgroundColor(ContextCompat.getColor(this@SalesPatternActivity, R.color.divider))
            }
            binding.tablePattern.addView(separator)
        }
    }

    private fun updateInsights(insights: List<String>) {
        binding.llInsights.removeAllViews()
        insights.forEach { text ->
            val textView = TextView(this).apply {
                this.text = text
                setPadding(0, 12, 0, 12)
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setTextColor(ContextCompat.getColor(this@SalesPatternActivity, R.color.text_primary))
            }
            binding.llInsights.addView(textView)
        }
    }

    private fun getIndicatorEmoji(indicator: String): String = when (indicator) {
        "Very High" -> "🚀"
        "High" -> "🟢"
        "Average" -> "🟡"
        "Below Average" -> "🟠"
        else -> "🔴"
    }

    private fun getIndicatorColor(indicator: String): Int = when (indicator) {
        "Very High" -> ContextCompat.getColor(this, R.color.blue)
        "High" -> ContextCompat.getColor(this, R.color.green)
        "Average" -> ContextCompat.getColor(this, R.color.amber)
        "Below Average" -> ContextCompat.getColor(this, R.color.amber)
        else -> ContextCompat.getColor(this, R.color.red)
    }
}
