package com.biometric.app.data

import com.google.firebase.database.PropertyName
import com.google.gson.annotations.SerializedName
import com.biometric.app.data.entity.*
import java.io.Serializable
import java.math.BigDecimal
import java.math.RoundingMode
import java.util.*

data class OrderWithItems(
    val order: Order,
    val items: List<OrderItem> = emptyList(),
) : Serializable

data class CashFlowSummary(
    val totalIn: Double,
    val totalOut: Double,
    val salary: Double,
    val fixedExpenses: Double
) : Serializable

data class FinancialCategorySummary(
    val category: String,
    val description: String,
    val amount: Double,
    val type: String // IN or OUT
) : Serializable

data class DayData(
    val calendar: Calendar,
    val displayDate: String,
    var totalIn: Double = 0.0,
    var cashIn: Double = 0.0,
    var qrIn: Double = 0.0,
    var totalOut: Double = 0.0,
    var salaryEarned: Double = 0.0,
    var fixedExpense: Double = 0.0
) : Serializable

data class EmployeeStats(
    val employee: Employee? = null,
    val monthStart: Long = 0L,
    val monthEnd: Long = 0L,
    val pendingAdvance: Double = 0.0,
    var monthlyAdvance: Double = 0.0,
    val versionCount: Int = 0,

    // Monthly Totals & Counters
    var daysPresent: Int = 0,
    var daysAbsent: Int = 0,
    var closedShopDays: Int = 0,

    // Earned Values (Money) - Transitioning to BigDecimal for precision
    var totalNormalWorkedSalaryMonth: BigDecimal = BigDecimal.ZERO,
    var totalOTSalaryMonth: BigDecimal = BigDecimal.ZERO,
    var paidLeaveSalary: BigDecimal = BigDecimal.ZERO,
    var monthlyAllowance: BigDecimal = BigDecimal.ZERO,
    var bonusAmount: BigDecimal = BigDecimal.ZERO,
    var deductibleAmount: BigDecimal = BigDecimal.ZERO,
    var weekdayDeductibleHours: Double = 0.0,
    var weekdayDeductibleAmount: BigDecimal = BigDecimal.ZERO,
    var weekendDeductibleHours: Double = 0.0,
    var weekendDeductibleAmount: BigDecimal = BigDecimal.ZERO,

    // Payroll Breakdown (Phase 4)
    var payrollBreakdown: SalaryBreakdown? = null,

    // Work Hours
    var requiredWorkHours: Double = 0.0,
    var totalNormalWorkedHoursMonth: Double = 0.0,
    var totalOTHoursMonth: Double = 0.0,
    var shortfallHours: Double = 0.0,
    var shortfallDays: Double = 0.0,
    var paidLeaveAppliedHours: Double = 0.0,

    // Precision & Breakdown Fields
    var lateCount: Int = 0,
    var earlyCount: Int = 0,
    var gapCount: Int = 0,
    var leaveCount: Int = 0,
    var grossShortfallHours: Double = 0.0,
    var totalLateHours: Double = 0.0,
    var totalEarlyHours: Double = 0.0,
    var totalGapHours: Double = 0.0,
    var totalLeaveHours: Double = 0.0,
    val totalLateAmount: BigDecimal = BigDecimal.ZERO,
    val totalEarlyAmount: BigDecimal = BigDecimal.ZERO,
    val totalGapAmount: BigDecimal = BigDecimal.ZERO,
    val totalLeaveAmount: BigDecimal = BigDecimal.ZERO,
    val netLateAmount: BigDecimal = BigDecimal.ZERO,
    val netEarlyAmount: BigDecimal = BigDecimal.ZERO,
    val netGapAmount: BigDecimal = BigDecimal.ZERO,
    val netLeaveAmount: BigDecimal = BigDecimal.ZERO,
    val otCount: Int = 0,
    val paidLeaveCount: Int = 0,
    val allowanceCount: Int = 0,
    val bonusCount: Int = 0,

    // Header Stats (Selected Day)
    var selectedDayWorkedHours: Double = 0.0,
    var selectedDayNormalWorkedHours: Double = 0.0,
    var selectedDayOTHours: Double = 0.0,
    var selectedDayNormalWorkedSalary: BigDecimal = BigDecimal.ZERO,
    var selectedDayOTSalary: BigDecimal = BigDecimal.ZERO,
    var selectedDayAllowance: BigDecimal = BigDecimal.ZERO,
    var selectedDayWorkedSalary: BigDecimal = BigDecimal.ZERO,

    // Status & Config
    var isPresentToday: Boolean = false,
    var isCheckedIn: Boolean = false,
    var fullMonthSalary: Double = 0.0,
    var selectedDaySalaryRate: Double = 0.0,
    var isBonusEligible: Boolean = false,
    var isPaidLeaveEligible: Boolean = false,
    var isBonusEligibleByRule: Boolean = false,
    var isPaidLeaveEligibleByRule: Boolean = false,

    // Versioned UI info
    var salaryType: String = "",
    var shiftStart: String = "",
    var shiftEnd: String = "",
    var shift2Start: String? = null,
    var shift2End: String? = null,
    var hourlyRate: Double = 0.0,
    var netShiftHours: Double = 0.0,

    // Detail Maps
    val dayWiseEarnings: Map<Long, BigDecimal> = emptyMap(),
    val dayWiseOTEarnings: Map<Long, BigDecimal> = emptyMap(),
    val dayWiseAllowances: Map<Long, BigDecimal> = emptyMap(),
    val dayWiseWorkedHours: Map<Long, Double> = emptyMap(),
    val dayWiseBonus: Map<Long, BigDecimal> = emptyMap(),
    val dayWisePaidLeave: Map<Long, BigDecimal> = emptyMap(),
    val dayWisePaidLeaveHours: Map<Long, Double> = emptyMap(),
    val dayWiseOTHours: Map<Long, Double> = emptyMap(),
    val dayShortfalls: Map<Long, Double> = emptyMap(),

    // Compatibility fields
    var monthlySalary: Double = 0.0,
    val todayHours: Double = 0.0,
    val todaySalary: Double = 0.0,
    val totalHoursMonth: Double = 0.0,
    val selectedDaySalary: Double = 0.0,
    val selectedDayHours: Double = 0.0,
    val selectedDayMidnight: Long = 0L,
    val activityLog: List<SalaryActivityItem> = emptyList()
) : Serializable {
    // Centralized Calculation Helpers
    fun getNetPayableForStaffScreen(): Double {
        // Net Payable = Work Sal + OT Amt + Paid Leave Pay + Bonus
        val raw = totalNormalWorkedSalaryMonth
            .add(totalOTSalaryMonth)
            .add(paidLeaveSalary)
            .add(bonusAmount)
        return raw.setScale(0, RoundingMode.HALF_UP).toDouble()
    }

    /**
     * Unified logic for a specific range within the month stats.
     * Returns: (Net Salary Rounded) + Allowance
     */
    fun getRangeTotalEarnings(
        rangeStart: Long? = null,
        rangeEnd: Long? = null
    ): Double {
        val work = dayWiseEarnings.entries.filter { (rangeStart == null || it.key >= rangeStart) && (rangeEnd == null || it.key <= rangeEnd) }.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.value) }
        val ot = dayWiseOTEarnings.entries.filter { (rangeStart == null || it.key >= rangeStart) && (rangeEnd == null || it.key <= rangeEnd) }.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.value) }
        val pl = dayWisePaidLeave.entries.filter { (rangeStart == null || it.key >= rangeStart) && (rangeEnd == null || it.key <= rangeEnd) }.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.value) }
        val bonus = dayWiseBonus.entries.filter { (rangeStart == null || it.key >= rangeStart) && (rangeEnd == null || it.key <= rangeEnd) }.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.value) }
        val allowance = dayWiseAllowances.entries.filter { (rangeStart == null || it.key >= rangeStart) && (rangeEnd == null || it.key <= rangeEnd) }.fold(BigDecimal.ZERO) { acc, e -> acc.add(e.value) }
        
        val netSalaryRounded = work.add(ot).add(pl).add(bonus).setScale(0, RoundingMode.HALF_UP)
        return netSalaryRounded.add(allowance).toDouble()
    }

    fun getTotalCost(): Double {
        // Total Cost = Rounded Net Salary + Daily Allowances
        return getNetPayableForStaffScreen() + monthlyAllowance.toDouble()
    }

    fun getRoundedPeriodLiability(
        rangeStart: Long? = null,
        rangeEnd: Long? = null,
        includeBonus: Boolean = true
    ): Double {
        // Consistency: Sum raw daily components first, then round the Net Salary component once at the end
        val allDaysTs = (dayWiseEarnings.keys + dayWiseOTEarnings.keys + dayWiseBonus.keys + dayWisePaidLeave.keys + dayWiseAllowances.keys).distinct()
        
        var netSalaryRaw = BigDecimal.ZERO
        var totalAllowance = BigDecimal.ZERO
        
        allDaysTs.filter { (rangeStart == null || it >= rangeStart) && (rangeEnd == null || it <= rangeEnd) }.forEach { ts ->
            val work = dayWiseEarnings[ts] ?: BigDecimal.ZERO
            val ot = dayWiseOTEarnings[ts] ?: BigDecimal.ZERO
            val bonus = if (includeBonus) dayWiseBonus[ts] ?: BigDecimal.ZERO else BigDecimal.ZERO
            val pl = dayWisePaidLeave[ts] ?: BigDecimal.ZERO
            val allowance = dayWiseAllowances[ts] ?: BigDecimal.ZERO
            
            netSalaryRaw = netSalaryRaw.add(work).add(ot).add(bonus).add(pl)
            totalAllowance = totalAllowance.add(allowance)
        }
        
        // Match Staff Screen rounding: round the cumulative Net Salary to 0 decimals, then add Allowance
        val netSalaryRounded = netSalaryRaw.setScale(0, RoundingMode.HALF_UP)
        return netSalaryRounded.add(totalAllowance).toDouble()
    }

    fun getSelectedDayTotalCost(): Double {
        // Daily Cost = Rounded (Daily Work Sal + Daily OT + Daily Bonus + Daily PL) + Daily Allowance
        val ts = selectedDayMidnight
        val bonusOnDay = if (ts > 0) dayWiseBonus[ts] ?: BigDecimal.ZERO else BigDecimal.ZERO
        val plOnDay = if (ts > 0) dayWisePaidLeave[ts] ?: BigDecimal.ZERO else BigDecimal.ZERO
        
        val raw = selectedDayWorkedSalary.add(bonusOnDay).add(plOnDay)
        return raw.setScale(0, RoundingMode.HALF_UP).toDouble() + selectedDayAllowance.toDouble()
    }

    fun getNetPayable(): Double = getNetPayableForStaffScreen() - monthlyAdvance

    fun getFullMonthProjectedCost(): Double {
        // Projected = Base Salary + Monthly Allowance + Bonus + OT Earned so far
        return fullMonthSalary + monthlyAllowance.toDouble() + bonusAmount.toDouble() + totalOTSalaryMonth.toDouble()
    }
}

data class PosReportSummary(val totalSales: Double, val cashSales: Double, val qrSales: Double) : Serializable

data class FullBackupData(
    @SerializedName("timestamp") val timestamp: Long = System.currentTimeMillis(),
    @SerializedName("version") val version: Int = 1,
    @SerializedName("shops") val shops: List<Shop> = emptyList(),
    @SerializedName("items") val items: List<Item> = emptyList(),
    @SerializedName("prices") val prices: List<ShopItemPrice> = emptyList(),
    @SerializedName("orders") val orders: List<Order> = emptyList(),
    @SerializedName(value = "order_items", alternate = ["orderItems"]) val orderItems: List<OrderItem> = emptyList(),
    @SerializedName("cashbook") val cashbook: List<Cashbook> = emptyList(),
    @SerializedName("employees") val employees: List<Employee> = emptyList(),
    @SerializedName("attendance") val attendance: List<Attendance> = emptyList(),
    @SerializedName("advances") val advances: List<AdvancePayment> = emptyList(),
    @SerializedName(value = "fixed_expenses", alternate = ["fixedExpenses"]) val fixedExpenses: List<FixedExpense> = emptyList(),
    @SerializedName("investments") val investments: List<Investment> = emptyList(),
    @SerializedName("suppliers") val suppliers: List<Supplier> = emptyList(),
    @SerializedName(value = "inventory_items", alternate = ["inventoryItems"]) val inventoryItems: List<InventoryItem> = emptyList(),
    @SerializedName(value = "closed_days", alternate = ["closedDays"]) val closedDays: List<ShopClosedDay> = emptyList(),
    @SerializedName(value = "employee_history", alternate = ["employeeHistory"]) val employeeHistory: List<EmployeeHistory> = emptyList(),
    @SerializedName(value = "price_history", alternate = ["priceHistory"]) val priceHistory: List<PriceHistory> = emptyList(),
    @SerializedName(value = "audit_logs", alternate = ["auditLogs"]) val auditLogs: List<AuditLog> = emptyList(),
    @SerializedName(value = "salary_payments", alternate = ["salaryPayments"]) val salaryPayments: List<SalaryPayment> = emptyList(),
    @SerializedName("reminders") val reminders: List<Reminder> = emptyList(),
    @SerializedName(value = "shop_tables", alternate = ["shopTables"]) val shopTables: List<ShopTable> = emptyList(),
    @SerializedName(value = "recycle_bin", alternate = ["recycleBin"]) val recycleBin: List<RecycleBinItem> = emptyList(),
    @get:PropertyName("purchases")
    @SerializedName(value = "purchases", alternate = ["purchase_records"]) val purchases: List<Purchase> = emptyList(),
    @SerializedName(value = "stock_patterns", alternate = ["stockPatterns"]) val stockPatterns: List<StockPattern> = emptyList()
) : Serializable

data class SmartStockReminder(
    val itemName: String,
    val currentStock: Double,
    val unit: String,
    val suggestedDaily: Double,
    val suggestedWeekly: Double,
    val patternInsight: String,
    val urgency: String, // URGENT, PLANNED, STABLE
    val confidence: Int, // 0-100
    val lastPurchaseDate: Long,
    val avgGapDays: Int
) : Serializable

data class ForecastInsight(
    val remainingDays: Int = 0,
    val isVisible: Boolean = false,

    // Remaining Days Predictions
    val remainingSales: Double = 0.0,
    val remainingCashOut: Double = 0.0,
    val remainingSalary: Double = 0.0,
    val remainingFixed: Double = 0.0,
    val remainingProfit: Double = 0.0,

    // Historical Averages (Average of the "remaining days" period from last 3 months)
    val avgSales: Double = 0.0,
    val avgExpense: Double = 0.0,
    val avgProfit: Double = 0.0,

    // Overall Month
    val upToDateProfit: Double = 0.0,
    val finalEstimatedProfit: Double = 0.0
) : Serializable

data class SalaryActivityItem(
    val type: String, // LATE, EARLY, GAP, LEAVE, OT, BONUS, ALLOWANCE, PAID_LEAVE
    val title: String,
    val desc: String,
    val timestamp: Long,
    val totalHours: Double = 0.0,
    val netHours: Double = 0.0,
    val totalAmount: BigDecimal = BigDecimal.ZERO,
    val netAmount: BigDecimal = BigDecimal.ZERO
) : Serializable
