package com.biometric.app.ui.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.biometric.app.data.entity.FixedExpense
import com.biometric.app.databinding.ItemFixedExpenseBinding
import java.text.SimpleDateFormat
import java.util.*

class FixedExpenseAdapter(
    private val onEdit: (FixedExpense) -> Unit,
    private val onDelete: (FixedExpense) -> Unit
) : ListAdapter<FixedExpense, FixedExpenseAdapter.ViewHolder>(FixedExpenseDiffCallback()) {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemFixedExpenseBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val expense = getItem(position)
        holder.bind(expense)
    }

    inner class ViewHolder(private val binding: ItemFixedExpenseBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(expense: FixedExpense) {
            binding.tvExpenseName.text = expense.name
            binding.tvExpenseAmount.text = String.format(Locale.getDefault(), "₹%,.2f", expense.monthlyAmount)
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            binding.tvEffectiveDate.text = String.format(Locale.getDefault(), "Effective from: %s", sdf.format(Date(expense.effectiveFrom)))

            val icon = when {
                expense.name.contains("Rent", true) -> "🏠"
                expense.name.contains("EB", true) || expense.name.contains("Gas", true) -> "⚡"
                expense.name.contains("God", true) || expense.name.contains("Pooja", true) -> "🙏"
                expense.name.contains("Salary", true) -> "👤"
                expense.name.contains("Maintenance", true) -> "🛠️"
                else -> "📋"
            }
            binding.tvExpenseIcon.text = icon

            binding.btnEdit.setOnClickListener {
                onEdit(expense)
            }
            
            binding.btnDelete.setOnClickListener {
                onDelete(expense)
            }
            
            // Still allow clicking the item to edit
            itemView.setOnClickListener {
                onEdit(expense)
            }
        }
    }

    class FixedExpenseDiffCallback : DiffUtil.ItemCallback<FixedExpense>() {
        override fun areItemsTheSame(oldItem: FixedExpense, newItem: FixedExpense): Boolean {
            return oldItem.id == newItem.id
        }

        override fun areContentsTheSame(oldItem: FixedExpense, newItem: FixedExpense): Boolean {
            return oldItem == newItem
        }
    }
}
