package com.biometric.app.ui

import android.app.Dialog
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.biometric.app.R
import com.biometric.app.data.entity.Attendance
import com.biometric.app.data.entity.ShopClosedDay
import com.biometric.app.databinding.DialogAttendanceLogsBinding
import com.biometric.app.databinding.ItemFinanceRowBinding
import com.biometric.app.databinding.ItemMonthCardBinding
import com.biometric.app.ui.viewmodel.StaffViewModel
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*

class AttendanceLogsDialogFragment : DialogFragment() {

    private lateinit var viewModel: StaffViewModel
    private var _binding: DialogAttendanceLogsBinding? = null
    private val binding get() = _binding!!

    private var currentView = "MONTHS"
    private var selectedYear = Calendar.getInstance().get(Calendar.YEAR)
    private var currentMonthCal: Calendar = Calendar.getInstance()
    private val today = Calendar.getInstance()
    private var isFirstOpen = true

    data class DaySummary(
        val dateLabel: String,
        val dateKey: String,
        val totalWork: Double,
        val totalGap: Double,
        val breakHrs: Double,
        val netHours: Double,
        val status: String, // WORK, ABSENT, CLOSED_PAID, CLOSED_UNPAID, BEFORE_HIRE
        val sessions: List<Attendance>
    )

    companion object {
        const val TAG = "AttendanceLogsDialog"
        private const val ARG_EMPLOYEE_ID = "employeeId"
        private const val ARG_EMPLOYEE_NAME = "employeeName"
        private const val ARG_INITIAL_YEAR = "initialYear"
        private const val ARG_INITIAL_MONTH = "initialMonth"

        fun newInstance(employeeId: String, employeeName: String, initialYear: Int = -1, initialMonth: Int = -1): AttendanceLogsDialogFragment {
            val args = Bundle().apply {
                putString(ARG_EMPLOYEE_ID, employeeId)
                putString(ARG_EMPLOYEE_NAME, employeeName)
                putInt(ARG_INITIAL_YEAR, initialYear)
                putInt(ARG_INITIAL_MONTH, initialMonth)
            }
            return AttendanceLogsDialogFragment().apply {
                arguments = args
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        viewModel = ViewModelProvider(requireActivity())[StaffViewModel::class.java]
        
        val initialYear = requireArguments().getInt(ARG_INITIAL_YEAR, -1)
        if (initialYear != -1) {
            selectedYear = initialYear
        }
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        _binding = DialogAttendanceLogsBinding.inflate(layoutInflater)
        val employeeId = requireArguments().getString(ARG_EMPLOYEE_ID)!!
        val employeeName = requireArguments().getString(ARG_EMPLOYEE_NAME)!!
        val initialMonth = requireArguments().getInt(ARG_INITIAL_MONTH, -1)

        binding.rvLogs.layoutManager = LinearLayoutManager(requireContext())
        binding.btnYearToggle.text = selectedYear.toString()

        binding.btnYearToggle.setOnClickListener {
            showYearPickerDialog()
        }

        binding.btnPrevMonth.setOnClickListener {
            currentMonthCal.add(Calendar.MONTH, -1)
            selectedYear = currentMonthCal.get(Calendar.YEAR)
            binding.btnYearToggle.text = selectedYear.toString()
            showDaysView(employeeId, currentMonthCal)
        }

        binding.btnNextMonth.setOnClickListener {
            currentMonthCal.add(Calendar.MONTH, 1)
            selectedYear = currentMonthCal.get(Calendar.YEAR)
            binding.btnYearToggle.text = selectedYear.toString()
            showDaysView(employeeId, currentMonthCal)
        }

        val dialog = AlertDialog.Builder(requireActivity())
            .setTitle("$employeeName's Attendance Logs")
            .setView(binding.root)
            .setPositiveButton("Close", null)
            .setNegativeButton("Back", null)
            .create()

        dialog.setOnShowListener {
            val backBtn = dialog.getButton(AlertDialog.BUTTON_NEGATIVE)
            backBtn.setOnClickListener {
                if (currentView == "DAYS") {
                    showMonthsView(employeeId)
                }
            }
            
            if (isFirstOpen && initialMonth != -1) {
                isFirstOpen = false
                val cal = Calendar.getInstance()
                cal.set(Calendar.YEAR, selectedYear)
                cal.set(Calendar.MONTH, initialMonth)
                cal.set(Calendar.DAY_OF_MONTH, 1)
                showDaysView(employeeId, cal)
            } else {
                showMonthsView(employeeId)
                
                if (isFirstOpen && selectedYear == today.get(Calendar.YEAR)) {
                    isFirstOpen = false
                    showDaysView(employeeId, today)
                }
            }
        }

        return dialog
    }

    private fun showYearPickerDialog() {
        val employeeId = requireArguments().getString(ARG_EMPLOYEE_ID)!!
        val years = arrayOf("2024", "2025", "2026")
        AlertDialog.Builder(requireContext())
            .setTitle("Select Year")
            .setItems(years) { _, which ->
                selectedYear = years[which].toInt()
                binding.btnYearToggle.text = selectedYear.toString()
                showMonthsView(employeeId)
            }
            .show()
    }

    private fun showMonthsView(employeeId: String) {
        currentView = "MONTHS"
        binding.tvCurrentViewLabel.text = "Select Month"
        binding.llMonthNav.visibility = View.GONE
        (dialog as? AlertDialog)?.getButton(AlertDialog.BUTTON_NEGATIVE)?.visibility = View.GONE
        
        val monthsList = mutableListOf<Calendar>()
        val maxMonth = if (selectedYear == today.get(Calendar.YEAR)) today.get(Calendar.MONTH) else 11
        
        for (i in 0..maxMonth) {
            val cal = Calendar.getInstance()
            cal.set(Calendar.YEAR, selectedYear)
            cal.set(Calendar.MONTH, i)
            cal.set(Calendar.DAY_OF_MONTH, 1)
            monthsList.add(cal)
        }
        monthsList.reverse()

        binding.rvLogs.adapter = object : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
            override fun onCreateViewHolder(p: ViewGroup, v: Int) = object : androidx.recyclerview.widget.RecyclerView.ViewHolder(
                ItemMonthCardBinding.inflate(LayoutInflater.from(p.context), p, false).root
            ) {}
            override fun onBindViewHolder(h: androidx.recyclerview.widget.RecyclerView.ViewHolder, pos: Int) {
                val cal = monthsList[pos]
                val itemBinding = ItemMonthCardBinding.bind(h.itemView)
                val df = SimpleDateFormat("MMMM", Locale.getDefault())
                itemBinding.tvMonthName.text = df.format(cal.time)
                itemBinding.root.setOnClickListener { showDaysView(employeeId, cal) }
            }
            override fun getItemCount() = monthsList.size
        }
    }

    private fun showDaysView(employeeId: String, monthCal: Calendar) {
        currentView = "DAYS"
        currentMonthCal = monthCal.clone() as Calendar
        binding.tvCurrentViewLabel.text = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(monthCal.time)
        binding.llMonthNav.visibility = View.VISIBLE
        (dialog as? AlertDialog)?.getButton(AlertDialog.BUTTON_NEGATIVE)?.visibility = View.VISIBLE
        
        val employee = viewModel.employees.value.find { it.employeeId == employeeId } ?: return
        val shopId = employee.shopId
        
        val start = monthCal.clone() as Calendar
        start.set(Calendar.DAY_OF_MONTH, 1)
        start.set(Calendar.HOUR_OF_DAY, 0); start.set(Calendar.MINUTE, 0); start.set(Calendar.SECOND, 0)
        
        val end = monthCal.clone() as Calendar
        end.set(Calendar.DAY_OF_MONTH, end.getActualMaximum(Calendar.DAY_OF_MONTH))
        end.set(Calendar.HOUR_OF_DAY, 23); end.set(Calendar.MINUTE, 59); end.set(Calendar.SECOND, 59)

        lifecycleScope.launch {
            combine(
                viewModel.getAttendanceRecords(employeeId, start.timeInMillis, end.timeInMillis),
                viewModel.getClosedDays(shopId, start.timeInMillis, end.timeInMillis)
            ) { records: List<Attendance>, closedDays: List<ShopClosedDay> ->
                records to closedDays
            }.collect { (records: List<Attendance>, closedDays: List<ShopClosedDay>) ->
                if (currentView != "DAYS") return@collect
                
                val daySummaries = mutableListOf<DaySummary>()
                
                val groupedRecords = records.groupBy { 
                    SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(it.checkInTime))
                }
                val groupedClosed = closedDays.associateBy {
                    SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(it.date))
                }

                val maxDay = if (monthCal.get(Calendar.MONTH) == today.get(Calendar.MONTH) && 
                                 monthCal.get(Calendar.YEAR) == today.get(Calendar.YEAR)) {
                    today.get(Calendar.DAY_OF_MONTH)
                } else {
                    monthCal.getActualMaximum(Calendar.DAY_OF_MONTH)
                }

                for (day in 1..maxDay) {
                    val cal = monthCal.clone() as Calendar
                    cal.set(Calendar.DAY_OF_MONTH, day)
                    cal.set(Calendar.HOUR_OF_DAY, 0); cal.set(Calendar.MINUTE, 0); cal.set(Calendar.SECOND, 0); cal.set(Calendar.MILLISECOND, 0)
                    
                    val dateKey = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(cal.time)
                    val dateLabel = SimpleDateFormat("dd/MM (EEE)", Locale.getDefault()).format(cal.time)
                    
                    val dayRecords = groupedRecords[dateKey] ?: emptyList()
                    val closedDay = groupedClosed[dateKey]
                    
                    val status: String
                    val net: Double
                    var work = 0.0
                    var gap = 0.0
                    var dayBreak = employee.breakHours // Default from profile

                    // CHECK HIRE DATE RULE
                    val hireCal = Calendar.getInstance().apply { timeInMillis = employee.hireDate }
                    hireCal.set(Calendar.HOUR_OF_DAY, 0); hireCal.set(Calendar.MINUTE, 0); hireCal.set(Calendar.SECOND, 0); hireCal.set(Calendar.MILLISECOND, 0)

                    if (cal.timeInMillis < hireCal.timeInMillis) {
                        status = "BEFORE_HIRE"
                        net = 0.0
                    } else if (dayRecords.any { it.type == "WORK" }) {
                        dayRecords.filter { it.type == "WORK" }.forEach { 
                            work += if (it.checkOutTime == null) (System.currentTimeMillis() - it.checkInTime) / 3600000.0 else it.hoursWorked
                            dayBreak = it.breakHours // SNAPSHOT AWARE: Use the break from the record!
                        }
                        gap = dayRecords.filter { it.type == "GAP" }.sumOf { kotlin.math.abs(it.hoursWorked) }
                        status = "WORK"
                        net = work - gap - if (work > 0) dayBreak else 0.0
                    } else if (closedDay != null && (closedDay.affectedEmployeeIds.isEmpty() || employee.employeeId in closedDay.affectedEmployeeIds)) {
                        if (closedDay.paySalary) {
                            status = "CLOSED_PAID"
                            
                            val s1Parts = employee.shiftStart.split(":")
                            val e1Parts = employee.shiftEnd.split(":")
                            val s1Decimal = s1Parts[0].toInt() + s1Parts[1].toInt() / 60.0
                            var e1Decimal = e1Parts[0].toInt() + e1Parts[1].toInt() / 60.0
                            if (e1Decimal < s1Decimal) e1Decimal += 24.0
                            val s1Duration = e1Decimal - s1Decimal
                            
                            var s2Duration = 0.0
                            if (employee.shift2Start != null && employee.shift2End != null) {
                                val s2Parts = employee.shift2Start!!.split(":")
                                val e2Parts = employee.shift2End!!.split(":")
                                val s2Decimal = s2Parts[0].toInt() + s2Parts[1].toInt() / 60.0
                                var e2Decimal = e2Parts[0].toInt() + e2Parts[1].toInt() / 60.0
                                if (e2Decimal < s2Decimal) e2Decimal += 24.0
                                s2Duration = e2Decimal - s2Decimal
                            }

                            val shiftDuration = (s1Duration + s2Duration - employee.breakHours).coerceAtLeast(0.0)
                            net = shiftDuration
                        } else {
                            status = "CLOSED_UNPAID"
                            net = 0.0
                        }
                    } else {
                        status = "ABSENT"
                        net = 0.0
                    }
                    
                    daySummaries.add(DaySummary(dateLabel, dateKey, work, gap, dayBreak, net, status, dayRecords))
                }
                daySummaries.reverse()

                binding.rvLogs.adapter = object : androidx.recyclerview.widget.RecyclerView.Adapter<androidx.recyclerview.widget.RecyclerView.ViewHolder>() {
                    override fun onCreateViewHolder(p: ViewGroup, v: Int) = object : androidx.recyclerview.widget.RecyclerView.ViewHolder(
                        ItemFinanceRowBinding.inflate(LayoutInflater.from(p.context), p, false).root
                    ) {}
                    
                    override fun onBindViewHolder(h: androidx.recyclerview.widget.RecyclerView.ViewHolder, pos: Int) {
                        val summary = daySummaries[pos]
                        val itemBinding = ItemFinanceRowBinding.bind(h.itemView)
                        
                        itemBinding.tvDate.text = summary.dateLabel

                        when (summary.status) {
                            "BEFORE_HIRE" -> {
                                itemBinding.tvParticulars.text = "Not yet hired"
                                itemBinding.tvDebit.text = "-"
                                itemBinding.tvCredit.text = "-"
                            }
                            "WORK" -> {
                                itemBinding.tvParticulars.text = String.format(Locale.getDefault(), "Work: %.1fh | Brk: %.1fh | Gap: %.1fh", summary.totalWork, summary.breakHrs, summary.totalGap)
                                itemBinding.tvCredit.text = "%.2f hrs".format(summary.netHours)
                                itemBinding.tvCredit.setTextColor(ContextCompat.getColor(h.itemView.context, R.color.green))
                                itemBinding.tvDebit.text = ""
                            }
                            "CLOSED_PAID" -> {
                                itemBinding.tvParticulars.text = "Shop Closed (Paid)"
                                itemBinding.tvCredit.text = String.format(Locale.getDefault(), "%.2f hrs", summary.netHours)
                                itemBinding.tvCredit.setTextColor(ContextCompat.getColor(h.itemView.context, R.color.green))
                                itemBinding.tvDebit.text = ""
                            }
                            "CLOSED_UNPAID" -> {
                                itemBinding.tvParticulars.text = "Shop Closed (Unpaid)"
                                itemBinding.tvCredit.text = "0.00 hrs"
                                itemBinding.tvDebit.text = ""
                            }
                            "ABSENT" -> {
                                itemBinding.tvParticulars.text = "Absent"
                                itemBinding.tvDebit.text = "ABSENT"
                                itemBinding.tvDebit.setTextColor(ContextCompat.getColor(h.itemView.context, R.color.red))
                                itemBinding.tvCredit.text = ""
                            }
                        }
                        
                        itemBinding.root.setOnClickListener {
                            if (summary.status == "WORK") {
                                showDayDetailsDialog(summary)
                            }
                        }
                    }
                    override fun getItemCount() = daySummaries.size
                }
            }
        }
    }

    private fun showDayDetailsDialog(summary: DaySummary) {
        val employeeId = requireArguments().getString(ARG_EMPLOYEE_ID)
        val employee = viewModel.employees.value.find { it.employeeId == employeeId } ?: return
        
        val options = summary.sessions.map { 
            val df = SimpleDateFormat("HH:mm", Locale.getDefault())
            val checkOut = it.checkOutTime
            val out = if (checkOut != null) df.format(Date(checkOut)) else "RUNNING"
            var hours = it.hoursWorked
            if (checkOut == null) {
                hours = (System.currentTimeMillis() - it.checkInTime) / 3600000.0
            }
            "${df.format(Date(it.checkInTime))} - $out (${it.type}: %.2fh)".format(Locale.getDefault(), hours)
        }.toTypedArray()

        AlertDialog.Builder(requireContext())
            .setTitle("Sessions for ${summary.dateLabel}")
            .setItems(options) { _, which ->
                val session = summary.sessions[which]
                val fullDateFormat = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
                val auditInfo = "\n\nEntry recorded on: ${fullDateFormat.format(Date(session.createdAt))}"
                
                AlertDialog.Builder(requireContext())
                    .setTitle("Audit Details 🛡️")
                    .setMessage("Check-in: ${fullDateFormat.format(Date(session.checkInTime))}\n" +
                                "Check-out: ${session.checkOutTime?.let { fullDateFormat.format(Date(it)) } ?: "Ongoing"}\n" +
                                "Type: ${session.type}\n" +
                                "Hours: %.2f".format(session.hoursWorked) + 
                                auditInfo)
                    .setPositiveButton("Edit/Delete") { _, _ ->
                        ManualAttendanceDialogFragment.newInstance(employee, session)
                            .show(parentFragmentManager, ManualAttendanceDialogFragment.TAG)
                    }
                    .setNegativeButton("Close", null)
                    .show()
            }
            .setPositiveButton("Close", null)
            .show()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}
