package com.biometric.app.ui.reports

import androidx.paging.PagingSource
import androidx.paging.PagingState
import com.google.firebase.database.DataSnapshot
import com.google.firebase.database.DatabaseError
import com.google.firebase.database.ValueEventListener
import com.biometric.app.data.entity.Cashbook
import com.biometric.app.sync.FirebaseSyncManager
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

class CashbookPagingSource(
    private val firebaseSync: FirebaseSyncManager,
    private val shopId: String?,
    private val startTime: Long,
    private val endTime: Long
) : PagingSource<Long, Cashbook>() {

    override fun getRefreshKey(state: PagingState<Long, Cashbook>): Long? = state.anchorPosition?.let {
        state.closestItemToPosition(it)?.transactionDate
    }

    override suspend fun load(params: LoadParams<Long>): LoadResult<Long, Cashbook> {
        return try {
            val key = params.key ?: endTime
            val result = fetchFromFirebase(key, params.loadSize)
            
            LoadResult.Page(
                data = result,
                prevKey = null, // Only support one-way loading for now
                nextKey = if (result.size < params.loadSize) null else result.last().transactionDate - 1
            )
        } catch (e: Exception) {
            LoadResult.Error(e)
        }
    }

    private suspend fun fetchFromFirebase(endAt: Long, limit: Int): List<Cashbook> = suspendCancellableCoroutine { cont ->
        val ref = firebaseSync.getOwnerRef()?.child("cashbook") ?: run {
            cont.resume(emptyList())
            return@suspendCancellableCoroutine
        }

        var query = ref.orderByChild("transactionDate").endAt(endAt.toDouble()).limitToLast(limit)

        query.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val list = mutableListOf<Cashbook>()
                for (child in snapshot.children) {
                    child.getValue(Cashbook::class.java)?.let { entry ->
                        if ((shopId.isNullOrEmpty() || entry.shopId == shopId) && entry.transactionDate >= startTime) {
                            list.add(entry)
                        }
                    }
                }
                // Sort descending because we loaded limitToLast
                cont.resume(list.sortedByDescending { it.transactionDate })
            }
            override fun onCancelled(error: DatabaseError) {
                cont.resume(emptyList())
            }
        })
    }
}
