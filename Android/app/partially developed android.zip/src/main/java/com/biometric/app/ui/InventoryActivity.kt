package com.biometric.app.ui

import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.util.TypedValue
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.viewModels
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.biometric.app.R
import com.biometric.app.data.entity.PriceHistory
import com.biometric.app.databinding.ActivityInventoryBinding
import com.biometric.app.databinding.DialogPriceHistoryBinding
import com.biometric.app.databinding.ItemInventoryRowBinding
import com.biometric.app.databinding.ItemPriceHistoryRowBinding
import com.biometric.app.ui.viewmodel.InventoryDisplayItem
import com.biometric.app.ui.viewmodel.InventoryViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import com.biometric.app.ui.adapter.HorizontalFilterAdapter
import com.biometric.app.util.DateRangeUtil
import com.biometric.app.util.PickerHelper
import com.biometric.app.util.HapticUtil
import com.biometric.app.util.PremiumLoader
import androidx.core.view.isVisible
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

@AndroidEntryPoint
class InventoryActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityInventoryBinding
    private val viewModel: InventoryViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var inventoryAdapter: InventoryAdapter
    private lateinit var filterAdapter: HorizontalFilterAdapter
    private var selectedDate = Calendar.getInstance()
    private var shopId: String? = null
    private var shopName: String = ""
    private var isGlobal: Boolean = false
    private var inventoryMenu: Menu? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityInventoryBinding.inflate(layoutInflater)
        setContentView(binding.root)

        isGlobal = intent.getBooleanExtra("IS_GLOBAL", false)
        shopId = intent.getStringExtra("SHOP_ID")
        shopName = intent.getStringExtra("SHOP_NAME") ?: (if (isGlobal) "Global Network" else "Inventory")

        if (isGlobal) {
            shopId = ""
            viewModel.setShopId("")
        }

        setupToolbar()
        setupUI()
        setupRecyclerView()
        observeViewModel()

        setupMotionFeedback(
            binding.layoutFilterIcons.btnPrevDate, binding.layoutFilterIcons.btnNextDate,
            binding.btnBackfill,
        )
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        updateToolbarTitle(shopName)
    }

    private fun showShopSelectionDialog() {
        val shops = mainViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                sharedViewModel.setSelectedShop(selectedShop)
            }
            .show()
    }

    private fun updateToolbarTitle(shopName: String) {
        this.shopName = shopName
        val line1 = if (shopName.contains("Inventory", ignoreCase = true)) "Network Stock" else shopName
        setupDualHeader(binding.toolbar, line1, "Inventory Management")
    }

    private fun setupUI() {
        filterAdapter = HorizontalFilterAdapter(showCustom = false) { selected: String ->
            viewModel.setPeriod(selected)
        }
        binding.layoutFilterIcons.rvFilterIcons.layoutManager = androidx.recyclerview.widget.GridLayoutManager(this, 7)
        binding.layoutFilterIcons.rvFilterIcons.adapter = filterAdapter

        binding.layoutFilterIcons.btnPrevDate.setOnClickListener { adjustDate(-1) }
        binding.layoutFilterIcons.btnNextDate.setOnClickListener { adjustDate(1) }

        binding.layoutFilterIcons.tvDateLabel.setOnClickListener {
            PickerHelper.showSmartPicker(
                this, viewModel.state.value.periodLabel, selectedDate
            ) { newDate ->
                viewModel.setReferenceDate(newDate.timeInMillis)
            }
        }

        binding.etSearchInventory.addTextChangedListener(
            object : TextWatcher {
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                    inventoryAdapter.filter(s.toString())
                }
                override fun afterTextChanged(s: Editable?) {}
            }
        )

        binding.btnBackfill.setOnClickListener {
            shopId?.let {
                viewModel.runInventoryBackfill(it)
            }
        }
    }

    private fun showPredictionsDialog() {
        val predictions = viewModel.state.value.stockPredictions
        if (predictions.isEmpty()) {
            Toast.makeText(this, "Not enough data for AI prediction yet. Keep recording purchases!", Toast.LENGTH_SHORT).show()
            return
        }

        val dialogBinding = com.biometric.app.databinding.DialogPredictionsBinding.inflate(LayoutInflater.from(this))
        predictions.forEach { pred ->
            val itemBinding = com.biometric.app.databinding.ItemStockPredictionBinding.inflate(LayoutInflater.from(this), dialogBinding.llPredictionsContainer, false)
            itemBinding.tvItemName.text = pred.itemName
            itemBinding.tvInsight.text = pred.patternInsight
            itemBinding.tvDaily.text = String.format(Locale.getDefault(), "%.1f %s", pred.suggestedDaily, pred.unit)
            itemBinding.tvWeekly.text = String.format(Locale.getDefault(), "%.1f %s", pred.suggestedWeekly, pred.unit)
            itemBinding.tvConfidence.text = String.format(Locale.getDefault(), "%d%%", pred.confidence)
            
            if (pred.urgency == "URGENT") {
                itemBinding.tvUrgency.setText(R.string.replenish_label)
                itemBinding.tvUrgency.setBackgroundResource(R.drawable.badge_bg_red)
            } else {
                itemBinding.tvUrgency.setText(R.string.stable_label)
                itemBinding.tvUrgency.setBackgroundResource(R.drawable.badge_bg_green)
            }
            
            dialogBinding.llPredictionsContainer.addView(itemBinding.root)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("AI Predictive Ordering 🤖")
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun adjustDate(amount: Int) {
        DateRangeUtil.adjustDate(viewModel.state.value.periodLabel, selectedDate, amount)
        viewModel.setReferenceDate(selectedDate.timeInMillis)
    }

    private fun setupRecyclerView() {
        inventoryAdapter = InventoryAdapter(
            onItemClick = { item ->
                showPriceHistory(item)
            },
        ) { item ->
            showRenameDialog(item)
        }
        binding.rvInventory.apply {
            layoutManager = LinearLayoutManager(this@InventoryActivity)
            adapter = inventoryAdapter
        }
    }

    private fun showRenameDialog(item: InventoryDisplayItem) {
        val input = android.widget.EditText(this).apply {
            setText(item.name)
            setSelection(item.name.length)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Rename / Merge Item")
            .setMessage("Changing this name will update ALL past Cashbook entries and Price History records for this item. If the new name already exists, they will be merged. Proceed?")
            .setView(input)
            .setPositiveButton("Rename Globally") { _, _ ->
                val newName = input.text.toString()
                if (newName.isNotBlank() && (newName != item.name)) {
                    viewModel.renameItemGlobally(item.name, newName)
                }
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun showPriceHistory(item: InventoryDisplayItem) {
        val dialogBinding = DialogPriceHistoryBinding.inflate(layoutInflater)
        val historyAdapter = PriceHistoryAdapter(item.unitType)
        dialogBinding.rvPriceHistory.apply {
            layoutManager = LinearLayoutManager(this@InventoryActivity)
            adapter = historyAdapter
        }
        dialogBinding.tvItemTitle.text = item.name

        lifecycleScope.launch {
            val sId = shopId ?: sharedViewModel.selectedShop.value?.shopId ?: return@launch
            viewModel.getPriceHistory(sId, item.name).collect { history ->
                historyAdapter.submitList(history)
            }
        }

        MaterialAlertDialogBuilder(this)
            .setView(dialogBinding.root)
            .setPositiveButton("Close", null)
            .show()
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        if (!isGlobal) {
                            shop?.let {
                                shopId = it.shopId
                                viewModel.setShopId(it.shopId)
                                updateToolbarTitle(it.name)
                            }
                        }
                    }
                }
                launch {
                    viewModel.state.collectLatest { state ->
                        // UNIFORM LOADING: Use Smart Delay Loader
                        val isDataZero = state.items.isEmpty() && state.totalStockValue == 0.0
                        if (state.isLoading) {
                            PremiumLoader.show(binding.brewingLoader, PremiumLoader.ScreenType.STOCK, lifecycleScope, immediate = true)
                            if (isDataZero) binding.contentLayout.visibility = View.GONE
                        } else {
                            PremiumLoader.hide(binding.brewingLoader)
                            binding.contentLayout.visibility = View.VISIBLE
                            binding.contentLayout.alpha = 1f
                        }
                        inventoryAdapter.updateList(state.items)
                        updateSummary(state.totalStockValue, state.totalItemCount)
                        
                        val oldAlerts = viewModel.state.value.alerts
                        updateInsights(state.alerts, state.suggestions)
                        if (oldAlerts.isEmpty() != state.alerts.isEmpty()) {
                            invalidateOptionsMenu()
                        }
                        
                        updateFilterUI(state.periodLabel, state.selectedDate)
                    }
                }
            }
        }
    }

    private fun updateFilterUI(period: String, date: Long) {
        selectedDate.timeInMillis = date
        binding.layoutFilterIcons.tvDateLabel.text = DateRangeUtil.getFormattedRangeLabel(period, date)
        filterAdapter.setSelected(period, date)
    }

    private fun updateInsights(alerts: List<String>, suggestions: List<String>) {
        if (alerts.isNotEmpty()) {
            HapticUtil.vibrateRisk(binding.root)
        }

        binding.llSuggestions.removeAllViews()

        suggestions.forEach { text ->
            val tv = TextView(this).apply {
                this.text = text
                setTextColor(ContextCompat.getColor(context, R.color.text_primary))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
                setPadding(0, 8, 0, 8)
            }
            binding.llSuggestions.addView(tv)
        }
        
        binding.cardSuggestions.visibility = if (suggestions.isEmpty()) View.GONE else View.VISIBLE
    }

    private fun updateSummary(totalValue: Double, itemCount: Int) {
        val currencyFormat = NumberFormat.getCurrencyInstance(Locale.forLanguageTag("en-IN"))
        binding.tvTotalStockValue.text = currencyFormat.format(totalValue)
        binding.tvTotalItemCount.text = itemCount.toString()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val alerts = viewModel.state.value.alerts
        val extraActions = if (alerts.isNotEmpty()) {
            listOf(GlobalSwitcherDelegate.ActionItem("⚠️", "Critical Alerts") {
                showCriticalAlertsDialog()
            })
        } else {
            emptyList()
        }
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        inventoryMenu = menu
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val alerts = viewModel.state.value.alerts
        val extraActions = if (alerts.isNotEmpty()) {
            listOf(GlobalSwitcherDelegate.ActionItem("⚠️", "Critical Alerts") {
                showCriticalAlertsDialog()
            })
        } else {
            emptyList()
        }
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun showCriticalAlertsDialog() {
        val alerts = viewModel.state.value.alerts
        if (alerts.isEmpty()) return

        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            val padding = (16 * resources.displayMetrics.density).toInt()
            setPadding(padding, padding, padding, padding)
        }

        alerts.forEach { text ->
            val tv = TextView(this).apply {
                this.text = "• $text"
                setTextColor(ContextCompat.getColor(context, R.color.alert_text))
                setTextSize(TypedValue.COMPLEX_UNIT_SP, 14f)
                setPadding(0, 8, 0, 8)
                setTypeface(null, Typeface.BOLD)
            }
            container.addView(tv)
        }

        MaterialAlertDialogBuilder(this)
            .setTitle("Critical Inventory Alerts ⚠️")
            .setView(container)
            .setPositiveButton("Close", null)
            .show()
    }

    class InventoryAdapter(
        private val onItemClick: (InventoryDisplayItem) -> Unit,
        private val onItemLongClick: (InventoryDisplayItem) -> Unit
    ) : RecyclerView.Adapter<InventoryAdapter.ViewHolder>() {
        
        private var items: List<InventoryDisplayItem> = listOf()
        private var filteredItems: List<InventoryDisplayItem> = listOf()

        class ViewHolder(val binding: ItemInventoryRowBinding) : RecyclerView.ViewHolder(binding.root)

        fun updateList(newItems: List<InventoryDisplayItem>) {
            items = newItems
            filter("")
        }

        fun filter(query: String) {
            filteredItems = if (query.isEmpty()) items else items.filter { it.name.contains(query, ignoreCase = true) }
            notifyDataSetChanged()
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemInventoryRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        private fun getEmoji(name: String): String = when {
            name.contains("MILK", true) -> "🥛"
            name.contains("SUGAR", true) -> "🍬"
            name.contains("OIL", true) -> "🛢"
            name.contains("FLOUR", true) -> "🌾"
            name.contains("TEA", true) -> "☕"
            name.contains("COFFEE", true) -> "☕"
            name.contains("GAS", true) -> "🔥"
            else -> "📦"
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val item = filteredItems[position]
            val context = holder.itemView.context
            
            holder.binding.tvItemEmoji.text = getEmoji(item.name)
            holder.binding.tvItemName.text = item.name
            holder.binding.tvQuantity.text = String.format(Locale.getDefault(), "%.1f %s", item.totalQuantity, item.unitType)
            holder.binding.tvTotalCost.text = String.format(Locale.getDefault(), "₹%,.0f total", item.totalCost)
            
            holder.binding.tvAvgPrice.text = String.format(Locale.getDefault(), "₹%.1f/%s", item.avgPrice, item.unitType.take(1))
            holder.binding.tvLastPrice.text = String.format(Locale.getDefault(), "₹%.1f/%s", item.lastPrice, item.unitType.take(1))

            if (item.lastPrice > (item.avgPrice * 1.1)) {
                holder.binding.tvLastPrice.setTextColor(ContextCompat.getColor(context, R.color.red))
            } else {
                holder.binding.tvLastPrice.setTextColor(ContextCompat.getColor(context, R.color.colorPrimary))
            }

            holder.itemView.setOnClickListener { onItemClick(item) }
            holder.itemView.setOnLongClickListener { 
                onItemLongClick(item)
                true
            }
        }

        override fun getItemCount() = filteredItems.size
    }

    class PriceHistoryAdapter(private val unit: String) : RecyclerView.Adapter<PriceHistoryAdapter.ViewHolder>() {
        private var items = listOf<PriceHistory>()

        fun submitList(newItems: List<PriceHistory>) {
            items = newItems
            notifyDataSetChanged()
        }

        class ViewHolder(val binding: ItemPriceHistoryRowBinding) : RecyclerView.ViewHolder(binding.root)

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
            val binding = ItemPriceHistoryRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return ViewHolder(binding)
        }

        override fun onBindViewHolder(holder: ViewHolder, position: Int) {
            val history = items[position]
            val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
            holder.binding.tvDate.text = sdf.format(Date(history.date))
            holder.binding.tvQuantity.text = String.format(Locale.getDefault(), "%.1f %s", history.quantity, unit)
            holder.binding.tvPrice.text = String.format(Locale.getDefault(), "₹%.1f/%s", history.price, unit.take(1))
        }

        override fun getItemCount() = items.size
    }
}
