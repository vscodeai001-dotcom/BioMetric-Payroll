package com.biometric.app.ui

import android.content.Intent
import android.os.Bundle
import android.view.HapticFeedbackConstants
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.core.view.isVisible
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.bumptech.glide.Glide
import com.biometric.app.data.entity.Shop
import com.biometric.app.data.entity.UserProfile
import com.biometric.app.databinding.ActivityShopDashboardBinding
import com.biometric.app.domain.BrandingManager
import com.biometric.app.domain.FeatureManager
import com.biometric.app.ui.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@OptIn(ExperimentalCoroutinesApi::class)
@AndroidEntryPoint
class ShopDashboardActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityShopDashboardBinding
    @Inject lateinit var sharedViewModel: SharedViewModel
    @Inject lateinit var featureManager: FeatureManager
    @Inject lateinit var brandingManager: BrandingManager
    
    private var currentShop: Shop? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (isFinishing) return
        
        binding = ActivityShopDashboardBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupCards()
        observeViewModel()

        adjustLayoutForScreenSize()

        // Apply interactive motion to all cards
        setupMotionFeedback(
            binding.cardPOS, binding.cardStaff, binding.cardFinance, 
            binding.cardDetailedReport, binding.cardAuditTrail, binding.cardPrediction,
            binding.cardSalesPattern, binding.cardStaffPerformance, binding.cardSpendAnalysis,
            binding.cardBusinessHealth, binding.cardRiskAlerts, binding.cardDayWiseReport,
            binding.cardRecovery, binding.cardClosedDays, binding.cardFixedExpenses,
            binding.cardInventory, binding.cardStaffPermissions,
        )
    }

    override fun onStart() {
        super.onStart()
        // RE-APPLY permissions if coming back from Settings
        sharedViewModel.userProfile.value?.let { applyRolePermissions(it) }
    }

    private fun adjustLayoutForScreenSize() {
        val displayMetrics = resources.displayMetrics
        val widthDp = displayMetrics.widthPixels / displayMetrics.density
        
        // DYNAMIC SPAN: 
        // Small phones (< 380dp) -> 2 columns
        // Normal phones (380-600dp) -> 3 columns
        // Tablets (> 600dp) -> 4-5 columns
        val spanCount = when {
            widthDp < 380 -> 2
            widthDp < 600 -> 3
            widthDp < 900 -> 4
            else -> 5
        }
        
        // Update all grids safely
        binding.gridSales.columnCount = spanCount
        binding.gridWorkforce.columnCount = spanCount
        binding.gridIntelligence.columnCount = spanCount
        binding.gridAudit.columnCount = spanCount
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        currentShop = shop
                        shop?.let {
                            updateToolbarTitle(it.name)
                        }
                    }
                }
                launch {
                    sharedViewModel.userProfile.collectLatest { profile ->
                        profile?.let {
                            applyRolePermissions(it)
                            
                            // Apply branding
                            supportActionBar?.title = it.brandingName ?: "Shop Dashboard"
                            it.brandingLogoUrl?.let { url ->
                                binding.ivAppLogo.visibility = View.VISIBLE
                                Glide.with(this@ShopDashboardActivity).load(url).into(binding.ivAppLogo)
                            } ?: run {
                                binding.ivAppLogo.visibility = View.GONE
                            }
                        }
                    }
                }
            }
        }
    }

    private fun applyRolePermissions(profile: UserProfile) {
        binding.cardPOS.visibility = View.GONE // Omit Teashop related
        binding.cardStaff.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.STAFF)) View.VISIBLE else View.GONE
        binding.cardFinance.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.FINANCE)) View.VISIBLE else View.GONE
        binding.cardDetailedReport.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.REPORTS)) View.VISIBLE else View.GONE
        binding.cardAuditTrail.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.AUDIT_TRAIL)) View.VISIBLE else View.GONE
        binding.cardPrediction.visibility = View.GONE // Omit Teashop related
        binding.cardSalesPattern.visibility = View.GONE // Omit Teashop related
        binding.cardStaffPerformance.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.STAFF)) View.VISIBLE else View.GONE
        binding.cardSpendAnalysis.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.REPORTS)) View.VISIBLE else View.GONE
        binding.cardBusinessHealth.visibility = View.GONE // Omit Teashop related
        binding.cardRiskAlerts.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.RISK_ALERTS)) View.VISIBLE else View.GONE
        binding.cardDayWiseReport.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.REPORTS)) View.VISIBLE else View.GONE
        binding.cardRecovery.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.INVESTMENTS)) View.VISIBLE else View.GONE
        binding.cardFixedExpenses.visibility = if (featureManager.isFeatureEnabled(FeatureManager.Feature.FIXED_EXPENSES)) View.VISIBLE else View.GONE
        binding.cardInventory.visibility = View.GONE // Omit Teashop related
        
        // Hide Section Titles if empty
        // ... handled by layout if desired, but here we just hide cards
        
        // ADMIN CONTROLS: Toggleable via Settings
        val prefs = getSharedPreferences("app_prefs", MODE_PRIVATE)
        val adminControlsEnabled = prefs.getBoolean("enable_admin_controls", false)
        
        val showAdmin = profile.isOwner() && adminControlsEnabled
        binding.llAdminSection.visibility = if (showAdmin) View.VISIBLE else View.GONE
        
        // Update Grid Visibility if section empty
        binding.gridAudit.isVisible = (binding.cardDetailedReport.isVisible || 
            binding.cardAuditTrail.isVisible || 
            binding.cardFixedExpenses.isVisible ||
            binding.cardDayWiseReport.isVisible || 
            binding.cardSpendAnalysis.isVisible ||
            binding.cardRiskAlerts.isVisible)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Shop Insight")
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) {
            Toast.makeText(this, "Loading shops, please try again in a moment...", Toast.LENGTH_SHORT).show()
            return
        }

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                val selectedShop = shops[which]
                sharedViewModel.setSelectedShop(selectedShop)
                Toast.makeText(this, "Switched to ${selectedShop.name}", Toast.LENGTH_SHORT).show()
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🧠", "AI Assistant") {
                startActivity(Intent(this, AiChatActivity::class.java))
            },
            GlobalSwitcherDelegate.ActionItem("⚙️", "Settings") {
                val intent = Intent(this, SettingsActivity::class.java).apply {
                    currentShop?.let {
                        putExtra("SHOP_ID", it.shopId)
                        putExtra("SHOP_NAME", it.name)
                    }
                }
                startActivity(intent)
            }
        )
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu, extraActions = extraActions, activity = this)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val extraActions = listOf(
            GlobalSwitcherDelegate.ActionItem("🧠", "AI Assistant") {
                startActivity(Intent(this, AiChatActivity::class.java))
            },
            GlobalSwitcherDelegate.ActionItem("⚙️", "Settings") {
                val intent = Intent(this, SettingsActivity::class.java).apply {
                    currentShop?.let {
                        putExtra("SHOP_ID", it.shopId)
                        putExtra("SHOP_NAME", it.name)
                    }
                }
                startActivity(intent)
            }
        )
        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, extraActions)) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupCards() {
        val shopCards = listOf<Pair<View, Class<*>>>(
            binding.cardPOS to POSActivity::class.java,
            binding.cardStaff to StaffActivity::class.java,
            binding.cardFinance to FinanceEntryActivity::class.java,
            binding.cardDetailedReport to DetailedReportActivity::class.java,
            binding.cardAuditTrail to AuditTrailActivity::class.java,
            binding.cardPrediction to FinancialPredictionActivity::class.java,
            binding.cardSalesPattern to SalesPatternActivity::class.java,
            binding.cardStaffPerformance to StaffPerformanceActivity::class.java,
            binding.cardSpendAnalysis to SpendAnalysisActivity::class.java,
            binding.cardBusinessHealth to BusinessHealthActivity::class.java,
            binding.cardRiskAlerts to RiskAlertActivity::class.java,
            binding.cardDayWiseReport to DayWiseReportActivity::class.java,
            binding.cardRecovery to InvestmentRecoveryActivity::class.java,
            binding.cardClosedDays to ShopClosedDaysActivity::class.java,
            binding.cardFixedExpenses to FixedExpensesActivity::class.java,
            binding.cardInventory to InventoryActivity::class.java,
            binding.cardStaffPermissions to StaffPermissionActivity::class.java,
        )

        shopCards.forEach { pair ->
            val card = pair.first
            val activityClass = pair.second
            card.setOnClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                val shop = currentShop
                if (shop != null) {
                    val intent = Intent(this, activityClass).apply {
                        putExtra("SHOP_ID", shop.shopId)
                        putExtra("SHOP_NAME", shop.name)
                        if (activityClass == POSActivity::class.java) {
                            putExtra("TABLE_COUNT", shop.tableCount)
                        }
                    }
                    startActivity(intent)
                } else {
                    Toast.makeText(this, "Please select a shop first", Toast.LENGTH_SHORT).show()
                    showShopSelectionDialog()
                }
            }
        }
    }
}
