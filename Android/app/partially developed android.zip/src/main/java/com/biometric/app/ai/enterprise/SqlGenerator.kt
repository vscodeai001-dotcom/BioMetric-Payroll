package com.biometric.app.ai.enterprise

import com.google.ai.client.generativeai.GenerativeModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class SqlGenerator(private val apiKey: String) {

    private val modelNames = listOf("gemini-1.5-flash", "gemini-1.5-flash-latest", "gemini-pro")

    suspend fun generateSql(query: String, history: String = "", currentShopId: String? = null): String = withContext(Dispatchers.IO) {
        // 1. LOCAL SMART-RULE PARSER (Resilience Layer)
        val localSql = tryLocalParse(query, currentShopId)
        if (localSql != null) return@withContext localSql

        // 2. MULTI-BRAIN AI LAYER
        var lastError = ""
        for (modelName in modelNames) {
            try {
                val model = GenerativeModel(modelName = modelName, apiKey = apiKey)
                val prompt = buildPrompt(query, history)
                val response = model.generateContent(prompt)
                val sql = response.text?.trim() ?: ""
                
                if (sql.isNotBlank() && !sql.contains("ERROR")) {
                    return@withContext cleanSql(sql)
                }
            } catch (e: Exception) {
                lastError = e.message ?: "Unknown"
                android.util.Log.w("SqlGenerator", "Model $modelName failed: $lastError")
                continue // Try next model
            }
        }
        
        "ERROR: All models busy. Using local analysis fallback."
    }

    private fun tryLocalParse(query: String, shopId: String?): String? {
        val q = query.lowercase().trim()
        val shopFilter = if (shopId != null) "AND shopId = '$shopId'" else ""
        
        // 1. TOP SELLING / BEST ITEMS
        if (q.contains("top") || q.contains("best") || q.contains("highest selling")) {
            return "SELECT itemName, SUM(quantity) as Qty FROM order_items WHERE 1=1 GROUP BY itemName ORDER BY Qty DESC LIMIT 10"
        }

        // 2. RECOVERY / INVESTMENT
        if (q.contains("recovery") || q.contains("investment") || q.contains("capital")) {
            return "SELECT itemName, amount, date FROM investments WHERE 1=1 $shopFilter ORDER BY date DESC"
        }

        // 3. DATE SPECIFIC MONTHS (e.g., Jan 2025 sales)
        val monthNames = listOf("jan", "feb", "mar", "apr", "may", "jun", "jul", "aug", "sep", "oct", "nov", "dec")
        val containsMonth = monthNames.any { q.contains(it) }
        
        if (containsMonth) {
            monthNames.forEachIndexed { index, month ->
                if (q.contains(month)) {
                    val year = if (q.contains("2024")) "2024" else if (q.contains("2026")) "2026" else "2025"
                    val monthNum = String.format("%02d", index + 1)
                    
                    return if (q.contains("sale") || q.contains("revenue") || q.contains("income")) {
                        "SELECT SUM(amount) as ${month.uppercase()}_Sales FROM cashbook WHERE transactionType='IN' AND strftime('%Y-%m', transactionDate/1000, 'unixepoch') = '$year-$monthNum' $shopFilter"
                    } else if (q.contains("profit")) {
                        "SELECT (SUM(CASE WHEN transactionType='IN' THEN amount ELSE 0 END) - SUM(CASE WHEN transactionType='OUT' THEN amount ELSE 0 END)) as ${month.uppercase()}_Profit FROM cashbook WHERE strftime('%Y-%m', transactionDate/1000, 'unixepoch') = '$year-$monthNum' $shopFilter"
                    } else {
                        // Just list transactions for that month if general query
                        "SELECT category, amount, transactionDate as date FROM cashbook WHERE strftime('%Y-%m', transactionDate/1000, 'unixepoch') = '$year-$monthNum' $shopFilter"
                    }
                }
            }
        }

        // 4. DAY SPECIFIC (Saturday, Sunday etc) - Use full names to avoid partial matches like "MON" in "Month"
        val fullDays = mapOf("sunday" to "0", "monday" to "1", "tuesday" to "2", "wednesday" to "3", "thursday" to "4", "friday" to "5", "saturday" to "6")
        fullDays.forEach { (name, id) ->
            if (q.contains(name) && q.contains("sale")) {
                return "SELECT transactionDate as date, amount FROM cashbook WHERE transactionType='IN' AND strftime('%w', transactionDate/1000, 'unixepoch') = '$id' $shopFilter"
            }
        }

        // 5. SIMPLE SALES/PROFIT
        return when {
            q.contains("today") && q.contains("sale") -> 
                "SELECT SUM(amount) as Today_Sales FROM cashbook WHERE transactionType='IN' AND transactionDate >= (strftime('%s','now','start of day')*1000) $shopFilter"
            q.contains("yesterday") && q.contains("sale") -> 
                "SELECT SUM(amount) as Yesterday_Sales FROM cashbook WHERE transactionType='IN' AND transactionDate >= (strftime('%s','now','-1 day','start of day')*1000) AND transactionDate < (strftime('%s','now','start of day')*1000) $shopFilter"
            q.contains("profit") -> 
                "SELECT (SUM(CASE WHEN transactionType='IN' THEN amount ELSE 0 END) - SUM(CASE WHEN transactionType='OUT' THEN amount ELSE 0 END)) as Total_Profit FROM cashbook WHERE 1=1 $shopFilter"
            else -> null
        }
    }

    private fun buildPrompt(query: String, history: String): String {
        val now = System.currentTimeMillis()
        val cal = java.util.Calendar.getInstance()
        val todayStr = java.text.SimpleDateFormat("yyyy-MM-dd (EEEE)", java.util.Locale.getDefault()).format(cal.time)
        val monthStr = java.text.SimpleDateFormat("MMMM yyyy", java.util.Locale.getDefault()).format(cal.time)
        
        return """
            You are the Senior Business Intelligence Analyst for Biometric Payroll.
            Your task is to convert the user's business question into a single valid SQLite SELECT query.
            
            ${SchemaManager.schemaPrompt}
            
            BUSINESS CONTEXT:
            - Today's Date: $todayStr
            - Current Month/Year: $monthStr
            - Current Timestamp (ms): $now
            
            CRITICAL RULES:
            1. PROFIT: To calculate profit, use (SUM(CASE WHEN transactionType='IN' THEN amount ELSE 0 END) - SUM(CASE WHEN transactionType='OUT' THEN amount ELSE 0 END)) from the 'cashbook' table.
            2. SALES: Total Sales is usually SUM(amount) from 'cashbook' where transactionType='IN' and category IN ('SALES', 'DAILY SALES (CASH)', 'DAILY SALES (QR)').
            3. ITEM SALES: Use 'order_items' joined with 'orders' for item-specific sales queries (e.g. "how many milk sold").
            4. DATE FILTERING: All dates are stored as INTEGER (milliseconds). Use strftime('%Y-%m-%d', closedAt/1000, 'unixepoch') or similar for comparisons.
            5. SALARY: Salary expenses are in 'cashbook' where category='SALARY' or category='ADVANCE'.
            6. GROUPING: If the user asks for a "list" or "breakdown" by day/month, always include the date/month in the SELECT and GROUP BY.
            7. WEEKDAYS: Sunday is 0, Monday is 1, etc. in strftime('%w', ...).
            8. PRECISION: Return exact values. Do not use LIMIT unless requested.
            
            CONVERSATION HISTORY:
            $history
            
            QUESTION: "$query"
            
            Return ONLY the raw SQL query. No markdown, no explanation.
        """.trimIndent()
    }

    private fun cleanSql(sql: String): String {
        return sql.replace("```sql", "").replace("```", "").trim()
    }
}
