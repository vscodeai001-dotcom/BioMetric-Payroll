package com.biometric.app.ui.viewmodel

import android.app.Application
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.biometric.app.data.FinancialCategory
import com.biometric.app.data.MainRepository
import com.biometric.app.data.entity.Attendance
import com.biometric.app.data.entity.Employee
import com.biometric.app.util.DateRangeUtil
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.*
import javax.inject.Inject

data class StaffPerformanceMetrics(
    val employee: Employee,
    val workedHours: Double,
    val presentDays: Int,
    val absentDays: Int,
    val totalEarnings: Double, // Gross (Net Salary + Allowance)
    val baseSalaryRate: Double,
    val baseSalaryEarned: Double,
    val lateAmt: Double,
    val earlyAmt: Double,
    val gapAmt: Double,
    val leaveAmt: Double,
    val allowance: Double,
    val bonus: Double,
    val otAmt: Double,
    val paidLeaveAmt: Double,
    val advanceAmt: Double,
    val totalCredit: Double,
    val totalDebit: Double,
    val salaryDue: Double,
    val productivityIndicator: String // Low, Medium, High, Very High
)

@HiltViewModel
class StaffPerformanceViewModel @Inject constructor(
    application: Application,
    private val repository: MainRepository
) : AndroidViewModel(application) {

    private val _state = MutableStateFlow(StaffPerformanceState())
    val state: StateFlow<StaffPerformanceState> = _state.asStateFlow()

    fun loadPerformance(shopId: String, period: String, date: Long) {
        viewModelScope.launch(Dispatchers.Default) {
            val (start, end) = getTimestampsForPeriod(period, date)
            val cacheKey = "staff_performance_${shopId}_${period}_${start}_${end}"
            
            // OPTIMISTIC UI: Try to load from cache first
            val cached = repository.getListCache<StaffPerformanceState>(cacheKey).firstOrNull()
            
            // UNIFORM LOADING: Only set loading true if no cache available
            if (cached != null) {
                _state.value = cached.copy(isLoading = false)
            } else {
                _state.update { it.copy(isLoading = true) }
            }

            repository.logAction(shopId, "VIEW", "Salary", "Staff Performance", period)
            
            // Collect fresh data from repository
            combine(
                repository.getShopEmployees(shopId),
                repository.getCashbookEntriesForPeriod(shopId, start, end)
            ) { allEmployees, cashbookEntries ->

                // 1. Calculate metrics for registered employees
                val employeeMetrics = allEmployees.filter { emp ->
                    val hireTs = emp.hireDate
                    val termTs = emp.terminateDate ?: Long.MAX_VALUE
                    (hireTs <= end) && (termTs >= start)
                }.map { employee ->
                    calculateAggregatedMetrics(employee, start, end)
                }

                // 2. Process manual salary entries from Cashbook
                val manualSalaryEntries = cashbookEntries.filter {
                    it.transactionType == "OUT" && 
                    FinancialCategory.isSalary(it.category, it.description) &&
                    it.referenceId == null
                }

                val finalMetricsList = mutableListOf<StaffPerformanceMetrics>()
                finalMetricsList.addAll(employeeMetrics)

                manualSalaryEntries.forEach { entry ->
                    val desc = entry.description ?: ""
                    val cleanName = desc.replace("Salary:", "", ignoreCase = true).trim()
                    
                    val existing = finalMetricsList.find { it.employee.name.equals(cleanName, ignoreCase = true) }
                    if (existing != null) {
                        val idx = finalMetricsList.indexOf(existing)
                        finalMetricsList[idx] = existing.copy(
                            totalEarnings = existing.totalEarnings + entry.amount,
                            baseSalaryEarned = existing.baseSalaryEarned + entry.amount,
                            salaryDue = existing.salaryDue + entry.amount
                        )
                    } else {
                        finalMetricsList.add(
                            StaffPerformanceMetrics(
                                employee = Employee(name = if (cleanName.isEmpty()) "Manual Entry" else cleanName, shopId = shopId),
                                workedHours = 0.0,
                                presentDays = 0,
                                absentDays = 0,
                                totalEarnings = entry.amount,
                                baseSalaryRate = entry.amount,
                                baseSalaryEarned = entry.amount,
                                lateAmt = 0.0,
                                earlyAmt = 0.0,
                                gapAmt = 0.0,
                                leaveAmt = 0.0,
                                allowance = 0.0,
                                bonus = 0.0,
                                otAmt = 0.0,
                                paidLeaveAmt = 0.0,
                                advanceAmt = 0.0,
                                totalCredit = 0.0,
                                totalDebit = 0.0,
                                salaryDue = entry.amount,
                                productivityIndicator = "N/A"
                            )
                        )
                    }
                }

                val sdf = SimpleDateFormat("dd MMM yyyy", Locale.getDefault())
                val periodLabel = if (start == end) sdf.format(Date(start)) else "${sdf.format(Date(start))} – ${sdf.format(Date(end))}"

                val sortedByProductivity = finalMetricsList.sortedByDescending { it.totalEarnings }
                val topStaff = sortedByProductivity.firstOrNull()
                val insights = generateDetailedInsights(finalMetricsList, topStaff)

                val result = StaffPerformanceState(
                    metrics = sortedByProductivity,
                    topStaff = topStaff,
                    insights = insights,
                    periodLabel = periodLabel,
                    isLoading = false
                )
                
                repository.saveListCache(cacheKey, listOf(result))
                result
            }.collect { newState ->
                _state.value = newState
            }
        }
    }

    private suspend fun calculateAggregatedMetrics(employee: Employee, start: Long, end: Long): StaffPerformanceMetrics {
        // Determine all unique months touched by the range [start, end]
        val touchedMonths = mutableListOf<Pair<Long, Long>>()
        val calMonth = Calendar.getInstance().apply { timeInMillis = start }
        while (calMonth.timeInMillis <= end) {
            val mStart = (calMonth.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, 1)
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }.timeInMillis
            val mEnd = (calMonth.clone() as Calendar).apply {
                set(Calendar.DAY_OF_MONTH, getActualMaximum(Calendar.DAY_OF_MONTH))
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            }.timeInMillis
            touchedMonths.add(mStart to mEnd)
            
            // Move to next month
            calMonth.timeInMillis = mEnd
            calMonth.add(Calendar.MILLISECOND, 1)
        }

        var totalWorkedHours = 0.0
        var totalPresentDays = 0
        var totalEarnings = 0.0
        var totalBaseSalaryRate = 0.0
        var totalBaseSalaryEarned = 0.0
        var totalLateAmt = 0.0
        var totalEarlyAmt = 0.0
        var totalGapAmt = 0.0
        var totalLeaveAmt = 0.0
        var totalAllowance = 0.0
        var totalBonus = 0.0
        var totalPaidLeaveAmt = 0.0
        var totalOT = 0.0
        
        var totalNetShiftHours = 0.0
        var activeMonthsCount = 0

        touchedMonths.forEach { (monthStart, monthEnd) ->
            val intersectStart = maxOf(start, monthStart)
            val intersectEnd = minOf(end, monthEnd)

            val stats = repository.getEmployeeStatsFlow(
                employee = employee, 
                start = monthStart, 
                end = monthEnd, 
                selDayStart = intersectStart, 
                selDayEnd = intersectEnd
            ).first()

            // UNIFIED: Use getRangeTotalEarnings to match other screens
            totalEarnings += stats.getRangeTotalEarnings(intersectStart, intersectEnd)
            
            // Worked Hours for this month's intersection
            totalWorkedHours += stats.dayWiseWorkedHours.entries
                .filter { it.key in intersectStart..intersectEnd }
                .sumOf { it.value }

            // Present Days for this month's intersection
            totalPresentDays += stats.dayWiseWorkedHours.keys.count { it in intersectStart..intersectEnd }

            // Individual components
            totalBaseSalaryRate = stats.fullMonthSalary 
            totalBaseSalaryEarned += stats.dayWiseEarnings.entries.filter { it.key in intersectStart..intersectEnd }.sumOf { it.value.toDouble() }
            totalAllowance += stats.dayWiseAllowances.entries.filter { it.key in intersectStart..intersectEnd }.sumOf { it.value.toDouble() }
            totalBonus += stats.dayWiseBonus.entries.filter { it.key in intersectStart..intersectEnd }.sumOf { it.value.toDouble() }
            totalPaidLeaveAmt += stats.dayWisePaidLeave.entries.filter { it.key in intersectStart..intersectEnd }.sumOf { it.value.toDouble() }
            totalOT += stats.dayWiseOTEarnings.entries.filter { it.key in intersectStart..intersectEnd }.sumOf { it.value.toDouble() }

            // Deductions (Gross amounts to match Staff Insights detail cards)
            totalLateAmt += stats.totalLateAmount.toDouble()
            totalEarlyAmt += stats.totalEarlyAmount.toDouble()
            totalGapAmt += stats.totalGapAmount.toDouble()
            totalLeaveAmt += stats.totalLeaveAmount.toDouble()
            
            if (stats.netShiftHours > 0) {
                totalNetShiftHours += stats.netShiftHours
                activeMonthsCount++
            }
        }

        // Fetch Advances for the whole period
        val advances = repository.getAdvanceRecords(employee.employeeId, start, end).first()
        val totalAdvanceAmt = advances.sumOf { it.amount }

        val totalCredit = totalOT + totalAllowance + totalBonus + totalPaidLeaveAmt
        val totalDebit = totalLateAmt + totalEarlyAmt + totalGapAmt + totalLeaveAmt
        val salaryDue = totalEarnings - totalAllowance - totalAdvanceAmt

        val daysInPeriod = ((end - start) / 86400000L).toInt() + 1
        val totalAbsent = maxOf(0, daysInPeriod - totalPresentDays)
        val avgNetShiftHours = if (activeMonthsCount > 0) totalNetShiftHours / activeMonthsCount else 0.0

        val productivityIndicator = when {
            avgNetShiftHours <= 0 -> "Medium"
            totalWorkedHours >= (avgNetShiftHours * totalPresentDays) * 0.9 -> "Very High"
            totalWorkedHours >= (avgNetShiftHours * totalPresentDays) * 0.7 -> "High"
            else -> "Low"
        }

        return StaffPerformanceMetrics(
            employee = employee,
            workedHours = totalWorkedHours,
            presentDays = totalPresentDays,
            absentDays = totalAbsent,
            totalEarnings = totalEarnings,
            baseSalaryRate = totalBaseSalaryRate,
            baseSalaryEarned = totalBaseSalaryEarned,
            lateAmt = totalLateAmt,
            earlyAmt = totalEarlyAmt,
            gapAmt = totalGapAmt,
            leaveAmt = totalLeaveAmt,
            allowance = totalAllowance,
            bonus = totalBonus,
            otAmt = totalOT,
            paidLeaveAmt = totalPaidLeaveAmt,
            advanceAmt = totalAdvanceAmt,
            totalCredit = totalCredit,
            totalDebit = totalDebit,
            salaryDue = salaryDue,
            productivityIndicator = productivityIndicator
        )
    }

    private fun generateDetailedInsights(metrics: List<StaffPerformanceMetrics>, top: StaffPerformanceMetrics?): List<String> {
        val insights = mutableListOf<String>()
        top?.let {
            insights.add("🏆 \"${it.employee.name} is the top performer with ${String.format("%.1f", it.workedHours)} working hours and ₹${String.format("%.0f", it.totalEarnings)} earned.\"")
        }
        
        val perfectAttendance = metrics.filter { it.absentDays == 0 && it.presentDays > 0 }
        if (perfectAttendance.isNotEmpty()) {
            insights.add("⭐ \"${perfectAttendance.joinToString { it.employee.name }} maintained 100% attendance during this period.\"")
        }

        val highAllowance = metrics.sortedByDescending { it.allowance }.firstOrNull()
        if (highAllowance != null && highAllowance.allowance > 0) {
            insights.add("💡 \"${highAllowance.employee.name} earned the highest allowance (₹${String.format("%.0f", highAllowance.allowance)}).\"")
        }

        if (insights.isEmpty()) insights.add("📊 Team performance metrics are consistent with current projections.")
        
        return insights
    }

    private fun getTimestampsForPeriod(period: String, date: Long): Pair<Long, Long> {
        return DateRangeUtil.getRangeForPeriod(period, date)
    }
}

data class StaffPerformanceState(
    val metrics: List<StaffPerformanceMetrics> = emptyList(),
    val topStaff: StaffPerformanceMetrics? = null,
    val insights: List<String> = emptyList(),
    val periodLabel: String = "",
    val isLoading: Boolean = true
)
