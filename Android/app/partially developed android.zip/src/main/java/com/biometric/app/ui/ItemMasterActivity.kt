package com.biometric.app.ui

import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.widget.SearchView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.GridLayoutManager
import com.biometric.app.databinding.ActivityItemMasterBinding
import com.biometric.app.ui.adapter.ItemMasterAdapter
import com.biometric.app.ui.viewmodel.ItemMasterViewModel
import com.biometric.app.ui.viewmodel.MainViewModel
import com.biometric.app.ui.viewmodel.SharedViewModel
import dagger.hilt.android.AndroidEntryPoint
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch
import javax.inject.Inject

@AndroidEntryPoint
class ItemMasterActivity : MotionBaseActivity() {

    private lateinit var binding: ActivityItemMasterBinding
    private val viewModel: ItemMasterViewModel by viewModels()
    private val mainViewModel: MainViewModel by viewModels()
    @Inject lateinit var sharedViewModel: SharedViewModel
    private lateinit var adapter: ItemMasterAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityItemMasterBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupToolbar()
        setupUI()
        observeViewModel()
    }

    private fun setupToolbar() {
        setSupportActionBar(binding.toolbar)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        binding.toolbar.setNavigationOnClickListener { finish() }
        
        binding.toolbar.setOnClickListener {
            showShopSelectionDialog()
        }
        
        val shopName = sharedViewModel.selectedShop.value?.name ?: "Shop"
        updateToolbarTitle(shopName)
    }

    private fun updateToolbarTitle(shopName: String) {
        setupDualHeader(binding.toolbar, shopName, "Item Master")
    }

    private fun showShopSelectionDialog() {
        val shops = sharedViewModel.allShops.value
        if (shops.isEmpty()) return

        val shopNames = shops.map { it.name }.toTypedArray()
        MaterialAlertDialogBuilder(this)
            .setTitle("Switch Shop")
            .setItems(shopNames) { _, which ->
                sharedViewModel.setSelectedShop(shops[which])
            }
            .show()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        GlobalSwitcherDelegate.inflateMenu(menuInflater, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val addItemAction = GlobalSwitcherDelegate.ActionItem(
            emoji = "🍰",
            label = "Add New Item",
            onClick = {
                AddItemDialogFragment.newInstance().show(supportFragmentManager, AddItemDialogFragment.TAG)
            }
        )

        if (GlobalSwitcherDelegate.handleOptionsItemSelected(this, item, sharedViewModel, listOf(addItemAction))) {
            return true
        }
        return super.onOptionsItemSelected(item)
    }

    private fun setupUI() {
        adapter = ItemMasterAdapter(
            onSetPriceClick = { item ->
                val shopId = sharedViewModel.selectedShop.value?.shopId
                if (shopId != null) {
                    SetPriceDialogFragment.newInstance(item.itemId, item.name, shopId)
                        .show(supportFragmentManager, SetPriceDialogFragment.TAG)
                } else {
                    Toast.makeText(this, "Shop context missing. Please open from Dashboard.", Toast.LENGTH_SHORT).show()
                }
            },
            onEditClick = { item ->
                AddItemDialogFragment.newInstance(item.itemId).show(supportFragmentManager, AddItemDialogFragment.TAG)
            },
            onDeleteClick = { item ->
                MaterialAlertDialogBuilder(this)
                    .setTitle("Delete Item")
                    .setMessage("Are you sure you want to delete '${item.name}'?")
                    .setPositiveButton("Delete") { _, _ -> viewModel.deleteItem(item) }
                    .setNegativeButton("Cancel", null)
                    .show()
            }
        )
        
        binding.rvItems.layoutManager = GridLayoutManager(this, 2)
        binding.rvItems.adapter = adapter

        binding.searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean = false
            override fun onQueryTextChange(newText: String?): Boolean {
                adapter.filter(newText.orEmpty())
                return true
            }
        })
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    sharedViewModel.selectedShop.collectLatest { shop ->
                        shop?.let {
                            updateToolbarTitle(it.name)
                            viewModel.setShopId(it.shopId)
                        }
                    }
                }
                launch {
                    viewModel.allItemsWithPrices.collect { items ->
                        adapter.updateData(items)
                    }
                }
            }
        }
    }
}