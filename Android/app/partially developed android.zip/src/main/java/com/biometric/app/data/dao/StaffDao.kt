package com.biometric.app.data.dao

// Removed Room dependency
