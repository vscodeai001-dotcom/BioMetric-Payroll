package com.biometric.app.data.entity

import androidx.annotation.Keep
import com.google.firebase.database.PropertyName
import java.io.Serializable

@Keep
data class MonthlySnapshot(
    @get:PropertyName("snapshotId") @set:PropertyName("snapshotId")
    var snapshotId: String = "", // Format: shopId_yyyyMM
    
    @get:PropertyName("shopId") @set:PropertyName("shopId")
    var shopId: String = "",
    
    @get:PropertyName("monthKey") @set:PropertyName("monthKey")
    var monthKey: String = "", // yyyyMM
    
    @get:PropertyName("totalSales") @set:PropertyName("totalSales")
    var totalSales: Double = 0.0,
    
    @get:PropertyName("totalSalary") @set:PropertyName("totalSalary")
    var totalSalary: Double = 0.0,
    
    @get:PropertyName("totalExpense") @set:PropertyName("totalExpense")
    var totalExpense: Double = 0.0,
    
    @get:PropertyName("fixedExpenses") @set:PropertyName("fixedExpenses")
    var fixedExpenses: Double = 0.0,
    
    @get:PropertyName("netProfit") @set:PropertyName("netProfit")
    var netProfit: Double = 0.0,
    
    @get:PropertyName("isFinalized") @set:PropertyName("isFinalized")
    var isFinalized: Boolean = false,
    
    @get:PropertyName("lastUpdated") @set:PropertyName("lastModified")
    var lastUpdated: Long = System.currentTimeMillis()
) : Serializable
